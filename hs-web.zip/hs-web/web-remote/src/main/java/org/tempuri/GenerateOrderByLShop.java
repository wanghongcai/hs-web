
package org.tempuri;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ShipmentNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strShipmentInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strAccessUser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strAccessPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "shipmentNo",
    "strShipmentInfo",
    "strAccessUser",
    "strAccessPassword"
})
@XmlRootElement(name = "GenerateOrderByLShop")
public class GenerateOrderByLShop {

    @XmlElement(name = "ShipmentNo")
    protected String shipmentNo;
    protected String strShipmentInfo;
    protected String strAccessUser;
    protected String strAccessPassword;

    /**
     * Gets the value of the shipmentNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentNo() {
        return shipmentNo;
    }

    /**
     * Sets the value of the shipmentNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentNo(String value) {
        this.shipmentNo = value;
    }

    /**
     * Gets the value of the strShipmentInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrShipmentInfo() {
        return strShipmentInfo;
    }

    /**
     * Sets the value of the strShipmentInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrShipmentInfo(String value) {
        this.strShipmentInfo = value;
    }

    /**
     * Gets the value of the strAccessUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessUser() {
        return strAccessUser;
    }

    /**
     * Sets the value of the strAccessUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessUser(String value) {
        this.strAccessUser = value;
    }

    /**
     * Gets the value of the strAccessPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessPassword() {
        return strAccessPassword;
    }

    /**
     * Sets the value of the strAccessPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessPassword(String value) {
        this.strAccessPassword = value;
    }

}
