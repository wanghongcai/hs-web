
package org.tempuri;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OrderType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BTCPSO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderParamXML" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strAccessUser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strAccessPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "orderType",
    "btcpso",
    "orderParamXML",
    "strAccessUser",
    "strAccessPassword"
})
@XmlRootElement(name = "AddREAndZREOrderByLShop")
public class AddREAndZREOrderByLShop {

    @XmlElement(name = "OrderType")
    protected String orderType;
    @XmlElement(name = "BTCPSO")
    protected String btcpso;
    @XmlElement(name = "OrderParamXML")
    protected String orderParamXML;
    protected String strAccessUser;
    protected String strAccessPassword;

    /**
     * Gets the value of the orderType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderType() {
        return orderType;
    }

    /**
     * Sets the value of the orderType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderType(String value) {
        this.orderType = value;
    }

    /**
     * Gets the value of the btcpso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBTCPSO() {
        return btcpso;
    }

    /**
     * Sets the value of the btcpso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBTCPSO(String value) {
        this.btcpso = value;
    }

    /**
     * Gets the value of the orderParamXML property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderParamXML() {
        return orderParamXML;
    }

    /**
     * Sets the value of the orderParamXML property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderParamXML(String value) {
        this.orderParamXML = value;
    }

    /**
     * Gets the value of the strAccessUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessUser() {
        return strAccessUser;
    }

    /**
     * Sets the value of the strAccessUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessUser(String value) {
        this.strAccessUser = value;
    }

    /**
     * Gets the value of the strAccessPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessPassword() {
        return strAccessPassword;
    }

    /**
     * Sets the value of the strAccessPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessPassword(String value) {
        this.strAccessPassword = value;
    }

}
