
package org.tempuri;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="listProductInfo" type="{http://tempuri.org/}ArrayOfProductInfo" minOccurs="0"/>
 *         &lt;element name="strAccessUser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strAccessPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listProductInfo",
    "strAccessUser",
    "strAccessPassword"
})
@XmlRootElement(name = "CheckMultiMachineSVCProdPurchase")
public class CheckMultiMachineSVCProdPurchase {

    protected ArrayOfProductInfo listProductInfo;
    protected String strAccessUser;
    protected String strAccessPassword;

    /**
     * Gets the value of the listProductInfo property.
     * 
     * @return
     *     possible object is
     *     {@link org.tempuri.ArrayOfProductInfo }
     *     
     */
    public ArrayOfProductInfo getListProductInfo() {
        return listProductInfo;
    }

    /**
     * Sets the value of the listProductInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link org.tempuri.ArrayOfProductInfo }
     *     
     */
    public void setListProductInfo(ArrayOfProductInfo value) {
        this.listProductInfo = value;
    }

    /**
     * Gets the value of the strAccessUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessUser() {
        return strAccessUser;
    }

    /**
     * Sets the value of the strAccessUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessUser(String value) {
        this.strAccessUser = value;
    }

    /**
     * Gets the value of the strAccessPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrAccessPassword() {
        return strAccessPassword;
    }

    /**
     * Sets the value of the strAccessPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrAccessPassword(String value) {
        this.strAccessPassword = value;
    }

}
