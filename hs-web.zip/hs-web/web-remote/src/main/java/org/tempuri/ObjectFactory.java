
package org.tempuri;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.tempuri package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.tempuri
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link org.tempuri.SVCProdAdviseByLShopResponse }
     * 
     */
    public SVCProdAdviseByLShopResponse createSVCProdAdviseByLShopResponse() {
        return new SVCProdAdviseByLShopResponse();
    }

    /**
     * Create an instance of {@link org.tempuri.ProductAdivices }
     * 
     */
    public ProductAdivices createProductAdivices() {
        return new ProductAdivices();
    }

    /**
     * Create an instance of {@link GETActiveCodeByMaterialNoLShopResponse }
     * 
     */
    public GETActiveCodeByMaterialNoLShopResponse createGETActiveCodeByMaterialNoLShopResponse() {
        return new GETActiveCodeByMaterialNoLShopResponse();
    }

    /**
     * Create an instance of {@link org.tempuri.AddREAndZREOrderByLShop }
     * 
     */
    public AddREAndZREOrderByLShop createAddREAndZREOrderByLShop() {
        return new AddREAndZREOrderByLShop();
    }

    /**
     * Create an instance of {@link org.tempuri.RegisterSVCProductByLShopResponse }
     * 
     */
    public RegisterSVCProductByLShopResponse createRegisterSVCProductByLShopResponse() {
        return new RegisterSVCProductByLShopResponse();
    }

    /**
     * Create an instance of {@link org.tempuri.SVCProdAdviseByLShop }
     * 
     */
    public SVCProdAdviseByLShop createSVCProdAdviseByLShop() {
        return new SVCProdAdviseByLShop();
    }

    /**
     * Create an instance of {@link org.tempuri.ArrayOfProductCarts }
     * 
     */
    public ArrayOfProductCarts createArrayOfProductCarts() {
        return new ArrayOfProductCarts();
    }

    /**
     * Create an instance of {@link CheckMultiMachineSVCProdPurchaseResponse }
     * 
     */
    public CheckMultiMachineSVCProdPurchaseResponse createCheckMultiMachineSVCProdPurchaseResponse() {
        return new CheckMultiMachineSVCProdPurchaseResponse();
    }

    /**
     * Create an instance of {@link ArrayOfReturnProductInfo }
     * 
     */
    public ArrayOfReturnProductInfo createArrayOfReturnProductInfo() {
        return new ArrayOfReturnProductInfo();
    }

    /**
     * Create an instance of {@link GETActiveCodeByMaterialNoLShop }
     * 
     */
    public GETActiveCodeByMaterialNoLShop createGETActiveCodeByMaterialNoLShop() {
        return new GETActiveCodeByMaterialNoLShop();
    }

    /**
     * Create an instance of {@link CheckMultiMachineSVCProdPurchase }
     * 
     */
    public CheckMultiMachineSVCProdPurchase createCheckMultiMachineSVCProdPurchase() {
        return new CheckMultiMachineSVCProdPurchase();
    }

    /**
     * Create an instance of {@link ArrayOfProductInfo }
     * 
     */
    public ArrayOfProductInfo createArrayOfProductInfo() {
        return new ArrayOfProductInfo();
    }

    /**
     * Create an instance of {@link org.tempuri.RegisterSVCProductByLShop }
     * 
     */
    public RegisterSVCProductByLShop createRegisterSVCProductByLShop() {
        return new RegisterSVCProductByLShop();
    }

    /**
     * Create an instance of {@link org.tempuri.AddREAndZREOrderByLShopResponse }
     * 
     */
    public AddREAndZREOrderByLShopResponse createAddREAndZREOrderByLShopResponse() {
        return new AddREAndZREOrderByLShopResponse();
    }

    /**
     * Create an instance of {@link GenerateOrderByLShopResponse }
     * 
     */
    public GenerateOrderByLShopResponse createGenerateOrderByLShopResponse() {
        return new GenerateOrderByLShopResponse();
    }

    /**
     * Create an instance of {@link GenerateOrderByLShop }
     * 
     */
    public GenerateOrderByLShop createGenerateOrderByLShop() {
        return new GenerateOrderByLShop();
    }

    /**
     * Create an instance of {@link ProductCarts }
     * 
     */
    public ProductCarts createProductCarts() {
        return new ProductCarts();
    }

    /**
     * Create an instance of {@link org.tempuri.ReturnProductInfo }
     * 
     */
    public ReturnProductInfo createReturnProductInfo() {
        return new ReturnProductInfo();
    }

    /**
     * Create an instance of {@link org.tempuri.ProdMaterialGroup }
     * 
     */
    public ProdMaterialGroup createProdMaterialGroup() {
        return new ProdMaterialGroup();
    }

    /**
     * Create an instance of {@link ArrayOfString }
     * 
     */
    public ArrayOfString createArrayOfString() {
        return new ArrayOfString();
    }

    /**
     * Create an instance of {@link ProductInfo }
     * 
     */
    public ProductInfo createProductInfo() {
        return new ProductInfo();
    }

    /**
     * Create an instance of {@link org.tempuri.ArrayOfProdMaterialGroup }
     * 
     */
    public ArrayOfProdMaterialGroup createArrayOfProdMaterialGroup() {
        return new ArrayOfProdMaterialGroup();
    }

}
