
package org.tempuri;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ProductAdivices complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductAdivices">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="padName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="manufactureDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="listExtended" type="{http://tempuri.org/}ArrayOfProdMaterialGroup" minOccurs="0"/>
 *         &lt;element name="listSite" type="{http://tempuri.org/}ArrayOfProdMaterialGroup" minOccurs="0"/>
 *         &lt;element name="listSolution" type="{http://tempuri.org/}ArrayOfProdMaterialGroup" minOccurs="0"/>
 *         &lt;element name="listPromotion" type="{http://tempuri.org/}ArrayOfProdMaterialGroup" minOccurs="0"/>
 *         &lt;element name="errorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductAdivices", propOrder = {
    "padName",
    "endDate",
    "manufactureDate",
    "listExtended",
    "listSite",
    "listSolution",
    "listPromotion",
    "errorMsg"
})
public class ProductAdivices {

    protected String padName;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar endDate;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar manufactureDate;
    protected ArrayOfProdMaterialGroup listExtended;
    protected ArrayOfProdMaterialGroup listSite;
    protected ArrayOfProdMaterialGroup listSolution;
    protected ArrayOfProdMaterialGroup listPromotion;
    protected String errorMsg;

    /**
     * Gets the value of the padName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPadName() {
        return padName;
    }

    /**
     * Sets the value of the padName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPadName(String value) {
        this.padName = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the manufactureDate property.
     * 
     * @return
     *     possible object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getManufactureDate() {
        return manufactureDate;
    }

    /**
     * Sets the value of the manufactureDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link javax.xml.datatype.XMLGregorianCalendar }
     *     
     */
    public void setManufactureDate(XMLGregorianCalendar value) {
        this.manufactureDate = value;
    }

    /**
     * Gets the value of the listExtended property.
     * 
     * @return
     *     possible object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public ArrayOfProdMaterialGroup getListExtended() {
        return listExtended;
    }

    /**
     * Sets the value of the listExtended property.
     * 
     * @param value
     *     allowed object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public void setListExtended(ArrayOfProdMaterialGroup value) {
        this.listExtended = value;
    }

    /**
     * Gets the value of the listSite property.
     * 
     * @return
     *     possible object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public ArrayOfProdMaterialGroup getListSite() {
        return listSite;
    }

    /**
     * Sets the value of the listSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public void setListSite(ArrayOfProdMaterialGroup value) {
        this.listSite = value;
    }

    /**
     * Gets the value of the listSolution property.
     * 
     * @return
     *     possible object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public ArrayOfProdMaterialGroup getListSolution() {
        return listSolution;
    }

    /**
     * Sets the value of the listSolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public void setListSolution(ArrayOfProdMaterialGroup value) {
        this.listSolution = value;
    }

    /**
     * Gets the value of the listPromotion property.
     * 
     * @return
     *     possible object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public ArrayOfProdMaterialGroup getListPromotion() {
        return listPromotion;
    }

    /**
     * Sets the value of the listPromotion property.
     * 
     * @param value
     *     allowed object is
     *     {@link org.tempuri.ArrayOfProdMaterialGroup }
     *     
     */
    public void setListPromotion(ArrayOfProdMaterialGroup value) {
        this.listPromotion = value;
    }

    /**
     * Gets the value of the errorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * Sets the value of the errorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMsg(String value) {
        this.errorMsg = value;
    }

}
