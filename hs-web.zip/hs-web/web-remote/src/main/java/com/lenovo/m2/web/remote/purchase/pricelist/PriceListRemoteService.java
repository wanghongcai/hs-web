package com.lenovo.m2.web.remote.purchase.pricelist;

import java.util.List;
import java.util.Map;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.api.param.pricelist.ManualOrderParam;
import com.lenovo.m2.hsbuy.api.param.pricelist.PriceListParam;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceList;

/**
 * Created by syj on 2016/7/21.
 */
public interface PriceListRemoteService {

	/**
	 * 报价单列表
	 * @param pageQuery
	 * @param priceList
	 * @return
	 */
    public RemoteResult<PageModel2<PriceList>> getPriceListPage(Tenant tenant, PageQuery pageQuery, PriceListParam priceList);

    /**
     * 报价单详情
     * @param priceList
     * @return
     */
    public RemoteResult<PriceList> getPriceListDetail(Tenant tenant ,PriceListParam priceList);

    /**
     * 保存报价单
     * @param priceList
     * @return
     */
    public RemoteResult<String> insertPriceList(Tenant tenant,PriceListParam priceList);


    /**
     * 手动订单抛送
     * @param manualOrderVo
     * @return
     */
	public RemoteResult<Map> genMaualOrder(Tenant tenant,ManualOrderParam manualOrderVo);

	/**
	 * 报价单提交订单
	 * @param pl
	 * @return
	 */
    public RemoteResult<Boolean> submitPriceList(Tenant tenant,PriceListParam pl);
    
    /**
     * 拉取商城提交订单的报价单（smb同步状态用）
     * @return
     */
    RemoteResult<String> pullOrderedDealNo();

    
    /**
     * 更新为已下单
     * @param manualOrderVo
     * @return
     */
    public RemoteResult<Integer> updateToOrdered(String itCode, String dealNo);
    
    
    /**
     * 查询报价单信息
     * @param 
     * itCode和userId必须有一个
     * @return
     */
    public RemoteResult<String> queryPdfUrl(String itCode, String userId, String dealNo, List<String> showParams);
    
}
