package com.lenovo.m2.web.remote.purchase.invoice.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.integral.CouponAndIntegralInfo;
import com.lenovo.m2.hsbuy.domain.invoice.param.AddVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoListParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.result.GetVatInvoiceInfoResult;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceIdAndUuid;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;
import com.lenovo.m2.hsbuy.integral.CouponAndIntegralInfoService;
import com.lenovo.m2.hsbuy.integral.ExchangeCouponRecordService;
import com.lenovo.m2.hsbuy.invoice.InvoiceApiService;
import com.lenovo.m2.hsbuy.smb17.InvoiceShopApiService;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.remote.purchase.BaseCommonUtil;
import com.lenovo.m2.web.remote.purchase.invoice.InvoiceRemoteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by bob on 2015/11/19.
 */
@Service
public class InvoiceRemoteServiceImpl extends BaseCommonUtil implements InvoiceRemoteService {

    private static Logger logger = LogManager.getLogger(InvoiceRemoteServiceImpl.class.getName());

    @Autowired
    private InvoiceApiService invoiceApiService;

    @Autowired
    private InvoiceShopApiService invoiceShopApiService;

    @Autowired
    private CouponAndIntegralInfoService couponAndIntegralInfoService;

    @Autowired
    private ExchangeCouponRecordService exchangeCouponRecordService;


    @Override
    public RemoteResult<CouponAndIntegralInfo> getCouponInfo(String couponId) {
        try{
            RemoteResult<CouponAndIntegralInfo> result = couponAndIntegralInfoService.getCouponInfo(couponId);
            logger.info("getCouponInfo result={}", JsonUtil.toJson(result));
            return result;  
        }   catch(Exception e ) {
            logger.error("getCouponInfo 异常",e);
            return null;
        }
    }

    @Override
    public RemoteResult<List<CouponAndIntegralInfo>> getAllCouponInfo() {
        try{
            RemoteResult<List<CouponAndIntegralInfo>> result = couponAndIntegralInfoService.getAllCouponInfo();
            logger.info("getAllCouponInfo result={}", JsonUtil.toJson(result));
            return result;
        }catch(Exception e){
            logger.error("getAllCouponInfo 异常",e);
            return null;
        }

    }

    @Override
    public RemoteResult exchangeCoupon(String shopId, String couponId, String agentId, String agentCode,String buyerId) {
        try{
            RemoteResult result = exchangeCouponRecordService.exchangeCoupon(shopId,couponId,agentId,agentCode,buyerId);
            logger.info("exchangeCoupon result={}", JsonUtil.toJson(result));
            return result;
        }catch(Exception e){
            logger.error("exchangeCoupon 异常",e);
            return null;
        }
    }

    @Override
    public String addVatInvoiceInfoParam(Tenant tenant, AddVatInvoiceInfoParam addVatInvoiceInfoParam) {
        logger.info("addVatInvoiceInfoParam accepts vatInvoiceInfoParam information :{}", JsonUtil.toJson(addVatInvoiceInfoParam));
        try {
            RemoteResult<String> re = invoiceApiService.addVatInvoiceInfo(addVatInvoiceInfoParam,tenant);
            logger.info("addVatInvoiceInfoParam return :" + JsonUtil.toJson(re));
            return JsonUtil.toJson(new FpsResult(re));
        } catch (Exception e) {
            logger.error("addVatInvoiceInfoParam  error:", e);
            return toJson(new FpsResult<String>(ErrorMessageEnum.ERROR_SYSTEM_BUSY));
        }
    }

    @Override
    public String getVatInvoiceInfo(Tenant tenant, GetVatInvoiceInfoParam getVatInvoiceInfoParam) {
        logger.info("getVatInvoiceInfo accepts vatInvoiceInfoParam information :{}", JsonUtil.toJson(getVatInvoiceInfoParam));
        try {
            RemoteResult<GetVatInvoiceInfoResult> re = invoiceApiService.getVatInvoiceInfo(getVatInvoiceInfoParam,tenant);
            logger.info("getVatInvoiceInfo return :" + JsonUtil.toJson(re));
            return JsonUtil.toJson(new FpsResult(re));
        } catch (Exception e) {
            logger.error("getVatInvoiceInfo  error:", e);
            return toJson(new FpsResult<String>(ErrorMessageEnum.ERROR_SYSTEM_BUSY));
        }
    }

    @Override
    public RemoteResult<List<GetVatInvoiceInfoResult>> getVatInvoiceInfo(GetVatInvoiceInfoListParam var1, Tenant var2) {
        try{
           logger.info("getVatInvoiceInfo list param:GetVatInvoiceInfoListParam={},tenant={}",JsonUtil.toJson(var1),var2);
           RemoteResult<List<GetVatInvoiceInfoResult>> result = invoiceApiService.getVatInvoiceInfo(var1,var2);
            logger.info("getVatInvoiceInfo list result:{}",JsonUtil.toJson(result));
            return result;
        }catch(Exception e){
            logger.error("getVatInvoiceInfo list error",e);
            return null;
        }
    }

    /**
     * 查询用户的发票信息
     *
     * @param lenovoid the lenovoid
     * @return the remote result
     */
    @Override
    public RemoteResult<List<InvoiceShop>> queryInvoice(String lenovoid) {
        logger.info("getVatInvoiceInfo accepts queryInvoice information :{}", lenovoid);
        RemoteResult<List<InvoiceShop>> result = new RemoteResult<>();
        try {
            result = invoiceShopApiService.queryInvoice(lenovoid);
            return result;
        } catch (Exception e) {
            logger.error("queryInvoice  error:", e);
            result.setResultCode(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCode() + "");
            result.setResultMsg(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCommon());
            result.setT(null);
            return result;
        }
    }

    /**
     * 查询用户的发票信息
     *
     * @param id the id
     * @return the remote result
     */
    @Override
    public RemoteResult<InvoiceShop> queryInvoiceForId(String id,String lenovoId) {
        logger.info("getVatInvoiceInfo accepts queryInvoiceForId information :{}", id);
        RemoteResult<InvoiceShop> result = new RemoteResult<>();
        try {
            result = invoiceShopApiService.queryInvoiceForId(id,lenovoId);
            return result;
        } catch (Exception e) {
            logger.error("queryInvoice  error:", e);
            result.setResultCode(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCode() + "");
            result.setResultMsg(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCommon());
            result.setT(null);
            result.setSuccess(false);
            return result;
        }
    }

    /**
     * 增删改的数据交互.
     *
     * @param invoiceShop the invoice shop
     *                    synType	Int     1增加，2修改，3删除
     * @return the remote result
     */
    @Override
    public RemoteResult<InvoiceIdAndUuid> synInvoice(InvoiceShop invoiceShop) {
        logger.info("getVatInvoiceInfo accepts synInvoice information :{}", JsonUtil.toJson(invoiceShop));
        RemoteResult<InvoiceIdAndUuid> result = new RemoteResult<>();
        try {
            result = invoiceShopApiService.synInvoice(invoiceShop);
            logger.info("getVatInvoiceInfo accepts synInvoice result :{}", JsonUtil.toJson(result));
            return result;
        } catch (Exception e) {
            logger.error("synInvoice  error:", e);
            result.setResultCode(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCode() + "");
            result.setResultMsg(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCommon());
            result.setT(null);
            result.setSuccess(false);
            return result;
        }
    }


}
