package com.lenovo.m2.web.remote.my.utils;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import com.lenovo.m2.web.remote.my.order.OrderMongoService;
import org.apache.commons.lang3.StringUtils;
import org.lenovo.comment.client.OrderCommnetClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2015/11/19.
 */
@Service(value = "kafkaCommentService")
public class KafkaCommentService {
    private static final Logger logger = LogManager.getLogger(KafkaCommentService.class);
    private static final Logger ERROR = LogManager.getLogger("kafkaErrorLogger");
    @Autowired
    private OrderMongoService orderMongoService;
    public  boolean produceOrderMessage(String ordercode, String merchantId){
        if ("8".equals(merchantId)){

            MongoOrderDetail m = orderMongoService.getOrderByOrdercode(ordercode, merchantId);
            logger.info("kafka's mongoOrderDetail"+ JsonUtil.toJson(m));
            String orderMainCode = m.getOrderMainCode();
            List<MongoOrderDetail> mongoOrderDetails = orderMongoService.getOrderDetailByOrderMainCode(orderMainCode,merchantId);
            for (MongoOrderDetail mongoOrderDetail : mongoOrderDetails){
                String message = "";
                try{
                    String source = convertSource(mongoOrderDetail.getShopId(),mongoOrderDetail.getTerminal());
                    String _source = StringUtils.isEmpty(source) ? "0":source;
                    mongoOrderDetail.setSource(_source);
                    message = JacksonUtil.toJson(mongoOrderDetail);
                    logger.info("传入的message:"+message);
                    long start = System.currentTimeMillis();
                    RemoteResult<Boolean> remoteResult = OrderCommnetClient.getInstance().AddOrderMessage(message);
                    long time = System.currentTimeMillis()-start;
                    logger.info("---kafka 写入已签收订单消息结束---response result:["+ JsonUtil.toJson(remoteResult)+" orderCode: " + mongoOrderDetail.getOrderCode() + " cost time: " + time + "ms");
                    if (remoteResult==null){
                        ERROR.error("errorMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:kafka写入消息返回为空}");
                        return false;
                    }else {
                        if ("200".equals(remoteResult.getResultCode())) {
                            return true;
                        } else {
                            ERROR.error("errorMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:" + remoteResult.getResultMsg() + "}");
                        }
                    }
                }catch (Exception e){
                    ERROR.error("exceptionMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:" + e.getMessage() + "}");
                    return false;
                }
            }
        }else{
            MongoOrderDetail mongoOrderDetail = orderMongoService.getOrderByOrdercode(ordercode, merchantId);
            logger.info("kafka's mongoOrderDetail"+ JsonUtil.toJson(mongoOrderDetail));
            String message = "";
            try{
                String source = convertSource(mongoOrderDetail.getShopId(),mongoOrderDetail.getTerminal());
                String _source = StringUtils.isEmpty(source) ? "0":source;
                mongoOrderDetail.setSource(_source);
                message = JacksonUtil.toJson(mongoOrderDetail);
                logger.info("传入的message:"+message);
                long start = System.currentTimeMillis();
                RemoteResult<Boolean> remoteResult = OrderCommnetClient.getInstance().AddOrderMessage(message);
                long time = System.currentTimeMillis()-start;
                logger.info("---kafka 写入已签收订单消息结束---response result:["+ JsonUtil.toJson(remoteResult)+" orderCode: " + mongoOrderDetail.getOrderCode() + " cost time: " + time + "ms");
                if (remoteResult==null){
                    ERROR.error("errorMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:kafka写入消息返回为空}");
                    return false;
                }else {
                    if ("200".equals(remoteResult.getResultCode())) {
                        return true;
                    } else {
                        ERROR.error("errorMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:" + remoteResult.getResultMsg() + "}");
                    }
                }
            }catch (Exception e){
                ERROR.error("exceptionMsg:{orderCode:" + mongoOrderDetail.getOrderCode() + ",msg:" + e.getMessage() + "}");
                return false;
            }
        }
        return false;
    }
    /**
     * 转换source.兼容 评价系统
     *                      商户（ShopId）
     *                      1	Lenovo
     2	Think
     3	EPP
     4	Roaming
     5	Moto
     6	dongde
     7	ThinkCenter
     终端（Terminal）
     1	PC
     2	WAP
     3	APP
     4	微信
     */

    private  String convertSource(String shopId,String terminal){
        Map<String,String> sourceMap = new HashMap<>();
        sourceMap.put("11","4");
        sourceMap.put("12","1");
        sourceMap.put("13","3");
        sourceMap.put("14","2");

        sourceMap.put("31","22");
        sourceMap.put("32","20");

        sourceMap.put("21","8");
        sourceMap.put("22","5");
        sourceMap.put("23","7");
        sourceMap.put("24","6");
        sourceMap.put("7","11");

//        sourceMap.put("23","7");
//        sourceMap.put("23","7");
        return  sourceMap.get(shopId+terminal);

    }
}
