package com.lenovo.m2.web.remote.couponV2.util;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.stock.utils.HttpConnectionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import java.util.Map;

public class OpenPlatUtil {
    static final Logger log = LoggerFactory.getLogger(OpenPlatUtil.class);
	private static String DEFAULT_APP_KEY  =  CustomizedPropertyConfigurer.getContextProperty("sms_openapiAppKey");
    private static String DEFAULT_SECRETKEY =  CustomizedPropertyConfigurer.getContextProperty("sms_openapiScrebt");
	
    public static String invokeOpenPlat(String method, String param) throws RuntimeException {
        OpenPlatReq req = new OpenPlatReq(method, param);
        String url =  CustomizedPropertyConfigurer.getContextProperty("sms_openapiUrl");
        String platRes =  HttpConnectionUtil.getHttpPostContent(url, req.getPostBody());
        Map map = JsonUtil.fromJson(platRes, Map.class);
        Object success = map.get("success");
        if("true".equals(String.valueOf(success))){
            Object obj = map.get("result");
            return JsonUtil.tranString(((Map)obj).get(String.format("%s_response", method.replaceAll("\\.", "_"))));
        }else{
            throw new RuntimeException("解析开放平台数据异常:"+platRes);
            
        }

    }
    
    public static String openSdk(String method, Map<String, Object> lenovo_param_json){
    	String url =  CustomizedPropertyConfigurer.getContextProperty("sms_openapiUrl");
    	Response response = null;
    	try {
			 response = JavaSDKClient.proxy(url,DEFAULT_APP_KEY, DEFAULT_SECRETKEY, method, lenovo_param_json, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	int status = response.getStatus();
    	if(200==status) {
    		StringBuilder body = response.getBody();
    		 Map map = JsonUtil.fromJson(body.toString(), Map.class);
	        log.info("解析map: "+ JSON.toJSONString(map));
	        Object success = map.get("success");
	        if("true".equals(String.valueOf(success))){
	            Object obj = map.get("result");
	            return JsonUtil.tranString(((Map)obj).get(String.format("%s_response", method.replaceAll("\\.", "_"))));
	        }else{
	            throw new RuntimeException("解析开放平台数据异常:"+body.toString());
	        }
    	}else {
    		 throw new RuntimeException("解析开放结果:"+status+"结果是:"+response.getBody().toString());
    	}
    }
  
}