package com.lenovo.m2.web.remote.purchase.activity.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.api.domain.ReservationInfo;
import com.lenovo.m2.buy.promotion.api.domain.ReservationRequest;
import com.lenovo.m2.buy.promotion.api.service.ActivityService;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.domain.purchase.activity.AddReservationResVO;
import com.lenovo.m2.web.remote.purchase.activity.RemoteReservationService;
import com.lenovo.m2.web.remote.purchase.member.MemberInfoService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import com.lenovo.m2.buy.promotion.api.domain.ReservationRequest;

@Service
public class RemoteReservationServiceImpl implements RemoteReservationService{
	
	 private static Logger log =  LogManager.getLogger(RemoteReservationServiceImpl.class.getName());
	
	@Autowired
	private ActivityService activityService;
	
	@Autowired
	private MemberInfoService memberInfoService;
	
	@Override
	public AddReservationResVO addReservation(int shopId, int terminal, String gcode, String userId, String userName) throws Exception {
		AddReservationResVO vo = new AddReservationResVO();
						
		ReservationRequest request = new ReservationRequest();
		request.setGcode(gcode);
		request.setGname("test"); //TODO
		request.setShopid(shopId);
		request.setTerminal(terminal);
		request.setUserId(userId);
		request.setUserName(userName);
		
		RemoteResult<String> rr = activityService.addReservation(request);
		if(!rr.isSuccess()){
            RemoteResultUtil.updateMsgAndReplace(rr, PromptEnum.PROMOTION);
			vo.setRc(Integer.parseInt(rr.getResultCode()));
			vo.setMsg(rr.getResultMsg());
			return vo;
		}
		vo.setRc(0);
		vo.setReservationId(rr.getT());

		try{//try catch 封起来， 失败不影响主流程
			Map<String, Object> mapInfo = memberInfoService.getInfo(userId);
			String phone = (String)mapInfo.get("mobile");
			vo.setPhone(phone);
		}catch(Exception e){
			log.error("", e);
		}
		return vo;
	}

	@Override
	public PageModel2<com.lenovo.m2.web.domain.purchase.seckill.ReservationInfo> bookList(Tenant tenant, String userId, Integer pageSize, Integer pageNow) {
		log.info("activityService.getBookList req tenant={}, userid={}, pageSize={}, pageNow={}",
				new Object[]{tenant, userId, pageSize, pageNow}
				);
		RemoteResult<PageModel2<ReservationInfo>> ret = activityService.getBookList(tenant, userId, pageSize, pageNow);
		int size = ret!=null?ret.getT().getDatas().size():0;
		List<com.lenovo.m2.web.domain.purchase.seckill.ReservationInfo> list = new ArrayList<>(size);
		if(size>0){
			for(ReservationInfo r: ret.getT().getDatas()){
				log.info("当前faId{}=",r.getFaId());
				com.lenovo.m2.web.domain.purchase.seckill.ReservationInfo tmp = new com.lenovo.m2.web.domain.purchase.seckill.ReservationInfo();
				tmp.setCode(String.valueOf(r.getGcode()));
				tmp.setId(r.getId());
				tmp.setName(r.getGname());
				tmp.setPic(r.getPic());
				tmp.setReservationtime(r.getReservationtime());
				tmp.setSeckillendtime(r.getSeckillEndTime());
				tmp.setSeckillstarttime(r.getSeckillStartTime());
				tmp.setStatus(r.getStatus());
				tmp.setFaId(r.getFaId());
				list.add(tmp);
			}
			log.info("activityService.getBookList res, size={}", size);
		}

		PageQuery pq = new PageQuery(pageNow, pageSize);
		pq.setTotalCount(ret!=null?ret.getT().getTotalCount():0);
       log.info("当前返回结果list={}=",JsonUtil.toJson(list));
		return new PageModel2<>(pq, list);
	}

	@Override
	public boolean isHaveReservation(int activityId, String gcode, String userId) {
		return activityService.isHaveReservation(activityId, gcode, userId);
	}

	@Override
	public BaseInfo updateReservationPhone(String userId, String reservationId, String phone) {
		try{
			activityService.updateReservationPhone(userId, reservationId, phone);
			return BaseInfo.success();
		}catch(Exception e){
			log.error("",e);
			return BaseInfo.fail();
		}
		
	}

}
