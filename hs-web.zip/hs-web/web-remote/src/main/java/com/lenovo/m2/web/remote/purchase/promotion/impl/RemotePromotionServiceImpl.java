package com.lenovo.m2.web.remote.purchase.promotion.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.bee.PromotionRoutedService;
import com.lenovo.m2.hsbuy.domain.bee.PromotionInfo;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.remote.purchase.promotion.RemotePromotionService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by D_xiao on 16/11/15.
 */
@Service
public class RemotePromotionServiceImpl implements RemotePromotionService {
    private static Logger log =  LogManager.getLogger(RemotePromotionServiceImpl.class.getName());

    @Autowired
    @Qualifier("promotionRoutedServiceBee")
    public PromotionRoutedService remotePromotionService;

    @Override
    public RemoteResult<Boolean> pushPromotionInfo(PromotionInfo var1, Tenant tenant) {
        try {

            //TODO By MaHao
            RemoteResult<Boolean> result = remotePromotionService.pushPromotionInfo(var1,tenant);
            log.info("调用pushPromotionInfo成功!返回={}", JsonUtil.toJson(result));
            return result;
        }catch(Exception e){
            log.error("调用远程pushPromotionInfo接口异常,",e);
            return null;
        }

    }
}
