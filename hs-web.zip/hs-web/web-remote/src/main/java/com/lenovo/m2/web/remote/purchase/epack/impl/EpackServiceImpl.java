package com.lenovo.m2.web.remote.purchase.epack.impl;

import com.lenovo.m2.web.common.purchase.util.ExceptionUtil;
import com.lenovo.m2.web.remote.purchase.epack.EpackService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.tempuri.*;

import java.util.List;

/**
 * Created by fenglg1 on 2016/11/10.
 */
@Service("epackService")
public class EpackServiceImpl implements EpackService {

    private static Logger log =  LogManager.getLogger(EpackServiceImpl.class);

//    @Autowired
//    private EpackWSForLShopSoap epackWSForLShopSoap;

    @Override
    public boolean checkSN(String wsdlLocation, String SNCode, String materialCode, String epackUsername, String epackPassword) {
//
//        try {
//            // for local test
//            /*EpackWSForLShop ss = new EpackWSForLShop(new URL("http://10.99.101.68:91/WebService/EpackWSForLShop.asmx?wsdl"), new QName("http://tempuri.org/", "EpackWSForLShop"));
//            EpackWSForLShopSoap port = ss.getEpackWSForLShopSoap();*/
//
//            ArrayOfProductInfo arrayOfProductInfo = new ArrayOfProductInfo();
//            ProductInfo productInfo = new ProductInfo();
//            productInfo.setMachineNo(SNCode);
//            ArrayOfString arrayOfString = new ArrayOfString();
//            arrayOfString.getString().add(materialCode);
//            productInfo.setListMaterialNo(arrayOfString);
//            arrayOfProductInfo.getProductInfo().add(productInfo);
//            log.info("Call Epack Start ......");
//            long startTime = System.currentTimeMillis();
//            ArrayOfReturnProductInfo returnProductInfo = epackWSForLShopSoap.checkMultiMachineSVCProdPurchase(arrayOfProductInfo, epackUsername, epackPassword);
//            log.info("Call Epack End. used: " + (System.currentTimeMillis() - startTime)+"ms");
//            List<ReturnProductInfo> returnProductInfoList = returnProductInfo.getReturnProductInfo();
//            ReturnProductInfo reProductInfo = returnProductInfoList.get(0);
//            log.info(String.format("Call Epack return result: Status:%d MaterialNo:%s MachineNo:%s ErrorMessage:%s", reProductInfo.getStatus(), reProductInfo.getMaterialNo(), reProductInfo.getMachineNo(), reProductInfo.getErrorMessage()));
//            int returnStatus = reProductInfo.getStatus();
//            if(returnStatus == 200){
//                return true;
//            }
//        } catch (Exception e) {
//            log.error("调用Epack出错，" + ExceptionUtil.getStackTrace(e));
//        }

        return false;
    }

    public static void main(String[] args) {
        EpackServiceImpl epackService = new EpackServiceImpl();
        epackService.checkSN(null, "r302m6dk", "31051853", "thinkservice", "lenovo2009");
    }
}
