package com.lenovo.m2.web.remote.exception;

public class AccountServiceException extends RuntimeException {
    private static final long serialVersionUID = 1L;

	public AccountServiceException(String msg) {
		super(msg);
	}
}