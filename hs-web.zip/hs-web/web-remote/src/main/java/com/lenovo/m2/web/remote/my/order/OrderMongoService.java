package com.lenovo.m2.web.remote.my.order;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import com.lenovo.m2.web.domain.my.order.UserProduct;

import java.util.List;
import java.util.Map;

/**
 * 订单mongo操作
 * Created by mayan3 on 2015/10/12.
 */
public interface OrderMongoService {

    List<MongoOrderDetail> getOrderByOrderStatus(String merchantId, String id, PageQuery pageQuery, String orderstatus, String startTime, String endTime, String searchtext, String orderType);

    /**
     * 通过订单编号取订单信息（含子类信息）
     * 根据merchantId 获取数据源
     */
    MongoOrderDetail getOrderByOrdercode(String ordercode, String merchantId);


    /**
     * 通过订单编号更新订单field字段值为parameter
     * @param merchantId 平台号 商城 think epp
     * @param orderCode 订单编号
     * @param field     更新字段
     * @param parameter 更新值
     * @return
     */
    int updateMongoOrder(String merchantId, String orderCode, String field, String parameter);

    int updateMongoOrder2(String merchantId, String orderCode, Map<String, String> map);

    List<UserProduct> getUserProducts(String merchantId, String id, String startTime, String endTime);
    /**
     * 通过订单编号和商品商品编号更新mongoOrder内嵌product的field字段值为parameter
     * @param merchantId
     * @param orderCode
     * @param productCode
     * @param field
     * @param parameter
     * @return
     */
    int updateMongoOrderProduct(String merchantId, String orderCode, String productCode, String field, String parameter);

    List<MongoOrderDetail> getOrderDetailByOrderMainCode(String orderno, String shopId);

}
