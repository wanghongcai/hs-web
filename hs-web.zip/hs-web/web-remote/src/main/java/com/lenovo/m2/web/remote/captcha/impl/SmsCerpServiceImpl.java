package com.lenovo.m2.web.remote.captcha.impl;

import com.lenovo.m2.web.common.my.CommonUtil;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.RedisKeyUtil;
import com.lenovo.m2.web.domain.my.MobileMsg;
import com.lenovo.m2.web.redis.MyRedisConn;
import com.lenovo.m2.web.remote.captcha.SmsCerpService;
import com.lenovo.m2.web.remote.couponV2.util.OpenPlatUtil;
import com.lenovo.m2.web.remote.exception.AccountServiceException;
import com.lenovo.sms.constants.Caller;
import com.lenovo.sms.model.SimpleSMS;
import com.lenovo.ucenter.sso.client.util.MD5;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class SmsCerpServiceImpl implements SmsCerpService {

	private static Logger logger = Logger.getLogger(SmsCerpServiceImpl.class);

	@Autowired
	private MyRedisConn myRedisConn;

	@Override
	public void sendMsgBySMS(MobileMsg mobile, boolean inner) {

		long appId = Long.parseLong(CustomizedPropertyConfigurer.getContextProperty("sms_appId"));// 应用id
		String appKey = CustomizedPropertyConfigurer.getContextProperty("sms_appKey");// 应用对应的秘钥

		long activeId = getActiveId();
		long timeStamp = System.currentTimeMillis();// 时间戳
		String md5Key = MD5.MD5Encode(appId + appKey + timeStamp);// 服务端校验的MD5值,加密顺序一定要注意
		
		
		Map<String, Object> param = new HashMap<String,Object>();
		param.put("mobile", mobile.getMobile());
		param.put("content", mobile.getContent());
		param.put("timeAt", timeStamp);
		param.put("appId", appId);
		param.put("activeId", activeId);
		param.put("key", md5Key);
		
		//String invokeOpenPlat = OpenPlatUtil.invokeOpenPlat("lenovo.sms.newSingleSms", param.toString());
		
		String openSdk = OpenPlatUtil.openSdk("lenovo.sms.newSingleSms", param);
		
		logger.info("发送短信结果:"+openSdk);
		
		String  redisSmsKey ="";

		if(!StringUtils.isEmpty(mobile.getPrekey())){//前缀不为空时，认为要缓存进redis来进行验证
			//myRedisConn.setex(mobile.getPrekey() + mobile.getShopId()  + mobile.getMobile(), 600, mobile.getCaptcha());
			redisSmsKey = mobile.getPrekey() + mobile.getShopId()  + mobile.getMobile();
		}else{
		//	myRedisConn.setex(RedisKeyUtil.CAPTCHA_PRE + mobile.getShopId()  + mobile.getMobile(), 600, mobile.getCaptcha());//默认的key
			redisSmsKey = RedisKeyUtil.CAPTCHA_PRE + mobile.getShopId()  + mobile.getMobile();
		}
		myRedisConn.setex(redisSmsKey, 600, mobile.getCaptcha());
		logger.info("redisSmsKey :" + redisSmsKey + " value:" + myRedisConn.get(redisSmsKey));
		String msg = "参数：mobile: " + mobile + " content:" + mobile.getContent() + " activeId:" + activeId;
		logger.info(msg);

	}


	private static long getActiveId() {
		long activeId = Long.parseLong(CustomizedPropertyConfigurer.getContextProperty("sms_activeId"));
		return activeId;
	}

	// / 根据 Agent设置来源
	public static void setAgent(String agent, SimpleSMS simpleSMS) {
		if (agent.contains("Android")) {
			simpleSMS.setCaller(Caller.Android);
		} else if (agent.contains("iPhone")) {
			simpleSMS.setCaller(Caller.IOS);
		} else if (agent.contains("iPod") || agent.contains("iPad")) {
			simpleSMS.setCaller(Caller.Touch);
		} else {
			simpleSMS.setCaller(Caller.Web);
		}
	}

	@Override
	public void sendMsg(String mobile, String shopid, boolean isinner, Object... places) {
		//短信内容模板
		String content = "【惠商商城验证码】您的账号{0}正在申请使用惠商商城虚拟资产或信用支付，支付验证码为{1}，谨防诈骗盗用切勿将验证码告诉他人避免资产损失! ";
		content = MessageFormat.format(content, places);
		
		MobileMsg mobileVO = new MobileMsg();
		mobileVO.setMobile(mobile);
		if(places.length>0){
			mobileVO.setCaptcha((String)places[1]);
		}
		mobileVO.setContent(content);
		mobileVO.setShopId(shopid);
		
		this.sendMsgBySMS(mobileVO,isinner);
	}

	/**
	 * 获取redis中的验证码信息
	 */
	@Override
	public String getCaptcha(String prekey, String shopid ,String loginname) {
		
		String result = myRedisConn.get(prekey + shopid + loginname);
		logger.info("smskey" + (prekey + shopid + loginname) + "value: " + result);
		return result;
	}

	@Override
	public String createCaptchaRandomNumber() {
		StringBuilder captcha = new StringBuilder();
		for (int i = 0; i < 6; i++) {
			captcha.append(new Random().nextInt(10));
		}
		return captcha.toString();
	}


	public boolean sendSmsCaptcha(MobileMsg mobile) {

		if (!CommonUtil.isMobile(mobile.getMobile())) {
			logger.warn("要发送短信的手机号非法："+mobile.getMobile());
			return false;
		}

		try {
			String captcha = createCaptchaRandomNumber();
			logger.info("captcha: " + captcha);
			sendMsg(mobile.getMobile(),mobile.getShopId(),mobile.isInner(), mobile.getMobile(),captcha);
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return false;
		}

	}

	/**
	 *
	 * @description:校验验证码
	 * @param mobile
	 * @return
	 */
	public boolean verifySmsCaptcha(MobileMsg mobile) {

		boolean flag = true;

		String captchacache="";

		if (StringUtils.isEmpty(mobile.getCaptcha())) {
			throw new AccountServiceException("验证码为空");
		}
		if(StringUtils.isEmpty(mobile.getPrekey())){//默认的key

			captchacache = getCaptcha(RedisKeyUtil.CAPTCHA_PRE,mobile.getShopId(),mobile.getMobile());
		}else{
			captchacache = getCaptcha(mobile.getPrekey(),mobile.getShopId(),mobile.getMobile());
		}
		
		if(captchacache == null ||"nil".equals(captchacache) || StringUtils.isEmpty(captchacache)){
			flag = false;
		}

		if (mobile.getCaptcha().equals(captchacache)) {
			//校验成功删除验证码
			if(StringUtils.isEmpty(mobile.getPrekey())){
				myRedisConn.del(RedisKeyUtil.CAPTCHA_PRE+mobile.getShopId()+mobile.getMobile());
			}else{
				myRedisConn.del(mobile.getPrekey()+mobile.getShopId()+mobile.getMobile());
			}
		}else {
			flag = false;
		}

		return flag;
	}
}