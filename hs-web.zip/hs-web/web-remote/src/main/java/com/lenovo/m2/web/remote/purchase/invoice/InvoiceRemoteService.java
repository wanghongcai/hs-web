package com.lenovo.m2.web.remote.purchase.invoice;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.integral.CouponAndIntegralInfo;
import com.lenovo.m2.hsbuy.domain.invoice.param.AddVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoListParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.result.GetVatInvoiceInfoResult;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceIdAndUuid;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;

import java.util.List;

/**
 * Created by bob on 2015/11/19.
 */
public interface InvoiceRemoteService {

    /**
     * 根据couponId获取优惠券和积分的绑定记录
     * @param couponId
     * @return
     */
    public RemoteResult<CouponAndIntegralInfo> getCouponInfo(String couponId);

    /**
     * 查询所有可以兑换的优惠券的列表--前端页面显示
     * @return
     */
    public RemoteResult<List<CouponAndIntegralInfo>> getAllCouponInfo();

    /**
     * 立即兑换接口
     * @param shopId
     * @param couponId
     * @param agentId
     * @param agentCode
     * @param buyerId
     * @return
     */
    public RemoteResult exchangeCoupon(String shopId,String couponId,String agentId,String agentCode,String buyerId);

    /**
     * 新版添加增票信息
     *
     * @param addVatInvoiceInfoParam the add vat invoice info param
     * @return the string
     * @author licy13
     */
    public String addVatInvoiceInfoParam(Tenant tenant, AddVatInvoiceInfoParam addVatInvoiceInfoParam);

    /**
     * 新版获取增票信息
     * <p>
     * 规则：
     * 1)如果只有lenovoId不为空，则返回的信息为改用户最新的一条记录
     * 2)如果三个参数都不为空，则返回的是共享的记录
     *
     * @param getVatInvoiceInfoParam the get vat invoice info param                               lenovoIdcustomerName;taxNo;
     * @return the vat invoice info
     * @author licy13
     */
    public String getVatInvoiceInfo(Tenant tenant, GetVatInvoiceInfoParam getVatInvoiceInfoParam);

    /**
     * 惠商增票
     * @param var1
     * @param var2
     * @return
     */
    public RemoteResult<List<GetVatInvoiceInfoResult>> getVatInvoiceInfo(GetVatInvoiceInfoListParam var1, Tenant var2);
/********************************************SMB******************************************************/
    /**
     * 查询用户的发票信息
     *
     * @param lenovoid the lenovoid
     * @return the remote result
     * @author licy13
     */
    public RemoteResult<List<InvoiceShop>> queryInvoice(String lenovoid);

    /**
     * 查询用户的发票信息
     *
     * @param id       the id
     * @param lenovoId the lenovo id
     * @return the remote result
     * @author licy13
     */
    public RemoteResult<InvoiceShop> queryInvoiceForId(String id,String lenovoId);

    /**
     * 增删改的数据交互.
     *
     * @param invoiceShop the invoice shop                    synType	Int     1增加，2修改，3删除
     * @return the remote result
     * @author licy13
     */
    public RemoteResult<InvoiceIdAndUuid> synInvoice(InvoiceShop invoiceShop);


}