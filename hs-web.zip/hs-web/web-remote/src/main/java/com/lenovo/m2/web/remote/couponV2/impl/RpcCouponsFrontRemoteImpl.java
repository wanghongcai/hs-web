
package com.lenovo.m2.web.remote.couponV2.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.dubboService.RpcCouponsService;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.web.remote.couponV2.RpcCouponsFrontRemote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


/**
 * Created by zhaocl1 on 2016/3/22.
 */

@Component("rpcCouponsFrontRemote")
public class RpcCouponsFrontRemoteImpl implements RpcCouponsFrontRemote {
    @Autowired
    private RpcCouponsService rpcCouponsService;

    @Override
    public RemoteResult add(SalescouponsApi salescouponsApi) {
        return rpcCouponsService.add(salescouponsApi);
    }

    @Override
    public RemoteResult delete(long id, String shopId, String terminal) {
        return rpcCouponsService.delete(id, shopId, terminal);
    }

    @Override
    public RemoteResult update(long id, String shopId, String terminal, BigDecimal amount, String fromtime, String totime,String userId) {
        return rpcCouponsService.update(id, shopId, terminal, amount, fromtime, totime,userId);
    }

    @Override
    public RemoteResult enableCoupons(Map<String, String> map) {
        return rpcCouponsService.enableCoupons(map);
    }

    @Override
    public RemoteResult getPage(String shopId, String terminal,String amount,String name, String fromtime, String totime, String page, String page_size,String status) {
        return rpcCouponsService.getPage(shopId, terminal,amount,name, fromtime, totime, page, page_size,status);
    }

    @Override
    public RemoteResult getCouponsPage(Map map) {
        return rpcCouponsService.getCouponsPage(map);
    }

    @Override
    public RemoteResult check(List<String> codeslist, String shopId, String terminal, String couponCode) {
        return rpcCouponsService.check(codeslist, shopId, terminal, couponCode);
    }

    @Override
    public RemoteResult updateCouponsStatus(String userId, CouponsApi couponsApi) {
        return rpcCouponsService.updateCouponsStatus(userId, couponsApi);
    }

    @Override
    public RemoteResult invalidCoupons(String userId, String shopId, String terminal, String id,String batchno) {
        return rpcCouponsService.invalidCoupons(userId, shopId, terminal, id,batchno);
    }
}
