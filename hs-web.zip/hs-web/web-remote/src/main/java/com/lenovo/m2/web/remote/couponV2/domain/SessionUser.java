
package com.lenovo.m2.web.remote.couponV2.domain;

import java.io.Serializable;

public class SessionUser implements Serializable{

/**
	 * 会员id
	 */

	private String memberid;

/**
	 * 用户名
	 */

	private String username;

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

