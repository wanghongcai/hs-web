package com.lenovo.m2.web.remote.purchase;

import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.ThreadLocalReqAndResp;
import com.lenovo.m2.web.common.purchase.util.XssHttpServletRequestWrapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.SimpleDateFormat;
import java.util.UUID;

/**
 * Created by chenww3 on 2015/6/15.
 */
public class BaseCommonUtil {
	private static Log log = LogFactory.getLog(BaseCommonUtil.class);
    protected static final String SHOPPING_CART = "shoppingCart";
    protected String toJson(Object obj){
        if(obj instanceof String){
            return (String)obj;
        }
        String rs = null;
        try {
            JsonUtil.OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            rs = JsonUtil.OM.writeValueAsString(obj);
        } catch (Exception e) {
        	log.error(e);
        }
        if(rs == null){
            rs = "{\"rc\":-1}";//解析JSON异常/IO异常
        }
        return rs;
    }

    protected HttpServletRequest request(){
        return ThreadLocalReqAndResp.getRequest();
    }

    protected HttpServletResponse response(){
        return ThreadLocalReqAndResp.getResponse();
    }

    protected HttpSession session(){
        return ThreadLocalReqAndResp.getSession();
    }
    /**
     * 从session中获取
     * @return
     */
    private SessionUser getSessionU(){
        return (SessionUser)this.session().getAttribute("user");
    }

    /**
     * GUID
     */
    protected String randomUUID(){
        return UUID.randomUUID().toString();
    }

    protected String getRemoteAddr(){
        return request().getHeader("X-Forward-For");
    }

    protected String getSessionid(){
        return this.session().getId();
    }


    protected boolean isNotNull(Object... obj){
        if(obj != null){
            for (Object o : obj) {
                if(o == null){
                    return false;
                }else if (o instanceof String){
                    String encoded = XssHttpServletRequestWrapper.xssEncode((String) o);
                    o = encoded;
                    if(o == null){
                        return false;
                    }
                }
            }
        }else{
            return false;
        }
        return true;
    }
    protected boolean isNull(Object... obj){
        return !isNotNull(obj);
    }
}
