package com.lenovo.m2.web.remote.purchase.pricelist.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.api.param.pricelist.ManualOrderParam;
import com.lenovo.m2.hsbuy.api.param.pricelist.PriceListParam;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceList;
import com.lenovo.m2.hsbuy.pricelist.PriceListService;
import com.lenovo.m2.web.remote.purchase.pricelist.PriceListRemoteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by syj on 2016/7/21.
 */
@Service("priceListRemoteService")
public class PriceListRemoteServiceImpl implements PriceListRemoteService {

    private static Logger log =  LogManager.getLogger(PriceListRemoteServiceImpl.class.getName());

    @Autowired
    private PriceListService priceListApiService;


    @Override
    public RemoteResult<PageModel2<PriceList>> getPriceListPage(Tenant tenant, PageQuery pageQuery, PriceListParam priceList) {
        return priceListApiService.getPriceListPage(tenant,pageQuery,priceList);
    }

    @Override
    public RemoteResult<PriceList> getPriceListDetail(Tenant tenant,PriceListParam priceList) {
        return priceListApiService.getPriceListDetail(tenant,priceList);
    }

    @Override
    public RemoteResult<String> insertPriceList(Tenant tenant,PriceListParam priceList) {
        return priceListApiService.insertPriceList(tenant,priceList);
    }



	@Override
	public RemoteResult<Map> genMaualOrder(Tenant tenant,ManualOrderParam manualOrderVo) {
		return priceListApiService.genManualOrder(tenant,manualOrderVo);
	}

    @Override
    public RemoteResult<Boolean> submitPriceList(Tenant tenant,PriceListParam pl) {
        return priceListApiService.submitPriceList(tenant,pl);
    }

	@Override
	public RemoteResult<String> pullOrderedDealNo() {
		return priceListApiService.pullOrderedDealNo();
	}

	@Override
	public RemoteResult<Integer> updateToOrdered(String itCode, String dealNo) {
		return priceListApiService.updateToOrdered(itCode, dealNo);
	}

	@Override
	public RemoteResult<String> queryPdfUrl(String itCode, String userId, String dealNo, List<String> showParams) {
		return priceListApiService.queryPdfUrl(itCode, userId, dealNo, showParams);
	}
}
