package com.lenovo.m2.web.remote.stock;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoParam;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoResult;

import java.util.List;
import java.util.Map;

/**
 * Created by mayan3 on 2016/3/14.
 */
public interface StockService {

   List<GetStockInfoResult> getStockInfo(List<GetStockInfoParam> params, Tenant tenant);

   Map getProductInfoBymaterialNum(String materialNum);
}
