package com.lenovo.m2.web.remote.my.order.impl;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.web.common.my.utils.DateUtil;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.remote.my.order.OrderDBService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;

/**
 * Created by mayan3 on 2015/10/12.
 */
@Service
public class OrderDBServiceImpl implements OrderDBService {

    private static final Logger logger = LogManager.getLogger(OrderDBServiceImpl.class);

    @Override
    public List<Order> selectOrderByOrderstatus(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext,
                                                Integer shipStatus, String commentStatus, Integer isreturn, String orderType) {

        return null;
    }

    @Override
    public HuiMallOrderCount getOrderCountByUser(String lenovoId, String merchantId) {


        return null;


    }

    private void searchDateScope(OrderExample.Criteria criteria, String orddate) {
        Calendar c = Calendar.getInstance();
        try {
            //
            if ("1".equals(orddate)) {
                criteria.andCreatetimeGreaterThanOrEqualTo(
                        DateUtil.parseDate(DateUtil.addMonth(DateUtil.getFirstDate("yyyy-MM-dd"), -2), "yyyy-MM-dd"));
            }
            // 今年内
            if ("2".equals(orddate)) {
                criteria.andCreatetimeGreaterThanOrEqualTo(DateUtil.getCurrYearFirst());
            }
            // 上一年
            if ("3".equals(orddate)) {
                criteria.andCreatetimeGreaterThanOrEqualTo(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 1))
                        .andCreatetimeLessThanOrEqualTo(DateUtil.getYearLast(c.get(Calendar.YEAR) - 1));
            }
            // 上两年
            if ("4".equals(orddate)) {
                criteria.andCreatetimeGreaterThanOrEqualTo(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 2))
                        .andCreatetimeLessThanOrEqualTo(DateUtil.getYearLast(c.get(Calendar.YEAR) - 2));
            }
            // 上三年及上三年以前
            if ("5".equals(orddate)) {
                criteria.andCreatetimeLessThanOrEqualTo(DateUtil.getYearLast(c.get(Calendar.YEAR) - 3));
            }
        } catch (ParseException e) {
            logger.error("订单时间查询错误！", e);
        }
    }

}
