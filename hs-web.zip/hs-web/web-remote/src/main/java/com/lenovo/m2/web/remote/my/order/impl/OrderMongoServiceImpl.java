package com.lenovo.m2.web.remote.my.order.impl;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import com.lenovo.m2.web.common.my.order.OrderMainConstant;
import com.lenovo.m2.web.common.my.utils.*;
import com.lenovo.m2.web.common.my.utils.DateUtil;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.my.utils.MongoBeanUtil;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.dao.my.dao.simple.common.impl.BaseMongoDaoImpl;
import com.lenovo.m2.web.domain.my.order.MongoOrder;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import com.lenovo.m2.web.domain.my.order.Product;
import com.lenovo.m2.web.domain.my.order.UserProduct;
import com.lenovo.m2.web.remote.my.order.OrderMongoService;
import com.mongodb.*;
import com.mongodb.util.JSON;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Created by mayan3 on 2015/10/12.
 */
@Service
public class OrderMongoServiceImpl extends BaseMongoDaoImpl<MongoOrder> implements OrderMongoService {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(OrderMongoServiceImpl.class);

    @Resource(name = "mongoTemplate")
    protected MongoTemplate mongoTemplate;

    private void searchDateScope(String startTime,String endTime,DBObject ref){
        ref.put("createTime", new BasicDBObject("$gte", startTime.toString()).append("$lte", endTime.toString()));
    }


    /**获取订单列表查询时间范围
     *
     * @param orddate
     * @param ref
     */

    private void searchDateScope(String orddate,DBObject ref){
        Calendar c = Calendar.getInstance();
        String fromDate = "";
        String toDate;
        //近三个月的
        if("1".equals(orddate)){
            fromDate = DateUtil.addMonth(DateUtil.getFirstDate("yyyy-MM-dd"), -2);
            ref.put("createTime", new BasicDBObject("$gte", fromDate.toString()));
        }
        //今年内
        if("2".equals(orddate)){
            fromDate = DateUtil.formatDate(DateUtil.getCurrYearFirst(), "yyyy-MM-dd");
            ref.put("createTime", new BasicDBObject("$gte", fromDate.toString()));
        }
        //上一年
        if("3".equals(orddate)){
            fromDate = DateUtil.formatDate(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 1), "yyyy-MM-dd");
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 1), "yyyy-MM-dd");
            ref.put("createTime", new BasicDBObject("$gte", fromDate.toString()).append("$lte", toDate.toString()));
        }
        //上两年
        if("4".equals(orddate)){
            fromDate = DateUtil.formatDate(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 2), "yyyy-MM-dd");
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 2), "yyyy-MM-dd");
            ref.put("createTime", new BasicDBObject("$gte", fromDate.toString()).append("$lte", toDate.toString()));
        }
        //上三年及上三年以前
        if("5".equals(orddate)){
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 3), "yyyy-MM-dd");
            ref.put("createTime", new BasicDBObject("$lte", fromDate.toString()));
        }
    }


    @Override
    public List<MongoOrderDetail> getOrderByOrderStatus(String merchantId, String lenovoId, PageQuery pageQuery, String orderstatus, String startTime, String endTime, String searchtext, String orderType) {
        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();


        if ("8".equals(merchantId)){
            list = SelectSmbOrderListFromMongodb(merchantId, lenovoId, pageQuery, orderstatus, startTime, endTime, searchtext, orderType);
        }else if ("9".equals(merchantId)){
            list = SelectSmbJfOrderListFromMongodb(merchantId, lenovoId, pageQuery, orderstatus, startTime, endTime, searchtext, orderType);
        }else{
            list = SelectOrderListFromMongodb(merchantId,lenovoId,pageQuery,orderstatus,startTime,endTime,searchtext,orderType);
        }

        return list;
    }

    private List<MongoOrderDetail> SelectSmbOrderListFromMongodb(String merchantId, String lenovoId, PageQuery pageQuery, String orderstatus, String startTime, String endTime, String searchtext, String orderType) {

        int pageNo = pageQuery.getPageNum();
        int pageSize = pageQuery.getPageSize();
        if(pageNo < 1){
            pageNo = 1;
        }
        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();

        DBObject ref = new BasicDBObject();
        ref.put("payStatus",new BasicDBObject("$ne","3"));//去除预约订单
        ref.put("lenovoId", lenovoId);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        ref.put("shopId", merchantId);
        if(StringUtils.isEmpty(orderType)){
            ref.put("orderAddType", new BasicDBObject("$ne", OrderMainConstant.ADD_TYPE_RAISE));//排除众筹团购订单
        }else{
            ref.put("orderAddType", orderType);
        }
        if(orderstatus != null && !"".equals(orderstatus)){
            if(orderstatus.equals("0")){
                ref.put("paymentType",new BasicDBObject("$ne","货到付款"));//去除货到付款订单
                ref.put("payStatus", orderstatus.toString());
                ref.put("orderStatus", "0");
            }else if(orderstatus.equals("1")){
                ref.put("payStatus", "1");
                ref.put("orderStatus", "2");
            }else if (orderstatus.equals("2")){
                ref.put("payStatus", "1");
                ref.put("orderStatus", "3");
            }
        }
        //订单查询时间范围
        searchDateScope(startTime, endTime, ref);
        //根据商品编号/商品名称/订单编号查询
        if(searchtext != null && !"".equals(searchtext)){
            BasicDBList values = new BasicDBList();
            Pattern pattern = Pattern.compile("^.*"+searchtext+".*$", Pattern.CASE_INSENSITIVE);
            values.add(new BasicDBObject("products.productCode", pattern));
            values.add(new BasicDBObject("products.productName", pattern));
            values.add(new BasicDBObject("customerOrderCode", pattern));
            ref.put("$or", values);
        }

        DBObject orderBy = new BasicDBObject("createTime", -1);

        //mongodb order by
        orderBy.put("orderMainCode",-1);

        DBCursor rs = getMCollectionByMerchantId("1").find(ref).sort(orderBy);
        //获取订单总数
        pageQuery.setTotalCount(rs.count());

        rs = rs.sort(orderBy).limit(pageSize).skip(pageSize*(pageNo-1));
        Map<String,String> map = new HashMap<String,String>();
        while (rs.hasNext()) {
            DBObject dbObject = (DBObject) rs.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
            map.put(mongoOrder.getOrderMainCode(),"1");
        }
        Set<String> set = map.keySet();
        for (String s : set){
            DBObject orderMainCodeRef = new BasicDBObject();
            orderMainCodeRef.put("orderMainCode",s);
            orderMainCodeRef.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
            DBObject orderMainCodeRef1 = new BasicDBObject();
            orderMainCodeRef1.put("createTime", -1);
            DBCursor orderMainCode = getMCollectionByMerchantId("1").find(orderMainCodeRef).sort(orderMainCodeRef1);
            while (orderMainCode.hasNext()){
                DBObject dbObjectForMainCode = (DBObject) orderMainCode.next();
                MongoOrderDetail mongoOrderDetail = MongoBeanUtil.dbObject2Bean(dbObjectForMainCode, new MongoOrderDetail());
                list.add(mongoOrderDetail);
            }
        }
        return list;
    }

    private List<MongoOrderDetail> SelectSmbJfOrderListFromMongodb(String merchantId, String lenovoId, PageQuery pageQuery, String orderstatus, String startTime, String endTime, String searchtext, String orderType) {

        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();
        list = SelectOrderListFromMongodb(merchantId,lenovoId,pageQuery,orderstatus,startTime,endTime,searchtext,orderType);
        return list;

    }

    public List<MongoOrderDetail> SelectOrderListFromMongodb(String merchantId, String lenovoId, PageQuery pageQuery, String orderstatus, String startTime, String endTime, String searchtext, String orderType){
        int pageNo = pageQuery.getPageNum();
        int pageSize = pageQuery.getPageSize();
        if(pageNo < 1){
            pageNo = 1;
        }
        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();

        DBObject ref = new BasicDBObject();
        ref.put("lenovoId", lenovoId);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        ref.put("shopId", merchantId);
        if(StringUtils.isEmpty(orderType)){
            ref.put("orderAddType", new BasicDBObject("$ne", OrderMainConstant.ADD_TYPE_RAISE));//排除众筹团购订单
        }else{
            ref.put("orderAddType", orderType);

        }

        logger.info("orderstatus={}",orderstatus);
        if(orderstatus != null && !"".equals(orderstatus)){
            //待付款
            if(orderstatus.equals("0")){
                ref.put("paymentType",new BasicDBObject("$ne","货到付款"));//去除货到付款订单
                ref.put("payStatus", orderstatus);
                ref.put("orderStatus", "0");
            }else if(orderstatus.equals("1")){
                ref.put("payStatus", "1");
                ref.put("orderStatus", "2");
            }else if (orderstatus.equals("2")){
                ref.put("payStatus", "1");
                ref.put("orderStatus", "3");
            }
        }
        //订单查询时间范围
        searchDateScope(startTime, endTime, ref);
        //根据商品编号/商品名称/订单编号查询
        if(searchtext != null && !"".equals(searchtext)){
            BasicDBList values = new BasicDBList();
            Pattern pattern = Pattern.compile("^.*"+searchtext+".*$", Pattern.CASE_INSENSITIVE);
            values.add(new BasicDBObject("products.productCode", pattern));
            values.add(new BasicDBObject("products.productName", pattern));
            values.add(new BasicDBObject("orderCode", pattern));
            ref.put("$or", values);
        }

        DBObject orderBy = new BasicDBObject("createTime", -1);
        logger.info("ref={}",ref);
        DBCursor rs = getMCollectionByMerchantId(merchantId).find(ref);
        logger.info("rs.count()={}",rs.count());
        //获取订单总数
        pageQuery.setTotalCount(rs.count());
        rs = rs.sort(orderBy).limit(pageSize).skip(pageSize*(pageNo-1));
        while (rs.hasNext()) {
            DBObject dbObject = (DBObject) rs.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
            list.add(mongoOrder);
        }

        return list;
    }

    @Override
    public List<UserProduct> getUserProducts(String merchantId, String lenovoId, String startTime, String endTime) {
        DBObject ref = new BasicDBObject();
        ref.put("lenovoId", lenovoId);

        ref.put("shopId", merchantId);
//        ref.put("payStatus", "2");
        ref.put("orderStatus", "7");
        searchDateScope(startTime,endTime,ref);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        DBObject orderBy = new BasicDBObject("createTime", -1);
        DBCursor rs = getMCollectionByMerchantId(merchantId).find(ref);
        rs = rs.sort(orderBy);
        List<UserProduct> userProducts = new ArrayList<UserProduct>();
        Map<String, Integer> map = new HashMap<String, Integer>();
        while (rs.hasNext()) {
            DBObject dbObject = (DBObject) rs.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
            if(mongoOrder.getProducts() != null){
                for (Product p : mongoOrder.getProducts()) {
                    if(map.get(p.getProductCode())!=null)
                        continue;
                    map.put(p.getProductCode(),1);
                    UserProduct up = new UserProduct();
                    up.setGcode(p.getProductCode());
                    up.setGname(p.getProductName());
                    up.setGexchange("");//换货状态，为空表示不是换货状态
                    up.setEvalstatus("");//评价状态  为空表示没有评价
                    up.setGdesc(p.getProductDesc());
                    up.setGphoto(p.getProductPhoto());
                    up.setGprice(p.getProductPay());
                    up.setGrealprice(p.getProductPay().multiply(new BigDecimal(p.getProductNumber())).subtract(p.getFavourablePay()));
                    up.setGspec(p.getSpecification());
                    up.setGcount(p.getProductNumber());
                    up.setOrderTime(mongoOrder.getCreateTime());
                    userProducts.add(up);
                }
            }
        }
        return userProducts;
    }

    public List<MongoOrderDetail> getTotalZCMongoOrderList(String merchantId, String lenovoId, String startTime, String endTime, String searchtext, String payStatus) {

        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();
        DBObject ref = new BasicDBObject();
        //ref.put("payStatus", new BasicDBObject("$ne", "3"));//去除预约订单
        ref.put("lenovoId", lenovoId);
        ref.put("shopId", merchantId);
        ref.put("orderAddType",  OrderMainConstant.ADD_TYPE_RAISE);
//        BasicDBList values1 = new BasicDBList();
//        values1.add(OrderMainConstant.ADD_TYPE_RAISE);
//        values1.add(OrderMainConstant.ADD_TYPE_GROUPPURCHASE);
//        ref.put("orderAddType", new BasicDBObject("$nin", values1));//排除众筹团购订单
//        BasicDBList dbList = new BasicDBList();//isDelete不存在或者为0正常订单 1代表已删除 2代表回收站彻底删除
//        dbList.add(new BasicDBObject("isDelete", new BasicDBObject("$exists", false)));//过滤掉已删除的订单
//        dbList.add(new BasicDBObject("isDelete", "0"));
//        ref.put("$or", dbList);
        if(!StringUtil.isEmpty(payStatus)){
            ref.put("payStatus",payStatus);
        }
        //订单查询时间范围
        searchDateScope(startTime, endTime, ref);
        //根据商品编号/商品名称/订单编号查询
        if(searchtext != null && !"".equals(searchtext)){
            BasicDBList values = new BasicDBList();
            Pattern pattern = Pattern.compile("^.*"+searchtext+".*$", Pattern.CASE_INSENSITIVE);
            values.add(new BasicDBObject("products.productCode", pattern));
            values.add(new BasicDBObject("products.productName", pattern));
            values.add(new BasicDBObject("orderCode", pattern));
            ref.put("$or", values);
        }
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        DBObject orderBy = new BasicDBObject("createTime", -1);
        DBCursor rs = getMCollectionByMerchantId(merchantId).find(ref);
        rs = rs.sort(orderBy);
        while (rs.hasNext()) {
            DBObject dbObject = (DBObject) rs.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
            list.add(mongoOrder);
        }

        return list;
    }

    @Override
    public List<MongoOrderDetail> getOrderDetailByOrderMainCode(String orderno, String shopId) {
        BasicDBObjectBuilder start = BasicDBObjectBuilder.start();
        if (orderno != null) {
            start = start.add("orderMainCode", orderno);
        }
        DBObject ref = start.get();
        ref.put("shopId",shopId);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        ref.put("lenovoId",ThreadLocalSessionTenant.getLocalLenovoId());
        logger.info("ref=============={}",JsonUtil.toJson(ref));
        DBCursor cur = getMCollectionByMerchantId("1").find(ref);
        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();
        while (cur.hasNext()) {
            DBObject dbObject = (DBObject) cur.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
            logger.info("mongoOrder==={}", JsonUtil.toJson(mongoOrder));
            list.add(mongoOrder);
        }
        return list;
    }

    @Override
    public MongoOrderDetail getOrderByOrdercode(String ordercode, String merchantId) {

        BasicDBObjectBuilder start = BasicDBObjectBuilder.start();


        if (ordercode != null) {
            start = start.add("orderCode", ordercode);
        }
        DBObject ref = start.get();
//        BasicDBList dbList = new BasicDBList();//isDelete不存在或者为0正常订单 1代表已删除 2代表回收站彻底删除
//        dbList.add(new BasicDBObject("activeStatus", new BasicDBObject("$exists", false)));//过滤掉已删除的订单
//        dbList.add(new BasicDBObject("activeStatus", "1"));
//        ref.put("$or",dbList);
        ref.put("shopId",merchantId);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        ref.put("orderCode",ordercode);
        ref.put("lenovoId",ThreadLocalSessionTenant.getLocalLenovoId());
        DBCursor cur = getMCollectionByMerchantId(merchantId).find(ref).limit(1);
        MongoOrderDetail mongoOrder = null;
        if (cur.hasNext()) {
            DBObject dbObject = (DBObject) cur.next();

            mongoOrder = MongoBeanUtil.dbObject2Bean(dbObject, new MongoOrderDetail());
        }
        return mongoOrder;
    }




    @Override
    public int updateMongoOrder(String merchantId,String orderCode, String field, String parameter) {

        DBObject obj = BasicDBObjectBuilder.start()
                .add("orderCode", orderCode).add("shopId",merchantId).add("activeStatus", "1").add("lenovoId",ThreadLocalSessionTenant.getLocalLenovoId()).get();
//        BasicDBList dbList = new BasicDBList();//isDelete不存在或者为0正常订单 1代表已删除 2代表回收站彻底删除
//        dbList.add(new BasicDBObject("activeStatus", new BasicDBObject("$exists", false)));//过滤掉已删除的订单
////        dbList.add(new BasicDBObject("activeStatus", "1"));
//        obj.put("$or",dbList);
        DBCursor cur = getMCollectionByMerchantId(merchantId).find(obj).limit(1);
        DBObject dbObject = null;
        if (cur.hasNext()) {
            dbObject = (DBObject) cur.next();
            dbObject.put(field, parameter);
            return getMCollectionByMerchantId(merchantId).update(obj,dbObject).getLastError().ok()?1:0;
        }
        return 0;
    }

    @Override
    public int updateMongoOrder2(String merchantId, String orderCode, Map<String, String> map) {
        DBObject obj = BasicDBObjectBuilder.start()
//                .add("orderCode", orderCode).get();

                .add("orderCode", orderCode).add("shopId",merchantId).add("activeStatus", "1").add("lenovoId",ThreadLocalSessionTenant.getLocalLenovoId()).get();

//        BasicDBList dbList = new BasicDBList();//isDelete不存在或者为0正常订单 1代表已删除 2代表回收站彻底删除
//        dbList.add(new BasicDBObject("activeStatus", new BasicDBObject("$exists", false)));//过滤掉已删除的订单
//        dbList.add(new BasicDBObject("activeStatus", "1"));
//        obj.put("$or",dbList);
        DBCursor cur = getMCollectionByMerchantId(merchantId).find(obj).limit(1);
        DBObject dbObject = null;
        Iterator<String> iter = map.keySet().iterator();
        if (cur.hasNext()) {
            dbObject = (DBObject) cur.next();
            while (iter.hasNext()) {
                String field = iter.next();
                String parameter = (String) map.get(field);
                dbObject.put(field, parameter);
            }

            return getMCollectionByMerchantId(merchantId).update(obj,dbObject).getLastError().ok()?1:0;
        }
        return 0;
    }

    @Override
    public int updateMongoOrderProduct(String merchantId, String orderCode, String productCode,String field, String parameter) {
        DBObject obj = BasicDBObjectBuilder.start()
                .add("orderCode", orderCode).add("shopId",merchantId).add("activeStatus", "1").add("lenovoId",ThreadLocalSessionTenant.getLocalLenovoId()).get();
//        BasicDBList dbList = new BasicDBList();//isDelete不存在或者为0正常订单 1代表已删除 2代表回收站彻底删除
//        dbList.add(new BasicDBObject("activeStatus", new BasicDBObject("$exists", false)));//过滤掉已删除的订单
//        dbList.add(new BasicDBObject("activeStatus", "1"));
//        obj.put("$or",dbList);
        DBCursor cur = getMCollectionByMerchantId(merchantId).find(obj).limit(1);
        DBObject dbObject = null;
        if (cur.hasNext()) {
            dbObject = (DBObject) cur.next();
            BasicDBList plist = (BasicDBList)dbObject.get("products");
            for(int i=0;i<plist.size();i++){
                BasicDBObject product = (BasicDBObject)plist.get(i);
                if (productCode.equals(product.get("productCode"))){
                    product.put(field,parameter);
                    break;
                }
            }
            return getMCollectionByMerchantId(merchantId).update(obj,dbObject).getLastError().ok()?1:0;
        }
        return 0;
    }
    /**
     * 根据merchantId 获取数据源
     * 1--商城
     * 2--EPP
     * 3--神奇工程 --无用
     * 4--roming --无用
     * 5--Think
     * @param merchantId
     * @return
     */
    public DBCollection getMCollectionByMerchantId(String merchantId){
        return getMCollection();
    }

}
