package com.lenovo.m2.web.remote.purchase.member.impl;

import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.HttpUtil;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.remote.purchase.member.MemberInfoService;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service("memberInfoService")
public class MemberInfoServiceImpl implements MemberInfoService {
	 private static Logger logger =  LogManager.getLogger(MemberInfoServiceImpl.class.getName());

	/**
	 * url:
	 * http://10.99.121.57:8080/user/get_info?lenovoId=567894&ticket=5e9b6d3d-4500-47fc-b32b-f2b4a1230fd3
	 *
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> getInfo(String lenovoId) {
		String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
		String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
		String url = String.format("%s/user/get_info?lenovoId=%s&ticket=%s", host, lenovoId, ticket);
		//接口失败返回null
		String res = HttpUtil.getStr(url);
		
		if(StringUtils.isEmpty(res)){
			throw new RuntimeException("获取用户信息失败");
		}
		Map<String, Object> map = JsonUtil.fromJson(res, Map.class);
						
		return map;
	}
//    public MemberRemoteVo getInfoObject(String lenovoId) {
//        String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//        String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//        String url = String.format("%s/user/get_info?lenovoId=%s&ticket=%s", host, lenovoId, ticket);
//        //接口失败返回null
//        String res = HttpUtil.getStr(url);
//
//        if(res == null){
//            throw new RuntimeException("获取用户信息失败");
//        }
//        Map<String, Object> map = JsonUtil.fromJson(res, Map.class);
//        String ret = map.get("ret")+"";
//
//        MemberRemoteVo memberRemoteVo = new MemberRemoteVo();
//        memberRemoteVo.setRet(ret);
//        memberRemoteVo.setMsg(map.get("msg")!=null?(String)map.get("msg"):"");
//        if("0".equals(ret)){//成功
//            MemberRemote memberRemote = JsonUtil.fromJson(res,MemberRemote.class);
//            memberRemoteVo.setMemberRemote(memberRemote);
//        }
//        return memberRemoteVo;
//    }
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> isexist(String lenovoId) {
//		String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//		String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//		// String ticket="5e9b6d3d-4500-47fc-b32b-f2b4a1230fd3";
//		String url = host+"/user/is_exist?";
//		url += "lenovoId=" + lenovoId + "&ticket=" + ticket;
//		// HttpGet get = new
//		// HttpGet("http://10.99.121.57:8080/user/get_info?"+"lenovoId="+lenovoId+"&ticket="+ticket);
//		HttpGet get = new HttpGet(url);
//		get.setHeader("Connection", "close");
//		Map<String, Object> map = new HashMap<String, Object>();
//		HttpResponse _response;
//
//		try {
//			_response = HttpUtil.executeProxy(get);
//			BufferedReader in = new BufferedReader(new InputStreamReader(
//					_response.getEntity().getContent()));
//			StringBuffer sb = new StringBuffer("");
//			String line = "";
//			String NL = System.getProperty("line.separator");
//			while ((line = in.readLine()) != null) {
//				sb.append(line + NL);
//			}
//			in.close();
//			map = JsonUtil.fromJson(sb.toString(), Map.class);
//			// map ret 0:成功
//			// result ture/false
//		} catch (Exception e) {
//			logger.error(e);
//		}finally{
//			get.releaseConnection();
//		}
//		return map;
//
//	}
//
//
//	  //map ret	0:成功
//	  //UserInfo   发送到CERP的实体
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> regist(String loginname,String lenovoId) {
//		String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//		String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//		// String ticket="5e9b6d3d-4500-47fc-b32b-f2b4a1230fd3";
//		String url = host+"/user/regist?";
//		// HttpGet get = new
//		// HttpGet("http://10.99.121.57:8080/user/get_info?"+"lenovoId="+lenovoId+"&ticket="+ticket);
//		HttpPost post = new HttpPost(url);
//		post.setHeader("Connection", "close");
//        List<NameValuePair> params = new ArrayList<NameValuePair>();
//        params.add(new BasicNameValuePair("loginname", loginname));
//        params.add(new BasicNameValuePair("lenovoId",lenovoId));
//    	params.add(new BasicNameValuePair("ticket", ticket));
//		Map<String, Object> map = new HashMap<String, Object>();
//		HttpResponse _response;
//		try {
//
//			post.setEntity(new UrlEncodedFormEntity(params,"UTF-8"));
//			_response = HttpUtil.executeProxy(post);
//			BufferedReader in = new BufferedReader(new InputStreamReader(
//					_response.getEntity().getContent()));
//			StringBuffer sb = new StringBuffer("");
//			String line = "";
//			String NL = System.getProperty("line.separator");
//			while ((line = in.readLine()) != null) {
//				sb.append(line + NL);
//			}
//			in.close();
//			map = JsonUtil.fromJson(sb.toString(), Map.class);
//
//		} catch (Exception e) {
//			logger.error(e);
//		}finally{
//			post.releaseConnection();
//		}
//		return map;
//
//	}
//
//
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> updateMemberInfo(MemberRemote memberRemote) {
//
//        String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//        String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//        String url = host+"/user/update_info?";
//        HttpPost post = new HttpPost(url);
//
//        post.setHeader("Connection", "close");
//        Map<String, Object> map = new HashMap<String, Object>();
//
//		List<NameValuePair> params = new ArrayList<NameValuePair>();
//		params.add(new BasicNameValuePair("lenovoId", memberRemote.getLenovoId()));
//		params.add(new BasicNameValuePair("loginname", memberRemote.getLoginname()));
//		params.add(new BasicNameValuePair("username", memberRemote.getUsername()));
//		params.add(new BasicNameValuePair("realname", memberRemote.getRealname()));
//		params.add(new BasicNameValuePair("gender", memberRemote.getGender()));
//		params.add(new BasicNameValuePair("birthyear", memberRemote.getBirthyear()));
//		params.add(new BasicNameValuePair("birthmonth", memberRemote.getBirthmonth()));
//		params.add(new BasicNameValuePair("birthday", memberRemote.getBirthday()));
//		params.add(new BasicNameValuePair("mobile", memberRemote.getMobile()));
//		params.add(new BasicNameValuePair("email", memberRemote.getEmail()));
//		params.add(new BasicNameValuePair("ticket", ticket));
//		HttpResponse _response;
//		try {
//
//			post.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
//			_response = HttpUtil.executeProxy(post);
//			BufferedReader in = new BufferedReader(new InputStreamReader(
//					_response.getEntity().getContent(),"UTF-8"));
//			StringBuffer sb = new StringBuffer("");
//			String line = "";
//			String NL = System.getProperty("line.separator");
//			while ((line = in.readLine()) != null) {
//				sb.append(line + NL);
//			}
//			in.close();
//			map = JsonUtil.fromJson(sb.toString(), Map.class);
//
//		} catch (Exception e) {
//			logger.error(e);
//
//		}finally{
//			post.releaseConnection();
//		}
//		return map;
//	}
//
//
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> addScore(String lenovoId){
//		String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//		String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//		String url = host+"/score/add?";
//		url += "lenovoId=" + lenovoId + "&ticket=" + ticket+"&scoreType=5001&bizId=&bizDesc=";
//		HttpGet get = new HttpGet(url);
//		get.setHeader("Connection", "close");
//        Map<String, Object> map = new HashMap<String, Object>();
//        HttpResponse _response;
//        try {
//            _response = HttpUtil.executeProxy(get);
//            BufferedReader in = new BufferedReader(new InputStreamReader(
//                    _response.getEntity().getContent(),"UTF-8"));
//            StringBuffer sb = new StringBuffer("");
//            String line = "";
//            String NL = System.getProperty("line.separator");
//            while ((line = in.readLine()) != null) {
//                sb.append(line + NL);
//            }
//            in.close();
//            map = JsonUtil.fromJson(sb.toString(), Map.class);
//        } catch (Exception e) {
//            logger.error(e);
//
//        }finally{
//			get.releaseConnection();
//		}
//        return map;
//    }
//
//	@Override
//	@SuppressWarnings("unchecked")
//	public Map<String, Object> getScore(String lenovoId) {
//		String host = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoHost");
//		String ticket = (String) CustomizedPropertyConfigurer.getContextProperty("lenovoTicket");
//		String url = host+"/score/shoplogin.action?";
//		url += "lenovoId=" + lenovoId + "&ticket=" + ticket+"&bizId=&bizDesc=";
//		HttpGet get = new HttpGet(url);
//		get.setHeader("Connection", "close");
//        Map<String, Object> map = new HashMap<String, Object>();
//        HttpResponse _response;
//        try {
//            _response = HttpUtil.executeProxy(get);
//            BufferedReader in = new BufferedReader(new InputStreamReader(
//                    _response.getEntity().getContent(),"UTF-8"));
//            StringBuffer sb = new StringBuffer("");
//            String line = "";
//            String NL = System.getProperty("line.separator");
//            while ((line = in.readLine()) != null) {
//                sb.append(line + NL);
//            }
//            in.close();
//            //"ret":0,"shopScore":5898.0}
//            map = JsonUtil.fromJson(sb.toString(), Map.class);
//
//        } catch (Exception e) {
//            logger.error(e);
//
//        }finally{
//			get.releaseConnection();
//		}
//        return map;
//	}
}
