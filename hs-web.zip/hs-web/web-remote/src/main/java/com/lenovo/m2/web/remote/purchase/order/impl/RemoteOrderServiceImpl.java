package com.lenovo.m2.web.remote.purchase.order.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.purchase.param.*;
import com.lenovo.m2.hsbuy.domain.purchase.result.CheckOutResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.GetCartNGResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.SubmitOrderResult;
import com.lenovo.m2.hsbuy.purchase.NorderService;
import com.lenovo.m2.web.remote.purchase.order.RemoteOrderService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 
* @ClassName: RemoteOrderServiceImpl 
* @Description: 订单实现
* @author yuzj7@lenovo.com 
* @date 2016年3月8日 下午3:44:39 
*
 */
@Service
public class RemoteOrderServiceImpl implements RemoteOrderService {
    private static Logger log =  LogManager.getLogger(RemoteOrderServiceImpl.class.getName());

	@Autowired
	private NorderService norderService;

	@Override
	public RemoteResult<CheckOutResult> checkout(Tenant tenant, CheckOutParam checkOutParam) {
		try {
			log.info("checkout参数:tenant={},checkOutParam={}",tenant,checkOutParam);
			return norderService.checkout(tenant,checkOutParam);
		} catch (Exception e) {
			log.error("checkout 远程接口异常:", e);
			return null;
		}
	}

	@Override
	public RemoteResult<SubmitOrderResult> submitOrder(Tenant tenant, SubmitOrderParam submitOrderParam) {
		try {
			log.info("submitOrder 参数: tenant ={}, submitOrderParam ={}",tenant,submitOrderParam);
			return norderService.submitOrder(tenant,submitOrderParam);
		} catch (Exception e) {
			log.error("submitOrder 远程接口异常:", e);
			return null;
		}
	}

	@Override
	public RemoteResult<GetCartNGResult> getCartNG(Tenant tenant, GetCartNGParam cartNGParam) {
		try {
			log.info("getCartNG 参数: tenant ={}, submitOrderParam ={}",tenant,cartNGParam);
			return norderService.getCartNG(tenant,cartNGParam);
		} catch (Exception e) {
			log.error("getCartNG 远程接口异常:", e);
			return null;
		}
	}

	/**
	 * 发送订单信息给CPS
	 * @param orderNum
	 * @return
	 */
	@Override
	public RemoteResult<String> sendOrderInfoToCPS(Tenant tenant, Long orderNum) {
		try {
			log.info("sendOrderInfoToCPS 参数: tenant ={}, orderNum ={}",tenant,orderNum);
			return norderService.sendOrderInfoToCPS(tenant,orderNum);
		}catch(Exception e){
			log.error("sendOrderInfoToCPS 远程接口异常:", e);
			return null;
		}
	}


}
