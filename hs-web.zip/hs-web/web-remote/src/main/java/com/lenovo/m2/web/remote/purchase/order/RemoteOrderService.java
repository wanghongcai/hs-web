package com.lenovo.m2.web.remote.purchase.order;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.purchase.param.*;
import com.lenovo.m2.hsbuy.domain.purchase.result.CheckOutResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.GetCartNGResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.SubmitOrderResult;
import scala.Int;

/**
 * 
* @ClassName: RemoteOrderService 
* @Description: 订单接口
* @author yuzj7@lenovo.com 
* @date 2016年3月8日 下午3:35:05 
*
 */
public interface RemoteOrderService {


	RemoteResult<CheckOutResult> checkout(Tenant tenant, CheckOutParam checkOutParam);

	RemoteResult<SubmitOrderResult> submitOrder(Tenant tenant, SubmitOrderParam submitOrderParam);

	RemoteResult<GetCartNGResult> getCartNG(Tenant tenant, GetCartNGParam cartNGParam);

	RemoteResult<String> sendOrderInfoToCPS(Tenant tenant, Long orderNum);


}
