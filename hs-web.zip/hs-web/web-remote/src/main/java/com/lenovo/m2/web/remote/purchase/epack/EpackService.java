package com.lenovo.m2.web.remote.purchase.epack;

/**
 * Created by fenglg1 on 2016/11/10.
 */
public interface EpackService {

    /**
     * Check SN
     * @param wsdlLocation
     * @param SNCode
     * @param materialCode
     * @param epackUsername
     * @param epackPassword
     * @return
     */
    public boolean checkSN(String wsdlLocation, String SNCode, String materialCode, String epackUsername, String epackPassword);
}
