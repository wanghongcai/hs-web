package com.lenovo.m2.web.remote.purchase.invoice;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;

import java.util.List;

/**
 * Created by D_xiao on 2017/6/8.
 */
public interface CommonInvoiceRemoteService {

    /**
     * 普通发票和电子发票的保存
     * @param vatInvoice
     * @return
     */
    public RemoteResult<VatInvoice> saveInvoice(VatInvoice vatInvoice, Tenant tenant);



    /**
     * 通过title带出发票信息
     * @param vatInvoice
     * @return
     */
    public RemoteResult<VatInvoice> getInvoiceByTitle(VatInvoice vatInvoice, Tenant tenant);


    /**
     * 公司普票下拉列表
     * @param lenovoId
     * @param tenant
     * @return
     */
    public RemoteResult<List<VatInvoice>> getInvoiceByUser(String lenovoId, Tenant tenant);



}
