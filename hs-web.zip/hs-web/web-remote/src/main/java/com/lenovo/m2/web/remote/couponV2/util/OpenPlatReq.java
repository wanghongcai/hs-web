package com.lenovo.m2.web.remote.couponV2.util;

import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OpenPlatReq {

    static final Logger log = LoggerFactory.getLogger(OpenPlatReq.class);

    private String method;
    private String timestamp;
    private String v = "1.0";
    private String lenovo_param_json;
    private String app_key;
    private String secretKey;

   
    private static String DEFAULT_APP_KEY  =  CustomizedPropertyConfigurer.getContextProperty("openplat_app_key");
    private static String DEFAULT_SECRETKEY =  CustomizedPropertyConfigurer.getContextProperty("openplat_secretkey");
    public OpenPlatReq(String method, String paramBody){
        this.method = method;
        this.lenovo_param_json = paramBody;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        this.app_key = DEFAULT_APP_KEY;
        this.secretKey = DEFAULT_SECRETKEY;
       
    }

    public OpenPlatReq(String method, String paramBody, String app_key, String secretKey){
        this.method = method;
        this.lenovo_param_json = paramBody;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        this.app_key = app_key;
        this.secretKey = secretKey;
    }




    /**
     *
     * @param
     * @return
     */
     private String getPlain(){
        StringBuilder sb = new StringBuilder(128);
                sb.append("app_key").append(app_key)
                .append("lenovo_param_json").append(this.lenovo_param_json)
                .append("method").append(this.method)
                .append("timestamp").append(this.timestamp)
                .append("v").append(this.v);
        return sb.toString();
    }


    public String getPostBody(){
        String origPlain = getPlain();
        String plain = String.format("%s%s%s", this.secretKey, origPlain, this.secretKey);
        String sign  = md5Sum(plain);

        StringBuilder sb = new StringBuilder();
        sb.append("app_key").append('=').append(app_key).append('&')
                .append("lenovo_param_json").append('=').append(this.lenovo_param_json).append('&')
                .append("method").append('=').append(this.method).append('&')
                .append("timestamp").append('=').append(this.timestamp).append('&')
                .append("v").append('=').append(this.v).append('&')
                .append("&sign=").append(sign);

        log.info("plain={}, sign={}, post body={}", new Object[]{plain, sign, sb.toString()});

        return sb.toString();
    }


    private String md5Sum(String plain){
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
            String md5 =  new String(Hex.encodeHex(md.digest(plain.getBytes(Charset.forName("UTF-8")))));
            return md5.toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


public static void main(String[] args){



    String str = new OpenPlatReq("12345","12345","12345","12345").md5Sum("testapp_keytestlenovo_param_json{}methodlenovo_testtimestamp2016-07-26 09:58:51test");

    System.out.println(str);


}



}