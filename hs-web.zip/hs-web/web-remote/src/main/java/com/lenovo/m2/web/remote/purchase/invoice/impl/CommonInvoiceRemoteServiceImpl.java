package com.lenovo.m2.web.remote.purchase.invoice.impl;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;
import com.lenovo.m2.hsbuy.invoice.CommonInvoiceService;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.remote.purchase.invoice.CommonInvoiceRemoteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by D_xiao on 2017/6/8.
 */
@Service
public class CommonInvoiceRemoteServiceImpl implements CommonInvoiceRemoteService {

    private static Logger logger = LogManager.getLogger(CommonInvoiceRemoteServiceImpl.class.getName());

    @Autowired
    private CommonInvoiceService commonInvoiceService;

    @Override
    public RemoteResult<VatInvoice> saveInvoice(VatInvoice vatInvoice, Tenant tenant) {
        try {
            logger.info("[ saveInvoice 参数] : {}", JsonUtil.toJson(vatInvoice));
            RemoteResult<VatInvoice> remoteResult = commonInvoiceService.saveInvoice(vatInvoice,tenant);
            logger.info("[ saveInvoice 返回] : {}",JsonUtil.toJson(remoteResult));
            return remoteResult;
        }catch(Exception e){
            logger.error("[ saveInvoice 异常 ]:",e);
            return null;
        }
    }

    @Override
    public RemoteResult<VatInvoice> getInvoiceByTitle(VatInvoice vatInvoice,Tenant tenant) {
        try{
            logger.info("[ getInvoiceByTitle 参数] : {}", JsonUtil.toJson(vatInvoice));
            RemoteResult<VatInvoice> remoteResult = commonInvoiceService.getInvoiceByTitle(vatInvoice,tenant);
            logger.info("[ getInvoiceByTitle 返回] : {}",JsonUtil.toJson(remoteResult));
            return remoteResult;
        }catch(Exception e){
            logger.error("[ getInvoiceByTitle 异常]: ",e);
            return null;
        }
    }

    @Override
    public RemoteResult<List<VatInvoice>> getInvoiceByUser(String lenovoId, Tenant tenant) {
        try{
            logger.info("[ getInvoiceByUser 参数] lenovoId:{},tenant: {}",lenovoId, JsonUtil.toJson(tenant));
            RemoteResult<List<VatInvoice>> remoteResult = null; //TODO //commonInvoiceService.getInvoiceByUser(lenovoId,tenant);
            logger.info("[ getInvoiceByUser 返回] : {}",JsonUtil.toJson(remoteResult));
            return remoteResult;
        }catch(Exception e){
            logger.error("[ getInvoiceByUser 异常]: ",e);
            return null;
        }
    }
}
