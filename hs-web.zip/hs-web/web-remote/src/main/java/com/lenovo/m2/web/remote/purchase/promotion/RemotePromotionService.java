package com.lenovo.m2.web.remote.purchase.promotion;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.bee.PromotionInfo;


/**
 * c2c/cps推广信息接口
 */
public interface RemotePromotionService {

	/**
	 * cps、c2c提交订单后 将推广信息推送给分流系统调用此接口
	 * @param var1
	 * @return
     */
	RemoteResult<Boolean> pushPromotionInfo(PromotionInfo var1, Tenant tenant);
}
