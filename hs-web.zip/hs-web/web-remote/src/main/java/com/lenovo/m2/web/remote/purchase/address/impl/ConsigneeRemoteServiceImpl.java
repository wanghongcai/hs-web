package com.lenovo.m2.web.remote.purchase.address.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.address.AddressService;
import com.lenovo.m2.hsbuy.domain.address.AddressLog;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeAddressParam;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;
import com.lenovo.m2.hsbuy.domain.address.param.QueryAddressParam;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.remote.purchase.address.ConsigneeRemoteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: hukun2
 * Date: 16-3-3
 * Time: 下午8:48
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ConsigneeRemoteServiceImpl implements ConsigneeRemoteService {

    private static Logger log = LogManager.getLogger(AddressRemoteServiceImpl.class.getName());

    @Autowired
    public AddressService addressService;

    /**
     * 保存收货地址
     * @param tenant
     * @param consigneeAddressParam
     * @return
     */
    @Override
    public RemoteResult<String> saveConsignee(Tenant tenant, ConsigneeAddressParam consigneeAddressParam) {
        try {
            log.info("调用 saveConsignee 入参:Tenant:{},ConsigneeAddressParam:{}",tenant,JsonUtil.toJson(consigneeAddressParam));
            RemoteResult<String> result =  addressService.saveAddress(tenant,consigneeAddressParam);
            log.info("调用saveConsignee成功!返回={}", JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程saveConsignee接口异常,",e);
            return null;
        }
    }

    /**
     * 更新收货地址
     * @param tenant
     * @param consigneeAddressParam
     * @return
     */
    @Override
    public RemoteResult<Integer> updateConsignee(Tenant tenant, ConsigneeAddressParam consigneeAddressParam) {
        try {
            log.info("调用 updateConsignee 入参:Tenant:{},ConsigneeAddressParam:{}",tenant,JsonUtil.toJson(consigneeAddressParam));
            RemoteResult<Integer> result = addressService.updateAddress(tenant, consigneeAddressParam);
            if (result.isSuccess() && result != null) {
                result.setResultCode("0");
                result.setResultMsg("success");
                result.setSuccess(true);
                log.info("调用updateConsignee成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else{
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务updateAddress接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程updateConsignee接口异常,",e);
            return null;
        }
    }

    /**
     * 通过地址 ID 删除地址
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @Override
    public RemoteResult<Integer> deleteConsignee(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 deleteConsignee 入参:Tenant:{},consigneeParam:{}",tenant,JsonUtil.toJson(consigneeParam));
            RemoteResult<Integer> result = addressService.deleteAddress(tenant, consigneeParam);
            if (result.isSuccess() && result != null) {
                result.setResultCode("0");
                result.setResultMsg("success");
                result.setSuccess(true);
                log.info("调用deleteConsignee成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else {
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务deleteAddress接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程deleteConsignee接口异常,",e);
            return null;
        }
    }

    /**
     * 根据用户ID，获取收货人所有收货地址信息
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @Override
    public RemoteResult<List<Memberaddrs>> getConsignees(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 getConsignees 入参:Tenant:{},consigneeParam:{}",tenant,JsonUtil.toJson(consigneeParam));
            RemoteResult<List<Memberaddrs>> result = addressService.getAddressListByUser(tenant, consigneeParam);
            if (result.isSuccess() && result != null ) {
                result.setResultCode("0");
                result.setResultMsg("success");
                result.setSuccess(true);
                log.info("调用getConsignees成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else {
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getAddressListByUser接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getAddressListByUser接口异常,",e);
            return null;
        }
    }

    /**
     * 通过用户ID和地址ID，获取收货地址信息
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @Override
    public RemoteResult<Memberaddrs> getConsigneeById(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 getConsigneeById 入参:Tenant:{},consigneeParam:{}",tenant,JsonUtil.toJson(consigneeParam));
            RemoteResult<Memberaddrs> result = addressService.getAddressById(tenant, consigneeParam);
            if (result.isSuccess() && result != null ) {
                result.setResultCode("0");
                result.setSuccess(true);
                result.setResultMsg("success");
                log.info("getConsigneeById!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else {
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getAddressById接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getAddressById接口异常,",e);
            return null;
        }
    }

    /**
     * 个人中心获取用户地址总条数
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @Override
    public RemoteResult<Integer> getCountByType(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 getCountByType 入参:Tenant:{},consigneeParam:{}",tenant,JsonUtil.toJson(consigneeParam));
            RemoteResult<Integer> result = addressService.getAddressCount(tenant, consigneeParam);
            if (result.isSuccess() && result != null ) {
                result.setResultCode("0");
                result.setResultMsg("success");
                result.setSuccess(true);
                log.info("调用getCountByType成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else{
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getAddressCount接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getCountByType接口异常,",e);
            return null;
        }
    }

    /**
     * 分页查询用户地址
     * @param tenant
     * @param consigneeParam
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public RemoteResult<Map<String, Object>> getListPageByType(Tenant tenant, ConsigneeParam consigneeParam, int pageNum, int pageSize) {
        log.info("调用 getListPageByType 入参:Tenant:{},consigneeParam:{},pageNum:{},pageSize:{}",tenant,JsonUtil.toJson(consigneeParam),pageNum,pageSize);
        RemoteResult remoteResult = new RemoteResult<>(false);
        if(tenant == null || consigneeParam == null || StringUtil.isEmpty(consigneeParam.getLenovoId(), consigneeParam.getType())) {
            remoteResult.setResultCode(ErrorMessageEnum.ERROR_PARAM.getCode() + "");
            remoteResult.setResultMsg(ErrorMessageEnum.ERROR_PARAM.getCommon());
            return remoteResult;
        }
        try {
            RemoteResult<Integer> reCount = addressService.getAddressCount(tenant, consigneeParam);
            log.info("getListPageByType consigneeRemoteService.getCountByType return :{}", reCount);
            RemoteResultUtil.updateMsg(reCount, PromptEnum.ADDRESS);
            if(!reCount.isSuccess()) {
                remoteResult.setResultCode(reCount.getResultCode());
                remoteResult.setResultMsg(reCount.getResultMsg());
                return remoteResult;
            }
            int totalCount = reCount.getT();
            if(totalCount == 0) {
                Map<String, Object> map = new HashMap<>(2);
                map.put("totalCount", totalCount);
                map.put("totalPage", 0);
                map.put("currentPage", pageNum);
                map.put("list", new ArrayList<>(1));
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(ErrorMessageEnum.SUCCESS.getCode() + "");
                remoteResult.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                remoteResult.setT(map);
                return remoteResult;
            }
            if(pageSize > 10) {
                pageSize = 10;
            }
            int totalPage = totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1;
            if(pageNum < 0) {
                pageNum = 1;
            } else if(pageNum > totalPage) {
                pageNum = totalPage;
            }
            PageQuery pageQuery = new PageQuery(pageNum, pageSize);

            RemoteResult<List<Memberaddrs>> r = addressService.getAddressListByPage(tenant, consigneeParam, pageQuery);
            //log.info("getListPageByType consigneeRemoteService.getListPageByType return :{}", r);
            RemoteResultUtil.updateMsg(r, PromptEnum.ADDRESS);
            if(!r.isSuccess()) {
                remoteResult.setResultCode(r.getResultCode());
                remoteResult.setResultMsg(r.getResultMsg());
                return remoteResult;
            }
            Map<String, Object> map = new HashMap<>(2);
            map.put("totalCount", totalCount);
            map.put("totalPage", totalPage);
            map.put("currentPage", pageNum);
            map.put("list", r.getT());
            remoteResult.setSuccess(true);
            remoteResult.setResultCode(ErrorMessageEnum.SUCCESS.getCode() + "");
            remoteResult.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            remoteResult.setT(map);
            return remoteResult;
        } catch(Exception e) {
            log.error("getListPageByType error", e);
            remoteResult.setResultCode(ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION.getCode() + "");
            remoteResult.setResultMsg(ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION.getCommon());
        }
        return remoteResult;
        /*RemoteResult<Map<String, Object>> result = new RemoteResult<>();
        try {
            log.info("调用 getListPageByType 入参:Tenant:{},consigneeParam:{},pageNum:{},pageSize:{}",tenant,JsonUtil.toJson(consigneeParam),pageNum,pageSize);
            PageQuery pageQuery = new PageQuery();
            pageQuery.setPageNum(pageNum);
            pageQuery.setPageSize(pageSize);


            RemoteResult<List<Memberaddrs>> pageBean = addressService.getAddressListByPage(tenant, consigneeParam, pageQuery);
            if (pageBean != null && pageBean.isSuccess()) {
                log.info("调用getListPageByType成功!返回={}", JsonUtil.toJson(pageBean));
                if(pageBean.getT() != null && pageBean.getT() != null && !pageBean.getT().isEmpty()){
                    List<Memberaddrs> pageModel = pageBean.getT();
                    Map<String, Object> pageMap = new HashMap<>();
                    pageMap.put("list", pageModel);
                    pageMap.put("totalPage", 1);
                    pageMap.put("totalCount", pageModel.size());
                    pageMap.put("currentPage", 1);
                    result.setT(pageMap);
                    result.setResultCode("0");
                    result.setSuccess(true);
                    result.setResultMsg("success");
                    RemoteResultUtil.updateMsg(pageBean, PromptEnum.CONSIGNEESERVICE);
                    return result;
                }else {
                    result.setResultCode("0");
                    result.setSuccess(false);
                    result.setResultMsg("success");
                    RemoteResultUtil.updateMsg(pageBean, PromptEnum.CONSIGNEESERVICE);
                    return result;
                }
            }else {
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getAddressByPage接口成功！但返回值异常", JsonUtil.toJson(pageBean));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getListPageByType接口异常,",e);
            result.setSuccess(false);
            return result;
        }*/
    }


    /**
     * 设置默认收货地址
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @Override
    public RemoteResult<Boolean> setDefaultConsignee(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 setDefaultConsignee 入参:Tenant:{},consigneeParam:{}",tenant,consigneeParam);
            RemoteResult<Boolean> result = addressService.setDefaultAddress(tenant, consigneeParam);
            if (result.isSuccess() && result !=  null ) {
                result.setResultMsg("success");
                result.setResultCode("0");
                result.setSuccess(true);
                log.info("调用setDefaultConsignee成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else{
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务setDefaultAddress接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程setDefaultConsignee接口异常,",e);
            return null;
        }
    }

    @Override
    public RemoteResult<Memberaddrs> getDefaultOrNewById(Tenant tenant, ConsigneeParam consigneeParam) {
        try {
            log.info("调用 getDefaultOrNewById 入参:Tenant:{},consigneeParam:{}",tenant,JsonUtil.toJson(consigneeParam));
            RemoteResult remoteResult = new RemoteResult<>(false);
            if(tenant == null || consigneeParam == null || StringUtil.isEmpty(consigneeParam.getLenovoId(), consigneeParam.getType())) {
                remoteResult.setResultCode(ErrorMessageEnum.ERROR_PARAM.getCode() + "");
                remoteResult.setResultMsg(ErrorMessageEnum.ERROR_PARAM.getCommon());
                return remoteResult;
            }
            // 获取地址列表
            PageQuery pageQuery = new PageQuery();
            pageQuery.setPageNum(1);
            pageQuery.setPageSize(1);

            QueryAddressParam queryAddressParam = new QueryAddressParam();
            queryAddressParam.setLenovoId(consigneeParam.getLenovoId());
            queryAddressParam.setType(consigneeParam.getType());
            queryAddressParam.setShopId(tenant.getShopId());
            RemoteResult<PageModel2<Memberaddrs>>  deliverList = null; //TODO //addressService.getAddressByPage(tenant, queryAddressParam, pageQuery);
            if(!deliverList.isSuccess()) {
                remoteResult.setResultCode(deliverList.getResultCode());
                remoteResult.setResultMsg(deliverList.getResultMsg());
                return remoteResult;
            }
            // 获取选中的收货地址，没有的使用默认地址
            RemoteResult<Memberaddrs> re = null;
            if(deliverList.getT() != null || !deliverList.getT().getDatas().isEmpty()) {
                if(StringUtil.isEmpty(consigneeParam.getId())) {
                    re = addressService.getPreferredAddress(tenant, consigneeParam);
                } else {
                    re = addressService.getAddressById(tenant, consigneeParam);
                }
                if(!re.isSuccess()) {
                    remoteResult.setResultCode(re.getResultCode());
                    remoteResult.setResultMsg(re.getResultMsg());
                    return remoteResult;
                }
                // 如果用户没有默认地址且用户有地址，则拿出第一条做默认地址显示
                if(null == re.getT() &&!deliverList.getT().getDatas().isEmpty()) {
                    remoteResult.setSuccess(true);
                    remoteResult.setT(deliverList.getT().getDatas().get(0));
                    remoteResult.setResultCode(deliverList.getResultCode());
                    remoteResult.setResultMsg(deliverList.getResultMsg());
                } else {
                    remoteResult.setSuccess(true);
                    remoteResult.setT(re.getT());
                    remoteResult.setResultCode(re.getResultCode());
                    remoteResult.setResultMsg(re.getResultMsg());
                }
            }
            return remoteResult;
        }catch(Exception e){
            log.error("调用远程getDefaultOrNewById接口异常,",e);
            return null;
        }
    }

    /**
     * 根据guid获取地址ID
     * @param tenant
     * @param guid
     * @return
     */
    @Override
    public RemoteResult<String> getIdByGuid(Tenant tenant, String guid) {
        try {
            log.info("调用 getIdByGuid 入参:Tenant:{},guid:{}",tenant,guid);
            RemoteResult<String> result = addressService.getIdByGuid(tenant, guid);
            if (result.isSuccess() && result != null) {
                log.info("调用getIdByGuid成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                result.setResultCode("0");
                result.setSuccess(true);
                result.setResultMsg("success");
                return result;
            }else{
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getIdByGuid接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getIdByGuid接口异常,",e);
            return null;
        }
    }

    /**
     * 查询smb未同步地址信息
     * @param tenant
     * @param count
     * @return
     */
    @Override
    public RemoteResult<List<AddressLog>> getNotSyncAddress(Tenant tenant, Integer count) {
        try {
            log.info("调用 getNotSyncAddress 入参:Tenant:{},count:{}",tenant,count == null? 0:count);
            RemoteResult<List<AddressLog>> result = addressService.getNotSyncAddress(tenant, count == null ? 0 : count);
            if (result.isSuccess() && result != null) {
                result.setResultCode("0");
                result.setResultMsg("success");
                result.setSuccess(true);
                log.info("调用getNotSyncAddress成功!返回={}", JsonUtil.toJson(result));
                RemoteResultUtil.updateMsg(result, PromptEnum.CONSIGNEESERVICE);
                return result;
            }else {
                result.setSuccess(false);
                result.setResultMsg("fail");
                log.info("调用远程AddressService服务getNotSyncAddress接口成功！但返回值异常", JsonUtil.toJson(result));
                return result;
            }
        }catch(Exception e){
            log.error("调用远程getNotSyncAddress接口异常,",e);
            return null;
        }
    }

//    public static void main(String[] args) {
//        RemoteResult result=null;
//        System.out.println(result.isSuccess());
//    }

}
