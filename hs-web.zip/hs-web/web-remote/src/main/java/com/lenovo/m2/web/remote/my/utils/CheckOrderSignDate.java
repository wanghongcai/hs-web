package com.lenovo.m2.web.remote.my.utils;

import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by yezhenyue on 2015/10/21.
 */
public class CheckOrderSignDate {
    private static final Logger logger = LogManager.getLogger(CheckOrderSignDate.class);

    /**
     * 判断订单签收日期是否满足退换货条件
     * @param mongoOrder
     * @return
     * // -1代表不可退不可换 0代表可退可换 1代表只可换
     */
        public static Integer checkDays(MongoOrderDetail mongoOrder){
            String tempDate = mongoOrder.getRreceiptDate();
            if (null==tempDate||"".equals(tempDate)){
                logger.info("\n\n\nmongo订单的签收日期为空\n\n\n");
                mongoOrder.setCheckSignState(-1);
                return -1;
            }
            SimpleDateFormat sdf =   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date receiptDate = null;
            try {
                receiptDate = sdf.parse(tempDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if(new Date().getTime() - receiptDate.getTime()<=1000*60*60*24*7){
                logger.info("\n\n\n该订单签收未满7天，可以申请退换货\n\n\n");
                mongoOrder.setCheckSignState(0);
                return 0;
            } else if(new Date().getTime() - receiptDate.getTime()<=1000*60*60*24*15){
                logger.info("\n\n\n该订单签收已过7天但未满15天，可以申请换货\n\n\n");
                mongoOrder.setCheckSignState(1);
                return 1;
            }else{
                logger.info("\n\n\n该订单签收后超过15天，无法退换货 \n\n\n");
                mongoOrder.setCheckSignState(-1);
                return -1;
            }

            }





}
