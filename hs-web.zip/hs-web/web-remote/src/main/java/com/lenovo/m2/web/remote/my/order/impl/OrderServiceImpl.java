package com.lenovo.m2.web.remote.my.order.impl;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.credit.api.dubboService.CreditService;
import com.lenovo.m2.credit.api.model.CreditInfoApi;
import com.lenovo.m2.credit.api.model.CreditPartitionBillsApi;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.credit.api.model.TradeRecordApi;
import com.lenovo.m2.hsbuy.logistics.LogisticApiService;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import com.lenovo.m2.web.common.my.order.OrderMainConstant;
import com.lenovo.m2.web.common.my.utils.*;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import com.lenovo.m2.web.domain.my.order.Product;
import com.lenovo.m2.web.domain.my.order.smb.SmbDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetail;
import com.lenovo.m2.web.remote.my.order.OrderDBService;
import com.lenovo.m2.web.remote.my.order.OrderMongoService;
import com.lenovo.m2.web.remote.my.order.OrderService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lenovo.comment.client.OrderCommnetClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by mayan3 on 2015/10/12.
 */
@Service
public class OrderServiceImpl implements OrderService {

    private static final Logger logger = LogManager.getLogger(OrderServiceImpl.class);
    public static final String LUCKY_WHEEL_DURING_TIME_BEGAIN = CustomizedPropertyConfigurer.getContextProperty("LUCKY_WHEEL_DURING_TIME_BEGAIN");
    public static final String LUCKY_WHEEL_DURING_TIME_END = CustomizedPropertyConfigurer.getContextProperty("LUCKY_WHEEL_DURING_TIME_END");
    public static final String LUCKY_WHEEL_LIMIT_MONEY = CustomizedPropertyConfigurer.getContextProperty("LUCKY_WHEEL_LIMIT_MONEY");
    public static final String CREDIT_STATUS_TRUE = "1";
    public static final String CREDIT_STATUS_FALSE = "0";
    private DecimalFormat nf = new DecimalFormat("0.00");

    @Autowired
    private OrderMongoService orderMongoService;
    @Autowired
    private OrderDBService orderDBService;
    @Autowired
    private CreditService creditService;
    @Autowired
    private LogisticApiService logisticApiService;

    @Override
    public PageModel2<OrderDetailListJSONOrderList> queryOrder(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType) {
        List<OrderDetailListJSONOrderList> orderlist = null;

        orderlist = queryOrderAll(merchantId, lenovoId, pageQuery, orddate, searchtext,orderType,orderstatus);
        logger.info("orderlist1111111111111111={}", JsonUtil.toJson(orderlist));
        PageModel2<OrderDetailListJSONOrderList> pm2 = new PageModel2<OrderDetailListJSONOrderList>(pageQuery, orderlist);
        return pm2;
    }

    public List<OrderDetailListJSONOrderList> queryOrderAll(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderType,String orderstatus) {
        List<OrderDetailListJSONOrderList> orderlist = new ArrayList<OrderDetailListJSONOrderList>();
        QueryDate queryDate = getQueryDate(orddate);
        long start = System.currentTimeMillis();
        List<MongoOrderDetail> mongoOrderList = orderMongoService.getOrderByOrderStatus(merchantId, lenovoId, pageQuery, orderstatus, queryDate.fromDate, queryDate.toDate, searchtext,orderType);
        long end = System.currentTimeMillis();
        long time = end - start;
        logger.info("############# mongo cost time " + time + "ms");
        logger.info("mongoOrderList={}",JsonUtil.toJson(mongoOrderList));
        for (MongoOrderDetail mongoOrder : mongoOrderList) {
            if ("1".equals(mongoOrder.getIsDelete())) {//去掉已删除订单
                continue;
            }
            OrderDetailListJSONOrderList e = new OrderDetailListJSONOrderList();
            mongoOrdrer2JSONOrderList(mongoOrder, e);
            updateOrderStatus(mongoOrder,e);
            orderlist.add(e);
        }
        return orderlist;
    }

    /**
     订单状态
     正常订单：0
     取消订单：1
     已支付：2
     已发货：3
     已签收：4
     **/

    private void updateOrderStatus(MongoOrderDetail mongoOrder, OrderDetailListJSONOrderList e) {

        if ("1".equals(mongoOrder.getOrderStatus())) {
            e.setOrderstatus("已取消");
            e.setOrderstatuscode("-1");
        }else if ("0".equals(mongoOrder.getOrderStatus())){
            e.setOrderstatus("1".equals(mongoOrder.getPayStatus()) ? "已支付" : "待付款");// ** 订单状态名称（包含物流状态，是否退货状态）
            e.setOrderstatuscode("0");
        }else if ("2".equals(mongoOrder.getOrderStatus())) {
            e.setOrderstatus("待发货");
            e.setOrderstatuscode("1");
        } else if("3".equals(mongoOrder.getOrderStatus())) {
            e.setOrderstatus("待收货");
            e.setOrderstatuscode("2");
            e.setTimeline("2");
        } else if ("4".equals(mongoOrder.getOrderStatus())) {//已签收
            e.setOrderstatus("已签收");
            e.setOrderstatuscode("10");
            e.setTimeline("3");
            if ("1".equals(mongoOrder.getHasComment())) {
                e.setOrderstatus("已完成");
                e.setHasComment("1");
            } else {
                e.setOrderstatus("待评价");
                e.setHasComment("0");
            }
        }
    }

    @Override
    public PageModel2<OrderInfoVo> queryOrderForCustomerService(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType) {
        List<OrderInfoVo> orderlist = new ArrayList<OrderInfoVo>();
        QueryDate queryDate = getQueryDate(orddate);
        long start = System.currentTimeMillis();
        List<MongoOrderDetail> mongoOrderList = orderMongoService.getOrderByOrderStatus(merchantId, lenovoId, pageQuery, "", queryDate.fromDate, queryDate.toDate, searchtext,orderType);
        long end = System.currentTimeMillis();
        long time = end - start;
        logger.info("############# mongo cost time " + time + "ms");

        for (MongoOrderDetail mongoOrder : mongoOrderList) {
            OrderInfoVo e = new OrderInfoVo();
            mongoOrdrer2JSONOrderList(mongoOrder, e);
            e.setShipName(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipName());
            e.setShipMobile(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipMobile());
            e.setShipAddress(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getFullAddress());
            updateOrderStatus(mongoOrder,e);
            orderlist.add(e);
        }

        PageModel2<OrderInfoVo> pm2 = new PageModel2<OrderInfoVo>(pageQuery, orderlist);
        return pm2;
    }

    public OrderDetailListJSONOrderList getOrderDetailListJSONOrderList(String orderCode, String merchantId) {

        MongoOrderDetail mongoOrderDetail = orderMongoService.getOrderByOrdercode(orderCode, merchantId);
        if(mongoOrderDetail == null){
            mongoOrderDetail = new MongoOrderDetail();
        }
        logger.info("mongoOrderDetail's orderCode:"+mongoOrderDetail.getOrderCode());
        OrderDetailListJSONOrderList e = new OrderDetailDesc();
        mongoOrdrer2JSONOrderList(mongoOrderDetail, e);
        logger.info("e={}", JsonUtil.toJson(e));
        return e;
    }

    public void mongoOrdrer2JSONOrderList(MongoOrderDetail mongoOrder, OrderDetailListJSONOrderList e) {

        if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(mongoOrder.getShopId())){
            e.setAuditStatus(mongoOrder.getAuditStatus());
            e.setCreditLine(mongoOrder.getCreditLine());
            e.setPayPoint(mongoOrder.getPayPoint());

        }
        if(mongoOrder == null){
            return;
        }
        if(mongoOrder.getRreceiptDate() != null && !"".equals(mongoOrder.getRreceiptDate()) && !mongoOrder.getShopId().equals("8") && !mongoOrder.getShopId().equals("9")){
            Calendar c = Calendar.getInstance();
            Calendar c1 = Calendar.getInstance();
            try {
                c.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(mongoOrder.getRreceiptDate()));
                //将当前时间转成指定日期格式
                Date currentDate = DateUtil.parseDate(DateUtil.formatDate(new Date(), DateUtil.PATTERN_DEFAULT), DateUtil.PATTERN_DEFAULT);
                logger.info("当前日期currentDate："+currentDate);
                c1.setTime(currentDate);
            } catch (ParseException e1) {
                e1.printStackTrace();
            }
            e.setWithinsevendays(c1.getTimeInMillis() - c.getTimeInMillis() > 604800000 ? true : false);
            e.setCanreturn(c1.getTimeInMillis() - c.getTimeInMillis() > (2 * 604800000) ? "0" : "1");
        }else{
            e.setWithinsevendays(false);
            e.setCanreturn("1");
        }
        String taxCode = mongoOrder.getTaxType();
        String taxType = "普通发票";
        if ("D".equals(taxCode)) {
            taxType = "电子发票";
        } else if ("T".equals(taxCode) || "P".equals(taxCode)) {
            taxType = "普通发票";
        } else if ("Z".equals(taxCode)) {
            taxType = "增值税发票";
        } else if("999".equals(taxCode)){
            taxType = "999";
        }

        e.setPresell(mongoOrder.getPresell());
        e.setInvoiceType(taxType);
        //smb 主订单号存储
        e.setOrdermaincode(mongoOrder.getOrderMainCode());
        e.setCustomerOrderCode(mongoOrder.getCustomerOrderCode());
        e.setCustomerOrderCodeSon(mongoOrder.getCustomerOrderCodeSon());

        e.setVatBankNo(mongoOrder.getVatBankNo());
        e.setVatDeliveries(mongoOrder.getVatDeliveries());
        e.setVatdepositBank(mongoOrder.getVatdepositBank());
        e.setVatHeader(mongoOrder.getVatHeader());
        e.setVatTaxpayerIdentity(mongoOrder.getVatTaxpayerIdentity());
        e.setContractDeliveries(mongoOrder.getContractDeliveries());
        e.setRegisterAddress(mongoOrder.getRegisterAddress());
        e.setRegisterPhone(mongoOrder.getRegisterPhone());

        //smbjf 商城 存储积分 score
        e.setScore(mongoOrder.getScore());
        e.setOrderno(mongoOrder.getOrderCode());
        e.setOrdertime(mongoOrder.getCreateTime());
        e.setPayStatus(mongoOrder.getPayStatus());
        e.setOrderAddType(mongoOrder.getOrderAddType());
        e.setUploadStatus(mongoOrder.getUploadStatus());
        e.setFaid(mongoOrder.getFaid());
        e.setFaname(mongoOrder.getFaname());
        e.setBuyerCode(mongoOrder.getBuyerCode());
        e.setFaType(mongoOrder.getFaType());
        e.setPayTime(mongoOrder.getPayDatetime());
        e.setIsDelete(mongoOrder.getIsDelete());
        e.setTerminal(mongoOrder.getTerminal());
        if ("3".equals(mongoOrder.getPayStatus())) {
            e.setSalestype("5");
        }else{
            e.setSalestype(mongoOrder.getSalesOrderType());
        }
        e.setPaymode(mongoOrder.getPaymentType());
        //默认是手机订单
        e.setIstelord("1");
        //是否是手机订单,1是，0否
        Integer source = StringUtils.parseInteger(mongoOrder.getTerminal());
        if (source != null && source.equals(OrderMainConstant.TERMINAL_PC)) {
            e.setIstelord("0");
        }
        e.setTakeperson(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipName());

        List<OrderDetailListJSONOrderListGlist> glist = new ArrayList<OrderDetailListJSONOrderListGlist>();
        List<OrderDetailListJSONOrderListGlist> slist = new ArrayList<OrderDetailListJSONOrderListGlist>();
        List<OrderDetailListJSONOrderListGlist> giftlist = new ArrayList<OrderDetailListJSONOrderListGlist>();
        List<OrderDetailListJSONOrderListGlist> singleServiceGoods = new ArrayList<OrderDetailListJSONOrderListGlist>();

        if (mongoOrder.getPayStatus() != null) {//查出来的订单状态不为空

            e.setPaymoney(mongoOrder.getAmountMoney());//订单支付金额

            //mongodb的基本信息
            if (mongoOrder.getProducts() != null) {
                //慧商线下银行转账，上传转账凭证页面需要分销商编码
                e.setFaCode(mongoOrder.getProducts().get(0).getFaCode());

                for (Product p : mongoOrder.getProducts()) {
                    OrderDetailListJSONOrderListGlist g = new OrderDetailListJSONOrderListGlist();
                    g.setMachineSN(p.getMachineSN() != null ? p.getMachineSN() : "");
                    g.setServiceCode(p.getServiceCode() != null ? p.getServiceCode() : "");
                    g.setFaid(p.getFaid());
                    g.setGcode(p.getProductCode());
                    g.setGname(p.getProductName());
                    g.setGexchange(p.getGexchange() == null ? "" : p.getGexchange());//换货状态，为空表示不是换货状态
                    g.setEvalstatus("");//评价状态  为空表示没有评价
                    g.setGdesc(p.getProductDesc());
                    g.setGphoto(p.getProductPhoto());
                    g.setGprice(p.getProductPay());
                    g.setGrealprice(p.getProductPay().multiply(new BigDecimal(p.getProductNumber())).subtract(p.getFavourablePay()));
                    g.setGspec(p.getSpecification());
                    g.setGcount(p.getProductNumber());
                    g.setDeatLike(p.getDeatLike());
                    g.setGroupingID(p.getGroupingID());
                    g.setIsPhysical(String.valueOf(p.getIsPhysical()));
                    g.setgMaterial(p.getLenovoProductCode() == null ? "" : p.getLenovoProductCode());
                    g.setIsServiceProd(String.valueOf(p.getIsServiceProd()));
                    g.setSalesType(p.getSalesType() != null ? p.getSalesType() : "0");
                    g.setSkuType(p.getSkuType() != null && !"".equals(p.getSkuType()) ? p.getSkuType() : "0");

                    if ("1".equals(p.getIsGift())) {
                        giftlist.add(g);
                    } else if (p.getIsServiceProd() == 1) {
                        slist.add(g);
                    } else {
                        glist.add(g);
                    }
                }
            }
            if(CollectionUtils.isNotEmpty(glist) && CollectionUtils.isNotEmpty(slist)){
                singleServiceGoods = getSingleServiceGoods(glist,slist);
            }
        }

        e.setGlist(glist);
        e.setSlist(slist);
        e.setGiftList(giftlist);
        e.setSingleServerList(singleServiceGoods);
        e.setTotalGoodsCount(glist.size()+slist.size()+giftlist.size());
        e.setCostItem(mongoOrder.getCostItem());

    }
    private List<OrderDetailListJSONOrderListGlist> getSingleServiceGoods(List<OrderDetailListJSONOrderListGlist> glist, List<OrderDetailListJSONOrderListGlist> slist){
        List<OrderDetailListJSONOrderListGlist> singleServiceGoods = new ArrayList<OrderDetailListJSONOrderListGlist>();

        for (OrderDetailListJSONOrderListGlist s : slist) {
            boolean flag = true;
            for (OrderDetailListJSONOrderListGlist g : glist) {
                if (g.getGroupingID().equals(s.getGroupingID())) {
                    flag = false;
                    continue;
                }
            }
            if (flag){
                singleServiceGoods.add(s);
            }
        }
        return singleServiceGoods;
    }

    @Override
    public OrderDetailDesc getOrderDetailDescByOrdercode(String orderCode, String merchantId) {

        //orderCode = "13426770";
        MongoOrderDetail mongoOrderDetail = orderMongoService.getOrderByOrdercode(orderCode, merchantId);
        logger.info("mongoOrderDetail={}", JsonUtil.toJson(mongoOrderDetail));
        if (mongoOrderDetail == null){
            return null;
        }
        OrderDetailListJSONOrderList e = new OrderDetailDesc();
        mongoOrdrer2JSONOrderList(mongoOrderDetail, e);//列表
        mongoOrder2OrderDetail(mongoOrderDetail, (OrderDetailDesc) e);//详情页
        //优化逻辑，只有已支付的订单再去查mysql
        updateOrderStatus(mongoOrderDetail,e);
        logger.info("(OrderDetailDesc) e={}", JsonUtil.toJson(e));
        return (OrderDetailDesc) e;
    }

    private void mongoOrder2OrderDetail(MongoOrderDetail mongoOrder, OrderDetailDesc e) {
        String taxCode = mongoOrder.getTaxType();
        String taxType = "普通发票";
        if ("D".equals(taxCode)) {
            taxType = "电子发票";
        } else if ("T".equals(taxCode) || "P".equals(taxCode)) {
            taxType = "普通发票";
        } else if ("Z".equals(taxCode)) {
            taxType = "增值税发票";
        } else if("999".equals(taxCode)){
            taxType = "999";
        }
        if ("1".equals(mongoOrder.getPayStatus())) {
            e.setTimeline("1");
        } else {
            e.setTimeline("0");
        }
        if (mongoOrder.getTaxNoType() == 1){
            e.setTaxNoType("15位或20位识别码");
        }else if(mongoOrder.getTaxNoType() == 2){
            e.setTaxNoType("18位识别码");
        }else{
            e.setTaxNoType("无识别码");
        }

        e.setMarkText(mongoOrder.getAddonstr());//获取订单备注信息
        e.setReceiver(mongoOrder.takeReceiver());
        e.setTakepersonaddr(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getFullAddress());
        e.setTakepersonmobile(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipMobile());
        e.setTakepersonemail(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipEmail());
        e.setMarkText(mongoOrder.getAddonstr());
        e.setInvoiceType(taxType);
        e.setInvoiceContent(mongoOrder.getTaxContent());
        e.setInvoiceHeader(mongoOrder.getTaxCompany() == null ? "" : mongoOrder.getTaxCompany());
        e.setLenovoId(mongoOrder.getLenovoId());
        e.setFaType(mongoOrder.getFaType());
        e.setPayTime(mongoOrder.getPayDatetime());
        e.setCancelTime(mongoOrder.getCancelTime());
        e.setUsedLeDouNum(mongoOrder.getUsedLeDouNum());
        e.setGiveawayTotal(mongoOrder.getGiveawayTotal());
        e.setWaitReceiptDate(mongoOrder.getWaitReceiptDate());
        if (mongoOrder.getPreferredPayment() != null){
            try {
                PreferredPayment preferredPayment = new PreferredPayment();
                preferredPayment.setCoupons(mongoOrder.getPreferredPayment().getCoupons());
//                preferredPayment.setCoupons(mongoOrder.getPreferredPayment().getCoupons().add(mongoOrder.getVoucherTotalAmount()));
                preferredPayment.setBlackBeans(mongoOrder.getPreferredPayment().getBlackBeans());
                preferredPayment.setCouponCode(mongoOrder.getPreferredPayment().getCouponCode());
                preferredPayment.setFullReduce(mongoOrder.getPreferredPayment().getFullReduce());
                preferredPayment.setHappyBeans(mongoOrder.getPreferredPayment().getHappyBeans());
                preferredPayment.setVoucherTotalAmount(mongoOrder.getVoucherTotalAmount());
                e.setPreferredPayment(preferredPayment);
            }catch (Exception e1){
                logger.error("e1={}",e1);
                e.setPreferredPayment(mongoOrder.getPreferredPayment());
            }
        }else{
            e.setPreferredPayment(mongoOrder.getPreferredPayment());
        }
        e.setNotes(mongoOrder.getNotes());
        e.setRreceiptDate(mongoOrder.getRreceiptDate());
        e.setTerminal(mongoOrder.getTerminal());
        //=====ProcessTime

        e.setCvItems(mongoOrder.getCvItems());//cto订单 将自选配置信息放入
        if (mongoOrder.getPayStatus() != null) {//查出来的订单状态不为空

            e.setPaymoney(mongoOrder.getAmountMoney());//订单支付金额
            if (mongoOrder.takeReceiver() != null) {
                e.setTranmoney(mongoOrder.takeReceiver().getAdvanceFreightMoney());//运费
            }
            e.setCoupon(mongoOrder.getCoupon());//优惠券金额  ,mongoOrder.getGiveawayTotal()
//            String discountTotal = BigDecimalUtil.add(BigDecimalUtil.add(mongoOrder.getDiscount(),mongoOrder.getPreferredPayment().getCouponCode()),mongoOrder.getPreferredPayment().getCoupons());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getFullReduce());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getBlackBeans());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getHappyBeans());
//            e.setDiscount(BigDecimalUtil.numberStrformat(discountTotal,"0.00"));
            e.setUsedLeDouNum(mongoOrder.getPreferredPayment().getHappyBeans());
            e.setDiscount(mongoOrder.getGiveawayTotal());
            e.setOrdermoney(mongoOrder.getCostItem());// 订单商品总金额
            e.setCreditLine(mongoOrder.getCreditLine());//信用支付金額
            e.setPayPoint(mongoOrder.getPayPoint());//積分支付
            e.setTotalTax(mongoOrder.getTotalTax()); //税总计

            List<OrderPay> or_list = new ArrayList<OrderPay>();
            OrderPay op = new OrderPay();
            op.setPmoney(mongoOrder.getAmountMoney());
            op.setPtime(mongoOrder.getPayDatetime());
            op.setPno(mongoOrder.getPayOrderNo());
            if (mongoOrder.takePay() != null) {
                op.setPfrom(mongoOrder.takePay().getGatheringBank());
                op.setPayment(mongoOrder.takePay().getPayment());
                op.setPaymentLX(mongoOrder.takePay().getPaymentLX());
            }
            or_list.add(op);
            e.setPlist(or_list);
        }
    }

    @Override
    public PageModel2<UserProduct> queryPayedUserProducts(String merchantId, String lenovoId, PageQuery pageQuery, String orddate) {
        List<UserProduct> res = new ArrayList<UserProduct>();
        QueryDate queryDate = getQueryDate(orddate);
        List<UserProduct> userProducts = orderMongoService.getUserProducts(merchantId, lenovoId, queryDate.fromDate, queryDate.toDate);
        int pageNo = pageQuery.getPageNum();
        pageQuery.setTotalCount(userProducts.size());
        pageQuery.setPageNum(pageNo);
        int pageStart = (pageNo - 1) * pageQuery.getPageSize();
        if (pageStart >= userProducts.size())
            return new PageModel2<UserProduct>(pageQuery, res);
        int pageEnd = pageNo * pageQuery.getPageSize();
        if (userProducts.size() < pageEnd)
            pageEnd = userProducts.size();
        res = userProducts.subList(pageStart, pageEnd);
        PageModel2<UserProduct> pm2 = new PageModel2<UserProduct>(pageQuery, res);
        return pm2;
    }


    @Override
    public HuiMallOrderCount getOrderCount(String lenovoId, String merchantId) {
        return orderDBService.getOrderCountByUser(lenovoId, merchantId);
    }

    @Override
    public List<OrderDetailListJSONOrderList> getOrderDetailByOrderMainCode(String orderno, String shopId) {
        List<OrderDetailListJSONOrderList> orderlist = new ArrayList<>();
        List<MongoOrderDetail> mongoOrderList = orderMongoService.getOrderDetailByOrderMainCode(orderno,shopId);
        logger.info("smb_mongoOrderList={}", JsonUtil.toJson(mongoOrderList));
        logger.info("smb_mongoOrderList.size()={}",mongoOrderList.size());
        for (MongoOrderDetail mongoOrder : mongoOrderList) {
            if ("1".equals(mongoOrder.getIsDelete())) {//去掉已删除订单
                continue;
            }
            OrderDetailListJSONOrderList e = new OrderDetailDesc();
            mongoOrdrer2JSONOrderList(mongoOrder, e);
            mongoOrder2OrderDetail(mongoOrder, (OrderDetailDesc) e);//详情页
            //优化逻辑，只有已支付的订单再去查mysql
            updateOrderStatus(mongoOrder,e);
            orderlist.add(e);
        }
        return orderlist;
    }

    @Override
    public SmbDetail getSmbDetail(String orderno, String shopId, SmbOrderDetail smbOrderDetail) {
        List<MongoOrderDetail> mongoOrderList = orderMongoService.getOrderDetailByOrderMainCode(orderno,shopId);
        logger.info("JsonUtil.toJson(mongoOrderList)={}", JsonUtil.toJson(mongoOrderList));
        SmbDetail smbDetail = new SmbDetail();
        Money CouponsTotle = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money CouponCodeTotle = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money BlackBeansTotel = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money HappyBeansTotel = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money FullReduceTotel = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money DiscountTotel = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        Money orderMoneyTotel = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        PreferredPayment preferredPayment = new PreferredPayment();
        for (MongoOrderDetail m : mongoOrderList){
            CouponsTotle = CouponsTotle.add(m.getPreferredPayment().getCoupons());
            CouponCodeTotle = CouponCodeTotle.add(m.getPreferredPayment().getCouponCode());
//            BlackBeansTotel = BlackBeansTotel.add(m.getPreferredPayment().getBlackBeans());
            HappyBeansTotel = HappyBeansTotel.add(m.getPreferredPayment().getHappyBeans());
            FullReduceTotel = FullReduceTotel.add(m.getPreferredPayment().getFullReduce());
            logger.info("m.getCostItem()={}",m.getCostItem());
            orderMoneyTotel = orderMoneyTotel.add(m.getCostItem());
        }
        logger.info("smbDetail.setOrdermoney(orderMoneyTotel.toString());={}",orderMoneyTotel.toString());
        preferredPayment.setCouponCode(CouponCodeTotle);
        preferredPayment.setCoupons(CouponsTotle);
        preferredPayment.setBlackBeans(BlackBeansTotel);
        preferredPayment.setFullReduce(FullReduceTotel);
        preferredPayment.setHappyBeans(HappyBeansTotel);
//        DiscountTotel = DiscountTotel.add(HappyBeansTotel).add(FullReduceTotel).add(BlackBeansTotel).add(CouponsTotle).add(CouponCodeTotle);
        DiscountTotel = DiscountTotel.add(HappyBeansTotel).add(FullReduceTotel).add(BlackBeansTotel).add(CouponsTotle).add(CouponCodeTotle);
        mongoOrder2SmbOrderDetail(mongoOrderList.get(0), smbDetail);
        smbDetail.setOrdermoney(orderMoneyTotel);
        smbDetail.setPreferredPayment(preferredPayment);
        smbDetail.setDiscount(DiscountTotel);
        try {
            logger.info("smbOrderDetail={}", JsonUtil.toJson(smbOrderDetail));
            //copy 父类数据到子类
            BeanUtils.copyProperties(smbDetail, smbOrderDetail);
//            fatherToChild(smbOrderDetail,smbDetail);
            logger.info("smbDetail={}", JsonUtil.toJson(smbDetail));
        } catch (Exception e) {
            logger.error("ERROR_FATHER_TO_CHILD",e);
        }
        return smbDetail;
    }

    @Override
    public Map<String,Object> getHuiMallMessageListData(Map<String,String> mapPartitionBill, PageQuery pageQuery) {
        RemoteResult<PageModel2<CreditInfoApi>> creditInfoApi = creditService.getCreditInfoByPage(pageQuery,mapPartitionBill);
        Map map = new HashMap();
        map.put("creditInfoApi",creditInfoApi.getT());
        if(CREDIT_STATUS_FALSE.equals(mapPartitionBill.get("status"))){
            mapPartitionBill.put("status", CREDIT_STATUS_FALSE);
            RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiFalse = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBill);
            map.put("creditPartitionBillsApiFalse",creditPartitionBillsApiFalse.getT());
        }else if(CREDIT_STATUS_TRUE.equals(mapPartitionBill.get("status"))){
            mapPartitionBill.put("status",CREDIT_STATUS_TRUE);
            RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiTrue = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBill);
            map.put("creditPartitionBillsApiTrue",creditPartitionBillsApiTrue.getT());
        }else{
            mapPartitionBill.put("status", CREDIT_STATUS_FALSE);
            RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiFalse = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBill);
            map.put("creditPartitionBillsApiFalse",creditPartitionBillsApiFalse.getT());
            mapPartitionBill.put("status",CREDIT_STATUS_TRUE);
            RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiTrue = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBill);
            map.put("creditPartitionBillsApiTrue",creditPartitionBillsApiTrue.getT());
        }
        return map;
    }

    @Override
    public Map<String,Object> getHuiMallMessage(String lenovoId, PageQuery pageQuery) {
        Map mapInfo = new HashMap();
        mapInfo.put("buyerId",lenovoId);
        RemoteResult<PageModel2<CreditInfoApi>> creditInfoApi = creditService.getCreditInfoByPage(pageQuery,mapInfo);
        Map map = new HashMap();
        map.put("creditInfoApi",creditInfoApi.getT());
        return map;
    }

    @Override
    public Map<String,Object> getWapHuiMallMessage(String lenovoId, PageQuery pageQuery) {
        Map mapInfo = new HashMap();
        mapInfo.put("buyerId",lenovoId);
        RemoteResult<PageModel2<CreditInfoApi>> creditInfoApi = creditService.getCreditInfoByPage(pageQuery,mapInfo);
        Map mapPartitionBillFalse = new HashMap();
        mapPartitionBillFalse.put("buyerId", lenovoId);
        mapPartitionBillFalse.put("status",CREDIT_STATUS_FALSE);
        RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiFalse = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBillFalse);
        Map mapPartitionBillTrue = new HashMap();
        mapPartitionBillTrue.put("buyerId",lenovoId);
        mapPartitionBillTrue.put("status",CREDIT_STATUS_TRUE);
        RemoteResult<PageModel2<CreditPartitionBillsApi>> creditPartitionBillsApiTrue = creditService.getCreditPartitionBillsByPage(pageQuery, mapPartitionBillTrue);
        Map map = new HashMap();
        map.put("creditInfoApi",creditInfoApi.getT());
        map.put("creditPartitionBillsApiFalse",creditPartitionBillsApiFalse.getT());
        map.put("creditPartitionBillsApiTrue",creditPartitionBillsApiTrue.getT());
        return map;
    }

    @Override
    public RemoteResult<CreditPartitionBillsApi> getHuiMallDetailMessage(String str) {
        RemoteResult<CreditPartitionBillsApi> creditPartitionBillsApiFalse = creditService.getCreditPartitionBillsByBillNo(str);
        return creditPartitionBillsApiFalse;
    }

    @Override
    public RemoteResult<PageModel2<TradeRecordApi>> getTradeRecordByPage(PageQuery pageQuery, Map<String, Object> mapMess) {
        RemoteResult<PageModel2<TradeRecordApi>> pageModel2RemoteResult = creditService.getTradeRecordByPage(pageQuery,mapMess);
        return pageModel2RemoteResult;
    }

    @Override
    public Map<String, String> savePayTracking(String billNo, Long buyerId, String faCode, String unpaidAmount, String returnAmount) {
        Map<String, String> paraMap = new HashMap<>();
        BigDecimal unpaidAmountBigDecimal = new BigDecimal(unpaidAmount);
        BigDecimal returnAmountBigDecimal = new BigDecimal(returnAmount);
        if(returnAmountBigDecimal.compareTo(unpaidAmountBigDecimal) > 0){
            paraMap.put("rc", "0");
            paraMap.put("msg", "还款金额超出未还金额");
            return paraMap;
        }
        if(unpaidAmountBigDecimal.compareTo(new BigDecimal(2000)) >= 0 && returnAmountBigDecimal.compareTo(new BigDecimal(2000)) < 0){
            paraMap.put("rc", "0");
            paraMap.put("msg", "未还金额超过2000元 单笔最低限额2000元");
            return paraMap;
        }
        RemoteResult<String> savePayTrackingRemoteResult = creditService.savePayTracking(billNo, buyerId, faCode, returnAmountBigDecimal.doubleValue());
        logger.info("信用支付部分还款,信用账单号[" + billNo + "],后台返回结果RemoteResult[" + savePayTrackingRemoteResult + "]");
        if(savePayTrackingRemoteResult.isSuccess()){
            paraMap.put("rc", "1");
            paraMap.put("msg", "调用成功");
            paraMap.put("orderMainCode", savePayTrackingRemoteResult.getT());
        } else {
            paraMap.put("rc", "0");
            paraMap.put("msg", "服务器异常，请重新发起");
        }
        return paraMap;
    }

    @Override
    public RemoteResult<List<PayTrackingApi>> getHuimallcreditPaidData(String billNo, String faCode, Long buyerId) {
        RemoteResult<List<PayTrackingApi>>  result = creditService.getBillsPayTracking(billNo, buyerId, faCode);
        return result;
    }

    /**
     * 同步惠商订单信息给评价端
     * @param lenovoId
     * @param orderDetailListJSONOrderList
     * @return
     */
    @Override
    public RemoteResult<Boolean> synchronizeHsOderMessageToEvaluate(String lenovoId, OrderDetailListJSONOrderList orderDetailListJSONOrderList) {
        Map<String,Object> orderMessageMap = new HashMap<String,Object>();
        orderMessageMap.put("orderno",orderDetailListJSONOrderList.getOrderno());//        orderMessageMap.put("orderstatus",orderDetailListJSONOrderList.getOrderstatus());
        orderMessageMap.put("orderstatus",orderDetailListJSONOrderList.getOrderstatus());
        orderMessageMap.put("costItem",nf.format(orderDetailListJSONOrderList.getCostItem().getAmount()));
        orderMessageMap.put("payTime",orderDetailListJSONOrderList.getPayTime());
        orderMessageMap.put("lenovoId",lenovoId);
        List<OrderDetailListJSONOrderListGlist> glist = orderDetailListJSONOrderList.getGlist();
        List<Map<String,Object>> goodsMessageList = new ArrayList<Map<String,Object>>();
        for(OrderDetailListJSONOrderListGlist goods:glist){
            Map<String,Object> goodsMessageMap = new HashMap<String,Object>();
            goodsMessageMap.put("gphoto",goods.getGphoto());
            goodsMessageMap.put("gname",goods.getGname());
            goodsMessageMap.put("gprice",nf.format(goods.getGprice().getAmount()));
            goodsMessageMap.put("gcount",goods.getGcount());
            goodsMessageMap.put("gcode",goods.getGcode());
            goodsMessageMap.put("gMaterial",goods.getgMaterial());
            goodsMessageList.add(goodsMessageMap);
        }
        orderMessageMap.put("glist",goodsMessageList);
        String hsMessageJson = JsonUtil.toJson(orderMessageMap);
        logger.info("，同步 评论数据 :"+hsMessageJson);
        RemoteResult<Boolean> result =new RemoteResult<Boolean>(false);
        try {
            result = OrderCommnetClient.getInstance().AddHsOrderMessage(hsMessageJson);
            logger.info("同步 评论数据 结束："+result);
            if (result.isSuccess() && result != null){
                result.setSuccess(true);
                result.setResultCode("0");
                result.setResultMsg("success");
                return result;
            }else{
                logger.info("");
                result.setSuccess(false);
                result.setResultMsg("fail");
                return result;
            }
        }catch (Exception e){
            logger.error("同步评论数据 异常："+e,e.getMessage());
            result.setResultCode("err");
            result.setResultMsg("同步失败！"+e.getMessage());
            return result;
        }
    }

    @Override
    public RemoteResult<Map<String, Object>> getOrderTrackInfo(String orderNo, Tenant tenant) {
//        RemoteResult<Map<String, Object>> remoteResult = new RemoteResult<>();
        RemoteResult<Map<String, Object>> remoteResult = logisticApiService.getLogisticsTrack(orderNo,tenant);
        logger.info("logisticApiService_remoteResult={}",JsonUtil.toJson(remoteResult));
        return remoteResult;
    }


    private void mongoOrder2SmbOrderDetail(MongoOrderDetail mongoOrder, SmbDetail e) {
        String taxCode = mongoOrder.getTaxType();
        String taxType = "普通发票";
        if ("D".equals(taxCode)) {
            taxType = "电子发票";
        } else if ("T".equals(taxCode) || "P".equals(taxCode)) {
            taxType = "普通发票";
        } else if ("Z".equals(taxCode)) {
            taxType = "增值税发票";
        } else if("999".equals(taxCode)){
            taxType = "999";
        }
        if ("1".equals(mongoOrder.getPayStatus())) {
            e.setTimeline("1");
        } else {
            e.setTimeline("0");
        }
        e.setMarkText(mongoOrder.getAddonstr());//获取订单备注信息
        e.setReceiver(mongoOrder.takeReceiver());
        e.setTakepersonaddr(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getFullAddress());
        e.setTakepersonmobile(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipMobile());
        e.setTakepersonemail(mongoOrder.takeReceiver() == null ? "" : mongoOrder.takeReceiver().getShipEmail());
        e.setMarkText(mongoOrder.getAddonstr());
        e.setInvoiceType(taxType);
        e.setInvoiceContent(mongoOrder.getTaxContent());
        e.setInvoiceHeader(mongoOrder.getTaxCompany() == null ? "" : mongoOrder.getTaxCompany());
        e.setLenovoId(mongoOrder.getLenovoId());
        e.setFaType(mongoOrder.getFaType());
        e.setPayTime(mongoOrder.getPayDatetime());
        e.setCancelTime(mongoOrder.getCancelTime());
        e.setUsedLeDouNum(mongoOrder.getUsedLeDouNum());
        e.setGiveawayTotal(mongoOrder.getGiveawayTotal());
        e.setWaitReceiptDate(mongoOrder.getWaitReceiptDate());
        e.setPreferredPayment(mongoOrder.getPreferredPayment());
        e.setRreceiptDate(mongoOrder.getRreceiptDate());
        e.setTerminal(mongoOrder.getTerminal());
        //=====ProcessTime

        e.setCvItems(mongoOrder.getCvItems());//cto订单 将自选配置信息放入
        if (mongoOrder.getPayStatus() != null) {//查出来的订单状态不为空

            e.setPaymoney(mongoOrder.getAmountMoney());//订单支付金额
            if (mongoOrder.takeReceiver() != null) {
                e.setTranmoney(mongoOrder.takeReceiver().getAdvanceFreightMoney());//运费
            }
            e.setCoupon(mongoOrder.getCoupon());//优惠券金额  ,mongoOrder.getGiveawayTotal()
//            String discountTotal = BigDecimalUtil.add(BigDecimalUtil.add(mongoOrder.getDiscount(),mongoOrder.getPreferredPayment().getCouponCode()),mongoOrder.getPreferredPayment().getCoupons());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getFullReduce());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getBlackBeans());
//            discountTotal = BigDecimalUtil.add(discountTotal,mongoOrder.getPreferredPayment().getHappyBeans());
//            e.setDiscount(BigDecimalUtil.numberStrformat(discountTotal,"0.00"));
            e.setUsedLeDouNum(mongoOrder.getPreferredPayment().getHappyBeans());
            e.setDiscount(mongoOrder.getGiveawayTotal());
            e.setOrdermoney(mongoOrder.getCostItem());// 订单商品总金额

            List<OrderPay> or_list = new ArrayList<OrderPay>();
            OrderPay op = new OrderPay();
            op.setPmoney(mongoOrder.getAmountMoney());
            op.setPtime(mongoOrder.getPayDatetime());
            op.setPno(mongoOrder.getPayOrderNo());
            if (mongoOrder.takePay() != null) {
                op.setPfrom(mongoOrder.takePay().getGatheringBank());
                op.setPayment(mongoOrder.takePay().getPayment());
                op.setPaymentLX(mongoOrder.takePay().getPaymentLX());
            }
            or_list.add(op);
            e.setPlist(or_list);
        }
    }


    @Override
    public String getVoiceUrl(String ordernm) {

        //TODO MAHAO
        return null;
//        return orderdeliveriesMapper.getBtcpOrderNm(ordernm);
    }

    @Override
    public String getInVoiceUrlFromDB(String ordernm) {
        //TODO MAHAO
        return null;
//        return orderMapper.getInVoiceUrlFromDB(ordernm);
    }

    public QueryDate getQueryDate(String orddate) {
        Calendar c = Calendar.getInstance();
        String fromDate = "";
        String toDate = DateUtil.formatDate(new Date(new Date().getTime() + 24 * 60 * 60 * 1000L), "yyyy-MM-dd");
        //近三个月的
        if ("1".equals(orddate)) {
            fromDate = DateUtil.addMonth(DateUtil.getFirstDate("yyyy-MM-dd"), -3);
        }
        //今年内
        if ("2".equals(orddate)) {
            fromDate = DateUtil.formatDate(DateUtil.getCurrYearFirst(), "yyyy-MM-dd");
        }
        //上一年
        if ("3".equals(orddate)) {
            fromDate = DateUtil.formatDate(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 1), "yyyy-MM-dd");
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 1), "yyyy-MM-dd");
        }
        //上两年
        if ("4".equals(orddate)) {
            fromDate = DateUtil.formatDate(DateUtil.getYearFirst(c.get(Calendar.YEAR) - 2), "yyyy-MM-dd");
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 2), "yyyy-MM-dd");
        }
        //上三年及上三年以前
        if ("5".equals(orddate)) {
            toDate = DateUtil.formatDate(DateUtil.getYearLast(c.get(Calendar.YEAR) - 3), "yyyy-MM-dd");
        }
        return new QueryDate(fromDate, toDate);
    }

    class QueryDate {
        private String fromDate;
        private String toDate;

        public QueryDate(String fromDate, String toDate) {
            this.fromDate = fromDate;
            this.toDate = toDate;
        }

        public String getFromDate() {
            return fromDate;
        }

        public void setFromDate(String fromDate) {
            this.fromDate = fromDate;
        }

        public String getToDate() {
            return toDate;
        }

        public void setToDate(String toDate) {
            this.toDate = toDate;
        }
    }

  }
