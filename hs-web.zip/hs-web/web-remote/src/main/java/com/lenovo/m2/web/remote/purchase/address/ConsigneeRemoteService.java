package com.lenovo.m2.web.remote.purchase.address;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.address.AddressLog;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeAddressParam;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;

import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: hukun2
 * Date: 16-3-3
 * Time: 下午8:46
 * To change this template use File | Settings | File Templates.
 */
public interface ConsigneeRemoteService {
    public RemoteResult<String> saveConsignee(Tenant tenant, ConsigneeAddressParam consigneeAddressParam);
    public RemoteResult<Integer> updateConsignee(Tenant tenant, ConsigneeAddressParam consigneeAddressParam);
    public RemoteResult<Integer> deleteConsignee(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<List<Memberaddrs>> getConsignees(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<Memberaddrs> getConsigneeById(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<Integer> getCountByType(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<Map<String, Object>> getListPageByType(Tenant tenant, ConsigneeParam consigneeParam, int pageNum, int pageSize);
    public RemoteResult<Boolean> setDefaultConsignee(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<Memberaddrs> getDefaultOrNewById(Tenant tenant, ConsigneeParam consigneeParam);
    public RemoteResult<String> getIdByGuid(Tenant tenant, String guid);
    public RemoteResult<List<AddressLog>> getNotSyncAddress(Tenant tenant, Integer count);
}
