package com.lenovo.m2.web.remote.my.order;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.web.domain.my.logistics.Orderdeliveries;
import com.lenovo.m2.web.domain.my.logistics.OrderdeliveriesWithBLOBs;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.domain.my.order.newdb.Item;
import com.lenovo.m2.web.domain.my.order.newdb.Main;

import java.util.List;

/**
 * Created by mayan3 on 2015/10/12.
 */
public interface OrderDBService {

    public List<Order> selectOrderByOrderstatus(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext,
                                                Integer shipStatus, String commentStatus, Integer isreturn, String orderType);

    HuiMallOrderCount getOrderCountByUser(String lenovoId, String merchantId);


}
