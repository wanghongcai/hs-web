package com.lenovo.m2.web.remote.purchase.address.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.address.AreaAddressService;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.remote.purchase.address.AddressRemoteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: hukun2
 * Date: 16-3-3
 * Time: 下午8:47
 * To change this template use File | Settings | File Templates.
 */
@Service
public class AddressRemoteServiceImpl implements AddressRemoteService {

    private static Logger log = LogManager.getLogger(AddressRemoteServiceImpl.class.getName());
    @Autowired
    private AreaAddressService areaAddressService;

    /**
     * 获取省份列表
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<List<PartAddress>> getProvinceList(Tenant tenant) {
        try {
            log.info("调用 getProvinceList 入参:Tenant:{}",tenant);
            RemoteResult<List<PartAddress>> result =  areaAddressService.getProvinceList(tenant);
            log.info("调用getProvinceList成功!返回={}", com.lenovo.m2.web.common.purchase.util.JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程getProvinceList接口异常,",e);
            return null;
        }
    }

    @Override
    public RemoteResult<List<PartAddress>> getCityList(Tenant tenant, ProvinceParam provinceParam) {
        try {
            log.info("调用 getCityList 入参:Tenant:{},ProvinceParam:{}",tenant,provinceParam);
            RemoteResult<List<PartAddress>> result =  areaAddressService.getCityList(tenant,provinceParam);
            log.info("调用getCityList成功!返回={}", com.lenovo.m2.web.common.purchase.util.JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程getCityList接口异常",e);
            return null;
        }
    }

    @Override
    public RemoteResult<List<PartAddress>> getRegionList(Tenant tenant, ProvinceParam provinceParam) {
        try {
            log.info("调用 getRegionList 入参:Tenant:{},CityParam:{}",tenant,provinceParam);
            RemoteResult<List<PartAddress>> result =  areaAddressService.getCountyList(tenant,provinceParam);
            log.info("调用getRegionList!返回={}", com.lenovo.m2.web.common.purchase.util.JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程getRegionList接口异常,",e);
            return null;
        }
    }

    @Override
    public RemoteResult<String> getZip(Tenant tenant, ProvinceParam provinceParam) {
        try {
            log.info("调用 getZip 入参:Tenant:{},cityParam:{}",tenant,provinceParam);
            RemoteResult<String> result =  areaAddressService.getZip(tenant,provinceParam);
            log.info("调用getZip成功!返回={}", com.lenovo.m2.web.common.purchase.util.JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程getZip接口异常,",e);
            return null;
        }
    }

    @Override
    public RemoteResult<List<PartAddress>> getCounty(Tenant tenant, ProvinceParam provinceParam) {
        try {
            log.info("调用 getCounty 入参:Tenant:{},CountyParam:{}",tenant,provinceParam);
            RemoteResult<List<PartAddress>> result =  areaAddressService.getTownshipList(tenant,provinceParam);
            log.info("调用getCounty成功!返回={}", com.lenovo.m2.web.common.purchase.util.JsonUtil.toJson(result));
            RemoteResultUtil.updateMsg(result, PromptEnum.ADDRESS);
            return result;
        }catch(Exception e){
            log.error("调用远程getCounty接口异常,",e);
            return null;
        }
    }

    @Override
    public void reloadArea(Tenant tenant) {
        try {
            log.info("调用 reloadArea 入参:Tenant:{}",tenant);
            //TODO
            RemoteResult result = null; //areaAddressService.reloadAreaAddress(tenant);
            if (result.isSuccess()){
                log.info("调用reloadAreaAddress成功!返回={}", JsonUtil.toJson(result));
            }else{
                log.info("调用远程areaAddress服务reloadAreaAddress接口成功！但返回值异常", JsonUtil.toJson(result));
            }
        }catch(Exception e){
            log.error("调用远程reloadAreaAddress接口异常,",e);
        }
    }


}
