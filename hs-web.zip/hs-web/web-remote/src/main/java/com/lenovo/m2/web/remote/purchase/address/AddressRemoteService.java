package com.lenovo.m2.web.remote.purchase.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: hukun2
 * Date: 16-3-3
 * Time: 下午8:47
 * To change this template use File | Settings | File Templates.
 */
public interface AddressRemoteService {

    public RemoteResult<List<PartAddress>> getProvinceList(Tenant tenant);
    public RemoteResult<List<PartAddress>> getCityList(Tenant tenant, ProvinceParam provinceParam);
    public RemoteResult<List<PartAddress>> getRegionList(Tenant tenant, ProvinceParam provinceParam);
    public RemoteResult<String> getZip(Tenant tenant, ProvinceParam provinceParam);
    public RemoteResult<List<PartAddress>> getCounty(Tenant tenant, ProvinceParam provinceParam);
    public void reloadArea(Tenant tenant);



}
