package com.lenovo.m2.web.remote.my.order;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.credit.api.model.CreditPartitionBillsApi;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.credit.api.model.TradeRecordApi;
import com.lenovo.m2.web.domain.my.logistics.OrderdeliveriesWithBLOBs;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.domain.my.order.smb.SmbDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetail;

import java.util.List;
import java.util.Map;

/**
 * Created by mayan3 on 2015/10/12.
 */
public interface OrderService {

    /**
     * 0待付款|1待发货|2待收货|3待评价|4退换货|5已完成|6已取消
     */
    PageModel2<OrderDetailListJSONOrderList> queryOrder(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType);

    PageModel2<OrderInfoVo> queryOrderForCustomerService(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType);

    OrderDetailListJSONOrderList getOrderDetailListJSONOrderList(String orderCode, String merchantId);

    OrderDetailDesc getOrderDetailDescByOrdercode(String orderCode, String merchantId);

    PageModel2<UserProduct> queryPayedUserProducts(String merchantId, String lenovoId, PageQuery pageQuery, String orddate);

    String getVoiceUrl(String ordernm);

    String getInVoiceUrlFromDB(String ordernm);

    HuiMallOrderCount getOrderCount(String lenovoId, String merchantId);

    List<OrderDetailListJSONOrderList> getOrderDetailByOrderMainCode(String orderno, String shopId);

    SmbDetail getSmbDetail(String orderno, String shopId, SmbOrderDetail smbOrderDetail);


    Map<String,Object> getHuiMallMessage(String lenovoId, PageQuery pageQuery);

    Map<String,Object> getWapHuiMallMessage(String lenovoId, PageQuery pageQuery);

    Map<String,Object> getHuiMallMessageListData(Map<String,String> map, PageQuery pageQuery);

    RemoteResult<CreditPartitionBillsApi> getHuiMallDetailMessage(String str);

    RemoteResult<PageModel2<TradeRecordApi>> getTradeRecordByPage(PageQuery pageQuery, Map<String, Object> mapMess);

    Map<String, String> savePayTracking(String billNo, Long buyerId, String faCode, String unpaidAmount, String returnAmount);

    RemoteResult<List<PayTrackingApi>> getHuimallcreditPaidData(String billNo, String faCode, Long buyerId);

    /**
     * 同步惠商订单信息给评价端
     * @param lenovoId
     * @param orderDetailListJSONOrderList
     * @return
     */
    RemoteResult<Boolean> synchronizeHsOderMessageToEvaluate(String lenovoId,OrderDetailListJSONOrderList orderDetailListJSONOrderList);

    RemoteResult<Map<String,Object>> getOrderTrackInfo(String orderNo, Tenant tenant);
}
