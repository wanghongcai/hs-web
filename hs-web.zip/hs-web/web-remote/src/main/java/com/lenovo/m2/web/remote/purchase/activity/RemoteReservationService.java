package com.lenovo.m2.web.remote.purchase.activity;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.domain.purchase.activity.AddReservationResVO;

public interface RemoteReservationService {

	AddReservationResVO addReservation(int shopId, int terminal, String gcode, String userId, String userName) throws Exception;

	PageModel2<com.lenovo.m2.web.domain.purchase.seckill.ReservationInfo> bookList(Tenant tenant, String userId, Integer pageSize, Integer pageNow);

	boolean isHaveReservation(int activityId, String gcode, String userId);

	BaseInfo updateReservationPhone(String userId, String reservationId, String phone);

}
