package com.lenovo.m2.web.remote.purchase.member;

import java.util.Map;



public interface MemberInfoService {
	/**
	 * 根据lenovoId获取用户所有信息
	 * @param lenovoId
	 * @return
	 *@author  
	 * @date 2015-1-28下午7:00:15
	 */

	public Map<String, Object> getInfo(String lenovoId);




}
