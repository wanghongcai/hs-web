package com.lenovo.m2.web.remote.stock.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoParam;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoResult;
import com.lenovo.m2.hsbuy.inventory.StockPortApiService;
import com.lenovo.m2.web.remote.stock.StockService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by mayan3 on 2016/3/14.
 */
@Service
public class StockServiceImpl implements StockService {
    private static Logger LOGGER =  LogManager.getLogger(StockServiceImpl.class.getName());

//    private NewGoodsService proService =  ServicesClient.getInstance().getService(NewGoodsService.class);

    @Autowired
    private StockPortApiService stockPortApiService;

    @Override
    public List<GetStockInfoResult> getStockInfo(List<GetStockInfoParam> params, Tenant tenant) {
        List<GetStockInfoResult> list=null;
        try {
            RemoteResult remoteResult =stockPortApiService.getGlobalStockInfo(params, tenant);
            if(remoteResult.isSuccess()){
                Object object=remoteResult.getT();
                if(object!=null){
                    list=(List<GetStockInfoResult>)object;
                }
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }
        return list;
    }


    @Override
    public Map getProductInfoBymaterialNum(String materialNum) {
        return null;
    }
}
