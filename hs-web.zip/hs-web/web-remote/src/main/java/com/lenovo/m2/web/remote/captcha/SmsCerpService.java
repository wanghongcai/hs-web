package com.lenovo.m2.web.remote.captcha;

import com.lenovo.m2.web.domain.my.MobileMsg;

import java.util.Map;

public interface SmsCerpService {

	/**
	 * 下发短息接口
	 * @param mobile 下发的内容及手机号等信息
	 * @param isinner 是否内部下发
	 */
	void sendMsgBySMS(MobileMsg mobile, boolean isinner);

	/**
	 * 发送自定义短信
	 * @param mobile 手机号
	 * @param shopid 区分
	 * @param places 短信内容占位符
	 */
	void sendMsg(String mobile, String shopid, boolean isinner, Object... places);

	String getCaptcha(String prekey,String loginname,String shopid);

	String createCaptchaRandomNumber();

	boolean sendSmsCaptcha(MobileMsg mobile);

	boolean verifySmsCaptcha(MobileMsg mobile);
}