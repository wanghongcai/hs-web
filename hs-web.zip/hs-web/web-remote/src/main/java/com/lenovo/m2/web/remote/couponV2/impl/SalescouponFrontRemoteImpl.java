package com.lenovo.m2.web.remote.couponV2.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.dubboModel.UserApi;
import com.lenovo.m2.couponV2.api.dubboService.RpcMemberCounponrelsService;
import com.lenovo.m2.couponV2.api.dubboService.RpcSalescouponsService;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.api.service.MemberCounponrelsService;
import com.lenovo.m2.couponV2.api.service.OneKeyToReceiveService;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.remote.couponV2.SalescouponFrontRemote;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.lenovo.m2.couponV2.api.service.SalescouponsService;

import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/11.
 */
@Component("salescouponFrontRemote")
public class SalescouponFrontRemoteImpl implements SalescouponFrontRemote {
    private static Logger logger =  LogManager.getLogger(SalescouponFrontRemote.class.getName());
    @Autowired
    private SalescouponsService salescouponService;
    @Autowired
    private RpcSalescouponsService rpcSalescouponsService;
    @Autowired
    private MemberCounponrelsService memberCounponrelsService;
    @Autowired
    private RpcMemberCounponrelsService rpcMemberCounponrelsService;
    @Autowired
    private OneKeyToReceiveService oneKeyToReceiveService;

    @Override
    public RemoteResult bindCouponsForOneKeyPeople(String lenovoId, Integer activityType, String memberCode) {
        try{
            logger.info("bindCouponsForOneKeyPeople param :lenovoId={},activityType={},memberCode={}",lenovoId,activityType,memberCode);
            RemoteResult result = oneKeyToReceiveService.bindCouponsForOneKeyPeople(lenovoId,activityType,memberCode);
            RemoteResultUtil.updateMsgAndReplace(result, PromptEnum.ONEKEYTORECEIVESERVICE);
            return result;
        }catch(Exception e){
            logger.error("bindCouponsForOneKeyPeople error:",e);
            return null;
        }
    }
    @Override
    public RemoteResult<Boolean> addEppCoupon(int couponway, String lenovoid,String memberCode) {
        return rpcSalescouponsService.addEppCoupon(couponway,lenovoid,memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCoupons(Long couponId,String lenovoId, String memberCode) {
        return salescouponService.bindCoupons(couponId, lenovoId, memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCoupons(String shopId, Long couponId, String lenovoId, String memberCode) {
        return salescouponService.bindCoupons(shopId,couponId, lenovoId, memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCouponsForOnce(String shopId, Long couponId, String lenovoId, String memberCode) {
        return salescouponService.bindCouponsForOnce(shopId,couponId, lenovoId, memberCode);
    }

    @Override
    public int bindAllMemberSalesCoupons(String lenovoid, String memberCode, String groupcode, String shopid) {
        return memberCounponrelsService.bindAllMemberSalesCoupons(lenovoid,memberCode,groupcode,shopid);
    }

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(String lenovoId, String shopid, String teminal, String status, PageQuery pageQuery) {
        return memberCounponrelsService.getAppSaleCoupons(lenovoId,shopid,teminal,status,pageQuery);
    }

    @Override
    public RemoteResult getSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal) {
        RemoteResult result = rpcMemberCounponrelsService.getSalescouponsWithLenovoId(userApi, shopId, terminal);
        RemoteResultUtil.updateMsg(result, PromptEnum.RPCMEMBERCOUNPONRELSSERVICE);
        return result;
    }

    @Override
    public RemoteResult getUserSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal) {
        RemoteResult result = rpcMemberCounponrelsService.getUserSalescouponsWithLenovoId(userApi,shopId,terminal);
        RemoteResultUtil.updateMsg(result, PromptEnum.RPCMEMBERCOUNPONRELSSERVICE);
        return result;
    }

    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(String lenovoId, String shopid, String terminal, String status, String time, PageQuery pageQuery) {
        return memberCounponrelsService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status, time,pageQuery);
    }

    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery) {
        return memberCounponrelsService.getMemberCouponrelsPage4WapUserCenter(lenovoId, shopid, terminal, status, pageQuery);
    }

    @Override
    public RemoteResult bindBatchCoupons(String couponIds, String lenovoId, String memberCode) {
        RemoteResult result = rpcMemberCounponrelsService.bindBatchCoupons(couponIds, lenovoId, memberCode);
        RemoteResultUtil.updateMsg(result, PromptEnum.RPCMEMBERCOUNPONRELSSERVICE);
        return result;
    }

    @Override
    public RemoteResult getSalescouponsByClassification(PageQuery pageQuery,Map map) {
        return salescouponService.getSalescouponsByClassification(pageQuery,map);
    }

    @Override
    public RemoteResult getSalescouponsBySalesCouponIds(Tenant tenant, PageQuery pageQuery, Map map) {
        String displayPosition =  (String)map.get("displayPosition");
        logger.info("调用 getDistributeSalescoupons 参数pageQuery{},map{}： ", JsonUtil.toJson(pageQuery) , JsonUtil.toJson(map));
        RemoteResult result = salescouponService.getDistributeSalescoupons(tenant,pageQuery, Integer.parseInt(displayPosition));
        RemoteResultUtil.updateMsgAndReplace(result, PromptEnum.COUPON);
        return result;
    }

    @Override
    public RemoteResult getUserIshaveTheCoupon(Map map) {
        RemoteResult result = rpcMemberCounponrelsService.getUserIshaveTheCoupon(map);
        RemoteResultUtil.updateMsg(result, PromptEnum.RPCMEMBERCOUNPONRELSSERVICE);
        return result;
    }

    @Override
    public RemoteResult getSalesCouponsNumbersForId(Map map) {
        return salescouponService.getSalesCouponsNumbersForId(map);
    }

    @Override
    public RemoteResult getIsHaveSalesCouponsNum(Map map) {
        return salescouponService.getIsHaveSalesCouponsNum(map);
    }

    @Override
    public RemoteResult getMemberCouponsStatus(Map map) {
        return memberCounponrelsService.getMemberCouponsStatus(map);
    }

    @Override
    public RemoteResult getSalescouponsByUseScope(Tenant tenant, int useScope, Long salescouponId, String couponName) {
        RemoteResult result = salescouponService.getSalescouponsByUseScope(tenant, useScope, salescouponId, couponName);
        RemoteResultUtil.updateMsgAndReplace(result, PromptEnum.COUPON);
        return result;
    }

    @Override
    public RemoteResult<Integer> getMembercouponrelsByUser(Tenant tenant, String lenovoid, String terminal) {
        RemoteResult result = memberCounponrelsService.getMembercouponrelsByUser(tenant, lenovoid, terminal);
        RemoteResultUtil.updateMsgAndReplace(result, PromptEnum.COUPON);
        return result;
    }
}
