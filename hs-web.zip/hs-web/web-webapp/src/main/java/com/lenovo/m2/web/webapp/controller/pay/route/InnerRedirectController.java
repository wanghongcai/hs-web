package com.lenovo.m2.web.webapp.controller.pay.route;

import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import com.lenovo.m2.web.common.purchase.util.ViewPathUtil;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * 内部跳转
 * Created by MengQiang on 2016/12/9.
 */
@RequestMapping("/pay")
@Controller
@Scope("prototype")
public class InnerRedirectController extends BaseController {
    public static Logger LOGGER =  LogManager.getLogger(InnerRedirectController.class);

    @RequestMapping("/payLimit")
    public String payLimit(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        LOGGER.info("HTTP Invoke InnerRedirectController payLimit, shopId[" + shopId + "]");
        String payLimitURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            payLimitURL = "innerpay/b2c_pay_limit";
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)){
            payLimitURL = "innerpay/tk_pay_limit";
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)){
            payLimitURL = "innerpay/epp_pay_limit";
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)){
            payLimitURL = "innerpay/smb_pay_limit";
        } else {
            payLimitURL = "innerpay/b2c_pay_limit";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payLimit Finish, payLimitURL[" + payLimitURL + "]");
        return payLimitURL;
    }
    @RequestMapping("/payError")
    public String payError(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        paraMap.put("shopId",shopId);
        paraMap.put("termianl",terminal);
        LOGGER.info("HTTP Invoke InnerRedirectController payError, shopId[" + shopId + "]");
        String payErrorURL = null;
        paraMap.put("resultReason", "订单支付异常");
        if (PeakConstant.TERMINAL_PC.equals(terminal)){
            payErrorURL = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_pc_fail";
        }else {
            payErrorURL = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_wap_fail";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payError Finish, payErrorURL[" + payErrorURL + "]");
        return payErrorURL;
    }
    @RequestMapping("/payQuestion")
    public String payQuestion(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        LOGGER.info("HTTP Invoke InnerRedirectController payQuestion, shopId[" + shopId + "]");
        String payQuestionURL = null;
        if(PeakConstant.SHOPID_ALLINPAY.equals(shopId)){
            payQuestionURL = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/innerpay/allinpay_pay_question";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payQuestion Finish, payQuestionURL[" + payQuestionURL + "]");
        return payQuestionURL;
    }

    @RequestMapping("/payHelp")
    public String payHelp(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String terminal = request.getParameter("terminal");
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/innerpay/allinpay_payHelp";
    }
}
