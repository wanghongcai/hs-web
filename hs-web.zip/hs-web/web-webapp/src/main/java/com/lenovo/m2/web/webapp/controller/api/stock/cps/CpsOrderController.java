package com.lenovo.m2.web.webapp.controller.api.stock.cps;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.cps.api.PromotionRoutedService;
import com.lenovo.m2.cps.domain.CpsList;
import com.lenovo.m2.cps.domain.CpsUpdate;
import com.lenovo.m2.web.common.stock.utils.JsonUtil;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
@Scope("prototype")
@RequestMapping("/stock/cps")
public class CpsOrderController extends BaseController {
    private static final Logger LOGGER = LogManager.getLogger(CpsOrderController.class);
    @Autowired
    private PromotionRoutedService promotionRoutedService;
    /**
     cps第三方
     根据下单时间查询cps订单
     * @param cid            活动id
     * @param orderStartTime 订单生成时间
     * @param orderEndTime   订单结束时间
     * @return
     */
    @RequestMapping(value = "/SelectCpsOrderMessageByOrderStartTime",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String SelectCpsOrderMessageByOrderStartTime(String cid, String orderStartTime, String orderEndTime) {
        LOGGER.info("参数:cid=["+cid+"],orderStartTime=["+orderStartTime+"],orderEndTime=["+orderEndTime+"]");
        if (isNull(cid, orderStartTime, orderEndTime)) {
            return "参数错误";
        }
        try {
            RemoteResult<CpsList> result = promotionRoutedService.getCpsOrderByOrderCreateTime(cid, orderStartTime, orderEndTime);
            if (result != null && result.isSuccess() && result.getT() != null) {
                CpsList cpsList = result.getT();
                LOGGER.info("JsonUtil.toJson(cpsList)=[" + JsonUtil.toJson(cpsList) + "]");
                return JsonUtil.toJson(cpsList);
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }
        return null;
    }
    /**
     *
     cps第三方
     根据订单修改时间查询cps订单
     *
     * @param cid             活动id
     * @param updateStartTime 订单生成时间
     * @param updateEndTime   订单更新时间
     */
    @RequestMapping(value = "/SelectCpsOrderMessageByupdateEndTime",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String SelectCpsOrderMessageByupdateEndTime(String cid, String updateStartTime, String updateEndTime) {
        LOGGER.info("参数:cid=["+cid+"],updateStartTime=["+updateStartTime+"],updateEndTime=["+updateEndTime+"]");
        if (isNull(cid, updateStartTime, updateEndTime)) {
            return "参数错误";
        }
        try{
            RemoteResult<CpsUpdate> result = promotionRoutedService.getCpsOrderByOrderUpdateTime(cid, updateStartTime, updateEndTime);
            if (result!=null&& result.isSuccess()&&result.getT()!=null){
                CpsUpdate cu = result.getT();
                LOGGER.info("JsonUtil.toJson(CpsUpdate)=["+JsonUtil.toJson(cu)+"]");
                return JsonUtil.toJson(cu);
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }
        return null;
    }
}