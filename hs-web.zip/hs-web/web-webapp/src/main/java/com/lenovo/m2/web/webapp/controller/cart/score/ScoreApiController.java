package com.lenovo.m2.web.webapp.controller.cart.score;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.integral.CouponAndIntegralInfo;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.my.utils.HttpClientUtil;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.domain.my.enums.ShopIdEnum;
import com.lenovo.m2.web.remote.purchase.invoice.InvoiceRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;
import java.util.List;

/**
 * Created by D_xiao on 17/3/1.
 * 惠商积分兑换对外接口
 */
@Controller
@RequestMapping(value = "/score")
public class ScoreApiController extends BaseController {

    @Autowired
    private InvoiceRemoteService  invoiceRemoteService;

    private String exchangeUrl = CustomizedPropertyConfigurer.getContextProperty("exchange.url");

    public static Logger log =  LogManager.getLogger(ScoreApiController.class.getName());

    @RequestMapping(value = "/getCouponInfo",produces="application/json; charset=UTF-8")
    @ResponseBody
    public String getCouponInfo(String callbackparam,String couponId, HttpServletRequest request, HttpServletResponse response){
        try{
            logger.info("getCouponInfo param: couponId={}",couponId);
            if(couponId == null || "".equals(couponId)){
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM")),callbackparam);
            }
            RemoteResult<CouponAndIntegralInfo> result =  invoiceRemoteService.getCouponInfo(couponId);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT), callbackparam);
        }catch (Exception e){
            log.error("调用 getCouponInfo 异常:"+e.getMessage(),e);
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_TIMEOUT")),callbackparam);
        }


    }

    @RequestMapping(value = "/getAllCouponInfo",produces="application/json; charset=UTF-8")
    @ResponseBody
    public String getAllCouponInfo(String callbackparam, String type, HttpServletRequest request, HttpServletResponse response){
        try{
            log.info("getAllCouponInfo terminal:{}",type);
            RemoteResult<List<CouponAndIntegralInfo>> result =  invoiceRemoteService.getAllCouponInfo();
            log.info("getAllCouponInfo result1 : {}" + JsonUtil.toJson(result));
            int terminal = getBasePara().getTerminal();
            if(type!=null && !"".equals(type)){
                terminal = Integer.parseInt(type);
            }
            if(result!=null && result.getT()!=null){
                List<CouponAndIntegralInfo> list = result.getT();
                Iterator<CouponAndIntegralInfo> it = list.iterator();
                while(it.hasNext()){
                    CouponAndIntegralInfo couponAndIntegralInfo = it.next();
                    if(couponAndIntegralInfo.getPlatform().indexOf(String.valueOf(terminal))<0){
                        it.remove();
                    }
                }
                result.setT(list);
            }
            log.info("getAllCouponInfo result2 : {}" + JsonUtil.toJson(result));
            return JsonUtil.toJson(new FpsResult(result), callbackparam);
        }catch (Exception e){
            log.error("调用 getAllCouponInfo 异常:"+e.getMessage(),e);
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_TIMEOUT")),callbackparam);
        }


    }

    @RequestMapping(value = "/exchangeCoupon",produces="application/json; charset=UTF-8")
    @ResponseBody
    public String exchangeCoupon(String callbackparam,String couponId,String shopId,String memberId,String lenovoId, HttpServletRequest request, HttpServletResponse response){
        try{
            logger.info("exchangeCoupon param: shopId={},couponId={}",shopId,couponId);
            if(couponId == null || "".equals(couponId) ||shopId == null || "".equals(shopId) ){
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM")),callbackparam);
            }
            BasePara base = getBasePara();
            User user = base.getUser();
            logger.info("exchangeCoupon param : agentId={},agentCode={},buyerId={}",user.getMemberId(),user.getUsername(),user.getUserId());
            String address = exchangeUrl + user.getUserId();//1000000518 "http://i.itplace.lenovouat.com/rest/isAuthReal.jhtml?jxsNum="
            String jsonResult = HttpClientUtil.getStr(address);
            log.info("经销商认证信息:{}",jsonResult);
            com.alibaba.fastjson.JSONObject object = com.alibaba.fastjson.JSON.parseObject(jsonResult);
            if(object == null || object.getString("ret")==null || object.getBoolean("ret") ==false  ) {
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_BUYER_AUTH),callbackparam);
            }else{
                if("0".equals(object.getString("msg"))){
                    RemoteResult result = invoiceRemoteService.exchangeCoupon(ShopIdEnum.HUISHANG_SCORE.getType()+"",couponId,user.getMemberId(),user.getUsername(),user.getUserId());
                    logger.info("exchangeCoupon result:{}",JsonUtil.toJson(result));
                    return JsonUtil.toJson(new FpsResult(result), callbackparam);
                }else{
                    return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_BUYER_AUTH_NO),callbackparam);
                }
            }
        }catch (Throwable e){
            logger.error("调用 exchangeCoupon 异常:",e);
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_TIMEOUT),callbackparam);
        }


    }
}
