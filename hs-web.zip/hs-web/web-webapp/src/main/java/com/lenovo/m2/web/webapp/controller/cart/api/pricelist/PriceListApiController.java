package com.lenovo.m2.web.webapp.controller.cart.api.pricelist;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.api.param.pricelist.ManualOrderParam;
import com.lenovo.m2.hsbuy.api.param.pricelist.PriceListParam;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceListDetail;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.domain.purchase.priceList.PriceListAdaptor;
import com.lenovo.m2.web.domain.purchase.priceList.PriceListAdaptorParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import com.lenovo.m2.web.remote.purchase.pricelist.PriceListRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;

/**
 * Created by syj on 2016/7/26.
 */
@Controller
@RequestMapping(value = "/api/pricelist")
public class PriceListApiController extends BaseController {

    public static Logger log=  LogManager.getLogger(PriceListApiController.class.getName());

    @Autowired
    private PriceListRemoteService priceListRemoteService;
    
    
    /****************************** addPriceList *******************************/

    /**
     *   添加报价单
     */
    @RequestMapping(value = "/add", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String addPriceList(PriceListAdaptorParam priceListAdaptorParam) {
        RemoteResult<Map> result=new RemoteResult<>(false);
        try{
           // PriceListParam priceList = getPriceListParam(priceListAdaptorParam);
            // PriceListAdaptor request =  new PriceListAdaptor();
            // ClassReflection.reflectionAttr(priceListAdaptorParam,request);
            log.info("addPriceList priceListAdaptorParam = {}", JsonUtil.toJson(priceListAdaptorParam));
            PriceListParam priceList = new PriceListParam();
            org.springframework.beans.BeanUtils.copyProperties(priceListAdaptorParam,priceList);
        	String details = priceListAdaptorParam.getDetails();

        	List<PriceListDetail> listDetail = JsonUtil.readValuesAsArrayList(details, PriceListDetail.class);
        	priceList.setDetailList(listDetail);
        	priceList.setMemberNo(priceListAdaptorParam.getLenovoId());
        	priceList.setUserId(priceListAdaptorParam.getLenovoId());
            log.info("addPriceList priceList = {},tenant = {}", JsonUtil.toJson(priceList),getTenantCN());
            RemoteResult<String> res = priceListRemoteService.insertPriceList(getTenantCN(),priceList);
            log.info("remote result={}", JsonUtil.toJson(res));
            
            if(res.isSuccess()){
            	Map map = new HashMap<>();
            	map.put("pdfUrl", "");
                map.put("id",res.getT());
            	result.setSuccess(true);
            	result.setT(map);
            	return JsonUtil.toJson(result);
            }else{
            	result.setResultCode(res.getResultCode());
            	result.setResultMsg(res.getResultMsg());
            	return JsonUtil.toJson(result);
            }
            
        }catch(Exception t){
            log.error("add to pricelist error", t);
            result.setResultMsg(t.getMessage());
            return JsonUtil.toJson(result);
        }
    }

//    public PriceListParam getPriceListParam(PriceListAdaptorParam param){
//        PriceListParam price = new PriceListParam();
//        price.setId(param.getId());//(param)
//        price.setDealNo(param.getDealNo());
//        price.setExpireDate(param.getExpireDate());
//        price.setSaleOrganization(param.getSaleOrganization());
//        price.setItcode(param.getItcode());
//        price.setMemberNo(param.getMemberNo());
//        price.setTotalPrice(new Money(param.getTotalPrice(),"CNY"));
//        price.setPayee(param.getPayee());
//        price.setOpeningBank(param.getOpeningBank());
//        price.setAccountNumber(param.getAccountNumber());
//        price.setIsCreatedOrder(param.getIsCreatedOrder());
//        price.setAuditFile(param.getAuditFile());
//        price.setBuyerName(param.getBuyerName());
//        price.setBuyerAddress(param.getBuyerAddress());
//        price.setBuyerZip(param.getBuyerZip());
//        price.setBuyerPhone(param.getBuyerPhone());
//        price.setBuyerContacts(param.getBuyerContacts());
//        price.setBuyerTele(param.getBuyerTele());
//        price.setCustomManager(param.getCustomManager());
//        price.setCmPhone(param.getCmPhone());
//        price.setCmFax(param.getCmFax());
//        price.setCreateTime(param.getCreateTime());
//        price.setUpdateTime(param.getUpdateTime());
//        price.setDetail(param.getDetail());
//        price.setDetailList(param.getDetailList());
//        price.setUserId(param.getUserId());
//        price.setCurrencyCode(param.getCurrencyCode());
//        price.setShopId(param.getShopId());
//        price.setDetails(param.getDetails());
//        price.setLenovoId(param.getLenovoId());
//
//        return price;
//    }

    /**
     *   手工订单
     */
    @RequestMapping(value = "/manualorder", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public  String manualOrder(ManualOrderParam request) {
        RemoteResult<Map> result=new RemoteResult<>(false);
        try{
            log.info("pricelist manualorder = {},tenant={}", JsonUtil.toJson(request),getTenantCN());
        	result = priceListRemoteService.genMaualOrder(getTenantCN(),request);
        	
        	return JsonUtil.toJson(result);
        	
        }catch(Exception t){
            log.error("add to pricelist error", t);
            result.setResultMsg(t.getMessage());
            return JsonUtil.toJson(result);
        }
    }

    
    
    /**
     *  拉取商城提交订单的报价单列表
     */
    @RequestMapping(value = "/pullOrderedDealNo", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public String pullOrderedDealNo() {
        RemoteResult<String> result=new RemoteResult<>(false);
        try{
        	log.info("pull pricelist ");
        	result = priceListRemoteService.pullOrderedDealNo();
        	return JsonUtil.toJson(result);
        }catch(Exception t){
            log.error("add to pricelist error", t);
            result.setResultMsg(t.getMessage());
            return JsonUtil.toJson(result);
        }
    }
    
    
    /**
     * 更新为已下单
     * @return
     */
    @RequestMapping(value = "/updateToOrdered", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public  String updateToOrdered(String itCode, String userId, String dealNo) {
        RemoteResult<Integer> result=new RemoteResult<>(false);
        try{
        	log.info("updateToOrdered itCode={}, userId={}, dealNo={}", itCode, userId, dealNo);
        	result = priceListRemoteService.updateToOrdered(userId, dealNo);
        	return JsonUtil.toJson(result);
        }catch(Exception t){
            log.error("add to pricelist error", t);
            result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            result.setResultMsg(t.getMessage());
            return JsonUtil.toJson(result);
        }
    }
    
    
    /**
     * 查询报价单pdf
     * @return
     */
    @RequestMapping(value = "/queryPdfUrl", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public  String queryPdfUrl(String itCode, String userId, String dealNo) {
        RemoteResult<String> result=new RemoteResult<>(false);
        try{
        	log.info("updateToOrdered itCode={}, userId={}, dealNo={}", itCode, userId, dealNo);
        	result = priceListRemoteService.queryPdfUrl(itCode, userId, dealNo, null);
        	return JsonUtil.toJson(result);
        }catch(Exception t){
            log.error("add to pricelist error", t);
            result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            result.setResultMsg(t.getMessage());
            return JsonUtil.toJson(result);
        }
    }
    
    


}
