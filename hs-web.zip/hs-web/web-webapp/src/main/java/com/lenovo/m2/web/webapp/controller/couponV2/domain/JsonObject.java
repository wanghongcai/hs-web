package com.lenovo.m2.web.webapp.controller.couponV2.domain;

import java.io.Serializable;

/**
 * Created by zhanghb2 on 2015/12/29.
 */
public class JsonObject implements Serializable {
    private String ret;
    private String smallimg;
    private String bigimg;

    public String getRet() {
        return ret;
    }

    public void setRet(String ret) {
        this.ret = ret;
    }

    public String getSmallimg() {
        return smallimg;
    }

    public void setSmallimg(String smallimg) {
        this.smallimg = smallimg;
    }

    public String getBigimg() {
        return bigimg;
    }

    public void setBigimg(String bigimg) {
        this.bigimg = bigimg;
    }
}
