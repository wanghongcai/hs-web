package com.lenovo.m2.web.webapp.controller.cart.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.address.enums.AddressTypeEnums;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.annotation.NeedLogin;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.util.ViewPathUtil;
import com.lenovo.m2.web.remote.purchase.address.ConsigneeRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * <br> 实现用户收货信息维护
 *
 * @author shenjc
 */

@Controller
public class MemberAddrsController extends BaseController {

    private static Logger log = LogManager.getLogger(MemberAddrsController.class.getName());

    @Autowired
    private ConsigneeRemoteService consigneeRemoteService;

    /**
     * 为了兼容老版本的收货地址，没有删除该方法，（启用APP需更新地址）
     * 跳到个人中心收货地址列表(弃用)
     *
     * @author licy13
     * @deprecated use {@link MemberAddrsDongdeController#getPageListByType(int, int, String, Integer, Integer, HttpServletResponse, Map)} instead.
     */
    @Deprecated
    @RequestMapping("/getListPageNew")
    @NeedLogin
    public String getListPage(int shopId, int terminal, String type, Integer pageNum, Integer pageSize, HttpServletResponse response, Map<String, Object> map) {
        type = AddressTypeEnums.SH.getCode();
        pageSize = (pageSize == null || pageSize <= 0) ? 2 : pageSize;
        if (StringUtil.isEmpty(type)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "common/error";
        }

        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "common/error";
        }
        pageNum = (pageNum == null || pageNum <= 0) ? 1 : pageNum;
        pageSize = (pageSize == null || pageSize <= 0) ? 10 : pageSize;
        RemoteResult<Map<String, Object>> listResult = consigneeRemoteService.getListPageByType(getTenant(),new ConsigneeParam(user().getLenovoid(),type), pageNum, pageSize);
        if(listResult.isSuccess() && !listResult.getT().isEmpty()) {
            Map<String, Object> res = listResult.getT();
            map.put("res", res.get("list"));
            map.put("num", res.get("totalPage"));
            map.put("totalCount", res.get("totalCount"));
            map.put("index", res.get("currentPage"));
            map.put("type", type);
        }else {
            map.put("res", null);
            map.put("num", 1);
            map.put("totalCount", 0);
            map.put("index", 1);
            map.put("type", type);
        }
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buy/addressListPage";
    }

    /**
     * 查询收货信息列表(个人中心)（弃用）
     *
     * @author licy13
     * @deprecated use {@link MemberAddrsDongdeController#getListWapCenter(int, int, String, Map)} instead.
     */
    @Deprecated
    @RequestMapping("/getdeliverlistCenter")
    @NeedLogin
    public String getdeliverlistCenter(int shopId, int terminal, String type, Map<String, Object> map) {
        type=AddressTypeEnums.SH.getCode();
        if (StringUtil.isEmpty(type)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }

        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        RemoteResult<List<Memberaddrs>> result = consigneeRemoteService.getConsignees(getTenant(),new ConsigneeParam(user().getLenovoid(),type));
        List<Memberaddrs> memberaddrs = result.getT();
        map.put("res", memberaddrs);
        map.put("type", type);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/consignee_list_center";
    }

}
