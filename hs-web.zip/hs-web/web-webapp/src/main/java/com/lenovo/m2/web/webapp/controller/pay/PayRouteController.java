package com.lenovo.m2.web.webapp.controller.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.CommonMethod;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.manager.purchase.cashier.CashierManager;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.ThreadLocalSessionUser;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 支付入口，根据payType分发
 * Created by MengQiang on 2015/5/18.
 */
@RequestMapping("/pay")
@Controller
@Scope("prototype")
public class PayRouteController extends BaseController{
    private static Logger LOGGER = LogManager.getLogger(PayRouteController.class.getName());


    @Autowired
    private CashierManager cashierManager;

    @RequestMapping(value = "/toPay", produces = {"text/html;charset=UTF-8"})
    @ResponseBody
    public String pay(HttpServletRequest request, HttpServletResponse response) {

        String payType = request.getParameter("paymentTypeCode");
        String merchantCode = request.getParameter("merchantCode");
        String orderMainCode = request.getParameter("orderMainCode");
        String bankNo = request.getParameter("bankNo");
        String callback = request.getParameter("callback");
//        String transType = request.getParameter("transType");
//        String cardType = request.getParameter("cardType");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        String plat = request.getParameter("plat");
        String creditPay = request.getParameter("creditPay");//是否是信用还款支付
        SessionUser user = ThreadLocalSessionUser.getUser();
        if (StringUtils.isEmpty(plat)) {
            plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        }
        LOGGER.info("Https Pay Router Ready To Go! payType[" + payType + "],orderMainCode[" + orderMainCode + "],merchantCode[" + merchantCode + "],shopId[" + shopId + "],terminal[" + terminal + "],bankNo[" + bankNo + "],plat[" + plat + "],callback[" + callback + "],creditPay["+creditPay+"]");
//        Map<String, Object> paraMap = PropertiesHelper.loadToMap("pay_switch.properties");
        String returnInfo = "";
        if (user == null || StringUtil.isEmpty(user.getUsername()) || !islogin(request)) {
            //单点登录开启，且没有登录，需要先去登录
            LOGGER.info("Invoke Pay Router,but user is not loaded!");
            return callback + "(" + JacksonUtil.toJson(new BaseInfo(401, "用户未登录")) + ")";

        } else {



            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html");
            RemoteResult<String> returnResult = new RemoteResult<String>();
            returnInfo = realPay(user,creditPay, request, returnResult, response, callback, merchantCode);

            LOGGER.info("Invoke Pay Router Finish ! orderMainCode[" + orderMainCode + "],returnInfo[" + returnInfo + "]");
            return returnInfo;
        }
    }


    public String realPay(SessionUser user,String creditPay, HttpServletRequest request, RemoteResult<String> returnResult, HttpServletResponse response, String callback, String merchantCode) {
        try {
//            String plat = request.getParameter("plat");
//            String termial = request.getParameter("terminal");

            if(StringUtils.isNotEmpty(creditPay) && "true".equals(creditPay)){
                //信用还款支付
                returnResult = cashierManager.toCashierCreditPay(user,request);
            }else{
                returnResult = cashierManager.toCashierPay(user,request);
            }

            if (returnResult.isSuccess()) {
                LOGGER.info("表单信息[" + returnResult.getT() + "],merchantCode[" + merchantCode + "]");
                if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                    LOGGER.info("Roaming Return");
                    return JacksonUtil.toJson(new BaseInfo(0, returnResult.getT().toString()));
                }
                return callback + "(" + JacksonUtil.toJson(new BaseInfo(0, returnResult.getT().toString())) + ")";
            } else {
                LOGGER.info("merchantCode[" + merchantCode + "]");
                response.setContentType("application/json; charset=UTF-8");
                if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                    LOGGER.info("Roaming Return");
                    return JacksonUtil.toJson(new BaseInfo(1, returnResult.getResultMsg()));
                }
                return callback + "(" + JacksonUtil.toJson(new BaseInfo(1, returnResult.getResultMsg())) + ")";
            }
        } catch (Exception oe) {
            LOGGER.error("MerchantCode[" + merchantCode + "],支付的过程中出现异常", oe);
            response.setContentType("application/json; charset=UTF-8");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("支付异常");
            if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                LOGGER.info("Roaming Return");
                return JacksonUtil.toJson(new BaseInfo(2006, returnResult.getResultMsg()));
            }
            return callback + "(" + JacksonUtil.toJson(new BaseInfo(2006, returnResult.getResultMsg())) + ")";
        }
    }



    public  boolean  islogin(HttpServletRequest request){
        String lenovoId= getLenovoId();
        logger.info("lenovoId==单点登录获取======"+lenovoId);
        String lenovoid = request.getParameter("lenovoId");
        logger.info("lenovoid==前台页面获取======"+lenovoid);
        if(StringUtil.isNotEmpty(lenovoId)&&StringUtil.isNotEmpty(lenovoid)&&lenovoid.equals(lenovoId)){
            logger.info("单点登录校验正确。。。");
            return  true;
        }else{
            logger.info("单点登录校验失败。。。");
            return false;
        }
    }

}
