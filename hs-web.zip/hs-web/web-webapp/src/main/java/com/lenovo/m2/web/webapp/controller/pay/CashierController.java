package com.lenovo.m2.web.webapp.controller.pay;

import com.lenovo.contract.api.ContractApiService;
import com.lenovo.contract.domain.param.AutoSignBymixedParam;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.credit.api.dubboService.CreditService;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.manager.purchase.cashier.CashierManager;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.ThreadLocalSessionUser;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 收银台
 * Created by MengQiang on 2016年9月8日14:15:35.
 */
@Controller
@RequestMapping("/pay")
public class CashierController extends BaseController {

    private static Logger LOGGER = LogManager.getLogger(CashierController.class.getName());

    @Autowired
    private OpenOrderService OpenOrderService;
    @Autowired
    private ContractApiService contractApiService;
    @Autowired
    private CreditService creditService;
    @Autowired
    private CashierManager cashierManager;


    @RequestMapping("/toCashier")
    public String toNewCashier(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {

        String lenovoId = getLenovoId();
        String terminal = request.getParameter("terminal");
        String orderno = request.getParameter("orderMainCode");
        String creditPayStr = request.getParameter("creditPay");
        String shopId = request.getParameter("shopId");//商城
        SessionUser user = ThreadLocalSessionUser.getUser();
        //shopId = "1000";//惠商
        Tenant tenant = getTenant();
        String fa_id = "";
        String bill_amount = "";//订单金额
        String credit_amount = "";//信用还款金额
        String paymentWay = "0";//是否代收代付
        //boolean creditPay = true; //当前是正常支付还是信用支付
        boolean contractSigned = true;//合同是否已经签订了
        //String contractUrl = "http://goods.app.lefile.cn/contract/06cd1f506d094b9eae2791d36a328435.pdf";//合同内容地址
        String contractUrl = "";//合同内容地址
        boolean noBankList = false;//是否查询银行列表（当慧商订单全额信用的，收银台不显示银行列表，则不用去查了）

        paraMap.put("creditPay",creditPayStr);
        String accountType = "";//对公对私
        String paymentType = "1";//1:线上支付，2：线下银行转账
        int queryNum = 2;//需要查询订单的次数
        long sleepTime = 200L;//查询一次订单后睡眠的次数
        try{

            if (user == null || StringUtil.isEmpty(user.getUsername()) || StringUtil.isEmpty(lenovoId)) {
                LOGGER.info("Illegal Request lenovoId is null ! orderMainCode["+ orderno +"]");
                paraMap.put("resultReason", "用户未登录！");
                return getFailRedirect(shopId, terminal);
            }
            Map<String, Object> commonParam = PropertiesHelper.loadToMap("cashier_pay.properties");
            if("true".equals(creditPayStr)){
                //判断当前的用户是否是当前经销商的主账号//// TODO: 2017/5/23
                if (!SSOUtil.isMainAccount(user.getUsername())){
//            if (false){
                    LOGGER.info("Illegal Request, user is not the main user=="+lenovoId);
                    paraMap.put("resultReason", "当前登陆用户不是主账号！");
                    return getFailRedirect(shopId, terminal);
                }
                //信用还款
                RemoteResult<PayTrackingApi> creditRemoteResult = creditService.getPayTracking(orderno);
                LOGGER.info("获取订单信息：creditRemoteResult："+ JsonUtil.toJson(creditRemoteResult));
                if (creditRemoteResult == null || !creditRemoteResult.isSuccess() || creditRemoteResult.getT() == null){
                    LOGGER.info("Illegal Request creditRemoteResult is null ! creditRemoteResult["+ creditRemoteResult +"]");
                    paraMap.put("resultReason", "获取信用分期账单失败！");
                    return getFailRedirect(shopId, terminal);
                }
                PayTrackingApi payTracking = creditRemoteResult.getT();

                //检查信用账单状态
                String resultReason = cashierManager.checkCreditOrder(lenovoId,payTracking);
                if (StringUtils.isNotEmpty(resultReason)) {
                    paraMap.put("resultReason", resultReason);
                    return getFailRedirect(shopId, terminal);
                }

                bill_amount = payTracking.getReturnAmount().toString();//需还款额度
                accountType = String.valueOf(payTracking.getAccountType());
                fa_id = payTracking.getFaId();
            }else {
                //调用正常订单接口，查询订单信息
                RemoteResult<MongoOrderDetail> getOrderResult = OpenOrderService.getMongoOrderDetail(tenant,orderno);

                LOGGER.info("获取订单信息：remoteResult："+ JsonUtil.toJson(getOrderResult));
                if(getOrderResult == null || !getOrderResult.isSuccess() || getOrderResult.getT() == null){
                    LOGGER.info("获取订单信息失败！");
                    paraMap.put("resultReason", "获取订单失败！");
                    return getFailRedirect(shopId, terminal);
                }
                MongoOrderDetail mongoOrderDetail = getOrderResult.getT();

                //检查订单状态
                String resultReason = cashierManager.checkMongoOrder(lenovoId,mongoOrderDetail);
                if (StringUtils.isNotEmpty(resultReason) ) {
                    if (mongoOrderDetail.getSubmitOrderWay() == 2
                            && Integer.parseInt(PeakConstant.ORDER_AUDIT_SIGNING_CONTRACT) == mongoOrderDetail.getAuditStatus()){
                        //静默下单，直接从中间页到收银台，可能正在生成合同中
                        //查询三次mongo中的订单，若三次都没查到则页面提示正在生成合同
                        query:for (int i = 1; i <= queryNum; i++) {
                            Thread.sleep(i*sleepTime);
                            getOrderResult = OpenOrderService.getMongoOrderDetail(tenant,orderno);
                            if((getOrderResult != null && getOrderResult.isSuccess() && getOrderResult.getT() != null
                            && Integer.parseInt(PeakConstant.ORDER_AUDIT_SIGNING_CONTRACT) == getOrderResult.getT().getAuditStatus())){
                                LOGGER.info("获取静默下单订单信息！queryNum="+queryNum+",remoteResult="+ JsonUtil.toJson(getOrderResult));
                                if (i == queryNum){
                                    paraMap.put("resultReason", "正在生成合同中，请稍后再试！");
                                    return getFailRedirect(shopId, terminal);
                                }
                            }else {
                                break query;
                            }
                        }
                        //再次检查订单状态
                        mongoOrderDetail = getOrderResult.getT();
                        resultReason = cashierManager.checkMongoOrder(lenovoId,mongoOrderDetail);
                    }
                    if (StringUtils.isNotEmpty(resultReason)){
                        paraMap.put("resultReason", resultReason);
                        return getFailRedirect(shopId, terminal);
                    }
                }

                if (PeakConstant.ORDER_PAYMENTTYPE_OFFLINE_ZH.equals(String.valueOf(mongoOrderDetail.getPaymentType()))) {
                    LOGGER.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],PayStatus[" + mongoOrderDetail.getPayStatus() + "]");
                    //线下打款，不查询支付方式
                    noBankList = true;
                    paymentType = PeakConstant.ORDER_PAYMENTTYPE_OFFLINE;//线下银行转账
                    paraMap.put("paymentType",PeakConstant.ORDER_PAYMENTTYPE_OFFLINE);
                    //// 线下打款，，是否已经可以上传支付资料，即是否已经在收银台点击过支付了(在收银台点击过支付后，上传资料状态不是null)
                    if(PeakConstant.ORDER_CREDIT_USE_ALL != mongoOrderDetail.getCreditLineWay()
                            && PeakConstant.ORDER_OFFLINE_UPLOADSTATUS_NULL != mongoOrderDetail.getUploadStatus()) {
                        //若不是全额信用支付,且资料上传状态不是null，则跳转到错误异常页
                        LOGGER.info("Illegal Status,orderno[" + orderno + "],PayStatus[" + mongoOrderDetail.getPayStatus() + "]，" +
                                "uploadStatus="+mongoOrderDetail.getUploadStatus()+"");
                        paraMap.put("resultReason", "订单线下支付资料上传异常，请到订单列表查看详情！");
                        return getFailRedirect(shopId, terminal);

                    }
                }

                if (mongoOrderDetail.getCreditLine() != null){
                    credit_amount = mongoOrderDetail.getCreditLine().getAmount().toString();//信用金额
                }

                if(PeakConstant.ORDER_CREDIT_USE_NO != mongoOrderDetail.getCreditLineWay() ){
                    //creditLineWay; // 0:不用信用额度，1:部分用，2:全款用信用额度

                    //判断当前的用户是否是当前经销商的主账号//// TODO: 2017/5/23
                    if (!SSOUtil.isMainAccount(user.getUsername())){
//            if (false){
                        LOGGER.info("Illegal Request, user is not the main user=="+lenovoId);
                        paraMap.put("resultReason", "当前登陆用户不是主账号！");
                        return getFailRedirect(shopId, terminal);
                    }

                    if(PeakConstant.ORDER_CREDIT_USE_ALL == mongoOrderDetail.getCreditLineWay()){
                        //如果全款用信用额度，则不用查询银行列表
                        noBankList = true;
                    }

                    //只有使用信用额度，才会签署合同
                    contractUrl = mongoOrderDetail.getPactUrl();

                    if (StringUtil.isEmpty(contractUrl)){
                        LOGGER.info("Illegal contractUrl,mongoOrderDetail[" + mongoOrderDetail + "],contractUrl[" + contractUrl + "]");
                        paraMap.put("resultReason", "订单合同异常！");
                        return getFailRedirect(shopId, terminal);
                    }
                    if (PeakConstant.ORDER_AUDIT_STATUS_PASS.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
                        contractSigned = false;//未签订合同
                    }
                    if (PeakConstant.ORDER_AUDIT_SIGNED_CONTRACT.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
                        contractSigned = true;//已签订合同
                    }
                }

                bill_amount = mongoOrderDetail.getAmountMoney().toString();

                accountType = String.valueOf(mongoOrderDetail.getAccountType());
                fa_id = mongoOrderDetail.getFaid();
                paymentWay = mongoOrderDetail.getPaymentWay();
                paraMap.put("mongoOrderDetail", mongoOrderDetail);
                buildOrderInvalidTime(mongoOrderDetail,commonParam,paraMap);
            }

            //b2b的线上支付方式的订单不支持手机端支付---------------------收银台改造，放开，根据返回数据显示
//            if ((!PeakConstant.ORDER_PAYMENTTYPE_OFFLINE.equals(paymentType)) &&"2".equals(accountType) && !PeakConstant.TERMINAL_PC.equals(terminal)){
//                LOGGER.info("b2b不支持移动端支付,orderMainCode[" + orderno + "]");
//                paraMap.put("resultReason", "此订单为企业订单，不支持移动端支付，请到PC端进行支付！");
//                return getFailRedirect(shopId, terminal);
//            }

            String plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);

            paraMap.put("plat", plat);
            paraMap.put("shopId", shopId);
            paraMap.put("terminal", terminal);
            paraMap.put("lenovoId", lenovoId);
            paraMap.put("merchantCode", "");
            paraMap.put("creditAmount", credit_amount);
            paraMap.put("contractSigned", contractSigned);
            paraMap.put("contractUrl", contractUrl);
            //应还款额度
            paraMap.put("billAmount",bill_amount);
            //订单号
            paraMap.put("orderno",orderno);
            paraMap.put("account_type",accountType);

            //惠商获取商户订单支持的直连网银
            if (noBankList){
                //如果全款用信用额度，则不用查询银行列表
                return getCashierRedirect(shopId, terminal, paymentWay);
            }

            if(!getPayTypeList(orderno,lenovoId,fa_id,shopId,bill_amount,accountType,terminal,commonParam,paraMap)){
                return getFailRedirect(shopId, terminal);
            }
            return getCashierRedirect(shopId, terminal, paymentWay);
        }catch(Exception testException){
            LOGGER.error("Cashier Exception", testException);
            paraMap.put("resultReason", "网络异常，请稍后重试！");
            return getFailRedirect(shopId, terminal);
        }
    }

    /**
     * 查询银行列表和支付方式
     * @param fa_id
     * @param shopId
     * @param bill_amount
     * @param accountType
     * @param terminal
     * @param commonParam
     * @param paraMap
     * @return  true 查询成功；false 查询失败
     */
    public boolean getPayTypeList(String orderno, String lenovoId, String fa_id,String shopId,String bill_amount,String accountType,String terminal
            ,Map<String, Object> commonParam,Map<String, Object> paraMap){
        boolean queryFlay = true;//是否支付方式查询成功
        Tenant tenant = getTenant();

        String service = "lenovo_direct_banks";
        String sign_typ = "MD5";
        Map<String,String> requestMap = new HashMap<>();
        requestMap.put("service",service);
        requestMap.put("fa_id",fa_id);
        requestMap.put("shop_id",shopId);
        requestMap.put("bill_amount",bill_amount);
        requestMap.put("account_type",accountType);
        requestMap.put("out_trade_no",orderno);
        requestMap.put("lenovo_id",lenovoId);

        String signKey = (String)commonParam.get(shopId);
        String sign = PaySignUtils.buildSignKey(requestMap,sign_typ,signKey);
        requestMap.put("sign",sign);
        requestMap.put("sign_type",sign_typ);


        LOGGER.info("查询支付渠道参数，requestMap["+requestMap+"]");
        String url = String.valueOf(PropertiesHelper.loadToMap("cashier_pay.properties").get("URL_LENOVO_SUPPORT_PAY_TYPE_"+tenant.getCurrencyCode()));
        String result = HttpsClientUtil.doPost(url, requestMap, "utf-8");
//        String result = getBanks6();
//        String result = getBanks7();

        LOGGER.info("查询银行列表返回结果："+result);
        if (!StringUtil.isNotEmpty(result)){
            LOGGER.error("查询银行列表返回结果："+result);
            paraMap.put("resultReason", "网络出错");
            queryFlay = false;
        }
        JSONObject object = JSONObject.fromObject(result);
        if (object != null){
            if ("false".equals(object.getString("success"))){
                paraMap.put("resultReason", (String)object.get("resultMessage"));
                LOGGER.info("查询银行列表返回错误：resultMessage "+object.get("resultMessage"));
                queryFlay = false;
            }else if ("true".equals(object.getString("success"))){
                paraMap.put("bankList",object.get("bank_list"));//银行列表
                paraMap.put("payTypeList",object.get("pay_type_list"));//支付平台列表
                paraMap.put("points",object.get("points"));//积分支付信息

            }
        }else {
            paraMap.put("resultReason", "查询支付方式失败");
            LOGGER.info("查询支付方式失败");
            queryFlay = false;
        }
        return queryFlay;
    }

    /**
     * 签署合同
     * @return
     */
    @RequestMapping(value = "/toSignContract", produces = {"text/html;charset=UTF-8"})
    @ResponseBody
    public String toSignContract(){
        String resultJson = "";
        JSONObject obj = new JSONObject();
        String shopId = request().getParameter("shopId");
        Tenant tenant = Tenant.getTenant(Integer.parseInt(shopId));
        String orderNo = request().getParameter("orderNo");
        LOGGER.info("签订合同orderNo["+orderNo+"]");
        String lenovoId = request().getParameter("lenovoId");

        String status = "1";//签订状态  0失败；1成功；
        String result = "";//失败原因，或者合同url
        try{
            //首先获取订单信息
            while (true){
                //调用正常订单接口，查询订单信息
                RemoteResult<MongoOrderDetail> getOrderResult = OpenOrderService.getMongoOrderDetail(tenant,orderNo);


                if(getOrderResult == null || !getOrderResult.isSuccess()){
                    LOGGER.error("获取订单信息失败！");
                    status = "0";
                    result = "获取订单失败！";
                    break;
                }
                LOGGER.info("获取订单信息：remoteResult："+getOrderResult);
                MongoOrderDetail mongoOrderDetail = getOrderResult.getT();
                if (mongoOrderDetail == null) {
                    LOGGER.error("获取订单信息失败！");
                    status = "0";
                    result = "获取订单失败！";
                    break;
                }

                if (StringUtils.isNotEmpty(lenovoId) && !lenovoId.equals(mongoOrderDetail.getLenovoId())) {
                    LOGGER.error("非法请求！");
                    status = "0";
                    result = "非法请求！";
                    break;
                }
                if (!( PeakConstant.ORDER_AUDIT_STATUS_PASS.equals(String.valueOf(mongoOrderDetail.getAuditStatus())))) {
                    LOGGER.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],OrderStatus[" + mongoOrderDetail.getOrderStatus() + "]");
                    status = "0";
                    result = "订单审核状态异常，请重新发起！";
                    break;
                }
                if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(mongoOrderDetail.getOrderStatus()))) {
                    LOGGER.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],OrderStatus[" + mongoOrderDetail.getOrderStatus() + "]");
                    status = "0";
                    result = "订单状态异常，请重新发起！";
                    break;
                }
                if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
                    LOGGER.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],OrderStatus[" + mongoOrderDetail.getOrderStatus() + "]");
                    status = "0";
                    result = "订单已支付，请到订单列表查看详情！";
                    break;
                }

                if(mongoOrderDetail.getCreditLine() == null || mongoOrderDetail.getCreditLine().getAmount().compareTo(new BigDecimal(0)) == 0){
                    LOGGER.info("Illegal creditLine,mongoOrderDetail[" + mongoOrderDetail + "],creditLine[" + mongoOrderDetail.getCreditLine() + "]");
                    status = "0";
                    result = "订单信用金额为0，请到订单详情查看详情！";
                    break;
                }

                AutoSignBymixedParam param = new AutoSignBymixedParam();
                param.setOrderId(orderNo);
                RemoteResult<String> contractRemoteResult = contractApiService.autoSignBymixed(param,tenant);
                LOGGER.info("签订合同orderNo["+orderNo+"],结果"+contractRemoteResult);
                if (contractRemoteResult != null && contractRemoteResult.isSuccess()){
                    status = "1";
                    result = contractRemoteResult.getT();
                }else{
                    status = "0";
                    result = "签订合同失败";
                }
                break;
            }

        }catch (Exception e){
            logger.error("签订合同失败orderNo="+orderNo+",e--",e);
            status = "0";
            result = "签订合同失败";
        }
        obj.put("status", status);
        obj.put("result", result);
        resultJson = obj.toString();
        return resultJson;
    }

    /**
     * 将pdf转换为img放到页面上，暂时用于wap端
     * @param response
     */
    @RequestMapping(value="/getContractPdf")
    public void getContractPdf(HttpServletResponse response){
        String fileUrl = request().getParameter("fileUrl");
        LOGGER.info("获取pdfUrl["+fileUrl+"]");
        InputStream fileInputStream = null;
        OutputStream outputStream = null;
        try {
            URL url = new URL(fileUrl);
            if("https".equalsIgnoreCase(url.getProtocol())){
                SslUtils.ignoreSsl();
            }
            URLConnection connection = url.openConnection();
            fileInputStream = connection.getInputStream();
            outputStream = response.getOutputStream();
            ImgPdfUtils.pdfInputStream2ImgOutStream(fileInputStream,outputStream,1);
            outputStream.flush();
            outputStream.close();
            fileInputStream.close();

        } catch (Exception e) {
            LOGGER.error("获取合同pdf失败 url="+fileUrl+",e["+e+"]");
        }finally {
            try {
                if (outputStream != null){
                    outputStream.close();
                }
                if (fileInputStream != null){
                    fileInputStream.close();;
                }
            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }


    private void buildOrderInvalidTime(MongoOrderDetail mongoOrderDetail, Map<String, Object> commonParam,Map paraMap) {
        Date expirationTime = null;
        try {
            expirationTime = DateUtil.parseDate(mongoOrderDetail.getCreateTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT);
        }catch (Exception e){
            expirationTime = new Date();
        }
        if (expirationTime == null) {
            expirationTime = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(expirationTime);
        try {
            if (commonParam == null) {
                LOGGER.info("Invoke buildOrderInvalidTime commonParam Is NULL");
                if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                    calendar.add(Calendar.DATE, 15);
                    paraMap.put("expirationHour","15天");
                } else {
                    calendar.add(Calendar.HOUR, 24);
                    paraMap.put("expirationHour","24小时");
                }
                paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            } else {
                String queryStr = "ORDER_INVALID_TIME_" + mongoOrderDetail.getShopId() + "_" + mongoOrderDetail.getOrderAddType();
                String invalidTimeStr = (String) commonParam.get(queryStr);
                LOGGER.info("Invoke buildOrderInvalidTime Query[" + queryStr + "],invalidTime[" + invalidTimeStr + "]");
                if (StringUtils.isNotEmpty(invalidTimeStr) && !("null".equals(invalidTimeStr))) {
                    int invalidTimeInt = Integer.parseInt(invalidTimeStr);
                    calendar.add(Calendar.MINUTE, invalidTimeInt);
                    paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                    if (invalidTimeInt > 1440) {
                        invalidTimeInt = invalidTimeInt / 1440;
                        paraMap.put("expirationHour",invalidTimeInt + "天");
                    } else if (invalidTimeInt <= 60) {
                        paraMap.put("expirationHour",invalidTimeInt + "分钟");
                    } else {
                        invalidTimeInt = invalidTimeInt / 60;
                        paraMap.put("expirationHour",invalidTimeInt + "小时");
                    }
                } else {
                    LOGGER.info("Invoke buildOrderInvalidTime invalidTimeStr Is NULL");
                    if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                        calendar.add(Calendar.DATE, 15);
                        paraMap.put("expirationHour","15天");
                    } else {
                        calendar.add(Calendar.HOUR, 24);
                        paraMap.put("expirationHour","24小时");
                    }
                    paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                }
            }
        } catch (Exception e) {
            if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                calendar.add(Calendar.DATE, 15);
                paraMap.put("expirationHour","15天");
            } else {
                calendar.add(Calendar.HOUR, 24);
                paraMap.put("expirationHour","24小时");
            }
            paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
        }
    }


    /**
     * 基于SHOPID Terminal 跳转失败页
     *
     * @param shopId   shopId
     * @param terminal terminal
     * @return String
     */
    private String getFailRedirect(String shopId, String terminal) {
        String url = null;
        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_pc_fail";
        } else {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_wap_fail";
        }
        return url;
    }

    /**
     * Go Cashier
     */
    private String getCashierRedirect(String shopId, String terminal, String paymentWay) {
        String url = null;
        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/allinpay_pc";
        } else {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/allinpay_wap";
        }
        return url;
    }

    private String getSubmitOrderRedirect(String shopId, String terminal) {
        String url = null;
        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/submitorder_pc";
        } else {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/submitorder_wap";
        }
        return url;
    }

    /**
     * 查询银行列表返回失败信息
     * @param errCode
     * @return
     */
    public String getBanksErrorMsg(String errCode){
        String errorMsg = "查询银行列表返回参数错误";
        if ("10001".equals(errCode)){
            errorMsg = "错误的请求参数";
        }else if ("10002".equals(errCode)){
            errorMsg = "签名验证失败";
        }else if ("10003".equals(errCode)){
            errorMsg = "订单金额错误";
        }else if ("10004".equals(errCode)){
            errorMsg = "交易类型错误";
        }else if ("10005".equals(errCode)){
            errorMsg = "服务器出现异常";
        }
        return errorMsg;
    }

    public String getBanks(){
        String str = "{\n" +
                "  \"success\": true,\n" +
                "  \"total\": 4,\n" +
                "  \"bank_list\": [\n" +
                "    {\n" +
                "      \"bank_code\": 1,\n" +
                "      \"bank_abbr\": \"ICBC\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 17\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 2,\n" +
                "      \"bank_abbr\": \"CCB\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 3,\n" +
                "      \"bank_abbr\": \"BOC\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 6,\n" +
                "      \"bank_abbr\": \"CMB\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 2,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  ]\n" +
                "}\n";

        return str;
    }



//    public String getBanks3(){
//        String str = "{\n" +
//                "    \"success\": true,\n" +
//                "    \"resultMessage\": \"获取支付渠道成功!\",\n" +
//                "    \"bank_list\": [\n" +
//                "        {\n" +
//                "            \"bank_no\": 1,\n" +
//                "            \"bank_abbr\": \"ICBC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 1,\n" +
//                "            \"bank_abbr\": \"ICBC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 2,\n" +
//                "            \"bank_abbr\": \"CCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 2,\n" +
//                "            \"bank_abbr\": \"CCB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 3,\n" +
//                "            \"bank_abbr\": \"BOC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 3,\n" +
//                "            \"bank_abbr\": \"BOC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 4,\n" +
//                "            \"bank_abbr\": \"ABC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 4,\n" +
//                "            \"bank_abbr\": \"ABC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 5,\n" +
//                "            \"bank_abbr\": \"COMM\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 5,\n" +
//                "            \"bank_abbr\": \"COMM\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 6,\n" +
//                "            \"bank_abbr\": \"CMB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 6,\n" +
//                "            \"bank_abbr\": \"CMB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 7,\n" +
//                "            \"bank_abbr\": \"CITIC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 7,\n" +
//                "            \"bank_abbr\": \"CITIC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 8,\n" +
//                "            \"bank_abbr\": \"CMBC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 8,\n" +
//                "            \"bank_abbr\": \"CMBC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 9,\n" +
//                "            \"bank_abbr\": \"CIB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 9,\n" +
//                "            \"bank_abbr\": \"CIB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 10,\n" +
//                "            \"bank_abbr\": \"SPDB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 10,\n" +
//                "            \"bank_abbr\": \"SPDB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 11,\n" +
//                "            \"bank_abbr\": \"PSBC\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 11,\n" +
//                "            \"bank_abbr\": \"PSBC\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 12,\n" +
//                "            \"bank_abbr\": \"CEB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 12,\n" +
//                "            \"bank_abbr\": \"CEB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 13,\n" +
//                "            \"bank_abbr\": \"SPAB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 13,\n" +
//                "            \"bank_abbr\": \"SPAB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 14,\n" +
//                "            \"bank_abbr\": \"HXB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 14,\n" +
//                "            \"bank_abbr\": \"HXB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 15,\n" +
//                "            \"bank_abbr\": \"BJB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 15,\n" +
//                "            \"bank_abbr\": \"BJB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 16,\n" +
//                "            \"bank_abbr\": \"GDB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 16,\n" +
//                "            \"bank_abbr\": \"GDB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 17,\n" +
//                "            \"bank_abbr\": \"SHB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 17,\n" +
//                "            \"bank_abbr\": \"SHB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 18,\n" +
//                "            \"bank_abbr\": \"CZB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 19,\n" +
//                "            \"bank_abbr\": \"NJCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 21,\n" +
//                "            \"bank_abbr\": \"BONB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 22,\n" +
//                "            \"bank_abbr\": \"SRCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 22,\n" +
//                "            \"bank_abbr\": \"SRCB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 23,\n" +
//                "            \"bank_abbr\": \"BJRCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 24,\n" +
//                "            \"bank_abbr\": \"CBHB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 26,\n" +
//                "            \"bank_abbr\": \"HZCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                },\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 26,\n" +
//                "            \"bank_abbr\": \"HZCB\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 16,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 27,\n" +
//                "            \"bank_abbr\": \"BODL\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 27,\n" +
//                "            \"bank_abbr\": \"BODL\",\n" +
//                "            \"card_type\": 2,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 29,\n" +
//                "            \"bank_abbr\": \"HKB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 31,\n" +
//                "            \"bank_abbr\": \"GYB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 32,\n" +
//                "            \"bank_abbr\": \"HRXJB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 33,\n" +
//                "            \"bank_abbr\": \"QSB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 34,\n" +
//                "            \"bank_abbr\": \"TACCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 35,\n" +
//                "            \"bank_abbr\": \"ZJTLCB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 36,\n" +
//                "            \"bank_abbr\": \"ZZB\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 12,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.003\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"bank_no\": 37,\n" +
//                "            \"bank_abbr\": \"BEA\",\n" +
//                "            \"card_type\": 1,\n" +
//                "            \"pay_plat_list\": [\n" +
//                "                {\n" +
//                "                    \"plat_code\": 13,\n" +
//                "                    \"rateType\": 1,\n" +
//                "                    \"rate\": 0.002\n" +
//                "                }\n" +
//                "            ]\n" +
//                "        }\n" +
//                "    ],\n" +
//                "    \"pay_type_list\": [\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"13\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"1\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"14\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"2\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"9\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"15\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"12\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"16\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"fa_id\": \"hs201611041101\",\n" +
//                "            \"pay_type\": \"17\"\n" +
//                "        }\n" +
//                "    ]\n" +
//                "}";
//        return str;
//    }

    public String getBanks5(){
        String str = "{\n" +
                "  \"success\": true,\n" +
                "  \"total\": 4,\n" +
                "  \"bank_list\": [\n" +
                "    {\n" +
                "      \"bank_code\": 1,\n" +
                "      \"bank_abbr\": \"ICBC\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 17\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 2,\n" +
                "      \"bank_abbr\": \"CCB\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 3,\n" +
                "      \"bank_abbr\": \"BOC\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 1,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 12\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"bank_code\": 6,\n" +
                "      \"bank_abbr\": \"CMB\",\n" +
                "\"trans_type\": 1,\n" +
                "      \"card_type\": 2,\n" +
                "      \"pay_plat_list\": [\n" +
                "        {\n" +
                "          \"plat_code\": 16\n" +
                "        },\n" +
                "        {\n" +
                "          \"plat_code\": 13\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  ]\n" +
                "   ,\"points\":{\"usedPoints\":0,\"availablePoints\":100,\"pointStatus\":1,\"pointRate\":\"10\"}"+
                "}\n";

        return str;
    }

    public String getBanks6(){
        String str = "{\n" +
                "    \"success\":true,\n" +
                "    \"resultMessage\":\"获取支付渠道成功!\",\n" +
                "    \"pay_type_list\":[\n" +
                "        {\n" +
                "            \"fa_id\":\"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\":\"1\",\n" +
                "            \"accountType\":\"1\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\":\"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\":\"12\",\n" +
                "            \"accountType\":\"1\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\":\"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\":\"17\",\n" +
                "            \"accountType\":\"1\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\":\"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\":\"16\",\n" +
                "            \"accountType\":\"1\",\n" +
                "            \"bank_type_list\":[\n" +
                "                {\n" +
                "                    \"bank_type\":\"1\",\n" +
                "                    \"card_type_list\":[\n" +
                "                        {\n" +
                "                            \"card_type\":\"1\",\n" +
                "                            \"bank_list\":[\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                }\n" +
                "                            ]\n" +
                "                        }\n" +
                "                    ]\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\":\"2\",\n" +
                "                    \"card_type_list\":[\n" +
                "                        {\n" +
                "                            \"card_type\":\"1\",\n" +
                "                            \"bank_list\":[\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":2,\n" +
                "                                    \"bank_abbr\":\"CCB\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":3,\n" +
                "                                    \"bank_abbr\":\"BOC\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":3,\n" +
                "                                    \"bank_abbr\":\"BOC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":5,\n" +
                "                                    \"bank_abbr\":\"COMM\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":3,\n" +
                "                                    \"bank_abbr\":\"BOC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":5,\n" +
                "                                    \"bank_abbr\":\"COMM\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":3,\n" +
                "                                    \"bank_abbr\":\"BOC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":4,\n" +
                "                                    \"bank_abbr\":\"ABC\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":5,\n" +
                "                                    \"bank_abbr\":\"COMM\",\n" +
                "                                    \"card_type\":1,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":16,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.002\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                }" +
                "                            ]\n" +
                "                        }," +
                "                        {\n" +
                "                            \"card_type\":\"2\",\n" +
                "                            \"bank_list\":[\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                },\n" +
                "                                {\n" +
                "                                    \"bank_no\":29,\n" +
                "                                    \"bank_abbr\":\"HKB\",\n" +
                "                                    \"card_type\":2,\n" +
                "                                    \"pay_plat_list\":[\n" +
                "                                        {\n" +
                "                                            \"plat_code\":12,\n" +
                "                                            \"rateType\":1,\n" +
                "                                            \"rate\":0.003\n" +
                "                                        }\n" +
                "                                    ]\n" +
                "                                }\n" +
                "                            ]\n" +
                "                        }\n" +
                "                    ]\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"points\":{\n" +
                "        \"usedPoints\":0,\n" +
                "        \"availablePoints\":277050,\n" +
                "        \"pointStatus\":1,\n" +
                "        \"pointRate\":10\n" +
                "    }\n" +
                "}";

        return str;
    }

    public String getBanks7(){
        String str = "{\n" +
                "    \"success\": true,\n" +
                "    \"resultMessage\": \"获取支付渠道成功!\",\n" +
                "    \"pay_type_list\": [\n" +
                "        {\n" +
                "            \"fa_id\": \"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\": \"16\",\n" +
                "            \"accountType\": \"1\",\n" +
                "            \"bank_list\": [\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                }\n" +
                "            ]\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\": \"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\": \"17\",\n" +
                "            \"accountType\": \"1\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\": \"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\": \"1\",\n" +
                "            \"accountType\": \"1\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"fa_id\": \"7102f80a-e544-4631-9f98-71c9e9296a5d\",\n" +
                "            \"pay_type\": \"12\",\n" +
                "            \"account_type\": \"1\",\n" +
                "            \"bank_list\": [\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 1,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 2\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 1,\n" +
                "                    \"bank_abbr\": \"ICBC\",\n" +
                "                    \"card_type\": 1\n" +
                "                },\n" +
                "                {\n" +
                "                    \"bank_type\": 2,\n" +
                "                    \"bank_code\": 2,\n" +
                "                    \"bank_abbr\": \"CCB\",\n" +
                "                    \"card_type\": 1\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"points\": {\n" +
                "        \"usedPoints\": 0,\n" +
                "        \"availablePoints\": 277050,\n" +
                "        \"pointStatus\": 1,\n" +
                "        \"pointRate\": 10\n" +
                "    }\n" +
                "}";

        return str;
    }

}
