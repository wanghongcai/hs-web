package com.lenovo.m2.web.webapp.controller.cart.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.address.enums.AddressTypeEnums;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeAddressParam;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.annotation.CheckRefer;
import com.lenovo.m2.web.common.purchase.annotation.NeedLogin;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.common.purchase.util.ViewPathUtil;
import com.lenovo.m2.web.remote.purchase.address.ConsigneeRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ClassName: MemberAddrsDongdeController <br/>
 * Function: 收货地址重构，所有地址走这个类的逻辑. <br/>
 * date: 2016年6月29日 下午7:52:11 <br/>
 *
 * @author yuzj7@lenovo.com
 * @since JDK 1.7
 */

@Controller
@RequestMapping("/consignee")
public class MemberAddrsDongdeController extends BaseController {

    private static Logger log = LogManager.getLogger(MemberAddrsDongdeController.class.getName());

    @Autowired
    private ConsigneeRemoteService consigneeRemoteService;

    /**
     * <br>
     * 添加收货信息
     *
     * @return
     */
    @RequestMapping("/addconsignee")
    @ResponseBody
    @CheckRefer
    @NeedLogin
    public String addDeliver(int shopId, HttpServletResponse response) {
        if (super.user() == null) {
            return this.ajaxWriteStr(JsonUtil.toJson(new BaseInfo(401, "未登录")), response);
        }

        String delivername = request().getParameter("delivername");
        String deliverprovice = request().getParameter("deliverprovice");
        String delivercity = request().getParameter("delivercity");
        String delivercounty = request().getParameter("delivercounty");
        String deliverproviceNo = request().getParameter("deliverproviceNo");
        String delivercityNo = request().getParameter("delivercityNo");
        String delivercountyNo = request().getParameter("delivercountyNo");
        String deliverStreet = request().getParameter("deliverStreet");
        String delivertele = request().getParameter("delivertele");
        String delivermobile = request().getParameter("delivermobile");
        String deliveremail = request().getParameter("deliveremail");
        String isdefault = request().getParameter("isDefault");
        String type = request().getParameter("type");
        String areaNos = request().getParameter("areaNos");
        String company = request().getParameter("company");// 收货公司
        String towerShip = request().getParameter("towerShip");// 乡镇
        String zip = request().getParameter("zip");
        String regEx = "\\d+";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(deliverStreet);
        boolean rs = matcher.matches();
        if(rs){//收货地址不能全是数字校验
            return this.ajaxWriteStr(JsonUtil.toJson(new BaseInfo(401, "请输入正确收货地址")), response);
        }
        if ((AddressTypeEnums.SP.getCode()).equals(type) && StringUtil.isEmpty(zip)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        String lenovoId = super.user().getLenovoid();
        ConsigneeAddressParam consigneeEntity = new ConsigneeAddressParam();
        consigneeEntity.setLenovoId(lenovoId);
        consigneeEntity.setCreateby(lenovoId);
        consigneeEntity.setIsdefault(Integer.parseInt(isdefault));
        consigneeEntity.setAddress(deliverStreet);
        consigneeEntity.setCityCode(delivercity);
        consigneeEntity.setCityNo(delivercityNo);
        consigneeEntity.setCountyCode(delivercounty);
        consigneeEntity.setCountyNo(delivercountyNo);
        consigneeEntity.setEmail(deliveremail);
        consigneeEntity.setMobile(delivermobile);
        consigneeEntity.setName(delivername);
        consigneeEntity.setProvinceCode(deliverprovice);
        consigneeEntity.setProvinceNo(deliverproviceNo);
        consigneeEntity.setTel(delivertele);
        consigneeEntity.setType(type);
        consigneeEntity.setAreaNos(areaNos);
        consigneeEntity.setLenovoId(user().getLenovoid());
        consigneeEntity.setZip(zip);
        consigneeEntity.setTownshipCode(towerShip);
        consigneeEntity.setCompany(company);
        RemoteResult<String> result = consigneeRemoteService.saveConsignee(getTenant(),consigneeEntity);
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(result)), response);
    }

    /**
     * <br>
     * 修改收货信息
     *
     * @return
     */
    @RequestMapping("/updateconsignee")
    @ResponseBody
    @CheckRefer
    @NeedLogin
    public String modifyDeliver(int shopId, HttpServletResponse response) {
        if (super.user() == null) {
            return this.ajaxWriteStr(JsonUtil.toJson(new BaseInfo(401, "未登录")), response);
        }

        final String delivername = request().getParameter("delivername");
        final String deliverprovice = request().getParameter("deliverprovice");
        final String delivercity = request().getParameter("delivercity");
        final String delivercounty = request().getParameter("delivercounty");
        final String deliverproviceNo = request().getParameter("deliverprovinceNo");
        final String delivercityNo = request().getParameter("delivercityNo");
        final String delivercountyNo = request().getParameter("delivercountyNo");
        final String deliverStreet = request().getParameter("deliverStreet");
        final String delivertele = request().getParameter("delivertele");
        final String deliverid = request().getParameter("deliverid");
        final String delivermobile = request().getParameter("delivermobile");
        final String deliveremail = request().getParameter("deliveremail");
        final String isdefault = request().getParameter("isDefault");
        String type = request().getParameter("type");
        String areaNos = request().getParameter("areaNos");

        String company = request().getParameter("company");// 收货公司
        String towerShip = request().getParameter("towerShip");// 乡镇
        String zip = request().getParameter("zip");

        if ((AddressTypeEnums.SP.getCode()).equals(type) && StringUtil.isEmpty(zip)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        ConsigneeAddressParam consigneeEntity = new ConsigneeAddressParam();
        String lenovoId = user().getLenovoid();
        consigneeEntity.setLenovoId(lenovoId);
        consigneeEntity.setIsdefault(Integer.parseInt(isdefault));
        consigneeEntity.setAddress(deliverStreet);
        consigneeEntity.setCityCode(delivercity);
        consigneeEntity.setCountyCode(delivercounty);
        consigneeEntity.setCityNo(delivercityNo);
        consigneeEntity.setCountyNo(delivercountyNo);
        consigneeEntity.setEmail(deliveremail);
        consigneeEntity.setMobile(delivermobile);
        consigneeEntity.setName(delivername);
        consigneeEntity.setProvinceCode(deliverprovice);
        consigneeEntity.setProvinceNo(deliverproviceNo);
        consigneeEntity.setTel(delivertele);
        consigneeEntity.setId(deliverid);
        consigneeEntity.setType(type);
        consigneeEntity.setAreaNos(areaNos);
        consigneeEntity.setUpdateby(lenovoId);
        consigneeEntity.setZip(zip);
        consigneeEntity.setTownshipCode(towerShip);
        consigneeEntity.setCompany(company);

        RemoteResult<Integer> result = consigneeRemoteService.updateConsignee(getTenant(),consigneeEntity);
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(result)), response);
    }

    /**
     * <br>
     * 删除收货信息
     *
     * @return
     */
    @RequestMapping("/deleteconsignee")
    @ResponseBody
    @CheckRefer
    @NeedLogin
    public String deleteDeliver(int shopId, HttpServletResponse response) {
        String deliverid = request().getParameter("deliverid");
        String type = request().getParameter("type");
        if (StringUtil.isEmpty(deliverid)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        SessionUser user = user();
        log.info(" deleteDeliver lenovoId:{},tenant:{},type:{}",user.getLenovoid(),getTenant(),type);
        RemoteResult<Integer> result = consigneeRemoteService.deleteConsignee(getTenant(),new ConsigneeParam(deliverid,user.getLenovoid(),type));
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT)), response);
    }

    /**
     *
     * 获取地址列表，并返回json数据到前台页面<br/>
     *
     * @author yuzj7@lenovo.com
     * @param shopId
     * @param response
     * @return
     * @since JDK 1.7
     */
    @RequestMapping("/getList")
    @ResponseBody
    @NeedLogin
    public String getList(int shopId,String type,HttpServletResponse response) {
        if (StringUtil.isEmpty(type)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        String lenovoId = user().getLenovoid();
        User user = new User();
        user.setUserId(lenovoId);
        RemoteResult<List<Memberaddrs>> result = consigneeRemoteService.getConsignees(getTenant(),new ConsigneeParam(user().getLenovoid(),type));
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT)), response);
    }

    /**
     * 获取收货地址列表 分会总记录数和分页列表[个人中心获取]. <br/>
     *
     * @param shopId
     * @param type
     * @param pageNum
     * @param pageSize
     * @param response
     * @returniy
     * @author yuzj7@lenovo.com
     * @since JDK 1.7
     */
    @RequestMapping("/getPageListByType")
    @NeedLogin
    public String getPageListByType(int shopId, int terminal, String type, Integer pageNum, Integer pageSize, HttpServletResponse response, Map<String, Object> map) {
        if (!getAddressList(shopId, type, pageNum, pageSize, map))
            return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "common/error";
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buy/addressListPage";
    }

    /**
     * 获取收货地址列表 分会总记录数和分页列表
     *
     * @author licy13
     */
    @RequestMapping("/getPageList")
    @NeedLogin
    public String getPageList(int shopId, int terminal, String type, Integer pageNum, Integer pageSize, HttpServletResponse response, Map<String, Object> map) {
        if (StringUtil.isEmpty(type)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        pageNum = (pageNum == null || pageNum <= 0) ? 1 : pageNum;
        pageSize = (pageSize == null || pageSize <= 0) ? 10 : pageSize;

        User user = new User();
        String lenovoId = user().getLenovoid();
        user.setUserId(lenovoId);

        RemoteResult<Map<String, Object>> listResult = consigneeRemoteService.getListPageByType(getTenant(),new ConsigneeParam(user().getLenovoid(),type), pageNum, pageSize);
        Map<String, Object> res = listResult.getT();
        map.put("res", res.get("list"));
        map.put("num", res.get("totalPage"));
        map.put("totalCount", res.get("totalCount"));
        map.put("index", res.get("currentPage"));
        map.put("type", type);
        return this.ajaxWriteStr(JsonUtil.toJson(map), response);
    }


    /**
     *
     * 设置默认收货地址【个人中心设置】. <br/>
     *
     * @author yuzj7@lenovo.com
     * @param shopId
     * @param type
     * @param id
     * @param response
     * @return
     * @since JDK 1.7
     */
    @RequestMapping("/setDefault")
    @ResponseBody
    @CheckRefer
    @NeedLogin
    public String setDefault(int shopId, String type, String id, HttpServletResponse response) {
        if (StringUtil.isEmpty(id)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        RemoteResult<Boolean> result = consigneeRemoteService.setDefaultConsignee(getTenant(),new ConsigneeParam(id,user().getLenovoid(),type));
        return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
    }

    /**
     * @param index
     * @return
     * @Description: 校验分页数
     * @author yuzj7@lenovo.com
     * @date 2015年7月20日 下午6:12:47
     */
    @RequestMapping("/validatePage")
    @ResponseBody
    public String validatePage(String index, HttpServletResponse response) {
        if (StringUtil.isEmpty(index)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        int i = Integer.parseInt(index);
        if (i > 0) {
            return this.ajaxWriteStr(toJson(new BaseInfo(1, "success")), response);
        }
        return this.ajaxWriteStr(toJson(new BaseInfo(0, "failed")), response);
    }

    /**
     * pc端收票地址分页
     * Gets page Invoice Address.
     *
     * @param shopId   the shop id
     * @param pageNum  the page num
     * @param pageSize the page size
     * @param response the response
     * @param map      the map
     * @return the page Invoice Address
     */
    @RequestMapping("/getInvoiceAddress")
    @NeedLogin
    public String getPageListforsp(int shopId, Integer pageNum, Integer pageSize, HttpServletResponse response, Map<String, Object> map) {
        String type = AddressTypeEnums.SP.getCode();
        pageSize = (pageSize == null || pageSize <= 0) ? 4 : pageSize;
        if (!getAddressList(shopId, type, pageNum, pageSize, map)) return
                ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "common/error";
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType())+"checkout/buy/invoiceListPage";
    }

    private boolean getAddressList(int shopId, String type, Integer pageNum, Integer pageSize, Map<String, Object> map) {
        if (StringUtil.isEmpty(type)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return true;
        }

        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return true;
        }
        pageNum = (pageNum == null || pageNum <= 0) ? 1 : pageNum;
        pageSize = (pageSize == null || pageSize <= 0) ? 2 : pageSize;

        User user = new User();
        String lenovoId = user().getLenovoid();
        user.setUserId(lenovoId);
        RemoteResult<Map<String, Object>> listResult = consigneeRemoteService.getListPageByType(getTenant(),new ConsigneeParam(user().getLenovoid(),type), pageNum, pageSize);
        Map<String, Object> res =listResult.getT();
            map.put("res", res.get("list"));
            map.put("num", res.get("totalPage"));
            map.put("totalCount", res.get("totalCount"));
            map.put("index", res.get("currentPage"));
            map.put("type", type);
        return listResult.isSuccess();
    }
///////////////////////////    wap2.0  ////////////////////////////////////////

    /**
     * wap 查询地址信息列表,并跳转到新的页面
     *
     * @author licy13
     */
    @RequestMapping("/getListWap")
    @NeedLogin
    public String getListWap(int shopId, int terminal, String type, String lid, Map<String, Object> map) {

        if (StringUtil.isEmpty(type) || StringUtil.isEmpty(lid)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }

        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        RemoteResult<List<Memberaddrs>> result = consigneeRemoteService.getConsignees(getTenant(),new ConsigneeParam(user().getLenovoid(),type));
        List<Memberaddrs> memberaddrs = result.getT();
        map.put("res", memberaddrs);
        map.put("type", type);
        map.put("lid", lid);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/consignee_list";
    }

    /**
     * wap 查询地址信息列表,并跳转到新的页面(个人中心)
     *
     * @author licy13
     */
    @RequestMapping("/getListWapCenter")
    @NeedLogin
    public String getListWapCenter(int shopId, int terminal, String type, Map<String, Object> map) {
        if (StringUtil.isEmpty(type)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }

        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        RemoteResult<List<Memberaddrs>> result = consigneeRemoteService.getConsignees(getTenant(),new ConsigneeParam(user().getLenovoid(),type));
        List<Memberaddrs> memberaddrs = result.getT();
        map.put("res", memberaddrs);
        map.put("type", type);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/consignee_list_center";
    }


    /**
     * wap  查询单个地址信息，并跳转编辑页面
     *
     * @author licy13
     */
    @RequestMapping("/getByIdWap")
    @NeedLogin
    public String getByIdWap(int shopId, int terminal, String type, String lid, String id, Map<String, Object> map) {
        if (StringUtil.isEmpty(type) || StringUtil.isEmpty(lid)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        String lenovoId = user().getLenovoid();
        User user = new User();
        user.setUserId(lenovoId);
        RemoteResult<Memberaddrs> result = consigneeRemoteService.getConsigneeById(getTenant(),new ConsigneeParam(id,user().getLenovoid(),type));
        map.put("res",  result!=null?result.getT():"");
        map.put("lid", lid);
        map.put("type", type);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/consignee_modify";
    }

    /**
     * wap 查询单个地址信息，并跳转编辑页面(个人中心)
     *
     * @author licy13
     */
    @RequestMapping("/getByIdWapCenter")
    @NeedLogin
    public String getByIdWapCenter(int shopId, int terminal, String type, String id, Map<String, Object> map) {
        if (StringUtil.isEmpty(type)) {
            map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        if (isNull(user())) {
            map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/error";
        }
        RemoteResult<Memberaddrs> result = consigneeRemoteService.getConsigneeById(getTenant(),new ConsigneeParam(id,user().getLenovoid(),type));
        log.info("getByIdWapCenter result res:{}  type:{} ",result,type);
        map.put("res", result!=null?result.getT():"");
        map.put("type", type);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/consignee_modify_center";
    }

    /**
     * 根据id lenovo 获取用户默认地址或是最新一条地址
     *
     * @author licy13
     */
    @RequestMapping("/getDefaultOrNewById")
    @NeedLogin
    public String getDefaultOrNewById(int shopId, String type, String id, HttpServletResponse response, Map<String, Object> map) {
        if (StringUtil.isEmpty(type)) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(BaseInfo.errInfo(401)), response);
        }
        RemoteResult<Memberaddrs> result = consigneeRemoteService.getDefaultOrNewById(getTenant(),new ConsigneeParam(id,user().getLenovoid(),type));
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT)), response);
    }
}
