package com.lenovo.m2.web.webapp.controller.my;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.credit.api.model.CreditInfoApi;
import com.lenovo.m2.credit.api.model.CreditPartitionBillsApi;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.credit.api.model.TradeRecordApi;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.ordercenter.PayRecordsDetailResult;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.web.common.my.CommonConstant;
import com.lenovo.m2.web.common.my.MoneyUtil;
import com.lenovo.m2.web.common.my.model.useroperationlog.UserOperationLog;
import com.lenovo.m2.web.common.my.order.OrderMainConstant;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.my.utils.KafkaUtil;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.my.utils.domain.PayRecordMessage;
import com.lenovo.m2.web.common.my.utils.math.Coder;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.SSOUtil;
import com.lenovo.m2.web.domain.my.BaseInfo;
import com.lenovo.m2.web.domain.my.PackageLogistics;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;
import com.lenovo.m2.web.domain.my.order.OrderDetailDesc;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderList;
import com.lenovo.m2.web.domain.my.order.smb.SmbDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetailMessage;
import com.lenovo.m2.web.manager.my.order.OrderManager;
import com.lenovo.m2.web.remote.my.order.OrderService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.*;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 个人订单中心
 * Created by mayan3 on 2015/10/8.
 */
@Controller
@Scope("prototype")
@RequestMapping("/center")
public class OrderController extends BaseController {

    private static final Logger logger = LogManager.getLogger(OrderController.class);
    private static final int pageSize = 5;
    @Autowired
    private OrderManager orderManager;
    @Autowired
    private OrderInfoRpc orderInfoRpc;
    @Autowired
    private OrderService orderService;
    @Autowired
    private OpenOrderService openOrderService;

    public static final String CREDIT_STATUS_TRUE = "1";
    public static final String CREDIT_STATUS_FALSE = "0";

    @RequestMapping("/orderlist")
    public String orderlist(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        logger.info("orderdetail.lenovoId={}",lenovoId);
        try {
            Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain", domain);
            if (isNull(shopId)) {
                logger.error("###获取订单列表 merchantId为空");
                return "/cn/my/pc/index";
            }
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            if ("8".equals(shopId) || "9".equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
            }else{
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
            }
            //将待评价页面链接放入到map中
            if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                map.put("waitEvaluateUrl",CustomizedPropertyConfigurer.getContextProperty("huimall.order.waitEvaluate.url"));
            }
        } catch (Exception e) {
            logger.error(e.toString());
        }
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        return "/cn/my/pc/order/orderlist";
    }

    @RequestMapping("/orderlistdata")
    public String orderlistdata(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String lenovoId = getLenovoId();
        Tenant tenant = getTenant();
        logger.info("lenovoId={}",lenovoId);
        RemoteResult<PageModel2<OrderDetailListJSONOrderList>> re = null;
        String orderstatus = request.getParameter("orderstatus");
        String orderdate = request.getParameter("orderdate");
        String searchtext = request.getParameter("searchtext");
//      String merchantId = request.getParameter("merchantId");
        map.put("orderstatus", orderstatus == null ? "all" : orderstatus);//将订单查询条件回推给前台，用于前台操作后，带条件刷新
        map.put("searchtext", searchtext == null ? "" : searchtext);
        map.put("orderdate", orderdate == null ? "" : orderdate);
        if (searchtext != null && "".equals(searchtext.trim())) {
            searchtext = null;
        }
        if (searchtext != null) {
            try {
                searchtext = URLDecoder.decode(searchtext, "UTF-8");
            } catch (Exception e) {
                searchtext = null;
                logger.error("我的订单查询searchtext参数汉字解码异常", e);
            }
        }
        try {

            Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain", domain);
            if (isNull(shopId)) {
                logger.error("###获取订单列表 merchantId为空");
                return "/cn/my/pc/index";
            }
            PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
            logger.info("orderstatus={},searchtext={},orderdate={}",orderstatus,searchtext,orderdate);
            re = orderManager.queryOrder(shopId, lenovoId, pageQuery, orderdate, searchtext, orderstatus, null);

            if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)){
                makeSmbOrderListData(pageQuery, re, shopId, map, lenovoId,tenant);
            }else if(OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)){
                makeSmbJfOrderListData(pageQuery, re, shopId, map, lenovoId);
            }else if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                makeOrderListData(re, shopId, map, lenovoId);
            }else if(OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)){
                makeOrderListData(re, shopId, map, lenovoId);
            }else{
                makeOrderListData(re, shopId, map, lenovoId);
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        return "/cn/my/pc/order/content/orderlistdata";

    }

    private void makeSmbJfOrderListData(PageQuery pageQuery, RemoteResult<PageModel2<OrderDetailListJSONOrderList>> re, String shopId, Map<String, Object> map, String lenovoId) {
        //暂时观察跟普通商城差不多，如有不同的地方再拓展
        makeOrderListData(re, shopId, map, lenovoId);
    }

    private void makeSmbOrderListData(PageQuery pageQuery, RemoteResult<PageModel2<OrderDetailListJSONOrderList>> re, String shopId, Map<String, Object> map, String lenovoId,Tenant tenant){

        if (re != null && re.getT() != null && re.isSuccess()) {
            PageModel2<OrderDetailListJSONOrderList> pageModel2 = re.getT();

            List<OrderDetailListJSONOrderList> listJSONOrderLists = pageModel2.getDatas();

            logger.info("listJSONOrderLists={}", JsonUtil.toJson(listJSONOrderLists));

            //生成smb订单对象
            List<SmbOrderDetail> smbOrderDetail = makeSmbtDataObject(listJSONOrderLists,tenant);



            PageModel2<SmbOrderDetail> pm2 = new PageModel2<SmbOrderDetail>(pageQuery, smbOrderDetail);

            map.put("orderlistPaginated", new PaginatedUtils<SmbOrderDetail>(pm2));
            //支付信息
            if ("8".equals(shopId) || "9".equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
            }else{
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
            }
//                map.put("plat", MerchantAndPlatUtils.getPlat(merchantId, "PC"));
//                map.put("merchantCode", PlatUtils.getPlat(merchantId));
            //再次购买
            map.put("carUrl", CustomizedPropertyConfigurer.getContextProperty("car.url"));
            //商品信息
            if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.url"));
            } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.url"));
            } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smb.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smbjf.product.url"));
            }
            //用户信息
            map.put("memberUrl", CustomizedPropertyConfigurer.getContextProperty("member.url"));
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("lenovoId",getLenovoId());
        }

    }


    public List sortList(List list, String propertyName, boolean isAsc) {
        //借助commons-collections包的ComparatorUtils
        //BeanComparator，ComparableComparator和ComparatorChain都是实现了Comparator这个接口
        Comparator mycmp = ComparableComparator.getInstance();
        mycmp = ComparatorUtils.nullLowComparator(mycmp);  //允许null
        if(isAsc){
            mycmp = ComparatorUtils.reversedComparator(mycmp); //逆序
        }
        Comparator cmp = new BeanComparator(propertyName, mycmp);
        Collections.sort(list, cmp);
        return list;
    }


    private List<SmbOrderDetail> makeSmbtDataObject(List<OrderDetailListJSONOrderList> listJSONOrderLists,Tenant tenant) {

        Map<String,String> orderMap = new HashMap<String,String>();
        for (OrderDetailListJSONOrderList orderList : listJSONOrderLists){
            orderMap.put(orderList.getOrdermaincode(), OrderMainConstant.MERCHANT_ID_SMB);
        }
        Set<String> set = orderMap.keySet();
        logger.info("set--message={}", JsonUtil.toJson(set));
        List<SmbOrderDetailMessage> SmbOrderDetailMessages = new ArrayList<>();
        for (String s : set){
            SmbOrderDetailMessage smbOrderDetailMessage = new SmbOrderDetailMessage();
            List<OrderDetailListJSONOrderList> listJSONO = new ArrayList<>();
            for (OrderDetailListJSONOrderList orderList : listJSONOrderLists){
                if (s.equals(orderList.getOrdermaincode())){
                    listJSONO.add(orderList);
                }
            }
            smbOrderDetailMessage.setSmbOrderDetail(listJSONO);
            SmbOrderDetailMessages.add(smbOrderDetailMessage);
        }
        List<SmbOrderDetail> smbOrderDetails = new ArrayList<>();
        for (SmbOrderDetailMessage smbOrderDetailMessage : SmbOrderDetailMessages){
            SmbOrderDetail smbOrderDetail = copyOrderMessageToSmb(smbOrderDetailMessage,tenant);
            smbOrderDetails.add(smbOrderDetail);
        }
        logger.info("smbOrderDetails={}", JsonUtil.toJson(smbOrderDetails));
        //数据排序
        List<SmbOrderDetail> s = null;
        try {
            s = sortList(smbOrderDetails,"ordertime",true);
        }catch (Exception ee){
            logger.error("s = sortList();",ee);
        }
        if (s != null){
            return s;
        }else{
            return smbOrderDetails;
        }

    }

    private SmbOrderDetail copyOrderMessageToSmb(SmbOrderDetailMessage smbOrderDetailMessage,Tenant tenant) {
        SmbOrderDetail smbOrderDetail1 = new SmbOrderDetail();
        int count = 0;
        for (OrderDetailListJSONOrderList listJSONOrderList : smbOrderDetailMessage.getSmbOrderDetail()) {
            smbOrderDetail1.setOrderDetailListJSONOrderList(listJSONOrderList,count);
            count++;
        }
        return smbOrderDetail1;
    }

    private void makeOrderListData(RemoteResult<PageModel2<OrderDetailListJSONOrderList>> re, String shopId, Map<String, Object> map, String lenovoId){
        if (re != null && re.getT() != null && re.isSuccess()) {
            PageModel2<OrderDetailListJSONOrderList> pageModel2 = re.getT();

            List<OrderDetailListJSONOrderList> listJSONOrderLists = pageModel2.getDatas();

            //懂得充值单独判断订单状态
            for (OrderDetailListJSONOrderList p : listJSONOrderLists){
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    logger.info("p.getCreditLine().getCent()={}",p.getCreditLine() != null ? p.getCreditLine().getCent() : 0);
                    if ((p.getCreditLine() != null ? p.getCreditLine().getCent() : 0) > 0){
                        //判断用户主账号信息
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())){
                            p.setIsMainAccount(CREDIT_STATUS_TRUE);
                        }
                    }
                }
            }

            logger.info("");

            map.put("orderlistPaginated", new PaginatedUtils<OrderDetailListJSONOrderList>(pageModel2));
            //支付信息
            if ("8".equals(shopId) || "9".equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
            }else if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
            }else if(OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimalljf.url"));
            }else{
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
            }
            //再次购买
            map.put("carUrl", CustomizedPropertyConfigurer.getContextProperty("car.url"));
            //商品信息
            if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.url"));
            } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.url"));
            } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smb.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smbjf.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.url"));
            }else if (OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)) {
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.url"));
            }
            //将评论和查看评论页面链接放入map中
            if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)) {
                map.put("goEvaluateUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.order.goEvaluate.url"));
                map.put("viewEvaluateUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.order.viewEvaluate.url"));
            }
            //用户信息
            map.put("memberUrl", CustomizedPropertyConfigurer.getContextProperty("member.url"));
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("lenovoId",getLenovoId());

        }

    }


    //物流信息
    @RequestMapping(value = "/getOrderTrackInfo", method = RequestMethod.POST)
    public String getOrderTrackInfo(HttpServletRequest request, String orderNo, String type, Map<String, Object> map, String passKey) {


        String lenovoId =  getLenovoId();
        String confirmPasskey = null;
        try {
            confirmPasskey = Coder.encryptHMAC(lenovoId, orderNo, CommonConstant.TRACKINFO_TYPE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!StringUtils.equals(confirmPasskey, passKey)) {
            logger.info("###lenovoId not  match the current:" + lenovoId);
            return null;
        }
        Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
        String domain = resultMap.get("domain");
        map.put("domain", domain);
        RemoteResult<Map<String, Object>> remoteResult = orderManager.getOrderTrackInfo(orderNo,getTenant());

        Map<String, Object> m = remoteResult.getT();
        logger.info("m={}",toJson(m));
        if (m != null && !"".equals(m) && m.get("packageLogisticses") != null){
            List<PackageLogistics> p = (List<PackageLogistics>)m.get("packageLogisticses");
            map.put("logtype", 1);
            map.put("packageLogisticses", p);
            for (int i = 0; i < p.size(); i++){
                String str = "logistics" + (i + 1);
                map.put(str, m.get(str));
            }
        }else if (m != null && !"".equals(m)){
            map.put("logtype", 0);
            map.put("logistics0", m.get("logistics0"));
        }else{

        }
        logger.info("map={}",JsonUtil.toJson(map));
        switch (Integer.parseInt(type)) {
            case 1:
                return "/cn/my/pc/order/content/orderTrackInfoList";
            case 2:
                return "/cn/my/pc/order/content/orderTrackInfoDetail";
        }
        return null;
    }


    @RequestMapping(value = "/orderdetail", produces = "text/html;charset=UTF-8")
    public String orderdetail(HttpServletRequest request, String passkey, String orderno,
                              Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        Tenant tenant = getTenant();
        OrderDetailDesc orderDetail = null;
        try {
            Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain", domain);
            if (isNull(shopId)) {
                logger.error("###获取订单列表 merchantId为空");
                return "/cn/my/pc/index";
            }
            if (isNull(orderno, passkey, shopId)) {
                logger.error("###获取订单详情 orderNo为空");
                return "/cn/my/pc/index";
            }

            String confirmPasskey;
            String p = request.getParameter("p");
            if ("1".equals(p)) {
                confirmPasskey = Coder.encryptHMAC(orderno, CommonConstant.ORDERDETAIL_TYPE);
            } else {
                confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.ORDERDETAIL_TYPE);
            }
            if (passkey.equals(confirmPasskey)) {



//                //判断用户主账号信息
//                if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
//                    map.put("isMainAccount", CREDIT_STATUS_TRUE);
//                }
                if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)){
                    orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)){
                    logger.info("进入smb详情页面orderno={},shopId={}",orderno,shopId);
                    List<OrderDetailListJSONOrderList> orderDetailListJSONOrderLists = orderManager.getOrderDetailByOrderMainCode(orderno, shopId);
                    if (orderDetailListJSONOrderLists == null || orderDetailListJSONOrderLists.size() < 1) {
                        return "/cn/my/pc/index";
                    }
                    logger.info("orderDetailListJSONOrderLists={}", JsonUtil.toJson(orderDetailListJSONOrderLists));
                    SmbOrderDetailMessage smbOrderDetailMessage = new SmbOrderDetailMessage();
                    smbOrderDetailMessage.setSmbOrderDetail(orderDetailListJSONOrderLists);
                    logger.info("smbOrderDetailMessage={}", JsonUtil.toJson(smbOrderDetailMessage));
                    SmbOrderDetail smbOrderDetail = copyOrderMessageToSmb(smbOrderDetailMessage,tenant);
                    logger.info("copyOrderMessageToSmb.smbOrderDetail={}", JsonUtil.toJson(smbOrderDetail));
                    SmbDetail smbDetail = orderManager.getSmbDetail(orderno, shopId,smbOrderDetail);
                    logger.info("smbOrderDetail={}", JsonUtil.toJson(smbDetail));
                    makeSmbOrderDetail(map,orderno,shopId,lenovoId,request,smbDetail);
                    return "/cn/my/pc/order/orderdetail";
                }else{
                    orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                }

                if (!OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)) {
                    if (orderDetail == null) {
                        return "/cn/my/pc/index";
                    }
                }

                //判断用户主账号信息
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    if ((orderDetail.getCreditLine() != null ? orderDetail.getCreditLine().getCent() : 0) > 0){
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
                            orderDetail.setIsMainAccount(CREDIT_STATUS_TRUE);
                        }
                    }
                }


                //私人订制订单？
                if (orderDetail.getGlist() != null && orderDetail.getGlist().size() > 0){
                    logger.info("orderDetail.getGlist().get(0).getSkuType()={}",orderDetail.getGlist().get(0).getSkuType());
                    if (StringUtils.equals("10",orderDetail.getGlist().get(0).getSkuType()) || StringUtils.equals("11",orderDetail.getGlist().get(0).getSkuType())){
                        takeLenovoMakeOrderDetail(map,orderno,shopId,lenovoId,request,orderDetail);
                        return "/cn/my/pc/order/orderdetailfornewmakeinpc";
                    }
                }

                if (StringUtils.equals("9",orderDetail.getOrderAddType())){
                    takeLenovoMakeOrderDetail(map,orderno,shopId,lenovoId,request,orderDetail);
                    return "/cn/my/pc/order/orderdetailforlenovomakeinpc";
                }
                makeOrderDetail(map, orderno, shopId, lenovoId, request, orderDetail);
                logger.info("orderDetail---lastmessage--->"+ JsonUtil.toJson(orderDetail));

            } else {
                logger.error("###无权访问");
                return "/cn/my/pc/index";
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "/cn/my/pc/index";
        }
        return "/cn/my/pc/order/orderdetail";
    }


    @RequestMapping(value = "/offlineUpload", produces = "text/html;charset=UTF-8")
    public String offlineUpload(HttpServletRequest request, String passkey, String orderno,String payId,
                              Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        Tenant tenant = getTenant();
        OrderDetailDesc orderDetail = null;
        try {
            Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain", domain);
            map.put("payId", payId);
            if (isNull(shopId)) {
                logger.info("###获取订单列表 merchantId为空");
                return "/cn/my/pc/index";
            }

            String confirmPasskey;
            String p = request.getParameter("p");
            if ("1".equals(p)) {
                confirmPasskey = Coder.encryptHMAC(orderno, CommonConstant.ORDERDETAIL_TYPE);
            } else {
                confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.ORDERDETAIL_TYPE);
            }
            if (true) {


                RemoteResult<OrderDetailDesc> remoteResult = orderManager.getOrderDetailDescByOrdercode(orderno, shopId);
                if (!remoteResult.isSuccess()){
                    return "/cn/my/pc/index";
                }
                if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)){
                    orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)){
                    logger.info("进入smb详情页面orderno={},shopId={}",orderno,shopId);
                    List<OrderDetailListJSONOrderList> orderDetailListJSONOrderLists = orderManager.getOrderDetailByOrderMainCode(orderno, shopId);
                    logger.info("orderDetailListJSONOrderLists={}", JsonUtil.toJson(orderDetailListJSONOrderLists));
                    SmbOrderDetailMessage smbOrderDetailMessage = new SmbOrderDetailMessage();
                    smbOrderDetailMessage.setSmbOrderDetail(orderDetailListJSONOrderLists);
                    logger.info("smbOrderDetailMessage={}", JsonUtil.toJson(smbOrderDetailMessage));
                    SmbOrderDetail smbOrderDetail = copyOrderMessageToSmb(smbOrderDetailMessage,tenant);
                    logger.info("copyOrderMessageToSmb.smbOrderDetail={}", JsonUtil.toJson(smbOrderDetail));
                    SmbDetail smbDetail = orderManager.getSmbDetail(orderno, shopId,smbOrderDetail);
                    logger.info("smbOrderDetail={}", JsonUtil.toJson(smbDetail));
                    makeSmbOrderDetail(map,orderno,shopId,lenovoId,request,smbDetail);
                    return "/cn/my/pc/order/orderdetail";
                }else{
                    orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                }

                if (orderDetail == null){
                    return "/cn/my/pc/index";
                }
                //判断用户主账号信息
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    if ((orderDetail.getCreditLine() != null ? orderDetail.getCreditLine().getCent() : 0) > 0){
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
                            orderDetail.setIsMainAccount(CREDIT_STATUS_TRUE);
                        }
                    }
                }


                //私人订制订单？
                if (orderDetail.getGlist() != null && orderDetail.getGlist().size() > 0){
                    logger.info("orderDetail.getGlist().get(0).getSkuType()={}",orderDetail.getGlist().get(0).getSkuType());
                    if (StringUtils.equals("10",orderDetail.getGlist().get(0).getSkuType()) || StringUtils.equals("11",orderDetail.getGlist().get(0).getSkuType())){
                        takeLenovoMakeOrderDetail(map,orderno,shopId,lenovoId,request,orderDetail);
                        return "/cn/my/pc/order/orderdetailfornewmakeinpc";
                    }
                }

                if (StringUtils.equals("9",orderDetail.getOrderAddType())){
                    takeLenovoMakeOrderDetail(map,orderno,shopId,lenovoId,request,orderDetail);
                    return "/cn/my/pc/order/orderdetailforlenovomakeinpc";
                }
                makeOrderDetail(map, orderno, shopId, lenovoId, request, orderDetail);

                logger.info("orderDetail---lastmessage--->"+ JsonUtil.toJson(orderDetail));

            } else {
                logger.error("###无权访问");
                return "/cn/my/pc/index";
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "/cn/my/pc/index";
        }
        return "/cn/my/pc/order/huimall/offlineupload";
    }




    private void makeSmbOrderDetail(Map<String, Object> map, String orderno, String shopId, String lenovoId, HttpServletRequest request, SmbDetail smbDetail) throws Exception{

        //获取发票
        if ("3".equals(smbDetail.getOrderstatuscode()) || "10".equals(smbDetail.getOrderstatuscode())) {
            map.put("invoiceurl", "/center/getinvoiceurl.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE));
        }
        //支付信息
        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
        map.put("paymentAccount", "招商银行北京大屯路支行");
        map.put("paymentAccountCode", CustomizedPropertyConfigurer.getContextProperty("payment.account.code"));
        map.put("printurl", "/center/print.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE));

        map.put("orderDetail", smbDetail);
        //商品信息
        if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smb.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smbjf.product.url"));
        }
        //支付信息
        if ("8".equals(shopId) || "9".equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
        }
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);

        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), JsonUtil.toJson(smbDetail), getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
    }

    private void makeOrderDetail(Map<String, Object> map, String orderno, String shopId, String lenovoId, HttpServletRequest request,OrderDetailDesc orderDetail) throws Exception{

       //获取发票
        if ("3".equals(orderDetail.getOrderstatuscode()) || "10".equals(orderDetail.getOrderstatuscode())) {
            map.put("invoiceurl", "/center/getinvoiceurl.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE));
        }
        //支付信息
        if ("8".equals(shopId) || "9".equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
        }
        map.put("printurl", "/center/print.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE));
        map.put("orderDetail", orderDetail);
        //商品信息
        if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_SMB.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smb.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_SMBJF.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("smbjf.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.url"));
        }else if (OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.url"));
        }
        //支付信息
        if ("8".equals(shopId) || "9".equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
        }else if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
        }else if(OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimalljf.url"));
        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
        }
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);

        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), JsonUtil.toJson(orderDetail), getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
    }

    private void takeLenovoMakeOrderDetail(Map<String, Object> map, String orderno, String shopId, String lenovoId, HttpServletRequest request,OrderDetailDesc orderDetail) throws Exception{

        //获取发票
        if ("3".equals(orderDetail.getOrderstatuscode()) || "10".equals(orderDetail.getOrderstatuscode())) {
            map.put("invoiceurl", "/center/getinvoiceurl.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE));
        }
        //支付信息
        if ("8".equals(shopId) || "9".equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));
        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
        }
        map.put("printurl", "/center/print.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE));
        map.put("orderDetail", orderDetail);
        //商品信息
        if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.url"));
        } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
            map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.url"));
        }
        //支付信息
        if ("8".equals(shopId) || "9".equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.17.url"));

        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.url"));
        }
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);

        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), JsonUtil.toJson(orderDetail), getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
    }

    /**
     * 获取电子发票
     */
    @RequestMapping(value = "/getinvoiceurl",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String getinvoiceurl(HttpServletRequest request, String orderno, String passkey) {
        String invoiceurl = null;
        String result = "";
        try {
            String  lenovoId = getLenovoId();
            if (isNull(orderno, passkey)) {
                logger.info("###获取电子发票 orderNo为空");
                return JacksonUtil.toJson(new BaseInfo(20001, "下载电子票错误失败，请联系客服"));
            }

            String confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE);
            if (passkey.equals(confirmPasskey)) {
                invoiceurl = orderManager.getInVoiceUrlFromDB(orderno);
                if (StringUtils.isNotEmpty(invoiceurl)) {
                    result = JacksonUtil.toJson(new BaseInfo(invoiceurl));
                    return result;
                }
                logger.info("### invoice_url表中获取发票url为空 orderCode: " + orderno);
                invoiceurl = orderInfoRpc.getinvoiceurl(orderno);
                if (invoiceurl == null || invoiceurl.trim().equals("") || invoiceurl.contains("$")) {
                    logger.info("### Btcp 接口返回错误 orderno: " + orderno + " url: " + invoiceurl);
                    return JacksonUtil.toJson(new BaseInfo(20001, "下载电子票错误失败，请联系客服"));
                } else {
                    result = JacksonUtil.toJson(new BaseInfo(invoiceurl));
                    return result;
                }
            } else {
                return JacksonUtil.toJson(new BaseInfo(20001, "无权访问"));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(new BaseInfo(20001, "下载电子票错误失败，请联系客服"));
    }

    @RequestMapping(value = "/cancelorder", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String cancelorder(HttpServletRequest request, HttpServletResponse response, String orderNo) {

        logger.info("cancelorder orderNo: " + orderNo);

        //新增代码，用来校验是否有权限取消订单，pengyy4 修改于 2018-01-24
        /*******校验用户是否拥有权限 start********/
        Tenant tenant = getTenant();
        String shopId = tenant.getShopId() != null ? tenant.getShopId().toString() : "";
        RemoteResult<MongoOrderDetail> remoteResult = orderManager.getOrderByOrdercode(shopId,orderNo);

        if(!remoteResult.isSuccess() || remoteResult.getT() == null){
            logger.info("cancelorder No authority , orderNo: " + orderNo + ",shopId=" + shopId);
            return JacksonUtil.toJson(new BaseInfo(20001, "无权访问"));
        }
        /*******校验用户是否拥有权限 end********/

        Map<String, Object> resultMap = new HashMap<String, Object>();
        RemoteResult result = orderManager.cancelOrder(orderNo, tenant);
        if (result.isSuccess()) {
            resultMap.put("rc", "0");
            resultMap.put("msg", "取消订单成功");
            String jsonString = JacksonUtil.toJson(resultMap);
            return jsonString;
        } else {
            resultMap.put("rc", "9000");
            resultMap.put("msg", result.getResultMsg());
            String jsonString = JacksonUtil.toJson(resultMap);
            logger.info("jsonString={}", JacksonUtil.toJson(resultMap));
            return jsonString;
        }
    }

    /**
     * 打印订单详情
     */
    @RequestMapping(value = "/print")
    public String print(HttpServletRequest request, String orderno, String passkey) {
        try {
            String  lenovoId = getLenovoId();

            if (isNull(orderno, passkey)) {
                //todo
                return "/error";
            }

            String confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE);
            if (passkey.equals(confirmPasskey)) {

            } else {
                //todo 无权限访问
                return "/error";
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "";
    }

    /**
     * 惠商 我的信用
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/huimallcredit")
    public String huimallcredit(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        PageQuery pageQuery = new PageQuery(getPage(request), 2000);
        Map<String,Object> HuiMallCreditMap = new HashMap<>();
        logger.info("huimallcredit.lenovoId={}",lenovoId);
        try {
            HuiMallCreditMap = orderService.getHuiMallMessage(lenovoId,pageQuery);
        }catch (Exception e){
            logger.info("e",e);
        }
        logger.info("HuiMallCreditMap={}",JsonUtil.toJson(HuiMallCreditMap));
//        //获取信用列表
        PageModel2<CreditInfoApi> creditInfoApi = HuiMallCreditMap.get("creditInfoApi") != null && !"".equals(HuiMallCreditMap.get("creditInfoApi")) ? (PageModel2<CreditInfoApi>) HuiMallCreditMap.get("creditInfoApi") : null;
        if (creditInfoApi != null){
            map.put("creditList",new PaginatedUtils<CreditInfoApi>(creditInfoApi));
            logger.info("creditList={}",JsonUtil.toJson(new PaginatedUtils<CreditInfoApi>(creditInfoApi)));
        }else{
            map.put("creditList", "");
        }
        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        return "cn/my/pc/order/huimall/credit";
    }

    /**
     * 惠商 我的信用 还款记录数据层 获取
     */
    @RequestMapping("/huimallcreditlistdata")
    public String huimallcreditlistdata(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
        Map<String,Object> HuiMallCreditMap = new HashMap<>();
        logger.info("huimallcredit.lenovoId={}",lenovoId);
        String status = request.getParameter("status");// 待还款 0 已还款 1 交易记录 2
        String fromtime = request.getParameter("fromtime");
        String totime = request.getParameter("totime");
        String creditbussines = request.getParameter("creditbussines"); //分销商

        Map mapPartitionBill = new HashMap();
        mapPartitionBill.put("buyerId", lenovoId);
        if (CREDIT_STATUS_TRUE.equals(status)){   //1是已支付
            mapPartitionBill.put("status",CREDIT_STATUS_TRUE);
        }else{
            mapPartitionBill.put("status",CREDIT_STATUS_FALSE);
        }
        mapPartitionBill.put("fromtime",fromtime);
        mapPartitionBill.put("totime",totime);
        mapPartitionBill.put("faCode",creditbussines);


        logger.info("huimallcredit.lenovoId={}",lenovoId);
        try {
            HuiMallCreditMap = orderService.getHuiMallMessageListData(mapPartitionBill,pageQuery);
        }catch (Exception e){
            logger.error(e.getMessage(),e);
        }
        logger.info("HuiMallCreditMap={}",JsonUtil.toJson(HuiMallCreditMap));
        //获取信用列表  信用汇总
        PageModel2<CreditInfoApi> creditInfoApi = HuiMallCreditMap.get("creditInfoApi") != null && !"".equals(HuiMallCreditMap.get("creditInfoApi")) ? (PageModel2<CreditInfoApi>) HuiMallCreditMap.get("creditInfoApi") : null;
        // 待还款
        PageModel2<CreditPartitionBillsApi>  creditPartitionBillsApiFalse = HuiMallCreditMap.get("creditPartitionBillsApiFalse") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiFalse")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiFalse") : null;
        // 已还款
        PageModel2<CreditPartitionBillsApi> creditPartitionBillsApiTrue = HuiMallCreditMap.get("creditPartitionBillsApiTrue") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiTrue")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiTrue") : null;
        logger.info("creditList={}",JsonUtil.toJson(creditInfoApi));
        logger.info("creditDetailListNoPay={}",JsonUtil.toJson(creditPartitionBillsApiFalse));
        logger.info("creditDetailListPayFor={}",JsonUtil.toJson(creditPartitionBillsApiTrue));
        if (creditInfoApi != null){
            map.put("creditList",new PaginatedUtils<CreditInfoApi>(creditInfoApi));
            logger.info("creditList={}",JsonUtil.toJson(new PaginatedUtils<CreditInfoApi>(creditInfoApi)));
        }else{
            map.put("creditList", "");
        }
        if (!StringUtil.isEmpty(status)){
            if ("0".equals(status)){
                if (creditPartitionBillsApiFalse != null){
                    //获取未付款信用使用详情
                    map.put("creditDetailListNoPay",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse));
                    logger.info("creditDetailListNoPay={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse)));

                }else{
                    map.put("creditDetailListNoPay", "");
                }
            }else{
                if (creditPartitionBillsApiTrue != null){
                    //获取已付款信用使用详情
                    map.put("creditDetailListPayFor",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue));
                    logger.info("creditDetailListPayFor={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue)));
                }else{
                    map.put("creditDetailListPayFor", "");
                }
            }
        }else{
            if (creditPartitionBillsApiFalse != null){
                //获取未付款信用使用详情
                map.put("creditDetailListNoPay",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse));
                logger.info("creditDetailListNoPay={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse)));

            }else{
                map.put("creditDetailListNoPay", "");
            }
            if (creditPartitionBillsApiTrue != null){
                //获取已付款信用使用详情
                map.put("creditDetailListPayFor",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue));
                logger.info("creditDetailListPayFor={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue)));
            }else{
                map.put("creditDetailListPayFor", "");
            }
        }

        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
        map.put("status", status);
        map.put("fromtime",fromtime);
        map.put("totime",totime);
        map.put("creditbussines",creditbussines);

        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        if ("0".equals(status)){
            return "cn/my/pc/order/huimall/creditdata";
        }else{
            return "cn/my/pc/order/huimall/creditdatapay";
        }
    }

    @RequestMapping("/huimallcreditPaidData")
    @ResponseBody
    public String huimallcreditPaidData(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        RemoteResult remoteResult = new RemoteResult(false);
        String  lenovoId = getLenovoId();
        logger.info("huimallcredit.lenovoId={}",lenovoId);
        String billNo = request.getParameter("billNo"); //
        String faCode = request.getParameter("faCode"); //分销商
        String buyerId = request.getParameter("buyerId"); //
        if (StringUtils.isBlank(billNo) || StringUtils.isBlank(faCode) ||StringUtils.isBlank(buyerId)|| !StringUtils.isNumeric(buyerId)){
            remoteResult.setResultMsg("数据异常，请检查！");
            return JsonUtil.toJson(remoteResult);
        }
        logger.info("huimallcredit.billNo ",billNo);
        RemoteResult<List<PayTrackingApi>> result=new RemoteResult<List<PayTrackingApi>>(false);
        try {
            result = orderService.getHuimallcreditPaidData(billNo,faCode,Long.parseLong(buyerId));
        }catch (Exception e){
            logger.error(e.getMessage(),e);
            remoteResult.setResultMsg("ERROR");
            return JsonUtil.toJson(remoteResult);
        }
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        if(result.isSuccess()){
            result.setSuccess(true);
            result.setResultCode("00");
        }else {
            result.setResultMsg("查询数据为空");
        }
        return JsonUtil.toJson(result);
    }

    @RequestMapping("/huimallcreditpaymessage")
    public String huimallcreditpaymessage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
        String creditbussines = request.getParameter("creditbussines");
        String fromtime = request.getParameter("fromtime");
        String totime = request.getParameter("totime");
        Map<String, Object> mapMess = new HashMap<>();
        mapMess.put("buyerId",lenovoId);
        mapMess.put("faCode",creditbussines);
        mapMess.put("shopId",getTenant().getShopId());
        mapMess.put("fromtime",fromtime);
        mapMess.put("totime",totime);
        RemoteResult<PageModel2<TradeRecordApi>> tradeRecordApi =  orderService.getTradeRecordByPage(pageQuery, mapMess);
        map.put("tradeRecordApi",tradeRecordApi.getT() != null ? new PaginatedUtils<CreditPartitionBillsApi>(tradeRecordApi.getT()) : "");
        return "cn/my/pc/order/huimall/creditdatapaymessage";
    }

    /**
     * 信用支付部分还款
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/huimallPartialRepayment")
    @ResponseBody
    public String huimallPartialRepayment(HttpServletRequest request, HttpServletResponse response){
        String lenovoId = getLenovoId();
        String billNo = request.getParameter("billNo");
        String faCode = request.getParameter("faCode");
        String unpaidAmount = request.getParameter("unpaidAmount");
        String returnAmount = request.getParameter("returnAmount");
        logger.info("Ajax 调用 huimallPartialRepayment billNo[" + billNo + "],buyerId[" + lenovoId + "],faCode[" + faCode + "],unpaidAmount[" + unpaidAmount + "],returnAmount[" + returnAmount + "]");
        Map<String, String> paraMap = new HashMap<>();
        try{
            paraMap = orderService.savePayTracking(billNo, Long.parseLong(lenovoId), faCode, unpaidAmount, returnAmount);
            paraMap.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
        } catch(Exception e){
            logger.info("信用支付部分还款，调用后台新订单号接口异常", e.getMessage());
            paraMap.put("rc", "0");
            paraMap.put("msg", "服务器异常，请重新发起");
        }
        logger.info("Ajax 调用 huimallPartialRepayment 完成,Result[" + paraMap + "]");
        return JsonUtil.toJson(paraMap);
    }
    @RequestMapping("/huimallofflineupload")
    @ResponseBody
    public String huimallofflineupload(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        Tenant tenant = getTenant();
        String lenovoId = getLenovoId();
        RemoteResult remoteResult = new RemoteResult();
        if(StringUtil.isEmpty(lenovoId)){
            remoteResult.setSuccess(false);
            remoteResult.setResultMsg("用户未登录");
        }else{
            String faid = request.getParameter("faid");
            String orderCode = request.getParameter("orderCode");
            String paymentBank = request.getParameter("paymentBank");
            String paymentAmount = request.getParameter("paymentAmount");
            String paymentVoucher = request.getParameter("paymentVoucher");
            String paymentPic = request.getParameter("paymentPic");
            String paymentTime = request.getParameter("paymentTime");
            String payId = request.getParameter("payId");//用于再次上传凭证
            String buyerCode = request.getParameter("buyerCode");//经销商名称
            if (StringUtil.isEmpty(payId)){
                //第一次上传凭证
                payId = null;
            }

            if (StringUtil.isEmpty(faid,orderCode,paymentBank,paymentAmount,paymentVoucher,paymentPic,paymentTime)){
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("参数异常");
            }else{
                try{
                    PayRecords payRecords = new PayRecords();
                    payRecords.setFaId(faid);
                    payRecords.setPaymentUser(lenovoId);
                    payRecords.setOrderCode(orderCode);
                    payRecords.setPaymentBank(paymentBank);
                    payRecords.setPaymentAmount(MoneyUtil.creatMoney(paymentAmount));
                    payRecords.setPaymentVoucher(paymentVoucher);
                    payRecords.setPaymentPic(paymentPic);
                    payRecords.setPaymentTime(paymentTime);
                    payRecords.setStatus(0);//审核状态 0初始状态，1 审核通过，2审核拒绝 --初始化 0
                    payRecords.setShopId(tenant.getShopId());
                    payRecords.setCurrencyCode(tenant.getCurrencyCode());
                    payRecords.setPayId(payId);

                    logger.info("准备保存货到付款上传资料--payRecords--"+JsonUtil.toJson(payRecords));
                    remoteResult = openOrderService.saveMongoPayRecord(payRecords);
                    logger.info("保存货到付款上传资料结果--"+JsonUtil.toJson(remoteResult));
                }catch(Exception e){
                    logger.error("保存货到付款上传资料存mongo失败",e);
                }

                if (remoteResult.isSuccess()){
                    try {
                        PayRecordMessage message = new PayRecordMessage();
                        message.setShopId("14");
                        message.setFaId(faid);
                        message.setOrderId(orderCode);
                        message.setBuyerId(lenovoId);
                        message.setBuyerCode(buyerCode);
                        message.setSubmitTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                        KafkaUtil.KafkaSendMessage("other_my.properties","metadataBrokerList","fps_hs_offline_pay", JsonUtil.toJson(message));
                    }catch (Exception e){
                        logger.error("惠商线下银行转账上传后发送短信收失败={}", e);
                    }
                }else{
                    logger.info("保存货到付款上传资料结果失败");
                }
            }
        }
        return JsonUtil.toJson(remoteResult);
    }
    @RequestMapping("/huimallofflinelist")
    public String huimallofflinelist(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        logger.info("orderdetail.lenovoId={}",lenovoId);
        String shopId = getTenant().getShopId().toString();
        if (isNull(shopId)) {
            logger.error("###获取订单列表 merchantId为空");
            return "/cn/my/pc/index";
        }
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);
        return "cn/my/pc/order/huimall/huimallofflinelist";
    }

    @RequestMapping("/huimallofflinelistdata")
    public String huimallofflinelistdata(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        DownlinePayListParam downlinePayListParam = new DownlinePayListParam();
        String  lenovoId = getLenovoId();
        logger.info("orderdetail.lenovoId={}",lenovoId);
        String shopId = getTenant().getShopId().toString();
        downlinePayListParam.setShopId(Integer.parseInt(shopId));
        String status = request.getParameter("status");
        if ("0".equals(status) || "1".equals(status) || "2".equals(status)){
            downlinePayListParam.setStatus(Integer.parseInt(status));//审核状态 0初始状态，1 审核通过，2审核拒绝
        }
        downlinePayListParam.setPaymentUser(lenovoId);
        downlinePayListParam.setPageNum(getPage(request));
        downlinePayListParam.setPageSize(pageSize);
        RemoteResult<PageModel2<PayRecords>> remoteResult = new RemoteResult<>();
        try {
            remoteResult = orderManager.queryDownlinePayList(downlinePayListParam);
        }catch (Exception e){
            logger.error("e={}",e);
        }
        logger.info("RemoteResult<PageModel2<PayRecords>>={}",JsonUtil.toJson(remoteResult));
        if (remoteResult.isSuccess()){
            map.put("status",status);
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("offlinelistdata", new PaginatedUtils<OrderDetailListJSONOrderList>(remoteResult.getT()));
        }else{
            map.put("offlinelistdata", new PaginatedUtils<OrderDetailListJSONOrderList>(new PageModel2<PayRecords>()));
        }
        return "cn/my/pc/order/huimall/huimallofflinelistdata";
    }

    @RequestMapping("/huimallofflinedetail")
    public String huimallofflinedetail(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String p = request.getParameter("payId");
        RemoteResult<PayRecordsDetailResult> recordsDetail = new RemoteResult<>();
        try {
            recordsDetail = orderManager.payRecordsDetail(p,getTenant());
        }catch (Exception e){
            logger.error("e={}",e);
        }
        logger.info("recordsDetail={}",JsonUtil.toJson(recordsDetail));
        if (recordsDetail.isSuccess()){
            String  lenovoId = getLenovoId();
            logger.info("orderdetail.lenovoId={}",lenovoId);
            String shopId = getTenant().getShopId().toString();
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
        }
        map.put("offlinedetail",recordsDetail.getT());
        return "cn/my/pc/order/huimall/huimallofflinedetail";
    }


}
