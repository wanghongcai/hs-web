package com.lenovo.m2.web.webapp.controller.cart.pricelist;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.lenovo.m2.arch.framework.domain.Money;

import com.lenovo.m2.hsbuy.api.param.pricelist.PriceListParam;
import com.lenovo.m2.hsbuy.common.enums.PriceListStatus;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceList;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.purchase.annotation.NeedLogin;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.remote.purchase.pricelist.PriceListRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;

/**
 * Created by syj on 2016/7/19.
 */
@Controller
@RequestMapping("pricelist")
public class PriceListController extends BaseController {

    public static Logger log =  LogManager.getLogger(PriceListController.class.getName());

    @Autowired
    private PriceListRemoteService priceListRemoteService;

    private static int DEFAULT_PAGE_SIZE = 10;
    
    /**
     * 报价单列表页
     * @param pageQuery
     * @param priceList
     * @param map
     * @return
     */
    @RequestMapping("getPriceListPage")
    @NeedLogin
    public String getPriceListPage(PageQuery pageQuery, PriceListParam priceList, Map<String,Object> map){
    	if(pageQuery.getPageSize() == 0 || pageQuery.getPageSize() > 100){
    		pageQuery.setPageSize(DEFAULT_PAGE_SIZE);
    	}
    	BasePara b  = getBasePara();
    	copyBasePara(b, priceList);
    	priceList.setUserId(b.getUser().getUserId());
    	log.info("getPriceListPage dealNo={}, userId={}", priceList.getDealNo(), priceList.getUserId());
        try{
            RemoteResult<PageModel2<PriceList>> res = priceListRemoteService.getPriceListPage(getTenant(),pageQuery, priceList);
            if(res!=null && res.getT()!=null){
                for(PriceList p: res.getT().getDatas()){
                    Date d = p.getExpireDate();
                    String expirdate=new SimpleDateFormat("yyyy-MM-dd").format(d);
                    p.setAuditFile(expirdate);
                    Date sysdate=new Date();
                    if(p.getIsCreatedOrder() == PriceListStatus.ORDERED.getType()){
                        p.setCustomManager(PriceListStatus.ORDERED.getDescr());
                    }else {
                        if(d.before(sysdate)){
                            p.setCustomManager(PriceListStatus.EXPIRE_DATE.getDescr());
                        }else if(p.getIsCreatedOrder() == PriceListStatus.WAIT_TO_CHECK.getType()){
                            p.setCustomManager(PriceListStatus.WAIT_TO_CHECK.getDescr());
                        }else{
                            p.setCustomManager(PriceListStatus.NOT_ORDER.getDescr());
                        }
                    }
                    p.setTotalPrice(p.getTotalPrice());
                    //p.setTotalPrice(p.getTotalPrice().divide(new BigDecimal(10000)));
                }
                map.put("pricelist",res.getT());
                map.put("num",res.getT().getTotalPageNum());
                map.put("totalCount",res.getT().getTotalCount());
                map.put("index",res.getT().getPageNum());
                map.put("SearchDealNo", priceList.getDealNo());
            }
        }catch (Exception e){
            log.error("getPriceListPage", e);
        }
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "/pricelist/priceListMainPage";
    }


    /**
     * 报价单详情页
     * @param shopId
     * @param terminal
     * @param id
     * @param dealNo
     * @param map
     * @return
     */
    @RequestMapping("getPriceListDetail")
    public String getPriceListDetail(Integer shopId,Integer terminal,Long id,String dealNo,Map<String,Object> map){
        try{
        	BasePara b  = getBasePara();
            PriceListParam pl=new PriceListParam();
            copyBasePara(b, pl);

            pl.setId(id);
            pl.setDealNo(dealNo);
            pl.setTerminal(terminal);
            RemoteResult<PriceList> res=priceListRemoteService.getPriceListDetail(getTenant(),pl);
            if(res!=null && res.getT()!=null){
                String totalPriceCn="";
                String indate="";
                if(null!=res.getT().getTotalPrice()){
                    Money totalprice=res.getT().getTotalPrice();
                    totalPriceCn=NumberToCn.number2CNMontrayUnit(totalprice.getAmount());
                }
                if(null!=res.getT().getExpireDate()){
                    Date date=res.getT().getExpireDate();
                    indate=new SimpleDateFormat("yyyy-MM-dd").format(date);
                    Date sysdate=new Date();
                    if(date.before(sysdate)){
                        map.put("flag","0");//已失效
                    }else{
                        map.put("flag","1");//未下单
                    }
                }
                map.put("indate",indate);
                map.put("totalPriceCn",totalPriceCn);
                map.put("pricelist",res.getT());
            }
        }catch (Exception e){
            log.error("getPriceListDetail",e);
        }
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "pricelist/priceListDetailMainPage";
    }


    /**
     *
     * @Description: 校验分页数
     * @author yuzj7@lenovo.com
     * @date 2015年7月20日 下午6:12:47
     * @param index
     * @return
     */
    @RequestMapping("validatePage")
    @ResponseBody
    public String validatePage(String index) {
        if(StringUtil.isEmpty(index)){
            return toJson(new BaseInfo(400));
        }
        User u = getBasePara().getUser();
        if (!u.isLoggedIn()) {
            return JsonUtil.toJson(new BaseInfo(401, "未登录"));
        }
        int i = Integer.parseInt(index);
        if(i>=0 ){
            return toJson(new BaseInfo(1,"success"));
        }
        return toJson(new BaseInfo(0,"failed"));
    }

    /**
     * 详情页导出pdf
     * @param id
     * @param dealNo
     * @param showParam 需要显示配件的商品code 多个逗号分隔
     * @return
     */
    @RequestMapping(value = "/exportPDFdetail", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public String exportPDFdetail(Long id,String dealNo, String showParam){
        try{
        	BasePara b  = getBasePara();
        	User user = b.getUser();
            if (!user.isLoggedIn()) {
                return JsonUtil.toJson(new BaseInfo(401, "未登录"));
            }
            log.info("exportPDFdetail, dealNo={}, showParam={}", dealNo, showParam);
            List<String> showParamGcodes = new ArrayList<>(); 
            if(StringUtils.isNotEmpty(showParam)){
            	showParamGcodes = Arrays.asList(showParam.split(","));
            }
            RemoteResult<String> remoteResult=priceListRemoteService.queryPdfUrl("",user.getUserId(),dealNo, showParamGcodes); 
            return toJson(remoteResult);
          }catch (Exception e){
            log.error("PriceListController--getPriceListDetail",e);
            RemoteResult result= new RemoteResult();
            result.setSuccess(false);
            result.setResultMsg(e.getMessage());
            return toJson(result);
        }
    }

    public void createPdf(String pdfurl,HttpServletResponse response){

        try{
            String fileName="";
            if(null != pdfurl){
                String[] urls=pdfurl.split("/");
                fileName=urls[(urls.length-1)];
            }

            String downloadname=new String(fileName.getBytes("gbk"),"iso8859-1");
            //输出pdf
            response.setContentType("application/pdf; charset=UTF-8");
            response.setHeader("Content-disposition", "attachment;filename=" + downloadname);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");

            ServletOutputStream out = response.getOutputStream();
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(pdfurl));
            BufferedOutputStream bos = new BufferedOutputStream(out);
            byte[] buff = new byte[2048];
            int bytesRead;

            while(-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }

            response.getOutputStream().flush();
            response.getOutputStream().close();

            bos.close();
            bis.close();
            out.close();

        }catch (Exception e){
            log.error("PriceListController--createPdf"+e.getMessage());
        }


    }


    @RequestMapping(value="submitPriceList", produces = "application/json; charset=UTF-8")
    @ResponseBody
    @NeedLogin
    public String submitPriceList(Long id,String dealNo){
    	RemoteResult<Void> ret = new RemoteResult<>(true);
        try{
        	BasePara b  = getBasePara();
        	if(!b.getUser().isLoggedIn()){
        		ret.setSuccess(false);
        		ret.setResultCode(ErrorMessageEnum.ERROR_NOT_LOGIN.getCode()+"");
        		ret.setResultMsg(ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
        		return JsonUtil.toJson(ret);
        	}
        	
            PriceListParam pl=new PriceListParam();
            copyBasePara(b, pl);
            pl.setId(id);
            pl.setDealNo(dealNo);
            pl.setUserId(b.getUser().getUserId());
            priceListRemoteService.submitPriceList(getTenant(),pl);
            return JsonUtil.toJson(ret);
        }catch (Exception e){
            log.error("submitPriceList", e);
            ret.setSuccess(false);
            return JsonUtil.toJson(ret);
        }

    }


}
