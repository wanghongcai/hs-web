package com.lenovo.m2.web.webapp.controller.my;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.domain.my.BaseInfo;
import com.lenovo.m2.web.manager.my.order.OrderManager;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.UserInfoUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by yezhenyue on 2015/10/14.
 */
@Controller
@Scope("prototype")
public class CommonController extends BaseController {
    @Autowired
    private OrderManager orderManager;

    private static final Logger logger = LogManager.getLogger(CommonController.class);
    //确认签收
    @RequestMapping(value = "/center/confirmReceive",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String confirmReceive(String ordno) {
        if (isNull(ordno)) {
            return JacksonUtil.toJson(BaseInfo.errInfo(400));
        }
        String lenovoId = getLenovoId();
        if (isNull(lenovoId)) {
            return JacksonUtil.toJson(BaseInfo.errInfo(401));
        }
        long start = System.currentTimeMillis();
        RemoteResult remoteResult = orderManager.confirmReceive(ordno,lenovoId,getTenant());
        long end = System.currentTimeMillis();
        logger.info("confirmReceive_param={},confirmReceive_remoteresult={},confirmReceive_time={}",ordno, JsonUtil.toJson(remoteResult),(end-start));
        if (remoteResult.isSuccess()){
            return JsonUtil.toJson(new BaseInfo("操作成功"));
        }else{
            return JsonUtil.toJson(new BaseInfo("操作失败"));
        }
    }

    @RequestMapping(value = "/center/getUserBigImg",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String getUserBigImg() {
        Tenant tenant = getTenant();
        String result = "";
        String lenovoId = getLenovoId();
        if (isNull(lenovoId,tenant.getShopId().toString())) {
            return JacksonUtil.toJson(BaseInfo.errInfo(401));
        }
       result = UserInfoUtil.getUserBigImgUrl(lenovoId,tenant.getShopId().toString());
        return result;
    }

}
