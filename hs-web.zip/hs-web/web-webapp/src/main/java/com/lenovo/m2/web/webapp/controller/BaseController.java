package com.lenovo.m2.web.webapp.controller;

import com.google.common.base.Strings;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.common.enums.ShopIdEnum;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import com.lenovo.m2.web.common.my.utils.HttpClientUtil;
import com.lenovo.m2.web.common.purchase.constants.Contants;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.webapp.util.ThreadLocalSessionUser;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chenww3 on 2015/6/14.
 */
public class BaseController {


	public static Logger logger =  LogManager.getLogger(BaseController.class);

    private static String buyerUrl = CustomizedPropertyConfigurer.getContextProperty("buyer.url");

    //xssfilter 过滤器中赋值
    protected HttpServletRequest request(){
        return ThreadLocalReqAndResp.getRequest();
    }
    protected HttpServletResponse response(){
        return ThreadLocalReqAndResp.getResponse();
    }
    protected HttpSession session(){
        return ThreadLocalReqAndResp.getSession();
    }

    /****
     *
     * 公共方法-获取租户信息
     **/
    protected Tenant getTenant(){
        return ThreadLocalSessionTenant.getTenant();
    }


    //获取页码
    public int getPage(HttpServletRequest request) {
        String page = request.getParameter("page");
        if(page==null){
            return 1;
        }
        return Integer.parseInt(page);
    }

    public String getIp() {
        String sff = request().getHeader("X-Forwarded-For");// 根据nginx的配置，获取相应的ip
        if (Strings.isNullOrEmpty(sff)) {
            sff = request().getHeader("X-Real-IP");
        }
        if (Strings.isNullOrEmpty(sff)) {
            return Strings.isNullOrEmpty(request().getRemoteAddr()) ? "" : request().getRemoteAddr();
        }
        String[] ips = sff.split(",");
        String realip = ips[0];
        return realip;
    }

    /**
     * 公共平台租户信息
     * @return
     */
    protected Tenant getTenantCN(){
        Tenant tenant = new Tenant();
        HttpServletRequest servletRequest = request();
        try{
            if(servletRequest.getParameter("shopId")==null){
                tenant = Tenant.getTenant(8);
            }else{
                Integer shopId = Integer.parseInt(servletRequest.getParameter("shopId"));
                tenant = Tenant.getTenant(shopId);
            }
        }catch(Exception e){
            logger.error("getTenantCN 异常",e);
        }
        return tenant;
    }



    protected boolean isNotNull(Object... obj){
        if(obj != null){
            for (Object o : obj) {
                if(o == null){
                    return false;
                }else if (o instanceof String){
                    String encoded = XssHttpServletRequestWrapper.xssEncode((String) o);
                    o = encoded;
                    if(o == null){
                        return false;
                    }
                }
            }
        }else{
            return false;
        }
        return true;
    }
    protected boolean isNull(Object... obj){
        return !isNotNull(obj);
    }

    protected String toJson(Object obj){
        if(obj instanceof String){
            return (String)obj;
        }
        String rs = null;
        try {
            JsonUtil.OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            rs = JsonUtil.OM.writeValueAsString(obj);
        } catch (Exception e) {
        	logger.error(e);
        }
        if(rs == null){
            rs = "{\"rc\":-1}";//解析JSON异常/IO异常
        }
        return rs;
    }


    protected String toJson(Object obj, String callback){
        if(obj instanceof String){
            return (String)obj;
        }
        String rs = null;
        try {
            JsonUtil.OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            rs = JsonUtil.OM.writeValueAsString(obj);
        } catch (Exception e) {
        	logger.error(e);
        }
        if(rs == null){
            rs = "{\"rc\":-1}";//解析JSON异常/IO异常
        }
        if(StringUtils.isNotEmpty(callback)){
        	rs = String.format("%s(%s)", callback, rs);
        }

        return rs;
    }

    protected SessionUser user(){
    	return ThreadLocalSessionUser.getUser();
    }

    /**
     * mycenter method
     */
    protected String getLenovoId(){
        logger.info("user={}",JsonUtil.toJson(user()));
        String lenovoId = user().getLenovoid();
//        String lenovoId = "10088276858";
//        String lenovoId = "18101024154";
//        String lenovoId = "1000012111";//18101024154 ,慧商,uat,com
//        String lenovoId = "1000012107";//18612189136 ,慧商,uat,com
        logger.info("The lenovoId from SSO is: "+lenovoId);
        return lenovoId;
    }

    protected  BasePara getBasePara(){
    	HttpServletRequest servletRequest = request();
    	BasePara base = new BasePara() {
			@Override
			public BaseInfo validateAppPara() {
				return BaseInfo.success();
			}
		};
        try {
            Integer shopid = (Integer)servletRequest.getAttribute("shopId") == null ?1:(Integer)servletRequest.getAttribute("shopId");
            Integer terminal = Integer.parseInt((servletRequest.getAttribute("terminal") == null?1:servletRequest.getAttribute("terminal")).toString());
            if(servletRequest.getParameter("shopId")!=null){
                shopid = Integer.parseInt(servletRequest.getParameter("shopId"));
            }
            if(servletRequest.getParameter("terminal")!=null){
                terminal = Integer.parseInt(servletRequest.getParameter("terminal"));
            }
            logger.info("shopId:"+shopid);
            logger.info("terminal:" + terminal);
            base.setTerminal(terminal);
            base.setShopId(shopid);

            base.setFormat("json");
            base.setIp(servletRequest.getRemoteAddr());
            base.setSource("1");
            base.setV("1.0");
            SessionUser user = ThreadLocalSessionUser.getUser();
            User u = User.SessionUser2User(user);
            if(base.getShopId() == ShopIdEnum.HUI_SANG.getType() || base.getShopId() == ShopIdEnum.HUI_SANG_SCORE.getType()){
                com.alibaba.fastjson.JSONObject jsonObject = getBuyerAndFA(u.getUserId());
                if(jsonObject!= null){
                    u.setBuyerCode(jsonObject.getString("jxsname") == null? "" : jsonObject.getString("jxsname"));//经销商名称
                    base.setBeemobile(jsonObject.getString("beemobile") == null ? "":jsonObject.getString("beemobile"));
                }else{
                    u.setBuyerCode("");
                    base.setBeemobile("");
                }

                //xx        单点        流转user
                //agentcode loginName  username
                //agentid   groupcode  memberid
                u.setMemberId(user.getGroupCode());
            }
            base.setUser(u);
            logger.info("buyerId:{},user msg:{}",u.getUserId(),JsonUtil.toJson(u));
        }catch (Exception e){
            logger.error("getBasePara 异常",e);
        }

        return base;
    }

    public static com.alibaba.fastjson.JSONObject getBuyerAndFA(String buyerId){
        String address = buyerUrl + buyerId;//1000000518  "http://i.itplace.lenovouat.com/rest/getjxsinfo.jhtml?jxsnum="
        com.alibaba.fastjson.JSONObject jsonObject = new com.alibaba.fastjson.JSONObject();
        try {
            String jsonResult = HttpClientUtil.getStr(address);
            logger.info("分销商/经销商信息:"+jsonResult);
            com.alibaba.fastjson.JSONObject object = com.alibaba.fastjson.JSON.parseObject(jsonResult);
            if(object != null && object.getJSONObject("page")!=null && object.getInteger("success") == 1){
                com.alibaba.fastjson.JSONArray jsonArray = object.getJSONObject("page").getJSONArray("data");
                if(jsonArray!=null && jsonArray.size()>0){
                    jsonObject =jsonArray.getJSONObject(0);
                }
            }
            return jsonObject;
        }catch (Exception e){
            logger.error("获取分销商/经销商信息失败!",e);
            return null;
        }

    }

    /**
     * 获取userid , 登录时用登录的userid, 未登录用unique;
     * @param u
     * @return
     */
    protected Boolean getUser(User u){
        if(u == null){
            return false;
        }
        String userId = u.getUserId();
        if(StringUtils.isEmpty(userId)){
            userId = u.getUnique();
        }
        if(StringUtils.isEmpty(userId)){
            return false;
        }
        return true;
    }

    protected User getApiUser(){
    	HttpServletRequest servletRequest = request();

    	User u = new User();
    	u.setGroupCode("");
    	u.setIsLenovo(true);
    	u.setLoggedIn(true);
        u.setMemberId(servletRequest.getParameter("memberid"));
    	u.setUnique(servletRequest.getParameter("unique"));
    	u.setUserId(servletRequest.getParameter("userId"));
        String username =servletRequest.getParameter("userName");
    	u.setUsername(StringUtil.isEmpty(username)?"":username);
	return u;
    }

    /**
	 *
	* @Description: 接口签名校验
	* @author yuzj7@lenovo.com
	* @date 2015年5月18日 上午11:08:48
	* @param params		接口参数
	* @return
	 */
	protected BaseInfo verify(Map<String,String> params){
		if(null == params){
			return new BaseInfo(0, "缺少参数");
		}
		if( null == params.get("sign") || StringUtil.isEmpty(params.get("sign").toString()) ){
			return new BaseInfo(0, "缺少签名参数");
		}

		//对方使用的签名类型 使用md5 校验
		//String sign_type = params.get("sign_type");
		//对方的签名
		String sign = params.get("sign");
		/*if("qwer1234..".equals(sign)){
			return new BaseInfo(1, "验证签名成功");
		}*/
		//除去数组中的空值和签名参数
		Map<String,String> paramsNew = AlipayCore.paraFilter(params);
		//接口参数排序
		String line = AlipayCore.createLinkString(paramsNew);
		//重新签名
		boolean isSign = MD5.verify(line, sign, Contants.MD5_KEY, "utf-8");
		if(isSign){
			return new BaseInfo(1, "验证签名成功");
		}
		return new BaseInfo(0, "签名错误");
	}

	/**
	 * 输出json 数据供各个接口调用
	 *
	 * @throws IOException
	 */

	public String ajaxWriteStr(String jsonstr,HttpServletResponse response) {
		try {
			response.setContentType("text/html");// 这句设置很重要
			// // // 苹果浏览器和IE下必须设置这个
			response.setCharacterEncoding("UTF-8");
			// 添加数据压缩处理 -结束
			response.getWriter().write(jsonstr);
			response.getWriter().close();
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

	 protected void copyBasePara(BasePara base, Object dst){
		try{
			BeanUtils.copyProperties(base, dst);
		}catch(Exception t){
			logger.error("", t);
		}
	 }

    protected Map<String, String> getMapString(Map<String,Object> param) {
        Map<String, String> result = new HashMap<String, String>();

        for (String key : param.keySet()) {
            if(isNull(param.get(key))) {
                result.put(key, "");
                continue;
            }
            result.put(key, param.get(key).toString());
        }

        return result;
    }
}


