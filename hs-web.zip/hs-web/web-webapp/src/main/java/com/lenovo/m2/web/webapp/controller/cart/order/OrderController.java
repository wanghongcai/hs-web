package com.lenovo.m2.web.webapp.controller.cart.order;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.cart.CartService;
import com.lenovo.m2.hsbuy.domain.ApiResult;
import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;
import com.lenovo.m2.hsbuy.domain.invoice.param.AddVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoListParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.result.AddVatInvoiceInfoResult;
import com.lenovo.m2.hsbuy.domain.invoice.result.GetVatInvoiceInfoResult;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.hsbuy.domain.purchase.param.GetCartNGParam;
import com.lenovo.m2.hsbuy.domain.purchase.result.GetCartNGResult;
import com.lenovo.m2.web.common.purchase.annotation.Token;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.enums.TokenEnum;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.ErrorEnumUtil;
import com.lenovo.m2.web.common.purchase.util.BasePara;
import com.lenovo.m2.web.common.purchase.constants.ViewConstants;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.domain.my.MobileMsg;
import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;
import com.lenovo.m2.web.domain.purchase.order.backfill.UpdateItemTypeEnum;
import com.lenovo.m2.web.manager.purchase.order.BackFillService;
import com.lenovo.m2.web.manager.purchase.order.SubmitOrderService;
import com.lenovo.m2.web.redis.MyRedisConn;
import com.lenovo.m2.web.remote.captcha.SmsCerpService;
import com.lenovo.m2.web.remote.my.order.OrderMongoService;
import com.lenovo.m2.web.remote.purchase.epack.EpackService;
import com.lenovo.m2.web.remote.purchase.invoice.CommonInvoiceRemoteService;
import com.lenovo.m2.web.remote.purchase.invoice.InvoiceRemoteService;
import com.lenovo.m2.web.remote.purchase.order.RemoteOrderService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.lenovo.m2.web.domain.my.order.MongoOrderDetail;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author yuzj7@lenovo.com
 * @ClassName: OrderController
 * @Description: 提交订单
 * @date 2015年6月30日 下午7:56:20
 */
@Controller("orderControllerPurchase")
public class OrderController extends BaseController {

    private static Logger log =  LogManager.getLogger(OrderController.class.getName());

    @Autowired
    protected MyRedisConn redisConn;
    private String member_score_center_url = CustomizedPropertyConfigurer.getContextProperty("member.center.sore.url");
    private String customerUrl = CustomizedPropertyConfigurer.getContextProperty("customer.url");
    private String customerUrl_wap = CustomizedPropertyConfigurer.getContextProperty("customer.url.wap");
    private String customerUrl_wap_hs = CustomizedPropertyConfigurer.getContextProperty("customer.url.wap.hs");
    private String think_pc_url = CustomizedPropertyConfigurer.getContextProperty("think.pc.home.url");
    private String think_wap_url = CustomizedPropertyConfigurer.getContextProperty("think.wap.home.url");

    @Autowired
    private InvoiceRemoteService invoiceRemoteService;
    @Resource
    protected MongoTemplate mongoTemplate;
    @Autowired
    private RemoteOrderService remoteOrderService;
    @Autowired
    private SubmitOrderService submitOrderService;
    @Autowired
    private BackFillService backFillService;

    @Autowired
    private CommonInvoiceRemoteService commonInvoiceRemoteService;
    @Resource
    private CartService shoppingCartService;
    @Autowired
    private EpackService epackService;
    @Autowired
    private OrderMongoService orderMongoService;
    @Autowired
    private SmsCerpService smsCerpService;
//
//    @Value("#{configProperties['epack.url']}")
//    private String epackURL;
//    @Value("#{configProperties['epack.username']}")
//    private String epackUsername;
//    @Value("#{configProperties['epack.password']}")
//    private String epackPassword;

    /**
     * @param shopId
     * @param buyType 购买类型0：普通，1：立即购买 2:一键购（直接跳转到支付页面）
     * @param terminal
     * @param lid
     * @param consigneeId
     * @param map
     * @param response
     * @return
     * @Description: 进入PC结算中心
     * @author yuzj7@lenovo.com
     * @date 2015年7月21日 下午9:01:31
     */

    @RequestMapping(value = "/checkout")
    @Token(action = TokenEnum.GENERATE)
    public String checkout(Integer shopId, Integer buyType,Integer terminal,String lid,String consigneeId,String identity,String couponwap, Map<String, Object> map,
                           HttpServletResponse response,HttpServletRequest servletRequest) {

        log.info("+++++++++++++++log+++++++++++++++++++++++");
        log.info("shopId---"+shopId+"---terminal---"+terminal+"---lid---"+lid);
        if(null == shopId || null == terminal){
            // map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(terminal);
        }
        if (isNull(user())) {
            //map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN").getCommon());
            return ViewConstants.getCommonErrorPath(terminal);
        }
    	/*if(!p.matcher(lid).find()){
    		 map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
    		 return ViewConstants.getCommonErrorPath(terminal);
    	}*/

    	//报价单跳转标识，用于屏蔽结算页的优惠券和优惠码
        String priceListFlag = servletRequest.getParameter("priceListFlag");
        log.info("订单来源为报价单："+priceListFlag);

        BasePara base = getBasePara();

        if (StringUtil.isEmpty(lid)){//如果此次没有结算缓存则设置一个缓存id并重定向
            try {
                lid = System.currentTimeMillis()+"";
                map.put("lid", lid);
                BackFillOrderVo backFillOrderVo = new BackFillOrderVo();
                backFillOrderVo.setBuyType(buyType == null ? 0 : buyType);
                if(!StringUtil.isEmpty(identity)){
                    backFillOrderVo.setIdentityId(Long.parseLong(identity));
                }
                backFillService.initCheckOutCache(user().getLenovoid(),terminal,shopId,lid,backFillOrderVo);
                if(null!=priceListFlag){
                    response.sendRedirect("/checkout.jhtm?lid="+lid+"&shopId="+shopId+"&terminal="+terminal+"&priceListFlag="+priceListFlag);
                }else{
                    response.sendRedirect("/checkout.jhtm?lid="+lid+"&shopId="+shopId+"&terminal="+terminal);
                }
            } catch (IOException e) {
                log.error("checkout 异常",e);
                //map.put("detail", ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION.getCommon());
                map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_SYSTEM_EXCEPTION").getCommon());
                return ViewConstants.getCommonErrorPath(terminal);
            }
        }else{
            //校验lid 必须是后台生成的，过滤掉用户自己生成的，非法操作
            boolean right = backFillService.isRightLid(user().getLenovoid(), terminal, shopId, lid);
            try {
                if(!right){
                    //map.put("detail", ErrorMessageEnum.ERROR_GET_CART.getCommon());
                    map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_GET_CART").getCommon());
                    response.sendRedirect("/getcart.jhtm?terminal="+terminal);
                }
            } catch (IOException e) {
                log.error(e);
            }
        }
        String header = servletRequest.getHeader("Referer");
        log.info("Referer---{}",header);
        log.info("couponwap---{}",couponwap);
        map.put("lid",lid);
        map.put("couponwap",couponwap);
        map.put("referer",header);
        map.put("consigneeId", consigneeId);
        map.put("priceListFlag",priceListFlag);
        return ViewConstants.getCheckoutPath(terminal);
    }

    /**
     * @Author zhanghs 【zhanghs6@lenovo.com】
     * @Description: 使用虚拟货币（优惠券，优惠码，内购，礼品卡，乐豆）
     * @date 2016/3/30 15:06
     * @return
     *
     * @update 添加数据恢复险14
     */
    @RequestMapping(value = "/usevirtualcurrency")
    @Token(action = TokenEnum.GENERATE)
    public String UseVirtualCurrency(Integer shopId, Integer virtualType,Integer terminal,String lid,String content, Map<String, Object> map,
                                     HttpServletResponse response,HttpServletRequest request) {
        if(null == lid || null == virtualType){
            //map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(terminal);
        }
        if (isNull(user())) {
            //map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN").getCommon());
            return ViewConstants.getCommonErrorPath(terminal);
        }
        String json  = submitOrderService.UseVirtualCurrency(terminal,getTenant(),lid,virtualType,content,user(),request);
        return this.ajaxWriteStr(json, response);
    }


    /**
     * @param plat    平台
     * @param itemids 数据项id|数据项类型
     * @return
     * @Description: 进入WAP结算中心
     * @date 2015年7月21日 下午9:01:31

     @RequestMapping(value = "/checkoutWap")
     public String checkoutWap(Integer shopId, Integer terminal,String consigneeId, Map<String, Object> map, HttpServletResponse response) {

     //确定新页面是否能用
     // return ViewConstants.getNewInvoice(plat+"");

     map.put("consigneeId", consigneeId);
     return ViewConstants.getCheckoutPath(terminal);
     }*/


    /**
     *
     * @Title: getCheckOutData
     * @Description: 刷新获取结算数据 json 交互
     * @param shopId
     * @param terminal
     * @param map
     * @param response
     * @return    设定文件
     */
    @RequestMapping("/getCheckOutData")
    @ResponseBody
    public String getCheckOutData(String lid ,Integer terminal,Integer shopId, Map<String, Object> map, HttpServletResponse response, HttpServletRequest request) {
        try{
            if(null == lid){
                //map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
                map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
                return ViewConstants.getCommonErrorPath(terminal);
            }
            if (isNull(user())) {
                //map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
                map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN").getCommon());
                return ViewConstants.getCommonErrorPath(terminal);
            }
            String json  = submitOrderService.checkOut(terminal,getTenant(),lid,request,user());
            return this.ajaxWriteStr(json, response);
        }catch(Exception e){
            log.error("getCheckOutData  异常"+ com.lenovo.m2.credit.common.util.ExceptionUtil.getStackTrace(e));
            return "";
        }

    }


    /**
     *
     * @Title: submitOrder
     * @Description: ajax 提交订单
     * @param response
     * @param request
     * @return    设定文件
     */
    @RequestMapping("/submitOrder")
    @ResponseBody
    public String submitOrder(Boolean selectNormal, String preSaleMobile,String creditInfo,Integer terminal,Integer shopId,String lid,String orderremark,String cmanagercode,String captcha,HttpServletResponse response,HttpServletRequest request){
        try{
            if(null == lid || terminal ==null || StringUtil.isEmpty(lid)){
                //ApiResult<String> result = new ApiResult<String>(ErrorMessageEnum.ERROR_PARAM);
                //return  JsonUtil.toJson(result);
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM")));
            }
            if (isNull(user())) {
                //ApiResult<String> result = new ApiResult<String>(ErrorMessageEnum.ERROR_NOT_LOGIN);
                //return  JsonUtil.toJson(result);
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN")));
            }
            String json = submitOrderService.submitOrder(selectNormal,preSaleMobile,creditInfo, getTenant(), terminal, lid, orderremark, cmanagercode, request, user(), captcha);
            return this.ajaxWriteStr(json, response);
        }catch(Exception e){
            log.error("submitorder 异常",e);
            return "";
        }
    }


    /**
     * whw
     * 跳转到vat页面
     */
    //turnVAT_vm
    @RequestMapping("/turnVAT_vm")
    public String turnVAT_vm(Integer plat, Map<String, Object> map, String itemids, String merchantId, String sharecode,String deliverid) {
        log.info("plat:" + plat + "===" + itemids + "====merchantId" + merchantId);
        if (isNull(plat)) {
            //map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        if (isNull(user())) {
            //map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        map.put("itemids", itemids);
        map.put("sharecode", sharecode);
        map.put("merchantId", merchantId);
        map.put("deliverid", deliverid);

        return ViewConstants.getInvoiceVATVM(plat + "");
    }



    /**
     * @param ordernum
     * @param plat
     * @param map
     * @return
     * @Description:赚到订单提交成功页面
     * @author yuzj7@lenovo.com
     * @date 2015年8月17日 下午10:11:43
     */
    @RequestMapping("/toOrderSuccesspage")
    public String toOrderSuccesspage(String ordernum, int plat, Map<String, Object> map) {
        if (isNull(ordernum)) {
            //map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        if (isNull(user())) {
            //map.put("detail", ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        map.put("plat", plat);
        map.put("lenovoId", user().getLenovoid());
        return ViewConstants.getOrderSubmitSuccessPath(plat + "");
    }




    /**
     * @param plat 平台
     * @return
     * @Description: 提交订单阅读协议页面
     * @author yuzj7@lenovo.com
     * @date 2015年8月23日 下午4:20:19
     */
    @RequestMapping("/help/toHelpTermsPage")
    public String toHelpTermsPage(Integer plat, Map<String, Object> map) {
        if (isNull(plat)) {
            //map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        return ViewConstants.getHelpTerms(plat + "");
    }

    /**
     * @param plat
     * @param map
     * @return 设定文件
     * @Title: toRepeatSubmitPage
     * @Description: 到重复提交表单页面
     */
    @RequestMapping("/toRepeatSubmitPage")
    public String toRepeatSubmitPage(Integer plat, Map<String, Object> map) {
        if (isNull(plat)) {
            // map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(plat + "");
        }
        map.put("detail", "请不要重复提交表单!");
        return ViewConstants.getCommonErrorPath(plat + "");
    }


    /**
     * 跳转到think的通用条款页面
     */
    @RequestMapping("turnThink")
    public String turnThink() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/think_default";
    }

    /**
     * 跳转到think服务条款页面
     */
    @RequestMapping("turnThink2")
    public String turnThink2() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/think_default2";
    }

    /**
     * 跳转到预售条款页面
     */
    @RequestMapping("turnPresell")
    public String turnPresell() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/presell_default";
    }
    /**
     * 跳转到预售条款wap页面
     */
    @RequestMapping("turnPresellWap")
    public String turnPresellWap() {
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/presell_default_wap";
    }

    /**
     * 跳转到商城的我同意页面
     */
    @RequestMapping("turnB2C")
    public String turnB2C() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/b2c_default";
    }


    /**
     * 跳转到商城的我同意页面
     */
    @RequestMapping("turnB2C2")
    public String turnB2C2() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/b2c2_default";
    }


    /**
     * 跳转到惠商的我同意页面
     */
    @RequestMapping("turnHS")
    public String turnHS() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/hs_default";
    }

    /**
     * 跳转到懂得的我同意页面
     * @return
     */
    @RequestMapping("turnDongde")
    public String turnDongde() {
        return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "checkout/buywidget/dongde_agree";
    }


    /**
     * wap2.0 ：Jump to page editing by votes
     *
     * @deprecated use {@link # turnvat(int, int, String, Map)} instead.
     */
    @RequestMapping("/turnvat2_vm")
    @Deprecated
    public String turnvat2_vm(Integer terminal,Integer shopId,String lid, Map<String, Object> map) {
        map.put("lid", lid);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/invoice_vat";
    }


    @RequestMapping("/getCheckOutCart")
    public String getCheckOutCart(int shopId,int terminal,int buyType,HttpServletResponse response){
        if (isNull(user())){
            return toJson(BaseInfo.errInfo(401));
        }
        User user = User.SessionUser2User(user());
        GetCartNGParam getCartNGParam = new GetCartNGParam();
        getCartNGParam.setBuyType(buyType);
        getCartNGParam.setTerminal(terminal);
        getCartNGParam.setUser(user);
        RemoteResult<GetCartNGResult> json =  remoteOrderService.getCartNG(getTenant(),getCartNGParam);
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(json,PromptEnum.CHECKOUT)), response);
    }

    @RequestMapping("/getCheckOutCart/recovery")
    public String getCheckOutCartWap(int shopId,int terminal,int buyType,HttpServletResponse response){
        if (isNull(user())){
            return toJson(BaseInfo.errInfo(401));
        }
        User user = User.SessionUser2User(user());
        int recoveryFlag=0; //数据恢复险 0 刷新获取恢复险信息
        GetCartNGParam getCartNGParam = new GetCartNGParam();
        getCartNGParam.setBuyType(buyType);
        getCartNGParam.setRecoveryFlag(recoveryFlag);
        getCartNGParam.setTerminal(terminal);
        getCartNGParam.setUser(user);
        RemoteResult<GetCartNGResult> json =  remoteOrderService.getCartNG(getTenant(),getCartNGParam);
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(json,PromptEnum.CHECKOUT)), response);
    }

    @RequestMapping("/getCoupons")
    public String getCoupons(String order,Integer terminal,Integer shopId,String lid,String content, Map<String, Object> map) {
        map.put("data", content);
        map.put("terminal1", terminal);
        map.put("shopId1", shopId);
        map.put("lid1", lid);
        map.put("order1", order);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/coupon_tmp";
    }
    @RequestMapping("/getCouponlist")
    public String getCouponsN(Integer terminal,Integer shopId,String lid, Map<String, Object> map, HttpServletRequest request) {
        if(null == lid){
            // map.put("detail", ErrorMessageEnum.ERROR_PARAM.getCommon());
            map.put("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM").getCommon());
            return ViewConstants.getCommonErrorPath(terminal);
        }
        String json = submitOrderService.checkOut(terminal,getTenant(),lid,request,user());
        map.put("content", json);
        map.put("terminal1", terminal);
        map.put("shopId1", shopId);
        map.put("lid1", lid);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/coupon_tmp";
    }

    @RequestMapping("/toProductListPage")
    public String toProductListPage(String lid,Integer buyType,String faCode,String datarecovery,Map<String,Object> map){
        if (isNull(user())){
            return toJson(BaseInfo.errInfo(401));
        }
        map.put("buyType",buyType);
        map.put("lid", lid);
        map.put("datarecovery",datarecovery);
        map.put("faCode",faCode == null ? "":faCode);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/product_list";
    }


    /**
     *获取增票信息（最新一条或是共享信息）
     *@author licy13
     */
    @RequestMapping(value = "/getVatInvoiceInfo", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String getVatInvoiceInfo(GetVatInvoiceInfoParam getVatInvoiceInfoParam, Integer shopId) {
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        getVatInvoiceInfoParam.setLenovoId(user().getLenovoid());
        getVatInvoiceInfoParam.setShopId(shopId);

        logger.info("getVatInvoiceInfo-param:{}",toJson(getVatInvoiceInfoParam));
        String re = invoiceRemoteService.getVatInvoiceInfo(getTenant(),getVatInvoiceInfoParam);
        logger.info("getVatInvoiceInfo-re:{}",re);
        ApiResult<GetVatInvoiceInfoResult> apiResult = JsonUtil.fromJson(re, new TypeReference<ApiResult<GetVatInvoiceInfoResult>>() {});
        GetVatInvoiceInfoResult invoice=new GetVatInvoiceInfoResult();
        logger.info("getVatInvoiceInfo-apiResult:{}",JsonUtil.toJson(apiResult));
        if(apiResult!=null&&apiResult.getRc()==1000&&apiResult.getData()!=null){
            invoice=apiResult.getData();
        }else{
            return "{}";
        }
        logger.info("lenovoId:{},return invoice information {}", user().getLenovoid(), toJson(invoice));
        return toJson(invoice);

    }

    /**
     * 普票/电子票 通过title获取发票信息
     * @param vatInvoice
     * @return
     */
    @RequestMapping(value="/getCommonInvoice",produces = "application/json; charset=utf-8")
    @ResponseBody
    public String getCommonInvoice(VatInvoice vatInvoice){
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        RemoteResult<VatInvoice> commonInvoiceRemoteResult = commonInvoiceRemoteService.getInvoiceByTitle(vatInvoice,getTenant());
        return  JsonUtil.toJson(new FpsResult(commonInvoiceRemoteResult));
    }

    /**
     * 普票/电子票保存
     * @param vatInvoice
     * @return
     */
    @RequestMapping(value="/addCommonInvoice",produces = "application/json; charset=utf-8")
    @ResponseBody
    public String addCommonInvoice(VatInvoice vatInvoice){
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        vatInvoice.setCreateby(user().getLenovoid());
        vatInvoice.setShopid(getBasePara().getShopId());
//        if(vatInvoice.getInvoiceType() == 1 && vatInvoice.getCustType() ==1){
//            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_SAVE_INVOICE));
//
//        }
        RemoteResult<VatInvoice> commonInvoiceRemoteResult = commonInvoiceRemoteService.saveInvoice(vatInvoice,getTenant());
        return  JsonUtil.toJson(new FpsResult(commonInvoiceRemoteResult));
    }

    /**
     * 获取用户普票下拉列表
     * @return
     */
    @RequestMapping(value="/getInvoiceByUser",produces = "application/json; charset=utf-8")
    @ResponseBody
    public String getInvoiceByUser(){
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        RemoteResult<List<VatInvoice>> commonInvoiceRemoteResult = commonInvoiceRemoteService.getInvoiceByUser(user().getLenovoid(),getTenant());
        return  JsonUtil.toJson(new FpsResult(commonInvoiceRemoteResult));
    }

    /**
     * 惠商增票 faid,fatype
     * @return
     */
    @RequestMapping(value = "/getVatInvoiceInfoByHs", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String getVatInvoiceInfoByHs(GetVatInvoiceInfoListParam param) {
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        param.setLenovoId(user().getLenovoid());
        logger.info("getVatInvoiceInfoByHs-param:{}",toJson(param));
        RemoteResult<List<GetVatInvoiceInfoResult>> result = invoiceRemoteService.getVatInvoiceInfo(param,getTenant());
        return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
    }

    /**
     * 新版保存增票信息（更新缓存）
     *@author licy13
     */
    @RequestMapping("/saveVatInvoiceInfo")
    @ResponseBody
    public String saveVatInvoiceInfo(String invoice,String lid,Integer terminal,Integer shopId) {
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        if (StringUtil.isEmpty(invoice)||StringUtil.isEmpty(lid)) {
            return toJson(BaseInfo.errInfo(400));
        }
        String lenovoId = user().getLenovoid();
        log.info("lenovoId:{},  Accepts invoice information:{}", lenovoId, invoice);

        AddVatInvoiceInfoParam invoiceVo = JsonUtil.fromJson(invoice, AddVatInvoiceInfoParam.class);
        invoiceVo.setLenovoId(lenovoId);
        invoiceVo.setShopId(shopId);
        //校验注册电话
        if (StringUtil.isEmpty(invoiceVo.getPhoneNo())) {
            //return toJson(new BaseInfo(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_EMPTY));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_INVOICE_PHONENO_NOT_EMPTY")));
        }else if(!CheckParameterUtil.isPhone(invoiceVo.getPhoneNo())){
            //return toJson(new BaseInfo(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_FORMAT));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_INVOICE_PHONENO_NOT_FORMAT")));
        }

        String re = invoiceRemoteService.addVatInvoiceInfoParam(getTenant(),invoiceVo);
        ApiResult<AddVatInvoiceInfoResult> apiResult = JsonUtil.fromJson(re, new TypeReference<ApiResult<AddVatInvoiceInfoResult>>() {});
        if (apiResult.getRc()==1000&&apiResult.getData()!=null) {
            log.info("saveVatInvoiceInfo lenovoid:{},lid:{},vatInvoiceId:{}",lenovoId,lid,apiResult.getData().getVatInvoiceId());
            //invoiceHeader = 1 公司 ；invoiceTypeId = 2 增票
            String  content="{\"invoiceTypeId\":2,\"invoiceContent\":\""+invoiceVo.getCustomerName()+"\",\"invoiceHeader\":1,\"vatInvoiceId\":"+apiResult.getData().getVatInvoiceId()+"}";
            BackFillOrderVo result=backFillService.updateCheckOutCache(lenovoId,terminal,shopId,lid,content, UpdateItemTypeEnum.getValue(2));
            if (null != result){
                log.info("saveVatInvoiceInfo lenovoid{},cachecontent{}",lenovoId,content);
            }else{
                log.info("saveVatInvoiceInfo lenovoid{},Invoice cache update failed",lenovoId);
                // return toJson(new BaseInfo(ErrorMessageEnum.ERROR_INVOICE_FAIL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_INVOICE_FAIL")));
            }
            return toJson(new BaseInfo(1000));
        } else{
            return toJson(new BaseInfo(apiResult.getRc(), apiResult.getMsg()));
        }
    }

    /**
     *
     *@author licy13
     */
    @RequestMapping("/turnvat")
    public String turnvat(String faid,int terminal,int shopId,String lid, Map<String, Object> map) {
        map.put("lid", lid);
        map.put("faid", faid);
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/order/common/invoice_vat";
    }
    /**
     *
     * @Title: toO2OPcSuccess
     * @Description: o2o 转到成功页面
     * @param map
     * @return    设定文件
     * @throws
     */
    @RequestMapping("/toO2Opsuccess")
    public String toO2OPcSuccess(String orderMainCode,int terminal,int shopId,Map<String, Object> map){
        map.put("orderMainCode", orderMainCode);
        map.put("memberCenterHref", customerUrl);
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buycommon/o2o_success";
    }
    /**
     *
     * @Title: toO2OWapcSuccess
     * @Description: o2o wap 成功页
     * @param terminal
     * @param shopId
     * @param map
     * @return    设定文件
     * @throws
     */
    @RequestMapping("/toO2Owsuccess")
    public String toO2OWapcSuccess(String orderMainCode,int terminal,int shopId,Map<String, Object> map){
        map.put("orderMainCode", orderMainCode);
        map.put("memberCenterHref", customerUrl_wap);
        return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "checkout/order/common/o2o_success";
    }
    /**
     *
     * @Title: toScoreSuccess
     * @Description: 积分商城跳转链接
     * @param orderMainCode
     * @param shopId
     * @param terminal
     * @param map
     * @return    设定文件
     * @throws
     */
    @RequestMapping("/toScoreSuccess")
    public String toScoreSuccess(String orderMainCode,int shopId,int terminal, Map<String, Object> map){
        map.put("orderMainCode", orderMainCode);
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buycommon/score_success";
    }
    @RequestMapping("/toHsSuccess")
    public String toHsSuccess(String orderMainCode,int shopId,int terminal, Map<String, Object> map){
        map.put("orderMainCode", orderMainCode);
        map.put("shopId", shopId);
        map.put("terminal", terminal);
        String shopIdString = String.valueOf(shopId);
        List<MongoOrderDetail> mongoOrderDetailsList = null;
        try {
            mongoOrderDetailsList = orderMongoService.getOrderDetailByOrderMainCode(orderMainCode, shopIdString);
            logger.info("mongoOrderDetailsList------->={}", JsonUtil.toJson(mongoOrderDetailsList));
            if (mongoOrderDetailsList == null || mongoOrderDetailsList.isEmpty()){
                Thread.currentThread().sleep(3000);
                mongoOrderDetailsList = orderMongoService.getOrderDetailByOrderMainCode(orderMainCode, shopIdString);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        map.put("ordersByMongo", mongoOrderDetailsList);
        map.put("memberCenterHref", customerUrl_wap_hs); //惠商我的订单
        if(Terminal.isPC(terminal)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("pay.huimall.url"));
            return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buycommon/hs_success";
        }else{
            map.put("payUrl",CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
            return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/order/common/o2o_success";
        }
    }

    /**(暂时舍弃)
     * 调用Epack校验SN码是否合法
     * @param SNCode
     * @param materialCode
     * @param response
     * @return
     */
//    @RequestMapping("/checkSNCode")
//    public String checkSNCode(String SNCode, String materialCode, HttpServletResponse response){
//        log.info(String.format("Check SN parameters, SNCode:%s MaterialCode:%s", SNCode, materialCode));
//
//        boolean checkResult = epackService.checkSN(epackURL, SNCode, materialCode, epackUsername, epackPassword);
//        BaseInfo baseInfo = null;
//        if(!checkResult){
//            baseInfo = new BaseInfo(0, "SN码校验失败");
//            log.info("Check SN failure.");
//        }else {
//            baseInfo = new BaseInfo(1, "SN码校验成功");
//            log.info("Check SN Success.");
//        }
//
//        return this.ajaxWriteStr(JsonUtil.toJson(baseInfo), response);
//    }

    /**
     * 获取短信验证码
     * @return
     */
    @ResponseBody
    @RequestMapping("/sendCaptcha")
    public String sendMobileCaptcha(HttpServletResponse response) {
        Map<String, Object> result = new HashMap<>();
        MobileMsg mobileMsg = new MobileMsg();
        mobileMsg.setMobile(user().getUsername());
        mobileMsg.setShopId("14");
        mobileMsg.setInner(false);
        boolean flag = smsCerpService.sendSmsCaptcha(mobileMsg);
        if(flag) {
            result.put("ret", true);
        }else {
            result.put("ret", false);
            result.put("msg", "验证码发送失败，请重试！");
        }
        return this.ajaxWriteStr(JsonUtil.toJson(result), response);
    }

    /**
     * 校验手机验证码
     * @param captcha
     * @return
     */
    @ResponseBody
    @RequestMapping("/checkMobileCaptcha")
    public String checkMobileCaptcha(String captcha,HttpServletResponse response) {
        if(StringUtil.isEmpty(captcha)){
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM"))),response);
        }
        if (isNull(user())) {
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN"))),response);
        }
        MobileMsg mobile = new MobileMsg();
        mobile.setMobile(user().getUsername());
        mobile.setCaptcha(captcha);
        mobile.setShopId("14");
        boolean flag = smsCerpService.verifySmsCaptcha(mobile);
        if (!flag) {
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_CAPTCHA"))),response);
        }
        return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"SUCCESS"))),response);
    }

}
