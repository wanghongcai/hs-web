package com.lenovo.m2.web.webapp.controller.cart.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.remote.purchase.address.AddressRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;


/**
 * <br> 实现获取省市区列表
 *
 * @author shenjc
 */

@Controller("addressControllerPurchase")
public class AddressController extends BaseController {

    private static Logger log = LogManager.getLogger(AddressController.class.getName());
    @Autowired
    private AddressRemoteService addressService;
    /**
     * <br> 获取省份列表
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/getprovince")
    @ResponseBody
    public String getProvince( HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<List<PartAddress>> result = addressService.getProvinceList(getTenant());
        return this.ajaxWriteStr(JsonUtil.toJson(result), response);
    }

    /**
     * <br> 获取某省份下市列表
     *
     * @param provincename
     * @return
     */
    @RequestMapping("/getcities")
    @ResponseBody
    public String getCitiesz(String provincename, HttpServletResponse response) {
        RemoteResult<List<PartAddress>> remoteResult = new RemoteResult(false);
        if (StringUtils.isNotEmpty(provincename)) {
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");
            } catch (UnsupportedEncodingException e) {
                log.error(e);
            }
            ProvinceParam provinceParam = new ProvinceParam();
            provinceParam.setProvince(provincename);
            remoteResult = addressService.getCityList(getTenant(), provinceParam);
        }
        return this.ajaxWriteStr(JsonUtil.toJson(remoteResult), response);
    }

    /**
     * <br> 获取指定省、市下的区县列表
     *
     * @param provincename
     * @param cityname
     * @return
     */
    @RequestMapping("/getcounties")
    @ResponseBody
    public String getCountiesz( String provincename, String cityname, HttpServletResponse response) {
        RemoteResult<List<PartAddress>> remoteResult = new RemoteResult(false);
        if (StringUtils.isNotEmpty(provincename) && StringUtils.isNotEmpty(cityname)) {
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");
                cityname = URLDecoder.decode(cityname, "utf-8");
            } catch (UnsupportedEncodingException e) {
                log.error(e);
            }
            ProvinceParam provinceParam = new ProvinceParam();
            provinceParam.setProvince(provincename);
            provinceParam.setCity(cityname);
            remoteResult = addressService.getRegionList(getTenant(), provinceParam);
        }
        return this.ajaxWriteStr(JsonUtil.toJson(remoteResult), response);
    }

    /**
     * 获取乡镇信息
     *
     * @return
     * @author 朝阳
     * @date 2016/7/21
     */
    @RequestMapping("/getvillages")
    @ResponseBody
    public String getVillagesz(String provincename, String cityname, String countryname, HttpServletResponse response) {
        RemoteResult<List<PartAddress>> remoteResult = new RemoteResult(false);
        if (StringUtils.isNotEmpty(provincename) && StringUtils.isNotEmpty(cityname) && StringUtils.isNotEmpty(countryname)) {
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");
                cityname = URLDecoder.decode(cityname, "utf-8");
                countryname = URLDecoder.decode(countryname, "utf-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            ProvinceParam provinceParam = new ProvinceParam();
            provinceParam.setProvince(provincename);
            provinceParam.setCity(cityname);
            provinceParam.setCounty(countryname);
            remoteResult = addressService.getCounty(getTenant(), provinceParam );
        }
        return this.ajaxWriteStr(JsonUtil.toJson(remoteResult), response);
    }

    /**
     * 获取邮政编码
     * @author licy13
     * @date 2016/7/21
     */
    @RequestMapping("/getzip")
    @ResponseBody
    public String getZipz( String provincename, String cityname, HttpServletResponse response) {
        RemoteResult<String> remoteResult = new RemoteResult(false);
        if (StringUtils.isNotEmpty(provincename) && StringUtils.isNotEmpty(cityname)) {
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");
                cityname = URLDecoder.decode(cityname, "utf-8");
            } catch (UnsupportedEncodingException e) {
                log.error("error={}",e);
            }
            ProvinceParam provinceParam = new ProvinceParam();
            provinceParam.setProvince(provincename);
            provinceParam.setCity(cityname);
            remoteResult = addressService.getZip(getTenant(),provinceParam);
        }
        return this.ajaxWriteStr(JsonUtil.toJson(remoteResult), response);
    }


}
