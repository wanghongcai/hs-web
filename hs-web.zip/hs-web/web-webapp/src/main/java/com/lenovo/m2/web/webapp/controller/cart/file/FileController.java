package com.lenovo.m2.web.webapp.controller.cart.file;

import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.hsbuy.common.enums.Terminal;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.hsbuy.domain.pricelist.UploadImageEntity;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.remote.purchase.invoice.InvoiceRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.UUID;

/**
 * @author朝阳
 */
@Controller
public class FileController extends BaseController {
    public static Logger logger =  LogManager.getLogger(FileController.class);

    @Autowired
    private  InvoiceRemoteService invoiceRemoteService;


    /**  上传电子票资质/懂得通信身份证信息
     * @param file
     * @param map
     * @param response
     * @param type
     * @param number
     * @return
     */
    @RequestMapping(value = "/uploadOtherImage/{type}/{number}", method = RequestMethod.POST)
    @ResponseBody
    public String uploadOtherImage(@RequestParam("file") MultipartFile file, RedirectAttributesModelMap map, HttpServletResponse response,@PathVariable String type,@PathVariable String number) {
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_NOT_LOGIN)), response);
        }
        return uploadImage(file, map, response, type, number,"invoice");
    }
    @RequestMapping(value = "/uploadFile/{source}/{type}/{number}", method = RequestMethod.POST)
    @ResponseBody
    public String uploadFile(@RequestParam("file") MultipartFile file, RedirectAttributesModelMap map, HttpServletResponse response,@PathVariable String type,@PathVariable String number,@PathVariable String source) {
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_NOT_LOGIN)), response);
        }
        return uploadImage(file, map, response, type, number,source);
    }

    private String uploadImage(MultipartFile file, RedirectAttributesModelMap map, HttpServletResponse response, String type,String number,String source) {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        response.setHeader("Cache-Control", "no-cache");
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Headers", "x-requested-with");
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        String lenovoid = user().getLenovoid();
        //  2016/6/6 获取跳转链接url
        String url= "/uploadfile/temp/"+number+".jhtm";
        String md5 = "";
        InputStream fis = null;
        byte[] file_buff = null;
        try {
            fis = file.getInputStream();
            file_buff = null;
            if (fis != null) {
                int len = fis.available();
                file_buff = new byte[len];
                fis.read(file_buff);
            }
        } catch (IOException e) {
            logger.error("occur error:", e);
        }
        try {
            md5 = new MD5Check().getFileMD5String(file.getInputStream());
            logger.info("uploadImg from source:{} lenovoid:{} md5:{}",source,lenovoid,md5);
        } catch (IOException e) {
           logger.error(e);
        }

        String fileName = file.getOriginalFilename();
        UploadImageEntity paramUploadImageEntity = new UploadImageEntity();
        paramUploadImageEntity.setFile_buff(file_buff);
        paramUploadImageEntity.setFileName(fileName);
        paramUploadImageEntity.setSize(file.getSize());
        paramUploadImageEntity.setMd5(md5);
        User user=new User();
        user.setUserId(lenovoid);
        paramUploadImageEntity.setUser(user);
        RemoteResult uploadPicture=null;

        FpsResult passResult =new  FpsResult(uploadPicture);
        try {
			fis.close();
		} catch (IOException e1) {
			logger.error(e1);
		}
        String rc="";
        if(passResult !=null && null != passResult.getData() && passResult.getRc()==0){
	         rc = (String) passResult.getData();
        }
        logger.info("uploadImg from source:{} lenovoid:{} return:rc={}",source,lenovoid,rc);
        responseMsg(null,map, response, url, rc);
        return null;
    }

    private void responseMsg(String tempContextUrl,RedirectAttributesModelMap map, HttpServletResponse response, String url, String rc) {
        response.addHeader("Location", url + "?msg=" + rc);
        try {
            map.addFlashAttribute("domain", CustomizedPropertyConfigurer.getContextProperty("lenovo.domain"));
            if (PeakConstant.SHOPID_ALLINPAY.equals(String.valueOf(getTenant().getShopId()))){
                logger.info("getTenant().getShopId()");
                url = CustomizedPropertyConfigurer.getContextProperty("pc.pay.url.14") + "/uploadfile/temp.jhtm";
            }else if(PeakConstant.SHOPID_SMB.equals(String.valueOf(getTenant().getShopId()))){
                //如果是17的，且不是测试环境得，则改为https的请求头，否则浏览器会拦截（生产环境）
                if(!StringUtil.isEmpty(tempContextUrl) && !tempContextUrl.contains("uat.com") && !tempContextUrl.contains("https") ) {
                    url = tempContextUrl.replace("http","https") + url;
                }
            }
            String strurl = url+"?msg=" + rc;
            logger.info("<=======uploadFilePath：{}=======>",strurl);
            response.sendRedirect(strurl);
        } catch (IOException e) {
        	logger.error(e);
        }
    }

    @RequestMapping(value = "/wap/toTempPage1")
    public String toTempPage1(int terminal) {
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/order/common/TempPage1";
    }
    @RequestMapping(value = "/wap/toTempPage2")
    public String toTempPage2(int terminal) {
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/order/common/TempPage2";
    }

    @RequestMapping(value = "/pc/toTempPage1")
    public String toTempPagePC1(int terminal) {
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buywidget/TempPage1";
    }

    @RequestMapping(value = "/pc/toTempPage2")
    public String toTempPagePC2(int terminal) {
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buywidget/TempPage2";
    }
    @RequestMapping(value = "/pc/dongde/{number}")
    public String toTempPagePCBydongde(@PathVariable String number,int terminal, Map<String, Object> map) {
        map.put("number",number);
        return ViewPathUtil.getViewPathByPlat(terminal) + "checkout/buywidget/TempPage";
    }
    @RequestMapping(value = "/uploadfile/temp/{number}")
    public String toTempPage(@PathVariable String number,int terminal, Map<String, Object> map) {
        String num="1";
        switch (number){
            case "oneImag":
                num="1";
                break;
            case "twoImag":
                num="2";
                break;
            case "threeImag":
                num="3";
                break;
        }
        map.put("number",num);
        String urltemp="";
        if(Terminal.PC.getType() == terminal){
            urltemp="checkout/buywidget/TempPage";
        }else{
            urltemp="checkout/order/common/TempPage";
        }
        return ViewPathUtil.getViewPathByPlat(terminal) +urltemp;
    }

    @RequestMapping(value = "/uploadfile/temp")
    public String toTempPageUtil(int terminal, Map<String, Object> map) {

        String urltemp="";

            urltemp="cn/my/pc/order/huimall/TempPage";

        return urltemp;
    }



    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
    @ResponseBody
    public String uploadFileUtil(@RequestParam("file") MultipartFile file, RedirectAttributesModelMap map, HttpServletRequest servletRequest, HttpServletResponse response, String path,String orderno) {
        String terminalStr = servletRequest.getParameter("terminal");
        Integer terminal = Integer.parseInt(terminalStr);
        //解决https变更为http得问题
        StringBuffer url = servletRequest.getRequestURL();
        String tempContextUrl = url.delete(url.length() - servletRequest.getRequestURI().length(), url.length()).append(servletRequest.getContextPath()).append("/").toString();
        if (isNull(user()) || StringUtil.isEmpty(getLenovoId())) {
//        if (false) {
            //// TODO: 2017/7/8 当前登录用户
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_NOT_LOGIN)), response);
        }
        String msg;
        if ("2".equals(terminalStr) || "3".equals(terminalStr)) {
            msg = uploadImage4Wap(file, map,response, path);

        } else {
            msg = uploadImage(tempContextUrl,file, map,response, path);
        }

        logger.info("支付凭证地址--orderno="+orderno+"msg--" + msg);

        return null;
    }

    public String uploadImage(String tempContextUrl,MultipartFile file, RedirectAttributesModelMap map, HttpServletResponse response,String path) {

        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        response.setHeader("Cache-Control", "no-cache");
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Headers", "x-requested-with");
        String wholePic = "";
        String url = "/uploadfile/temp.jhtm";
        try {
            if (null != file) {
                InputStream fis1 = null;
                byte[] file_buff1 = null;
                try {
                    fis1 = file.getInputStream();
                    if (fis1 != null) {
                        int len = fis1.available();
                        file_buff1 = new byte[len];
                        fis1.read(file_buff1);
                    }
                } catch (IOException e) {
                    logger.error("上传线下支付凭证出错",e);
                    return "";
                }
                try {
                    fis1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                byte[] bytes = file_buff1;
                String fileName = file.getOriginalFilename();
                String prefix = "";

                if (!StringUtils.isEmpty(fileName) && fileName.contains(".")) {
                    prefix = fileName.substring(fileName.lastIndexOf("."));
                }
                fileName = UUID.randomUUID().toString().replace("-", "") + prefix;
                //==========先同步boss
                StringBuffer sb = new StringBuffer(100);
//                String appId = "offlinepay";
//                String appKey = "6CIAv4NaDx6CZ18i";
//                String uploadPath = "/dealer/";
//                String imageServerURL = "http://internal-up.lefile.cn/image/upload";
//                String domain = "offlinepay.app.lefile.cn/";
                String appId = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.appId");
                String appKey = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.appKey");
                String uploadPath = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.uploadPath");
                String imageServerURL = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.url");
                String domain = CustomizedPropertyConfigurer.getContextProperty(path + ".download.url");
//                String pic_url = "offlinepay.app.lefile.cn/";
                //System.out.println("THE whole identity upload to boss is  success,used:["+(endTime1-startTime1)+"ms],Json:"+ JsonUtil.toJson(remoteResult));

                //TODO
                //保存到图片服务器上
                //图片服务器返回的图片地址更新到增票信息中
                long  startTime = System.currentTimeMillis();
                //=====================my================
                String update = "1";

                long timeStamp = System.currentTimeMillis();
                String token = UploadImageClient.getToken(appId, appKey, timeStamp, uploadPath + fileName, "1");

                UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+uploadPath+fileName, bytes, fileName, "1");
//                printResult(methodName, uploadResponse);
                logger.info("上传文件地址--uploadResponse--"+JsonUtil.toJson(uploadResponse));
                String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, uploadPath + fileName);
//                String ResultFileName = uploadResponse.getFilename();
                //System.out.print("THE identity upload to FastDFS is  success,used:["+(endTime-startTime)+"ms],uploadResponse1:"+ JsonUtil.toJson(response));

                if (StringUtils.isEmpty(readURL)) {
                    return "";
                }
//                wholePic = pic_url + ResultFileName+"?token="+token+"&timestamp="+timeStamp;
                wholePic = readURL;


            }
        }catch (Exception e){
            logger.error("上传线下支付凭证出错",e);
        }


        responseMsg(tempContextUrl,map, response, url, wholePic);
        return wholePic;
    }

    private String uploadImage4Wap(MultipartFile file, RedirectAttributesModelMap map, HttpServletResponse response,String path) {

        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        response.setHeader("Cache-Control", "no-cache");
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Headers", "x-requested-with");
        String wholePic = "";
        String url = "/uploadfile/temp.jhtm";
        try {
            if (null != file) {
                InputStream fis1 = null;
                byte[] file_buff1 = null;
                try {
                    fis1 = file.getInputStream();
                    if (fis1 != null) {
                        int len = fis1.available();
                        file_buff1 = new byte[len];
                        fis1.read(file_buff1);
                    }
                } catch (IOException e) {
                    logger.error("上传线下支付凭证出错",e);
                    return "";
                }
                try {
                    fis1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                byte[] bytes = file_buff1;
                String fileName = file.getOriginalFilename();
                String prefix = "";

                if (!StringUtils.isEmpty(fileName) && fileName.contains(".")) {
                    prefix = fileName.substring(fileName.lastIndexOf("."));
                }
                fileName = UUID.randomUUID().toString().replace("-", "") + prefix;
                //==========先同步boss
                StringBuffer sb = new StringBuffer(100);
//                String appId = "offlinepay";
//                String appKey = "6CIAv4NaDx6CZ18i";
//                String uploadPath = "/dealer/";
//                String imageServerURL = "http://internal-up.lefile.cn/image/upload";
//                String domain = "offlinepay.app.lefile.cn/";
                String appId = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.appId");
                String appKey = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.appKey");
                String uploadPath = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.uploadPath");
                String imageServerURL = CustomizedPropertyConfigurer.getContextProperty(path + ".upload.url");
                String domain = CustomizedPropertyConfigurer.getContextProperty(path + ".download.url");
//                String pic_url = "offlinepay.app.lefile.cn/";
                //System.out.println("THE whole identity upload to boss is  success,used:["+(endTime1-startTime1)+"ms],Json:"+ JsonUtil.toJson(remoteResult));

                //TODO
                //保存到图片服务器上
                //图片服务器返回的图片地址更新到增票信息中
                long  startTime = System.currentTimeMillis();
                //=====================my================
                String update = "1";

                long timeStamp = System.currentTimeMillis();
                String token = UploadImageClient.getToken(appId, appKey, timeStamp, uploadPath + fileName, "1");

                UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+uploadPath+fileName, bytes, fileName, "1");
//                printResult(methodName, uploadResponse);
                logger.info("上传文件地址--uploadResponse--"+JsonUtil.toJson(uploadResponse));
                String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, uploadPath + fileName);
//                String ResultFileName = uploadResponse.getFilename();
                //System.out.print("THE identity upload to FastDFS is  success,used:["+(endTime-startTime)+"ms],uploadResponse1:"+ JsonUtil.toJson(response));

                if (StringUtils.isEmpty(readURL)) {
                    return "";
                }
//                wholePic = pic_url + ResultFileName+"?token="+token+"&timestamp="+timeStamp;
                wholePic = readURL;


            }
        }catch (Exception e){
            logger.error("上传线下支付凭证出错",e);
        }


        responseMsg4Wap(map, response, url, wholePic);
        return wholePic;
    }

    private void responseMsg4Wap(RedirectAttributesModelMap map, HttpServletResponse response, String url, String rc) {
        response.addHeader("Location", url + "?msg=" + rc);
        try {
            map.addFlashAttribute("domain", CustomizedPropertyConfigurer.getContextProperty("lenovo.domain"));
            if (PeakConstant.SHOPID_ALLINPAY.equals(String.valueOf(getTenant().getShopId()))){
                logger.info("getTenant().getShopId()");
                url = CustomizedPropertyConfigurer.getContextProperty("wap.pay.url.14") + "/uploadfile/temp.jhtm";
            }
            String strurl = url+"?msg=" + rc;
            logger.info(strurl);
            response.sendRedirect(strurl);
        } catch (IOException e) {
            logger.error(e);
        }
    }

}
