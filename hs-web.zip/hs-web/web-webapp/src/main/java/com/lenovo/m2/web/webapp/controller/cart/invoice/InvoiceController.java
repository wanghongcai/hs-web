package com.lenovo.m2.web.webapp.controller.cart.invoice;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceIdAndUuid;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.util.CheckParameterUtil;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.remote.purchase.invoice.InvoiceRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.risk.client.RiskServiceClient;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.util.List;


/**
 * 发票业务
 *
 * @author licy13
 * @date 2016 -07-28-17:35
 */
@Controller
@RequestMapping("/invoice")
public class InvoiceController extends BaseController {
    private static Logger log = LogManager.getLogger(InvoiceController.class.getName());

    @Autowired
    private InvoiceRemoteService invoiceRemoteService;

    private RiskServiceClient riskServiceClient = RiskServiceClient.getInstance();

    /**
     * SMB保存增票信息
     *
     * @param invoice the invoice
     * @param shopId  the shop id
     * @return the string
     * @author licy13
     */
    @RequestMapping("/smb/save")
    @ResponseBody
    public String synInvoice(String invoice, Integer shopId,HttpServletRequest request) {
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        if (StringUtil.isEmpty(invoice)) {
            return toJson(BaseInfo.errInfo(400));
        }
        log.info("lenovoId:{},  Accepts invoice information:{}", user().getLenovoid(), invoice);

        String verifyCode = request.getParameter("verifyCode");
        log.info("cookie中取出的值:"+getCookieValue(request, "codeid"));
        log.info("输入的验证码"+verifyCode);
        boolean authCaptcha = riskServiceClient.getMessageCaptchaService()
                .authCaptcha(getCookieValue(request, "codeid"), verifyCode);
        log.info("判断的值"+authCaptcha);
        if (!authCaptcha) {
            log.info("验证码错误"+authCaptcha);
            RemoteResult<String> result = new RemoteResult<>();
            result.setSuccess(false);
            result.setT(null);
            result.setResultMsg("验证码错误");
            return toJson(result);
        }

        InvoiceShop invoiceShop = JsonUtil.fromJson(invoice, InvoiceShop.class);
        invoiceShop.setLenovoID(user().getLenovoid());
        invoiceShop.setShopId(shopId);
        invoiceShop.setSynType(1);//同步状态，1增加，2修改，3删除
        //校验注册电话
        RemoteResult<InvoiceIdAndUuid> result = new RemoteResult<InvoiceIdAndUuid>();
        if (StringUtil.isEmpty(invoiceShop.getPhoneNo())) {
            result.setSuccess(false);
            result.setT(null);
            result.setResultCode(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_EMPTY.getCode()+"");
            result.setResultMsg(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_EMPTY.getCommon());
            return toJson(result);
        }else if(!CheckParameterUtil.isPhone(invoiceShop.getPhoneNo())){
            result.setSuccess(false);
            result.setT(null);
            result.setResultCode(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_FORMAT.getCode()+"");
            result.setResultMsg(ErrorMessageEnum.ERROR_INVOICE_PHONENO_NOT_FORMAT.getCommon());
            return toJson(result);
        }
        result = invoiceRemoteService.synInvoice(invoiceShop);
        log.info("synInvoice RemoteResult:", JsonUtil.toJson(result));
        return toJson(result);
    }

    /**
     * 获取增票信息 list
     *
     * @param shopId the shop id
     * @return the vat invoice info
     * @author licy13
     */
    @RequestMapping(value = "/smb/getList", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String queryInvoice(Integer shopId) {
        if (isNull(user())) {
            return toJson(BaseInfo.errInfo(401));
        }
        RemoteResult<List<InvoiceShop>> result = invoiceRemoteService.queryInvoice(user().getLenovoid());
        logger.info("queryInvoice-result:", JsonUtil.toJson(result));
        return toJson(result);
    }

    /**
     * 获取增票信息 by id
     *
     * @param uuid     the id
     * @param shopId the shop id
     * @return the vat invoice info
     * @author licy13
     */
    @RequestMapping(value = "/smb/getById", produces = "application/json; charset=utf-8")
    @ResponseBody
    public String queryInvoiceForId(String uuid, Integer shopId) {
        RemoteResult<InvoiceShop> result = new RemoteResult<>(false);
        if (isNull(user())) {
            result.setResultMsg(ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon());
            return toJson(result);
        }
        if (StringUtils.isBlank(uuid)) {
            result.setResultMsg(ErrorMessageEnum.ERROR_PARAM.getCommon());
            return toJson(result);
        }
        result = invoiceRemoteService.queryInvoiceForId(uuid, user().getLenovoid());
        logger.info("queryInvoiceForId-result:", JsonUtil.toJson(result));
        return toJson(result);
    }

    private String getCookieValue(HttpServletRequest request, String cookieName) {
        String value = "";
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();
                if (cookieName.equals(name)) {
                    value = cookie.getValue();
                    break;
                }
            }
        }
        return value;
    }
}
