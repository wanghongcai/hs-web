
package com.lenovo.m2.web.webapp.controller.couponV2;

import com.google.gson.Gson;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.dubboModel.SalescouponsInfoApi;
import com.lenovo.m2.couponV2.api.dubboModel.UserApi;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.common.exception.*;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.common.purchase.util.ExceptionUtil;
import com.lenovo.m2.web.manager.couponV2.SalescouponFrontService;
import com.lenovo.m2.web.remote.couponV2.SalescouponFrontRemote;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.*;
import com.lenovo.m2.web.webapp.util.MD5;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


/**
 * 对外http绑券接口
 * Created by yezhenyue on 2016/3/10.
 */

@Controller
@Scope("prototype")
public class SalescouponApiController extends BaseController {
    private static final Logger log = LogManager.getLogger(SalescouponApiController.class);

    private static final String CONTENT_TYPE = "text/plain; charset=utf-8";
    @Autowired
    private SalescouponFrontService salescouponFrontService;
    @Autowired
    private SalescouponFrontRemote salescouponFrontRemote;

    /**
     * 一键领券接口
     * @param callbackparam
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/bindCouponsForOneKeyPeople",produces="application/json; charset=UTF-8")
    @ResponseBody
    public String bindCouponsForOneKeyPeople(String callbackparam,String activityType, HttpServletRequest request, HttpServletResponse response){
        try{
            if(StringUtils.isEmpty(activityType)){
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM")),callbackparam);
            }
            BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
            RemoteResult remoteResult = salescouponFrontRemote.bindCouponsForOneKeyPeople(user().getLenovoid(),Integer.parseInt(activityType),user().getUsername());
            return JsonUtil.toJson(new FpsResult(remoteResult), callbackparam);
        }catch (Exception e){
            log.error("调用 bindCouponsForOneKeyPeople 异常:"+e.getMessage(),e);
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_TIMEOUT")),callbackparam);
        }


    }

/**epp绑券接口
     * couponway 1 注册后送券；2 订单成功后送券
     * @param request
     * @param response
     */

    @RequestMapping(value = "/bindEppCoupon",method = RequestMethod.POST)
    public void bindEppCoupon(HttpServletRequest request,HttpServletResponse response){

        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            ResponseData responseData = new ResponseData(false);
            String couponwayStr = request.getParameter("couponWay");
            String lenovoId = request.getParameter("lenovoId");
//            String memberId = request.getParameter("memberId");
            String memberCode = request.getParameter("memberCode");
            String sign = request.getParameter("sign");
            log.info("addEppCoupon: couponWay=" + couponwayStr + ", lenovoId:"+lenovoId+", memberCode:"+memberCode);

            if(StringUtils.isEmpty(couponwayStr)  || StringUtils.isEmpty(lenovoId)|| StringUtils.isEmpty(memberCode)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            //MD5 签名校验
            String md5 = MD5.sign(lenovoId + memberCode + couponwayStr, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)){
                //参数错误
                responseData.setCode("02");
                responseData.setMsg("签名验证失败");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            int couponway = Integer.valueOf(couponwayStr);
            RemoteResult<Boolean> remoteResult = salescouponFrontService.addEppCoupon(couponway,lenovoId,memberCode);
            if(remoteResult!=null&&remoteResult.isSuccess()){
                responseData.setSuccess(true);
                responseData.setCode("00");
                responseData.setMsg("操作成功");
            }else {
                responseData.setSuccess(false);
                responseData.setCode("02");
                responseData.setMsg("绑券失败");
            }

            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }

    }


/**
     * 通用绑券接口
     * @param request
     * @param response
     */

    @RequestMapping(value="/bindCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public void bindCoupons(HttpServletRequest request,HttpServletResponse response){
        RpcRemoteResult responseData = new RpcRemoteResult(false);
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            String couponId = request.getParameter("couponId");//优惠券id
            String lenovoId = request.getParameter("lenovoId");
            String memberCode = request.getParameter("memberCode");
            String shopId = request.getParameter("shopId");
            String sign = request.getParameter("sign");
            log.info("bindCoupons: couponId="+couponId+", lenovoId="+lenovoId+", memberCode="+memberCode);

            if(StringUtils.isEmpty(couponId) || StringUtils.isEmpty(lenovoId)|| StringUtils.isEmpty(memberCode)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
            }
            String md5 = MD5.sign(lenovoId + memberCode + couponId, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)){
                //参数错误
                responseData.setCode("02");
                responseData.setMsg("签名验证失败");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
            }
            long id = Long.parseLong(couponId);
            if(!StringUtils.isEmpty(shopId)){
                RemoteResult<Boolean> remoteResult = salescouponFrontService.bindCoupons(shopId, id, lenovoId, memberCode);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    responseData.setSuccess(true);
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else{
                    responseData.setCode("02");
                    responseData.setMsg("绑券失败！");
                }
            }else {
                RemoteResult<Boolean> remoteResult = salescouponFrontService.bindCoupons(id, lenovoId, memberCode);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    responseData.setSuccess(true);
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else {
                    responseData.setCode("02");
                    responseData.setMsg("绑券失败！");
                }
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
    }



/**
     * 社区使用
     * 绑券接口
     * @param request
     * @param response
     */

    @RequestMapping("/coupons/communityBindCoupons")
    public void communityBindCoupons(HttpServletRequest request,HttpServletResponse response){
        try {

            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            RpcRemoteResult responseData = new RpcRemoteResult(false);
            String couponId = request.getParameter("couponId");//优惠券id
//            String memberId = request.getParameter("memberId");
            String lenovoId = request.getParameter("lenovoId");
            String memberCode = request.getParameter("memberCode");
            String shopId = request.getParameter("shopId");
            String sign = request.getParameter("sign");
            log.info("bindCoupons: couponId="+couponId+", lenovoId="+lenovoId+", memberCode="+memberCode);

            if(StringUtils.isEmpty(couponId) || StringUtils.isEmpty(lenovoId)|| StringUtils.isEmpty(memberCode)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            String md5 = MD5.sign(lenovoId + memberCode + couponId, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)){
                //参数错误
                responseData.setCode("02");
                responseData.setMsg("签名验证失败");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            long id = Long.parseLong(couponId);
            if(!StringUtils.isEmpty(shopId)){
                RemoteResult<Boolean> remoteResult = salescouponFrontService.bindCoupons(shopId, id, lenovoId, memberCode);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    responseData.setSuccess(true);
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else{
                    responseData.setCode("02");
                    responseData.setMsg("绑券失败！");
                }
            }else {
                RemoteResult<Boolean> remoteResult = salescouponFrontService.bindCoupons(id, lenovoId, memberCode);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    responseData.setSuccess(true);
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else {
                    responseData.setCode("02");
                    responseData.setMsg("绑券失败！");
                }
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
    }



/**
     * 获取用户可用优惠券数量
     * @param request
     * @param response
     */

    @RequestMapping("/getSalescouponsWithLenovoId")
    public void getSalescouponsWithLenovoId(HttpServletRequest request,HttpServletResponse response){
        try {

            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            ResponseData responseData = new ResponseData(false);
            String shopId = request.getParameter("shopId");//优惠券id
            String terminal = request.getParameter("terminal");
            String lenovoId = request.getParameter("lenovoId");
//            String memberId = request.getParameter("memberId");
            String membercode = request.getParameter("membercode");
            String groupCode = request.getParameter("groupCode");
            log.info("getSalescouponsWithLenovoId: shopId="+shopId+", terminal="+terminal+", lenovoId="+lenovoId+", membercode="+membercode+", groupCode="+groupCode);

            if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal)|| StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(membercode) || StringUtils.isEmpty(groupCode)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
            }else {
                UserApi userApi = new UserApi();
                userApi.setLenovoid(lenovoId);
//                userApi.setId(memberId);
                userApi.setGroupCode(groupCode);
                userApi.setUsername(membercode);
                RemoteResult remoteResult = salescouponFrontService.getSalescouponsWithLenovoId(userApi, shopId, terminal);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    List<SalescouponsInfoApi> list = (List<SalescouponsInfoApi>)remoteResult.getT();
                    int size =0;
                    if(list == null || list.size() ==0){
                        size = 0;
                    }else {
                        size = list.size();
                    }
                    responseData.setSuccess(true);
                    responseData.setData(size + "");
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else {
                    responseData.setCode("02");
                    responseData.setMsg("查询失败！");
                }
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
    }
}


/**
     *
     * @param request
     * @param response
     * @param shopid
     * @param mv
     */

    @RequestMapping("/getSalescouponsByClassification")
    public void  getSalescouponsByClassification(HttpServletRequest request,HttpServletResponse response,String shopid, Model mv){

        try{

            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            int PAGE_SIZE = 6;
            ResponseData responseData = new ResponseData(false);
            String Classification = request.getParameter("classification");
            String sign = request.getParameter("sign");

            PageQuery pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
            log.info("getSalescouponsByClassification :Classification :" + Classification);
            String md5 = MD5.sign(Classification, Contants.MD5_KEY, "UTF-8");
            if (StringUtil.isEmpty(Classification)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            if (!md5.equals(sign)){
                //参数错误
                responseData.setCode("02");
                responseData.setMsg("签名验证失败");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            conditionMap.put("Classification", Classification);
            RemoteResult remoteResult = salescouponFrontService.getSalescouponsByClassification(pageQuery,conditionMap);
            if (remoteResult.isSuccess()){
                PageModel2 pageModel2 = (PageModel2)remoteResult.getT();

                responseData.setCode("00");
                responseData.setSuccess(true);
                responseData.setMsg("查询成功");
                responseData.setData(JacksonMapper.obj2json(pageModel2));
            }else {
                responseData.setCode("02");
                responseData.setSuccess(false);
                responseData.setMsg("查询失败");
            }

            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        }catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }

    }


/**
     * 单个绑券接口，优惠券只能领取一次
     * @param request
     * @param response
     */

    @RequestMapping("/coupons/bindCouponsForOnce")
    public void bindCouponsForOnce(HttpServletRequest request,HttpServletResponse response){
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            RpcRemoteResult responseData = new RpcRemoteResult(false);
            String couponId = request.getParameter("couponId");//优惠券id
            String lenovoId = request.getParameter("lenovoId");
            String memberCode = request.getParameter("memberCode");
            String shopId = "8";
            String sign = request.getParameter("sign");
            log.info("bindCouponsForOnce: couponId="+couponId+", lenovoId="+lenovoId+", memberCode="+memberCode+",shopId="+shopId);

            if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(couponId) || StringUtils.isEmpty(lenovoId)|| StringUtils.isEmpty(memberCode)){
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            String md5 = MD5.sign(lenovoId + memberCode + couponId, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)){
                //参数错误
                responseData.setCode("04");
                responseData.setMsg("签名验证失败");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            long id = Long.parseLong(couponId);
            RemoteResult<Boolean> remoteResult = salescouponFrontService.bindCouponsForOnce(shopId, id, lenovoId, memberCode);
            if(remoteResult != null && remoteResult.isSuccess()) {
                responseData.setSuccess(true);
                responseData.setCode("00");
                responseData.setMsg("操作成功");
            }else{
                responseData = new RpcRemoteResult(remoteResult);
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
    }


    /**
     * 根据优惠券ID获取优惠券
     * @param request
     * @param response
     */
    @RequestMapping("/coupons/getSalescouponsBySalesCouponIds")
    public void getSalescouponsBySalesCouponIds(HttpServletRequest request,HttpServletResponse response){
        try{
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            ResponseData responseData = new ResponseData(false);

            String page_size = request.getParameter("page_size");
            String displayPosition = request.getParameter("displayPosition");
            if (StringUtils.isEmpty(page_size)){
                page_size="6";
            }
            // 0: 个人中心  1：小新中心
            if(StringUtils.isEmpty(displayPosition)){
                displayPosition = "0";
            }
//            String shopId = request.getParameter("shopId");
//            if(StringUtil.isEmpty(shopId)){
//                shopId = "8";
//            }
            String shopId = "8";
            PageQuery pageQuery = new PageQuery(getPage(request),Integer.parseInt(page_size));
            responseData.setData(JacksonMapper.obj2json(new PageModel2<>(pageQuery,new ArrayList<>())));
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            conditionMap.put("displayPosition", displayPosition);
//            conditionMap.put("salesCouponIds", salesCouponIdList);
            log.info("getSalescouponsBySalesCouponIds shopId={},conditionmap ={}",shopId,conditionMap);
            RemoteResult remoteResult = salescouponFrontService.getSalescouponsBySalesCouponIds(Tenant.getTenant(Integer.parseInt(shopId)),pageQuery, conditionMap);
            //RemoteResult remoteResult = salescouponFrontService.getSalescouponsBySalesCouponIds(pageQuery, conditionMap);
            log.info("getSalescouponsBySalesCouponIds result ={}", JsonUtil.toJson(remoteResult));
            if (remoteResult.isSuccess()){
                PageModel2 pageModel2 = (PageModel2)remoteResult.getT();
                responseData.setCode("00");
                responseData.setSuccess(true);
                responseData.setMsg("查询成功");
//                responseData.setData(JacksonMapper.obj2json(pageModel2));
                Gson g = new Gson();
                responseData.setData(g.toJson(pageModel2));
            }else {
                responseData.setCode("02");
                responseData.setSuccess(false);
                responseData.setMsg("查询失败");
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        }catch (Exception e) {
            log.error(com.lenovo.m2.couponV2.common.exception.ExceptionUtil.getStackTrace(e));
        }
    }
    //对salescouponId去重
    public static void removeSalesCouponIdList (List list) {
        HashSet h = new HashSet(list);
        list.clear();
        list.addAll(h);
    }


/**
     * 查看用户是否拥有该优惠券
     * @param request
     * @param response
     * @return
     */

    @RequestMapping(value = "/coupons/getUserIshaveTheCoupon",produces = "text/json;charset=UTF-8",method = {RequestMethod.POST, RequestMethod.GET})
    public void getUserIshaveTheCoupon(HttpServletRequest request,HttpServletResponse response) {
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            ResponseData responseData = new ResponseData(false);

            String salesCouponIds = request.getParameter("salesCouponIds");
            String shopId = request.getParameter("shopId");
            String lenovoId = request.getParameter("lenovoId");
            String memberCode = request.getParameter("memberCode");
            String sign = request.getParameter("sign");

            log.info("getSalescouponsForLenovoId: shopId=" + shopId + ", lenovoId=" + lenovoId + ", memberCode=" + memberCode +",salesCouponIds"+salesCouponIds);

            if (StringUtils.isEmpty(shopId) || StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(memberCode)) {
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }

            String md5 = MD5.sign(salesCouponIds + shopId + lenovoId + memberCode, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)) {
                //参数错误
                responseData.setCode("03");
                responseData.setMsg("签名错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            String[] rs = salesCouponIds.split(",");
            List<String> salesCouponIdList = new ArrayList<String>();
            for (int i = 0; i < rs.length; i++) {
                salesCouponIdList.add(rs[i]);
            }
            removeSalesCouponIdList(salesCouponIdList);
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            conditionMap.put("salesCouponIds", salesCouponIdList);
            conditionMap.put("shopId", shopId);
            conditionMap.put("lenovoId", lenovoId);
            conditionMap.put("memberCode", memberCode);

            RemoteResult remoteResult = salescouponFrontService.getUserIshaveTheCoupon(conditionMap);
            if (remoteResult != null && remoteResult.isSuccess()) {
                List<MembercouponrelsApi> list = (List<MembercouponrelsApi>)remoteResult.getT();
                responseData.setSuccess(true);
                responseData.setCode("00");
                responseData.setMsg("操作成功");
                responseData.setData(JacksonMapper.obj2json(list));
                log.info("getSalescouponsForLenovoId: 结果 " + responseData);
            } else {
                responseData.setSuccess(false);
                responseData.setCode("02");
                responseData.setMsg("操作失败");
                log.info("getSalescouponsForLenovoId: 结果 " + responseData);
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
    }


/**
     * 获取优惠券可领取数量
     * @param request
     * @param response
     */

    @RequestMapping(value = "/coupons/getSalesUsableNumbers",produces = "text/json;charset=UTF-8",method = {RequestMethod.POST, RequestMethod.GET})
    public void getSalesUsableNumbers(HttpServletRequest request,HttpServletResponse response){
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            ResponseData responseData = new ResponseData(false);

            String salesCouponId = request.getParameter("salesCouponId");//优惠券id
            String shopId = request.getParameter("shopId");
            String receivedSign = request.getParameter("sign");
            log.info("getSalesUsableNumbers: shopId=" + shopId + ",salesCouponIds=" + salesCouponId);

            if (StringUtils.isEmpty(shopId) || StringUtils.isEmpty(salesCouponId)) {
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }

            String expectSign = MD5.sign(salesCouponId + shopId, Contants.MD5_KEY, "UTF-8");
            if (!expectSign.equals(receivedSign)) {
                responseData.setCode("03");
                responseData.setMsg("签名错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            conditionMap.put("shopId",shopId);
            conditionMap.put("id",salesCouponId);
            RemoteResult result = salescouponFrontService.getSalesCouponsNumbersForId(conditionMap);
            if (result != null && result.isSuccess()) {
               String count = result.getT().toString();
                responseData.setSuccess(true);
                responseData.setCode("00");
                responseData.setMsg("操作成功");
                responseData.setData(count);
                log.info("getSalesUsableNumbers: 结果 " + responseData);
            }else {
                responseData.setSuccess(false);
                responseData.setCode("02");
                responseData.setMsg(result.getResultMsg());
                responseData.setData("0");
                log.info("getSalesUsableNumbers: 结果 " + responseData);
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();

        }catch (Exception e) {
            log.error("getSalesUsableNumbers:方法异常" + ExceptionUtil.getStackTrace(e));
        }
    }


/**
     * 获取用户优惠券使用状态
     * @return
     */

    @RequestMapping(value = "/coupons/getMemberCouponsStatus",produces = "text/json;charset=UTF-8",method = {RequestMethod.POST, RequestMethod.GET})
    public void getMemberCouponsStatus(HttpServletRequest request,HttpServletResponse response){
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            ResponseData responseData = new ResponseData(false);

            //参数
            String salesCouponId = request.getParameter("salesCouponId");//优惠券id
            String shopId = request.getParameter("shopId");
            String lenovoId = request.getParameter("lenovoId");
            String sign = request.getParameter("sign");
            log.info("getSalesUsableNumbers: shopId=" + shopId + ",salesCouponIds=" + salesCouponId+",lenovoId="+lenovoId);

            if (StringUtils.isEmpty(shopId) || StringUtils.isEmpty(salesCouponId) || StringUtils.isEmpty(lenovoId)) {
                //参数错误
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }

            String md5 = MD5.sign(lenovoId + salesCouponId + shopId, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)) {
                //参数错误
                responseData.setCode("03");
                responseData.setMsg("签名错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }

            Map<String, Object> conditionMap = new HashMap<String, Object>();
            conditionMap.put("shopId",shopId);
            conditionMap.put("salesCouponId", salesCouponId);
            conditionMap.put("lenovoId", lenovoId);

            RemoteResult remoteResult = salescouponFrontService.getMemberCouponsStatus(conditionMap);
            if (remoteResult != null && remoteResult.isSuccess()) {
                List<MembercouponrelsApi> list = (List<MembercouponrelsApi>)remoteResult.getT();
                if (remoteResult.getResultCode().equals("04")){
                    responseData.setSuccess(true);
                    responseData.setCode("04");
                    responseData.setMsg("操作成功：该用户下没有salesCouponId为"+salesCouponId+"的优惠券");
                    responseData.setData(JacksonMapper.obj2json(list));
                    log.info("getSalescouponsForLenovoId: 结果 " + responseData);
                }else {
                    responseData.setSuccess(true);
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                    responseData.setData(JacksonMapper.obj2json(list));
                    log.info("getSalescouponsForLenovoId: 结果 " + responseData);
                }
            } else {
                responseData.setSuccess(false);
                responseData.setCode("02");
                responseData.setMsg("操作失败");
                log.info("getSalescouponsForLenovoId: 结果 " + responseData);
            }
            printWriter.write(JacksonMapper.obj2json(responseData));
            printWriter.close();
        }catch (Exception e) {
            log.error("getMemberCouponsStatus:方法异常" + ExceptionUtil.getStackTrace(e));
        }
    }


/**
     * 根据lenovoid获取用户有效优惠券
     * @param request
     * @param response
     */

    @RequestMapping(value = "/coupons/getUserSalescouponsWithLenovoId",produces = "text/json;charset=UTF-8",method = {RequestMethod.POST, RequestMethod.GET})
    public void getUserSalescouponsWithLenovoId(HttpServletRequest request,HttpServletResponse response){
        try {

            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();

            ResponseData responseData = new ResponseData(false);
            String shopId ="8";//商城id
            String terminal = request.getParameter("terminal");//终端
            String lenovoId = request.getParameter("lenovoId");//lenovoId
            String membercode = request.getParameter("membercode");
            String sign = request.getParameter("sign");
            log.info("getUserSalescouponsWithLenovoId: shopId="+shopId+", terminal="+terminal+", lenovoId="+lenovoId+", membercode="+membercode);

            if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal)|| StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(membercode)){
                responseData.setCode("01");
                responseData.setMsg("参数错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }
            String md5 = MD5.sign(lenovoId + membercode + shopId + terminal, Contants.MD5_KEY, "UTF-8");
            if (false) {
                //参数错误
                responseData.setCode("03");
                responseData.setMsg("签名错误");
                printWriter.write(JacksonMapper.obj2json(responseData));
                printWriter.close();
                return;
            }else {
                UserApi userApi = new UserApi();
                userApi.setLenovoid(lenovoId);
                userApi.setUsername(membercode);
                RemoteResult remoteResult = salescouponFrontService.getUserSalescouponsWithLenovoId(userApi, shopId, terminal);
                if(remoteResult!=null&&remoteResult.isSuccess()){
                    log.info(remoteResult.toString());
                    List<SalescouponsInfoApi> list = (List<SalescouponsInfoApi>)remoteResult.getT();
                    responseData.setSuccess(true);
                    responseData.setData(JsonUtil.toJson(list));
                    responseData.setCode("00");
                    responseData.setMsg("操作成功");
                }else {
                    responseData.setCode("02");
                    responseData.setMsg("查询失败！");
                }
            }
            printWriter.write(JsonUtil.toJson(responseData));
            printWriter.close();
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
    }
    /**
     * 获取惠商优惠券 惠商优惠券UseScope=10
     * @param request
     * @param response
     */
    @RequestMapping(value = "/coupons/queryCouponByUseScope",produces = "text/json;charset=UTF-8",method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public void queryCouponByUseScope(HttpServletRequest request, HttpServletResponse response){
        try {
            response.setContentType(CONTENT_TYPE);
            PrintWriter printWriter = response.getWriter();
            RemoteResult remoteResult = new RemoteResult();
            String shopId = request.getParameter("shopId");
            String useScope = request.getParameter("useScope");
            String salescouponId = request.getParameter("salescouponId");
            String couponName = request.getParameter("couponName");
            String sign = request.getParameter("sign");
            logger.info(String.format("queryCouponByUseScope 参数：shopId=%s, useScope=%s", shopId, useScope));
            if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(useScope)){
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("参数错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            String md5 = MD5.sign(shopId + useScope, Contants.MD5_KEY, "UTF-8");
            if (!md5.equals(sign)) {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("03");
                remoteResult.setResultMsg("签名错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            Tenant tenant = new Tenant();
            tenant.setShopId(Integer.valueOf(shopId));
            RemoteResult<List<SalescouponsApi>> result = salescouponFrontService.queryCouponByUseScope(tenant, Integer.parseInt(useScope), Long.valueOf(salescouponId), couponName);

            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(result.getT());
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("结果为空");
                remoteResult.setT(null);
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();

        } catch (IOException e) {
            log.error("查询惠商优惠券异常：" + com.lenovo.m2.couponV2.common.exception.ExceptionUtil.getStackTrace(e));
        }
    }
}

