package com.lenovo.m2.web.webapp.controller.api.stock;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoParam;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoResult;
import com.lenovo.m2.hsbuy.inventory.StockPortApiService;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.stock.utils.JsonUtil;
import com.lenovo.m2.web.remote.stock.StockService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import net.sf.json.JSONArray;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by mayan3 on 2016/3/14.
 */
@Controller
@Scope("prototype")
@RequestMapping("/stock")
public class StockController extends BaseController {
    @Autowired
    private StockService stockService;
    @Autowired
    private StockPortApiService stockPortApiService;
    private static final Logger LOGGER = LogManager.getLogger(StockController.class);

    public static List<GetStockInfoParam> converAnswerFormString(String answer) {
        if (answer == null || answer.equals(""))
            return new ArrayList();

        JSONArray jsonArray = JSONArray.fromObject(answer);
        List<GetStockInfoParam> list = (List) JSONArray.toCollection(jsonArray,
                GetStockInfoParam.class);

        return list;
    }

    /**
     * 商品详情页/刘维涛 查询商品库存
     * @param request
     * @param proInfos
     * @return
     */
    @RequestMapping(value = "/getStockInfo", produces = "text/json;charset=UTF-8", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String getStockInfo(HttpServletRequest request, String proInfos) {
        Tenant tenant = getTenant();
        LOGGER.info("getStockInfo params=[" + proInfos + "],tenant=[" + JsonUtil.toJson(tenant) + "]");
//        proInfos="[{\"productCode\":\"50007\",\"saleType\":\"0\"}]";
        if (isNull(proInfos, tenant)) {
            return JsonUtil.toJson(new BaseInfo(400, "请求参数错误"));
        }
        Integer shopid = tenant.getShopId();
        List<GetStockInfoParam> listParam = null;
        try {
            listParam = converAnswerFormString(proInfos);
            for (GetStockInfoParam param : listParam) {
                param.setShopid(shopid);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return JsonUtil.toJson(new BaseInfo(401, "参数解析错误"));
        }
        List<GetStockInfoResult> infoResultList = null;
        try {
            infoResultList = stockService.getStockInfo(listParam, tenant);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return JsonUtil.toJson(new BaseInfo(500, "系统异常"));
        }

        return JsonUtil.toJson(infoResultList);
    }






}
