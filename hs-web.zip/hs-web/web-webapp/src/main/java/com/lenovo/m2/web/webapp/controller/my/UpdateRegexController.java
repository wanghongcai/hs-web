package com.lenovo.m2.web.webapp.controller.my;


import com.lenovo.m2.web.webapp.util.LogisticsRegExp;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * Created by yezhenyue on 2015/10/26.
 */
@Controller
@Scope("prototype")
public class UpdateRegexController {
    @RequestMapping("/updateRegex")
    public void updateRegex(HttpServletRequest request, HttpServletResponse response,Model model){
        try {
            String regex = request.getParameter("regex");
            boolean flag = Boolean.parseBoolean(request.getParameter("flag"));
            LogisticsRegExp.updateMap(regex);
            LogisticsRegExp.setFlag(flag);
            PrintWriter out = response.getWriter();
            out.print("update regex: success");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
