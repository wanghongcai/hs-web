package com.lenovo.m2.web.webapp.controller.api.stock;

import com.google.common.base.Strings;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.common.stock.utils.ErrorUtils;
import com.lenovo.m2.web.common.stock.utils.JacksonUtil;
import com.lenovo.m2.web.common.stock.utils.PhoneUtil;
import com.lenovo.m2.web.common.stock.utils.ShopEnum;
import com.lenovo.m2.web.manager.stock.SmsCodeService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 订阅接口到货通知
 * Created by xuweihua on 2016/6/14.
 */

@Controller
@Scope("prototype")
@RequestMapping("/stock")
public class SubscribeController extends BaseController {

    @Autowired
    private SmsCodeService smsCodeService;

    /**
     * 商品详情页/刘维涛
     用户订阅到货通知
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/subscribe", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String subscribe2(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult remoteResult = new RemoteResult(false);
        String jsonpcallback = request.getParameter("jsonpcallback");
        try {
            //TODO
//            SubscribeParam data = new SubscribeParam();
//            data.setActivityType(Integer.parseInt(request.getParameter("activityType")));
//            data.setLinkAddress(request.getParameter("linkAddress"));
//            data.setLenovoID(request.getParameter("lenovoID"));
//            data.setLenovoAccount(request.getParameter("lenovoAccount"));
//            data.setClientType(request.getParameter("clientType"));
//            data.setPhone(request.getParameter("phone"));
//            data.setProductCode(request.getParameter("productCode"));
//            data.setSmsCode(request.getParameter("smsCode"));
//            data.setLeID(request.getParameter("leID"));
//            data.setIp("");//ip
//            data.setShopId(String.valueOf(getTenant().getShopId()));
//            data.setMallName(ShopEnum.getShopStr(getTenant().getShopId()));
//            remoteResult = subscribeService.subscribe(data);
            RemoteResultUtil.updateMsg(remoteResult, PromptEnum.SUBSCRIBESERVICE_SUBSCRIBE);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return jsonpcallback + "(" + JacksonUtil.toJson(remoteResult) + ")";
        //@RequestBody
    }

    /**
     * 商品详情页/刘维涛
     用户订阅到货通知获取验证码
     * @param mobile
     * @param leId
     * @param request
     * @return
     */
    @RequestMapping(value = "/sendsms", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String sendMobileCode(String mobile, String leId, HttpServletRequest request) {
        RemoteResult remoteResult = new RemoteResult(false);
        String jsonpcallback = request.getParameter("jsonpcallback");
        String userAgent = request.getHeader("User-Agent");
        String shopId = String.valueOf(getTenant().getShopId());
        try {
            //校验手机号格式
            if (Strings.isNullOrEmpty(mobile) || !PhoneUtil.verifyPhoneNumberFormat(mobile)) {
                remoteResult.setResultCode(ErrorUtils.ERR_CODE_SMS_PHONEERROR);
                remoteResult.setResultMsg("手机号格式错误");
                return jsonpcallback + "(" + JacksonUtil.toJson(remoteResult) + ")";
            }

            remoteResult = smsCodeService.sendSmsCode(mobile, userAgent, getIp(), leId, shopId);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return jsonpcallback + "(" + JacksonUtil.toJson(remoteResult) + ")";
    }
}
