package com.lenovo.m2.web.webapp.controller.my;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.purchase.NorderService;
import com.lenovo.m2.web.common.my.order.OrderMainConstant;
import com.lenovo.m2.web.common.my.utils.FileUtil;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.my.utils.MD5Util;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.domain.my.BaseInfo;
import com.lenovo.m2.web.domain.my.order.HuiMallOrderCount;
import com.lenovo.m2.web.domain.my.order.OrderCount;
import com.lenovo.m2.web.domain.my.order.OrderInfoVo;
import com.lenovo.m2.web.domain.my.order.UserProduct;
import com.lenovo.m2.web.manager.my.order.OrderManager;
import com.lenovo.m2.web.remote.my.order.OrderDBService;
import com.lenovo.m2.web.remote.my.order.OrderService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 对外http接口
 * Created by mayan3 on 2015/10/15.
 */
@Controller
@Scope("prototype")
public class RpcController extends BaseController {

    private static final Logger logger = LogManager.getLogger(RpcController.class);

    @Autowired
    private OrderManager orderManager;
    @Autowired
    private OrderService orderService;
    @Autowired
    private NorderService norderService;
    @RequestMapping("center/memberProducts")
    @ResponseBody
    public String memberProducts(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String lenovoId = "";
        Integer page = 1;
        Integer pageSize = 10;
        String merchantId = "";
        try {
            lenovoId = request.getParameter("lenovoId");
            page = Integer.parseInt(request.getParameter("page"));
            pageSize = Integer.parseInt(request.getParameter("pageSize"));
            merchantId = getTenant().getShopId().toString();
        } catch (Exception e) {
            return JacksonUtil.toJson(new BaseInfo(200, "参数错误"));
        }
        if (isNull(lenovoId, page, pageSize, merchantId))
            return JacksonUtil.toJson(new BaseInfo(200, "参数错误"));
        if (page <= 0 || pageSize <= 0)
            return JacksonUtil.toJson(new BaseInfo(200, "参数错误"));
        if (pageSize > 100)
            pageSize = 100;
        PageQuery pageQuery = new PageQuery(page, pageSize);
        RemoteResult<PageModel2<UserProduct>> re = orderManager.queryPayedUserProducts(merchantId, lenovoId, pageQuery, null);
        if (re != null && re.getT() != null && re.isSuccess()) {
            Map<String, Object> resultMap = new HashMap<String, Object>();
            resultMap.put("rc", 0);
            resultMap.put("products", re.getT());
            return JacksonUtil.toJson(resultMap);
        }
        return JacksonUtil.toJson(new BaseInfo(200, "错误"));
    }
    @RequestMapping(value = "center/getRoamingOrder",method = RequestMethod.POST)
    @ResponseBody
    public String queryUserRoamingOrderByMemberId(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String CERP_MD5_SALT = CustomizedPropertyConfigurer.getContextProperty("CERP_MD5_SALT");
        String lenovoId = request.getParameter("lenovoId");
        Integer page = StringUtils.parseInteger(request.getParameter("pageNow"));
        Integer pageSize = StringUtils.parseInteger(request.getParameter("pageSize"));
        String merchantId = getTenant().getShopId().toString();
        String sign = request.getParameter("sign");
        if (isNull(lenovoId, page, pageSize, merchantId,sign))
            return JacksonUtil.toJson(new BaseInfo(2001, "参数错误"));
        if (page <= 0 || pageSize <= 0)
            return JacksonUtil.toJson(new BaseInfo(2001, "参数错误"));
        if (pageSize > 100)
            pageSize = 100;
        try {
            String md5 = MD5Util.sign(lenovoId,CERP_MD5_SALT,"UTF-8");
            if (!sign.equals(md5)){
                return JacksonUtil.toJson(new BaseInfo(2001,"无权访问"));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return JacksonUtil.toJson(new BaseInfo(9001, e.getMessage()));
        }

        PageQuery pageQuery = new PageQuery(page, pageSize);
        RemoteResult<PageModel2<OrderInfoVo>> re = orderManager.queryOrderForCustomerService(merchantId, lenovoId, pageQuery, null, null, null,null);
        if (re != null && re.getT() != null && re.isSuccess()) {
            Map<String, Object> resultMap = new HashMap<String, Object>();
            resultMap.put("rc", 0);
            resultMap.put("orderList", re.getT().getDatas());
            return JacksonUtil.toJson(resultMap);
        }
        return JacksonUtil.toJson(new BaseInfo(9001, "错误"));
    }

    @RequestMapping(value = "center/queryUserOrderByMemberId",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String queryUserOrderByMemberId(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        logger.info("进入放发");
        try {
            String CERP_MD5_SALT = CustomizedPropertyConfigurer.getContextProperty("CERP_MD5_SALT");
            String lenovoId = request.getParameter("lenovoId");
            Integer page = StringUtils.parseInteger(request.getParameter("pageNow"));
            Integer pageSize = StringUtils.parseInteger(request.getParameter("pageSize"));
            String merchantId = getTenant().getShopId().toString();
            String tag = request.getParameter("tag");
            String sign = request.getParameter("sign");
            if (isNull(lenovoId, page, pageSize, merchantId,tag,sign))
                return JacksonUtil.toJson(new BaseInfo(2001, "参数错误"));
            if (page <= 0 || pageSize <= 0)
                return JacksonUtil.toJson(new BaseInfo(2001, "参数错误"));
            if (pageSize > 100)
                pageSize = 100;
            try {
                String md5 = MD5Util.sign(lenovoId+tag,CERP_MD5_SALT,"UTF-8");
                if (!sign.equals(md5)){
                    return JacksonUtil.toJson(new BaseInfo(2001,"无权访问"));
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                return JacksonUtil.toJson(new BaseInfo(9001, e.getMessage()));
            }

            PageQuery pageQuery = new PageQuery(page, pageSize);
            RemoteResult<PageModel2<OrderInfoVo>> re = orderManager.queryOrderForCustomerService(merchantId, lenovoId, pageQuery, null, null, null,null);
            if (re != null && re.getT() != null && re.isSuccess()) {
                Map<String, Object> resultMap = new HashMap<String, Object>();
                resultMap.put("rc", 0);
                resultMap.put("orderList", re.getT().getDatas());
                logger.info("JacksonUtil.toJson(resultMap)={}",JacksonUtil.toJson(resultMap));
                return JacksonUtil.toJson(resultMap);
            }
        }catch (Exception e){
            logger.error("e={}",e);
        }
        return JacksonUtil.toJson(new BaseInfo(9001, "错误"));
    }

    @RequestMapping(value = "center/rpc/getOrderCountByMemberId",method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String getOrderCountByMemberId(HttpServletRequest request, String lenovoId, Map<String, Object> map) {
        String merchantId = getTenant().getShopId().toString();
        if (lenovoId == null){
            map.put("code","500");
            map.put("message","fail");
            return JsonUtil.toJson(map);
        }
        HuiMallOrderCount orderCount = orderService.getOrderCount(lenovoId,merchantId);
        if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(merchantId) || OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(merchantId) ){
            map.put("result",orderCount);
        }else{
            OrderCount orderCount1 = new OrderCount();
            orderCount1.setReturnCount(orderCount.getReturnCount());
            orderCount1.setUnConfirmCount(orderCount.getUnConfirmCount());
            orderCount1.setUnShipCount(orderCount.getUnShipCount());
            orderCount1.setUnPayCount(orderCount.getUnPayCount());
            map.put("result",orderCount1);
        }
        map.put("code","200");
        map.put("message","success");
        return JsonUtil.toJson(map);
    }

    /**
     * 提供CPS查询订单数据接口
     * @param request
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    @RequestMapping(value = "/cps/getOrderInfoByParam",produces = "application/json;charset=UTF-8",method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public String getOrderInfoByParam(HttpServletRequest request,HttpServletResponse response,String cid,String orderStartTime,String orderEndTime){
        String resultInfo;
        if(null == cid || "".equals(cid)){
            resultInfo = "cid不能为空";
            return resultInfo;
        }
        if(null == orderStartTime || "".equals(orderStartTime)){
            resultInfo = "orderStartTime不能为空";
            return resultInfo;
        }
        if(null == orderEndTime || "".equals(orderEndTime)){
            resultInfo = "orderEndTime不能为空";
            return resultInfo;
        }
        resultInfo = norderService.getOrderByOrderParams(cid,orderStartTime,orderEndTime);
        return resultInfo;
    }

    /**
     * 提供业务导出CPS订单数据接口
     * @param request
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    @RequestMapping(value = "/cps/importOrderInfoByParam",produces = "application/json;charset=UTF-8",method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public String importOrderInfoByParam(HttpServletRequest request,HttpServletResponse response,String cid,String orderStartTime,String orderEndTime){
        String resultInfo;
        logger.info("RpcController importOrderInfoByParam：{},{},{}",cid,orderStartTime,orderEndTime);
        resultInfo = norderService.getImportOrderByOrderParams(cid,null,orderStartTime,orderEndTime);
        return resultInfo;
    }

    /**
     * 提供业务导出CPS订单数据接口
     * @param request
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    @RequestMapping(value = "/cps/importOrderInfoByParams",method = {RequestMethod.POST,RequestMethod.GET})
    public void importOrderInfoByParams(HttpServletRequest request,String orderNo,String cid,String orderStartTime,String orderEndTime){
        String resultInfo;
        logger.info("RpcController importOrderInfoByParam param：{},{},{},{}",cid,orderNo,orderStartTime,orderEndTime);
        resultInfo = norderService.getImportOrderByOrderParams(cid,orderNo,orderStartTime,orderEndTime);

        List<Map<String, Object>> list = (List<Map<String, Object>>)(JSONArray.parse(resultInfo));
        List<Row> rowList =new ArrayList<Row>() ;
        XSSFWorkbook wb = new XSSFWorkbook();
        XSSFSheet sheet = wb.createSheet();
        wb.setSheetName(0, "百应CPS订单");

        sheet.setColumnWidth(22, 256);

        sheet.createFreezePane(0, 2, 0, 2);//冻结首行
        XSSFRow row1 = sheet.createRow(0);
        XSSFCell cell0 = row1.createCell(0);
        cell0.setCellValue("订单编号");
        XSSFCell cell1 = row1.createCell(1);
        cell1.setCellValue("活动ID");
        XSSFCell cell2 = row1.createCell(2);
        cell2.setCellValue("反馈标签");
        XSSFCell cell3 = row1.createCell(3);
        cell3.setCellValue("下单时间");
        XSSFCell cell4 = row1.createCell(4);
        cell4.setCellValue("商品数量");
        XSSFCell cell5 = row1.createCell(5);
        cell5.setCellValue("商品金额");
        XSSFCell cell6 = row1.createCell(6);
        cell6.setCellValue("商品名称");
        XSSFCell cell7 = row1.createCell(7);
        cell7.setCellValue("更新时间");
        XSSFCell cell8 = row1.createCell(8);
        cell8.setCellValue("商品编号");
        XSSFCell cell9 = row1.createCell(9);
        cell9.setCellValue("商品类别");
        XSSFCell cell10 = row1.createCell(10);
        cell10.setCellValue("佣金类型");
        XSSFCell cell11 = row1.createCell(11);
        cell11.setCellValue("运费");
        XSSFCell cell12 = row1.createCell(12);
        cell12.setCellValue("优惠额");
        XSSFCell cell13 = row1.createCell(13);
        cell13.setCellValue("优惠码");
        XSSFCell cell14 = row1.createCell(14);
        cell14.setCellValue("订单状态");
        XSSFCell cell15 = row1.createCell(15);
        cell15.setCellValue("支付状态");
        XSSFCell cell16 = row1.createCell(16);
        cell16.setCellValue("支付方式");
        XSSFCell cell17 = row1.createCell(17);
        cell17.setCellValue("字符集");

        rowList.add(row1);
        if(!list.isEmpty()){
            int i=1;
            for (Map<String, Object> map : list) {
                //int lastRowNum = sheet.getLastRowNum();
                XSSFRow createRow = sheet.createRow(i);
                createRow.createCell(0).setCellValue((String)map.get("orderNo"));
                createRow.createCell(1).setCellValue((String)map.get("campaignId"));
                createRow.createCell(2).setCellValue((String)map.get("feedback"));
                createRow.createCell(3).setCellValue((String)map.get("orderTime"));
                createRow.createCell(4).setCellValue((String)map.get("amount"));
                createRow.createCell(5).setCellValue(((BigDecimal)map.get("price")).toString());
                createRow.createCell(6).setCellValue((String)map.get("name"));
                createRow.createCell(7).setCellValue((String)map.get("updateTime"));
                createRow.createCell(8).setCellValue((String)map.get("productNo"));
                createRow.createCell(9).setCellValue((String)map.get("category"));
                createRow.createCell(10).setCellValue((String)map.get("commissionType"));
                createRow.createCell(11).setCellValue((String)map.get("fare"));
                createRow.createCell(12).setCellValue(((BigDecimal)map.get("favorable")).toString());
                createRow.createCell(13).setCellValue((String)map.get("favorableCode"));
                createRow.createCell(14).setCellValue((String)map.get("orderStatus"));
                createRow.createCell(15).setCellValue((String)map.get("paymentStatus"));
                createRow.createCell(16).setCellValue((String)map.get("paymentType"));
                createRow.createCell(17).setCellValue((String)map.get("encoding"));
                rowList.add(createRow);
                i++;
            }
        }

        //开启输出流
        File temFile = null;
        String fileName = "百应CPS订单"+String.valueOf(new Date().getTime());
        try {
            temFile = File.createTempFile(fileName, ".xlsx");
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        String path = temFile.getAbsolutePath();//生成临时文件绝对路径
        OutputStream out = null;
        try {
            out = new FileOutputStream(path);
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }

        //关闭输出流
        try {
            wb.write(out);
            out.flush();
            out.close();
        } catch (IOException e1) {
            e1.printStackTrace();
        }finally{
            if(out != null){
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        //Http请求和响应的相关信息
        HttpHeaders headers = new HttpHeaders();
        byte[] bytes = null;
        try {
            //获取临时文件内容
            bytes = FileUtil.getContent(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 删除临时文件
        temFile.delete();
        //设置文件类型
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        //获取客户端浏览器的版本号
        String userAgent = request.getHeader("User-Agent");
        try {
            fileName = fileName + ".xlsx";
            if (userAgent.contains("MSIE")||userAgent.contains("Trident")) {
                //客户端浏览器为IE浏览器
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            }else{
                //非IE浏览器的处理：
                fileName = new String(fileName.getBytes("UTF-8"),"ISO-8859-1");
            }
            headers.setContentDispositionFormData("attachment",fileName);
        }catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        new ResponseEntity<byte[]>(bytes,headers, HttpStatus.OK);
        //return new ResponseEntity<byte[]>(bytes,headers, HttpStatus.OK);
    }

    /**
     * 分页查询CPS订单
     * @param request
     * @param orderNo
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    @RequestMapping(value = "/cps/getCpsOrderInfoByParam",produces = "application/json;charset=UTF-8",method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public String getCpsOrderInfoByParam(HttpServletRequest request,String orderNo,String cid,String orderStartTime,String orderEndTime){
        int pageNum = Integer.parseInt(request.getParameter("pageNum")==null?"1":request.getParameter("pageNum"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize")==null?"10":request.getParameter("pageSize"));
        logger.info("RpcController getCpsOrderInfoByParam 分页param：pageNum="+pageNum+",pageSize="+pageSize);
        PageQuery pageQuery = new PageQuery(pageNum,pageSize);
        RemoteResult<Map<String,Object>> remoteResult = norderService.getCpsOrderByOrderParams(cid,orderNo,orderStartTime,orderEndTime,pageQuery);
        Long totalCount = 0L;
        int totalPageNum = 0;
        if(remoteResult.getT().get("pageQuery")!=null){
            totalCount = ((PageQuery)remoteResult.getT().get("pageQuery")).getTotalCount();
            totalPageNum = ((PageQuery)remoteResult.getT().get("pageQuery")).getTotalPageNum();
        }
        logger.info("RpcController getCpsOrderInfoByParam 分页param：totalCount="+totalCount+",totalPageNum="+totalPageNum);
        Map<String,Object> map = new HashMap<>();
        map.put("resultData",remoteResult.getT().get("messageList")==null?new ArrayList<Map<String,Object>>():remoteResult.getT().get("messageList"));
        map.put("isSuccess",remoteResult.isSuccess());
        map.put("resultCode",remoteResult.getResultCode());
        map.put("resultMsg",remoteResult.getResultMsg());
        map.put("totalCount",totalCount);
        map.put("totalPageNum",totalPageNum);
        return JsonUtil.toJson(map);
    }
}
