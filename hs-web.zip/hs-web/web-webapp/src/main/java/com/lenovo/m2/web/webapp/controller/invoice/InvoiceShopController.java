package com.lenovo.m2.web.webapp.controller.invoice;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.hsbuy.common.smb17.ShopCode;
import com.lenovo.m2.hsbuy.common.util.ErrorUtils;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;
import com.lenovo.m2.hsbuy.smb17.InvoiceShopApiService;
import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.reward.utils.EncapsulationParam;
import com.lenovo.m2.web.remote.purchase.address.AddressRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangqy10 on 2017/4/26.
 * 17shopinvoice
 */
@Controller
@Scope("prototype")
@RequestMapping("/invoiceShop")
public class InvoiceShopController extends BaseController {
    private Logger logger = LogManager.getLogger(InvoiceShopController.class.getName());
    public static final int PAGE_SIZE=20;

    @Autowired
    private InvoiceShopApiService invoiceShopApiService17;
    @Autowired
    private AddressRemoteService addressService;

    @RequestMapping("/invoiceShopIndex")
    public String invoiceShopIndex(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        try {
            logger.info("<=====invoiceShopIndex start===========>");
            response.sendRedirect("/invoiceShop/invoiceShopIndexSSO.jhtm");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 17我的发票列表
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/invoiceShopIndexSSO")
    public String invoiceShopIndexSSO(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        logger.info("<====invoices list start:{}======>");
        if(!StringUtils.isEmpty(userId)){
            RemoteResult<List<InvoiceShop>> remoteResult=invoiceShopApiService17.queryInvoice(userId);
            //获取20条
            List<InvoiceShop> invoiceShopList=remoteResult.getT();
            List<InvoiceShop> invoices=invoiceShopList.size()>20?invoiceShopList.subList(0,20):invoiceShopList;
            if(CollectionUtils.isNotEmpty(invoices)){
                map.put("shopId",invoices.get(0).getShopId().intValue());
            }

            map.put("invoiceList",sorting(invoices));
        }else {
            map.put("invoiceList", new ArrayList<InvoiceShop>());
        }
        map.put("title","我的发票");
        logger.info("<====invoices list end:{}======>",JsonUtil.toJson(map));
        return "/invoiceShop/invoice";
    }


    @RequestMapping("/invoiceShopIndexPagSSO")
    public String invoiceShopIndexPag(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)){
            RemoteResult<List<InvoiceShop>> remoteResult=invoiceShopApiService17.queryInvoice(userId);
            //获取20条
            List<InvoiceShop> invoiceShopList=remoteResult.getT();
            List<InvoiceShop>invoices=invoiceShopList.size()>20?invoiceShopList.subList(0,20):invoiceShopList;

            if(CollectionUtils.isNotEmpty(invoices)){
                map.put("shopId",invoices.get(0).getShopId().intValue());
            }

            map.put("invoiceList",sorting(invoices));
        }else {
            map.put("invoiceList", new ArrayList<InvoiceShop>());
        }
        map.put("title","我的发票");

        return "/invoiceShop/invoicePag";
    }
    @RequestMapping("/delInvoiceSSO")
    public String delInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,String id){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop=new InvoiceShop();
            invoiceShop.setId(Integer.parseInt(id));
            invoiceShop.setShopId(ShopCode.smpsShop);
            invoiceShop.setSynType(3);
            invoiceShop.setLenovoID(userId);
            try {
                RemoteResult remoteResult=invoiceShopApiService17.modifyePersonalCenter(invoiceShop);
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("delInvoice错误", e);
            }
        }
        map.put("title","我的发票");
        return invoiceShopIndex(request,response,map);
    }


    @RequestMapping("/addInvoiceSSO")
    @ResponseBody
    public String addInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop =new InvoiceShop();
            try {
                EncapsulationParam.getObjectFromRequest(invoiceShop, request);
                invoiceShop.setSynType(1);
                invoiceShop.setLenovoID(userId);
                if(invoiceShop.getPayMan()==null){
                    invoiceShop.setPayMan(invoiceShop.getCustomerName());
                }
                invoiceShop.setCreateBy(userId);
                invoiceShop.setCreateTime(new Date());
                invoiceShop.setShopId(ShopCode.smpsShop);
                RemoteResult remoteResult=invoiceShopApiService17.modifyePersonalCenter(invoiceShop);
                if(remoteResult.isSuccess()){
                    return "1";
                }else {
                    logger.info("addInvoice---RemoteResult>>"+ JacksonUtil.toJson(remoteResult));
                    if(remoteResult.getResultCode().equals(ErrorUtils.ERR_CODE_CUSTOMERNAME_TAXNO_EXIST)){
                        return "19";
                    }
                    return "2";
                }
            }catch (Exception e){
                logger.error("addInvoice错误",e);
                return "9";
            }
        }
        return "8";
    }


    @RequestMapping("/updateInvoiceSSO")
    @ResponseBody
    public String updateInvoice(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String userId=getLenovoId(request);
        if(!StringUtils.isEmpty(userId)) {
            InvoiceShop invoiceShop =new InvoiceShop();
            try {
                EncapsulationParam.getObjectFromRequest(invoiceShop, request);
                invoiceShop.setSynType(2);
                invoiceShop.setLenovoID(userId);
                invoiceShop.setPayMan(invoiceShop.getCustomerName());
                invoiceShop.setShopId(ShopCode.smpsShop);
                invoiceShop.setUpdateBy(userId);
                invoiceShop.setUpdateTime(new Date());
                if(invoiceShop.getInvoiceType()!=null&&invoiceShop.getInvoiceType()==1){
                    invoiceShop.setApprovalStatus(3);
                }
                RemoteResult remoteResult=invoiceShopApiService17.modifyePersonalCenter(invoiceShop);
                if(remoteResult.isSuccess()){
                    return "1";
                }else {
                    logger.info("updateInvoice---RemoteResult>>"+ JacksonUtil.toJson(remoteResult));
                    return "2";
                }
            }catch (Exception e){
                logger.error("updateInvoice错误",e);
                return "9";
            }
        }
        return "8";
    }



    @RequestMapping("/getProvince")
    @ResponseBody
    public String getProvince(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        RemoteResult<List<PartAddress>>  re = addressService.getProvinceList(getTenant());
        return this.ajaxWriteStr(JsonUtil.toJson(re),response);
    }

    @RequestMapping("/getCityList")
    @ResponseBody
    public String getCityList(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,ProvinceParam provinceParam){
        RemoteResult<List<PartAddress>>  re = addressService.getCityList(getTenant(),provinceParam);
        return this.ajaxWriteStr(JsonUtil.toJson(re),response);
    }

    @RequestMapping("/getRegionList")
    @ResponseBody
    public String getRegionList(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,ProvinceParam provinceParam){
        RemoteResult<List<PartAddress>>  re = addressService.getRegionList(getTenant(),provinceParam);
        return this.ajaxWriteStr(JsonUtil.toJson(re),response);
    }

    @RequestMapping("/getZip")
    @ResponseBody
    public String getZip(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map,ProvinceParam provinceParam){
        RemoteResult<String>  re = addressService.getZip(getTenant(),provinceParam);
        String provinces="";
        if(null != re && re.isSuccess()){
            provinces=re.getT();
        }
        return provinces;
    }

    private  List<InvoiceShop> sorting(List<InvoiceShop> invoiceShops){
        List<InvoiceShop> invoiceShopList=new ArrayList<InvoiceShop>();
        for (int i=0;i<invoiceShops.size();i++){
            if(invoiceShops.get(i).getInvoiceType()>0){
                invoiceShopList.add(invoiceShops.get(i));
            }
        }
        for (int i=0;i<invoiceShops.size();i++){
            if(invoiceShops.get(i).getInvoiceType()==0){
                invoiceShopList.add(invoiceShops.get(i));
            }
        }
        return invoiceShopList;
    }


    protected String getLenovoId(HttpServletRequest request){
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        logger.info("The lenovoId from SSO is: " + lenovoId);
        return lenovoId;
//        return "119163";
//        return "11111111111";
    }

}
