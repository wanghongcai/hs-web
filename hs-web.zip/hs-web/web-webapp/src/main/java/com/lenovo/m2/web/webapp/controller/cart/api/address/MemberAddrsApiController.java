package com.lenovo.m2.web.webapp.controller.cart.api.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.pruchase.enums.AddressTypeEnums;
import com.lenovo.m2.hsbuy.domain.address.AddressLog;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeAddressParam;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.remote.purchase.address.ConsigneeRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.List;


/**
 * <br> 实现用户收货信息维护
 * @author shenjc
 *
 */

@Controller
@RequestMapping(value = "/api/consignee")
public class MemberAddrsApiController extends BaseController {

	public static Logger logger =  LogManager.getLogger(MemberAddrsApiController.class);
	
	@Autowired
	private ConsigneeRemoteService consigneeRemoteService;

    public void setConsigneeRemoteService(ConsigneeRemoteService consigneeRemoteService) {
        this.consigneeRemoteService = consigneeRemoteService;
    }

    /**
	 * <br> 添加收货信息
	 * @return
	 */
	@RequestMapping(value="/adddeliver",produces = "application/json; charset=utf-8")
	@ResponseBody 
	public String addDeliver(HttpServletResponse response,String userId,String v,
                             String source,String ip,String format,Integer shopId) {
		logger.info("addDeliver:start， shopId={}", shopId);
            String delivername = request().getParameter("deliverName");
            String deliverprovice = request().getParameter("deliverProvince");
            String delivercity = request().getParameter("deliverCity");
            String delivercounty = request().getParameter("deliverCounty");
            String deliverproviceNo = request().getParameter("deliverProvinceNo");
            String delivercityNo = request().getParameter("deliverCityNo");
            String delivercountyNo = request().getParameter("deliverCountyNo");

            String deliverStreet = request().getParameter("deliverStreet");
            String delivertele = request().getParameter("deliverTele");
            String delivermobile = request().getParameter("deliverMobile");
            String deliveremail = request().getParameter("deliverEmail");
            String isdefault = request().getParameter("isDefault");
            if (StringUtil.isEmpty(isdefault)) {
                isdefault = "0";
            }
            String type = request().getParameter("type");
            String areaNos = request().getParameter("areaNos");

            String company = request().getParameter("company");// 收货公司
            String towerShip = request().getParameter("deliverTowerShip");// 乡镇
            String zip = request().getParameter("zip");

            if ((AddressTypeEnums.SP.getCode()).equals(type) && StringUtil.isEmpty(zip)) {
                return this.ajaxWriteStr(toJson(BaseInfo.errInfo(400)), response);
            }
            ConsigneeAddressParam consigneeEntity = new ConsigneeAddressParam();
            consigneeEntity.setLenovoId(userId);
            consigneeEntity.setIsdefault(Integer.parseInt(isdefault));
            consigneeEntity.setAddress(deliverStreet);
            consigneeEntity.setCityCode(delivercity);
            consigneeEntity.setCityNo(delivercityNo);
            consigneeEntity.setCountyCode(delivercounty);
            consigneeEntity.setCountyNo(delivercountyNo);
            consigneeEntity.setEmail(deliveremail);
            consigneeEntity.setMobile(delivermobile);
            consigneeEntity.setName(delivername);
            consigneeEntity.setProvinceCode(deliverprovice);
            consigneeEntity.setProvinceNo(deliverproviceNo);
            consigneeEntity.setTel(delivertele);
            consigneeEntity.setType(type);
            consigneeEntity.setAreaNos(areaNos);
            consigneeEntity.setBackFlag(true);
            consigneeEntity.setZip(zip);
            consigneeEntity.setTownshipCode(towerShip);
            consigneeEntity.setCompany(company);
            RemoteResult<String> result = consigneeRemoteService.saveConsignee(getTenantCN(), consigneeEntity);
            FpsResult<String> fpsResult = new FpsResult<String>(result, PromptEnum.CHECKOUT);
            fpsResult.setMsg(result.getResultMsg());
            logger.info("adddeliver result:{} fpsresult:{}", JsonUtil.toJson(result), JsonUtil.toJson(fpsResult));
            return JsonUtil.toJson(fpsResult);
	}

	/**
	 * <br> 修改收货信息
	 * @return
	 */
	@RequestMapping(value="/modifydeliver",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String modifyDeliver(HttpServletResponse response,String userId,String v,String source,String ip,String format,int shopId) {
		logger.info("modifyDeliver:start");
            String delivername = request().getParameter("deliverName");
            String deliverprovice = request().getParameter("deliverProvince");
            String delivercity = request().getParameter("deliverCity");
            String delivercounty = request().getParameter("deliverCounty");
            String deliverproviceNo = request().getParameter("deliverProvinceNo");
            String delivercityNo = request().getParameter("deliverCityNo");
            String delivercountyNo = request().getParameter("deliverCountyNo");
            String deliverStreet = request().getParameter("deliverStreet");
            String delivertele = request().getParameter("deliverTele");
            String deliverid = request().getParameter("deliverId");
            String delivermobile = request().getParameter("deliverMobile");
            String deliveremail = request().getParameter("deliverEmail");
            String isdefault = request().getParameter("isDefault");
            Integer isDefault = isdefault == null ? null : Integer.parseInt(isdefault);
            String type = request().getParameter("type");
            String areaNos = request().getParameter("areaNos");

            String company = request().getParameter("company");// 收货公司
            String towerShip = request().getParameter("deliverTowerShip");// 乡镇
            String zip = request().getParameter("zip");

            if ((AddressTypeEnums.SP.getCode()).equals(type) && StringUtil.isEmpty(zip)) {
                return toJson(new BaseInfo(ErrorMessageEnum.ERROR_ILLEGAL));
            }
            ConsigneeAddressParam consigneeEntity = new ConsigneeAddressParam();
            consigneeEntity.setLenovoId(userId);
            consigneeEntity.setIsdefault(isDefault);
            consigneeEntity.setAddress(deliverStreet);
            consigneeEntity.setCityCode(delivercity);
            consigneeEntity.setCityNo(delivercityNo);
            consigneeEntity.setCountyCode(delivercounty);
            consigneeEntity.setCountyNo(delivercountyNo);
            consigneeEntity.setEmail(deliveremail);
            consigneeEntity.setMobile(delivermobile);
            consigneeEntity.setName(delivername);
            consigneeEntity.setProvinceCode(deliverprovice);
            consigneeEntity.setProvinceNo(deliverproviceNo);
            consigneeEntity.setTel(delivertele);
            consigneeEntity.setId(deliverid);
            consigneeEntity.setType(type);
            consigneeEntity.setAreaNos(areaNos);

            consigneeEntity.setZip(zip);
            consigneeEntity.setTownshipCode(towerShip);
            consigneeEntity.setCompany(company);
            RemoteResult<Integer> result = consigneeRemoteService.updateConsignee(getTenantCN(), consigneeEntity);
            FpsResult<Integer> fpsResult = new FpsResult<Integer>();
            fpsResult.setMsg(result.getResultMsg());
            fpsResult.setData(result.getT());
            fpsResult.setRc(Integer.parseInt(result.getResultCode()));
            fpsResult.setSuccess(result.isSuccess());
        return JsonUtil.toJson(fpsResult);
	}

	/**
	 * <br> 删除收货信息
	 * @return
	 */
	@RequestMapping(value = "/deletedeliver",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String deleteDeliver(HttpServletResponse response,String userId,String v,String source,String ip,String format,int shopId) {
		logger.info("deleteDeliver:start");

        String deliverid = request().getParameter("deliverId");
        String type = request().getParameter("type");
        if (StringUtil.isEmpty(deliverid)) {
            return toJson(new BaseInfo(ErrorMessageEnum.ERROR_ILLEGAL));
        }
        RemoteResult<Integer> result = consigneeRemoteService.deleteConsignee(getTenantCN(),new ConsigneeParam(deliverid,userId,type));// todo 确定
        FpsResult<Integer> fpsResult = new FpsResult<Integer>(result, PromptEnum.CHECKOUT);
        return JsonUtil.toJson(fpsResult);
	}

	/**
	 * <br> 查找单个收货信息
	 * @return
	 */
	@RequestMapping(value = "/getdeliver",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String getDeliver(String userId,String type,int shopId,String deliverId) {
        logger.info("getdeliver param: deliverId:{},type:{},userId:{}", deliverId,  type, userId);
        User user = new User();
        user.setUserId(userId);
        RemoteResult<Memberaddrs> result = consigneeRemoteService.getConsigneeById(getTenantCN(),new ConsigneeParam(deliverId,userId,type));
        FpsResult<Memberaddrs> fpsResult = new FpsResult<Memberaddrs>(result, PromptEnum.CHECKOUT);
        return JsonUtil.toJson(fpsResult);

	}


    /**
     * @Author zhanghs 【zhanghs6@lenovo.com】
     * @Description: 根据地址GUID获取地址ID（SMB商城使用）
     *
     * @date 2016/7/28 19:19
     * @return
     */
    @RequestMapping("/getIdByGuid")
    @ResponseBody
    public String getIdByGuid(String guid,int shopId) {
        logger.info("getIdByGuid param: guid:{},shopId:{}", guid, shopId);
        RemoteResult<String> result = consigneeRemoteService.getIdByGuid(getTenantCN(),guid);
        FpsResult<String> fpsResult = new FpsResult<String>(result, PromptEnum.CHECKOUT);
        return JsonUtil.toJson(fpsResult);

    }


    @RequestMapping(value = "/queryforsync",produces = "application/json; charset=utf-8")
	@ResponseBody
	public String queryforsync(String userId,String v,String source,String ip,String format,Integer count) {
        logger.info("queryforsync param: count:{}", count);
		RemoteResult<List<AddressLog>> result = consigneeRemoteService.getNotSyncAddress(getTenantCN(),count);
        FpsResult<List<AddressLog>> fpsresult = new FpsResult<List<AddressLog>>(result, PromptEnum.CHECKOUT);
        return JsonUtil.toJson(fpsresult);
	}


}
