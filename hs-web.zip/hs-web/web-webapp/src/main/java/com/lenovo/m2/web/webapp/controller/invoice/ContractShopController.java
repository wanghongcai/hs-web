package com.lenovo.m2.web.webapp.controller.invoice;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.hsbuy.domain.order.Pact;
import com.lenovo.m2.hsbuy.domain.smb17.Contract;
import com.lenovo.m2.hsbuy.smb17.ContractApiService;
import com.lenovo.m2.web.common.invoice.CmdUtil;
import com.lenovo.m2.web.common.invoice.ToMoney;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhangqy10 on 2017/4/27
 * 17shopinvoice
 */
@Controller
@Scope("prototype")
@RequestMapping("/contract")
public class ContractShopController extends BaseController {
    private Logger logger = LogManager.getLogger(ContractShopController.class);

    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    public static final int PAGE_SIZE = 10;
    @Autowired
    private ContractApiService contractApiService17;

    protected String getLenovoId(HttpServletRequest request) {
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        logger.info("The lenovoId from SSO is: " + lenovoId);
//        return lenovoId;
        return "156311";
//        return "149187";
//        return "11111111111";
    }

    @RequestMapping("/queryContract")
    public String queryContract(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        try {
            response.sendRedirect("/contract/queryContractSSO.jhtm");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 我的合同列表页
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/queryContractSSO")
    public String queryContractSSO(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        try {
            String userId = getLenovoId(request);
            map.put("title","我的合同");
            if (!StringUtils.isEmpty(userId)) {
                String index = request.getParameter("index");
                index = StringUtils.isEmpty(index) ? "1" : index;

                Map<String, String> parameterMap = new HashMap<String, String>();
                parameterMap.put("lenovoId", userId);
                String contractNo = request.getParameter("contractNo");
                if (!StringUtils.isEmpty(contractNo)) {
                    parameterMap.put("contractNo", contractNo);
                    map.put("contractNo", contractNo);
                }
                PageQuery pageQuery = new PageQuery(Integer.parseInt(index), PAGE_SIZE);
                PageModel2<Contract> contractPage = contractApiService17.getContractPage(pageQuery, parameterMap);

                if (contractPage.getTotalCount() > 0) {
                    map.put("num", (contractPage.getTotalCount() / PAGE_SIZE + ((contractPage.getTotalCount() % PAGE_SIZE == 0) ? 0 : 1)));
                    map.put("totalCount", contractPage.getTotalCount());
                    map.put("index", index);
                    map.put("type", "");
                    map.put("contractList", contractPage.getDatas());
                    return "/contract/contractList";
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        map.put("num", "0");
        map.put("totalCount", "0");
        map.put("index", 1);
        map.put("type", "");

        return "/contract/contractList";
    }


    /**
     * 页面获取百应合同详情
     * @param id
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/getContractDetailsSSO")
    public String getContractDetailsSSO(String id, HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String userId = getLenovoId(request);
        if (!StringUtils.isEmpty(userId)) {
            RemoteResult<Contract> remoteResult = contractApiService17.getContractInfo(userId, id);
            if (remoteResult.isSuccess() && remoteResult.getT() != null) {
                Pact pact= contractApiService17.getOrderMessageByOrderMainCode(remoteResult.getT().getOrderCode(), userId, "8");
                Contract contract = remoteResult.getT();
                if (pact != null && contract != null) {
//                    pact.setInvoiceShipMobile(contract.getShipMobile());
//                    pact.setInvoiceShipName(contract.getShipName());
//                    pact.setBuyerName(contract.getBuyerName());
//                    pact.setInvoiceShipAddress(contract.getShipAddress());
                    pact.setBuyerName(pact.getInvoiceTitle());
                    if(contract.getMigrationType()==1){
                        for(int i=0;i<pact.getGoodsList().size();i++){
                            pact.getGoodsList().get(i).setImageUrl("http://pic.17.lenovo.com.cn/g1"+pact.getGoodsList().get(i).getImageUrl());
                        }
                    }
                }
                map.put("pact", pact);
                map.put("gatheringNum", pact.getGatheringNum());
                map.put("takeEffectTimeStr", format.format(pact.getTakeEffectTime()));
            }
        }
        map.put("title","我的合同");
        return "/contract/contractDetails";
    }

    @RequestMapping("/getContractDetails")
    public String getContractDetails(String id, String userId, HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        RemoteResult<Contract> remoteResult = contractApiService17.getContractInfo(userId, id);
        if (remoteResult.isSuccess() && remoteResult.getT() != null) {
            Pact pact= contractApiService17.getOrderMessageByOrderMainCode(remoteResult.getT().getOrderCode(), userId, "8");
            Contract contract = remoteResult.getT();
            if (pact != null && contract != null) {
//                pact.setInvoiceShipMobile(contract.getShipMobile());
//                pact.setInvoiceShipName(contract.getShipName());
//                pact.setBuyerName(contract.getBuyerName());
//                pact.setInvoiceShipAddress(contract.getShipAddress());
                pact.setBuyerName(pact.getInvoiceTitle());
                if(contract.getMigrationType()==1){
                    for(int i=0;i<pact.getGoodsList().size();i++){
                        pact.getGoodsList().get(i).setImageUrl("http://pic.17.lenovo.com.cn/g1"+pact.getGoodsList().get(i).getImageUrl());
                    }
                }
            }

            map.put("pact", pact);
            map.put("gatheringNum", pact.getGatheringNum());
            map.put("takeEffectTimeStr", format.format(pact.getTakeEffectTime()));
        }
        map.put("title","我的合同");
        return "/contract/contractDetailsCmd";
    }


    /**
     * Http获取百应合同详情
     * @param orderCode
     * @param lenovoId
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/getContractDetailsCmd")
    public String getContractDetailsCmd(String orderCode, String lenovoId, HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        logger.info("getContractDetailsCmd  lenovoId, orderCode>>" + lenovoId + "," + orderCode);
        Pact pact= contractApiService17.getOrderMessageByOrderMainCode(orderCode, lenovoId, "8");
        RemoteResult<Contract> remoteResult = contractApiService17.getContractInfo(lenovoId, pact.getCode());
        Contract contract = remoteResult.getT();
        if (pact != null && contract != null) {
//            pact.setInvoiceShipMobile(contract.getShipMobile());
//            pact.setInvoiceShipName(contract.getShipName());
//            pact.setBuyerName(contract.getBuyerName());
//            pact.setInvoiceShipAddress(contract.getShipAddress());
            pact.setBuyerName(pact.getInvoiceTitle());
            if(contract.getMigrationType()==1){
                for(int i=0;i<pact.getGoodsList().size();i++){
                    pact.getGoodsList().get(i).setImageUrl("http://pic.17.lenovo.com.cn/g1"+pact.getGoodsList().get(i).getImageUrl());
                }
            }
        }
        map.put("pact", pact);
        map.put("gatheringNum", pact.getGatheringNum());
        map.put("takeEffectTimeStr", format.format(pact.getTakeEffectTime()));
        map.put("title","我的合同");
        return "/contract/contractDetailsCmd";
    }

    @RequestMapping("/downloadContractSSO")
    public String downloadContract(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        try {
            String userId = getLenovoId(request);
            if (!StringUtils.isEmpty(userId)) {
                String DEST = "/data/pdf/download/Contrac" + userId + ".pdf";
                String HTML = "/data/pdf/download/Contrac" + userId + ".html";
                String urls = request.getParameter("url");
                urls = urls.replace("getContractDetailsSSO", "getContractDetails");
                urls = urls + "&userId=" + userId;
                URL url = new URL(urls);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                InputStream inputStream = conn.getInputStream(); //通过输入流获得网站数据
                byte[] getData = readInputStream(inputStream); //获得网站的二进制数据
                String dataHtml = new String(getData, "UTF-8");

                File fileHTML = new File(HTML);
                FileWriter fileWritter = new FileWriter(fileHTML);
                BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
                bufferWritter.write(dataHtml);
                bufferWritter.close();

                String cmdret = CmdUtil.callCmd("wkhtmltopdf --margin-bottom 0 --margin-top 0 " + HTML + " " + DEST);

                logger.info("downloadContract----" + "wkhtmltopdf " + HTML + " " + DEST + ">>" + cmdret);

                InputStream inputStream2 = new FileInputStream(DEST);
                response.reset();
                response.setContentType("application/octet-stream;charset=UTF-8");
                response.setHeader("Content-Disposition", "attachment; filename=contract.pdf");
                OutputStream outputStream = new BufferedOutputStream(
                        response.getOutputStream());
                byte data[] = new byte[1024];
                while (inputStream2.read(data, 0, 1024) >= 0) {
                    outputStream.write(data);
                }
                outputStream.flush();
                outputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("downloadContract>>" + e.getMessage());
        }
        return null;
    }


    /**
     * 百应合同生成
     * @param orderCode
     * @param lenovoId
     * @param cId
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping("/downloadContractFoId")
    @ResponseBody
    public String downloadContractFoId(String orderCode, String lenovoId, String cId, HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        try {
            StringBuffer url2 = request.getRequestURL();
            String tempContextUrl = url2.delete(url2.length() - request.getRequestURI().length(), url2.length()).append("/").toString();
            logger.info("downloadContractFoId>>" + tempContextUrl + "contract/getContractDetailsCmd.jhtm?orderCode=" + orderCode + "&lenovoId=" + lenovoId);
            URL url = new URL(tempContextUrl + "contract/getContractDetailsCmd.jhtm?orderCode=" + orderCode + "&lenovoId=" + lenovoId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = conn.getInputStream(); //通过输入流获得网站数据
            byte[] getData = readInputStream(inputStream); //获得网站的二进制数据
            String dataHtml = new String(getData, "UTF-8");
            String DEST = "/data/pdf/interface/Contrac" + orderCode + ".pdf";
            String HTML = "/data/pdf/interface/Contrac" + orderCode + ".html";
            File fileHTML = new File(HTML);
            FileWriter fileWritter = new FileWriter(fileHTML);
            BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
            bufferWritter.write(dataHtml);
            bufferWritter.close();

            String cmdret = CmdUtil.callCmd("wkhtmltopdf --margin-bottom 0 --margin-top 0 " + HTML + " " + DEST);

            logger.info("downloadContractFoId----" + "wkhtmltopdf " + HTML + " " + DEST + ">>" + cmdret);
            InputStream inputStream2 = new FileInputStream(DEST);
            contractApiService17.uploadFile(IOUtils.toByteArray(inputStream2), lenovoId, cId);

        } catch (Exception e) {
            e.printStackTrace();
            logger.info("downloadContractFoId>>" + e.getMessage());
            return "No";
        }
        return "ok";
    }


//    @RequestMapping("/cmd")
//    @ResponseBody
//    public String cmd(String cmd, HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
//        String cmdret = "No";
//        try {
//            cmdret = CmdUtil.callCmd(cmd);
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.info("cmd>>" + e.getMessage());
//            return "No";
//        }
//        return cmdret;
//    }

    public static byte[] readInputStream(InputStream inputStream) throws IOException {
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while ((len = inputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }

        bos.close();
        return bos.toByteArray();
    }

}
