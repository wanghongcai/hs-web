package com.lenovo.m2.web.webapp.controller.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.manager.purchase.cashier.CashierManager;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.ThreadLocalSessionUser;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 收银台支付回调
 * Created by wanghao,@Date 2017/3/7 16:51
 */
@Controller
@RequestMapping("/pay")
public class CashierCallBackController extends BaseController {
    private static Logger LOGGER = LogManager.getLogger(CashierCallBackController.class.getName());

    @Autowired
    private OpenOrderService openOrderService;
    @Autowired
    private CashierManager cashierManager;

    /**
     * 接收支付同步回调
     * @param request
     * @param response
     */
    @RequestMapping("/cashierReturnUrl")
    public String cashierReturnUrl(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String outTradeNo = request.getParameter("out_trade_no");
        String tradeNo = request.getParameter("trade_no");//联想交易号
        String transactionNo = request.getParameter("transaction_no");//第三方交易号
        String shopId = request.getParameter("shop_id");
        String payTpe = request.getParameter("payment");//支付类型
        String totalFee = request.getParameter("total_fee");//支付类型
        String terminal = request.getParameter("terminal");
        String trade_status = request.getParameter("trade_status");//交易状态

        paraMap.put("shopId",shopId);
        paraMap.put("termianl",terminal);

        LOGGER.info("同步回调 outTradeNo[" + outTradeNo + "],tradeNo[" + tradeNo + "]");
        MongoOrderDetail mongoOrderDetail;
        try {
            Tenant tenant = Tenant.getTenant(Integer.parseInt(shopId));

            if (StringUtils.isNotEmpty(outTradeNo)) {
                RemoteResult<MongoOrderDetail> mongoOrderResult = openOrderService.getMongoOrderDetail(tenant,outTradeNo);
                if(mongoOrderResult == null || !mongoOrderResult.isSuccess()){
                    LOGGER.info("Cashierpay Original mongoOrderResult Is Null, mongoOrderResult【"+ mongoOrderResult +"】，outTradeNo[" + outTradeNo + "]");
                    paraMap.put("error_msg", "支付同步通知异常，订单查询失败");
                    return getSyncbackRedirect(shopId,terminal,"fail");
                }
                mongoOrderDetail = mongoOrderResult.getT();
                LOGGER.info("Cashierpay Original mongoOrderDetail [" + mongoOrderDetail + "]");
            } else {
                LOGGER.info("Cashierpay Original outTradeNo Is Null");
                paraMap.put("error_msg", "支付同步通知异常，订单号为空");
                //return "outpay/outpay_pc_fail";
                return getSyncbackRedirect(shopId,terminal,"fail");
            }
            if (mongoOrderDetail == null) {
                LOGGER.info("Cashierpay Original mongoOrderDetail Is Null, outTradeNo[" + outTradeNo + "]");
                paraMap.put("error_msg", "支付同步通知异常，订单为空");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }
            /*if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("Cashierpay Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("Cashierpay Original MerchantPayPlat Is Null");
                paraMap.put("error_msg", "支付同步通知异常，支付平台为空");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }*/
        } catch (Exception e) {
            LOGGER.info("支付同步回调获取订单信息异常", e);
            paraMap.put("error_msg", "支付同步回调获取订单信息异常");
            return getSyncbackRedirect(shopId,terminal,"fail");
        }
        boolean verifyFlag;
        try {
            verifyFlag = verifyNotify(request,shopId);


            //查看请求参数是否和订单参数一致
            if (verifyFlag){

                verifyFlag = mongoOrderDetail.getFaid().equals(request.getParameter("fa_id"));
            }else {
                LOGGER.error("Cashierpay Notify Check Signature error，outTradeNo[" + outTradeNo + "],TradeNo[" + tradeNo + "]");
                paraMap.put("error_msg", "系统异常");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }
            if (!verifyFlag){
                LOGGER.error("回调的faid和订单的faid不一致，回调faid["+request.getParameter("fa_id")+"],订单的faid【"+mongoOrderDetail.getFaid()+"】");
                paraMap.put("error_msg", "非法请求");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }

        } catch (Exception e) {
            LOGGER.error("Cashierpay Notify Check Signature EXCEPTION，outTradeNo[" + outTradeNo + "],TradeNo[" + tradeNo + "]", e);
            paraMap.put("error_msg", "Cashierpay Notify Check Signature EXCEPTION");
            return getSyncbackRedirect(shopId,terminal,"fail");
        }
        if (verifyFlag && "TRADE_SUCCESS".equals(trade_status)) {
            LOGGER.info("Cashierpay TRADE_SUCCESS ,outTradeNo[" + outTradeNo + "]");

            paraMap.put("totalFee", totalFee);
            return getSyncbackRedirect(shopId,terminal,"success");

        } else {
            LOGGER.info("Cashierpay Check Signature FAIL，outTradeNo[" + outTradeNo + "]");
        }
        return getSyncbackRedirect(shopId,terminal,"fail");
    }

    /**
     * 接收支付异步回调
     * @param request
     * @param response
     */
//    @RequestMapping("/cashierNotifyUrl")
//    public void cashierNotifyUrl(HttpServletRequest request, HttpServletResponse response) {
//        String outTradeNo = request.getParameter("out_trade_no");
//        String tradeNo = request.getParameter("trade_no");//联想交易号
//        String transactionNo = request.getParameter("transaction_no");//第三方交易号
//        String shopId = request.getParameter("shop_id");
//        String payTpe = request.getParameter("payment");//支付类型
//        String trade_status = request.getParameter("trade_status");//交易状态
//
//        LOGGER.info("异步回调 outTradeNo[" + outTradeNo + "],tradeNo[" + tradeNo + "]");
//        Map<String, Object> paraMap = new HashMap();
//        MongoOrderDetail mongoOrderDetail;
//        Tenant tenant = Tenant.getTenant(Integer.parseInt(shopId));
//        try {
//
//            if (StringUtils.isNotEmpty(outTradeNo)) {
//
//                RemoteResult<MongoOrderDetail> mongoOrderResult = openOrderService.getMongoOrderDetail(tenant,outTradeNo);
//                if(mongoOrderResult == null || !mongoOrderResult.isSuccess()){
//                    LOGGER.info("Cashierpay Original mongoOrderResult Is Null, mongoOrderResult【"+ mongoOrderResult +"】，outTradeNo[" + outTradeNo + "]");
//                    return ;
//                }
//                mongoOrderDetail = mongoOrderResult.getT();
//                LOGGER.info("Cashierpay Original mongoOrderDetail [" + mongoOrderDetail + "]");
//            } else {
//                LOGGER.info("Cashierpay Original outTradeNo Is Null");
//                return;
//            }
//            if (mongoOrderDetail == null) {
//                LOGGER.info("Cashierpay Original mongoOrderDetail Is Null, outTradeNo[" + outTradeNo + "]");
//                return;
//            }
//        } catch (Exception e) {
//            LOGGER.info("支付异步回调获取订单平台信息异常", e);
//            return;
//        }
//        boolean verifyFlag ;
//        RemoteResult<String> updateResult = new RemoteResult<String>();
//        try {
//            verifyFlag = verifyNotify(request,shopId);
//            //查看请求参数是否和订单参数一致
//            if (verifyFlag){
//
//                verifyFlag = mongoOrderDetail.getFaid().equals(request.getParameter("fa_id"));
//            }else {
//                LOGGER.error("Cashierpay Notify Check Signature error，outTradeNo[" + outTradeNo + "],TradeNo[" + tradeNo + "]");
//                return ;
//            }
//            if (verifyFlag){
//
//                verifyFlag = mongoOrderDetail.getAmountMoney().getAmount().compareTo(new BigDecimal(request.getParameter("total_fee"))) == 0;
//            }else {
//                LOGGER.error("回调的faid和订单的faid不一致，回调faid["+request.getParameter("fa_id")+"],订单的faid【"+mongoOrderDetail.getFaid()+"】");
//                return;
//            }
//            if (!verifyFlag){
//                LOGGER.error("回调的金额和订单的金额不一致，回调金额["+request.getParameter("total_fee")+"],订单的【"+mongoOrderDetail.getAmountMoney()+"】");
//                return ;
//            }
//        } catch (Exception e) {
//            LOGGER.error("Cashierpay Notify Check Signature EXCEPTION，outTradeNo[" + outTradeNo + "],TradeNo[" + tradeNo + "]", e);
//            return;
//        }
//        if (verifyFlag && ("TRADE_SUCCESS".equals(trade_status) || "TRADE_FINISH".equals(trade_status))) {
//            LOGGER.info("Cashierpay TRADE_SUCCESS ,outTradeNo[" + outTradeNo + "]");
//            try {
//                updateResult = cashierManager.callUpdate(tenant,outTradeNo,request,mongoOrderDetail);
//                if(updateResult.isSuccess()){
//                    LOGGER.info("异步回调，修改订单状态为已支付，调用修改接口修改成功,outTradeNo[" + outTradeNo + "]");
//                    response.getWriter().write("success");
//                }else{
//                    LOGGER.info("异步回调，修改订单状态为已支付，调用修改接口修改失败,outTradeNo[" + outTradeNo + "],updateResult[" + updateResult.getResultMsg() + "]");
//                }
//            } catch (Exception ex) {
//                LOGGER.error("Cashierpay Call MiddleWare FAIL, outTradeNo[" + outTradeNo + "]", ex);
//                return;
//            }
//        } else {
//            LOGGER.info("Cashierpay Check Signature FAIL，outTradeNo[" + outTradeNo + "]");
//            return;
//        }
//
//    }

    /**
     * 接收支付同步异常回调
     * @param request
     * @param response
     */
    @RequestMapping("/cashierExceptionUrl")
    public String cashierExceptionUrl(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String outTradeNo = "";
        String tradeInfo = request.getParameter("trade_info");
        //String service = request.getParameter("service");
        String shopId = request.getParameter("shop_id");
        String payTpe = request.getParameter("payment");//支付类型
        String errorCode = request.getParameter("error_code");//支付类型
        String terminal = request.getParameter("terminal");

        paraMap.put("shopId",shopId);
        paraMap.put("termianl",terminal);

        if (StringUtil.isNotEmpty(tradeInfo)){
            try {
                tradeInfo = URLDecoder.decode(tradeInfo, "UTF-8");
            } catch (Exception e) {
                LOGGER.info("URLDecode TradeInfo Fail", e);
                paraMap.put("resultReason", "服务器异常，请重新发起");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }
            LOGGER.info("URLDECODER tradeInfo[" + tradeInfo + "]");

            try {
                // 切割tradeInfo中的请求参数
                String[] paramArray = tradeInfo.split("&\\+&");
                if (paramArray.length == 0) {
                    LOGGER.info("Analysis paramArray FAIL, paramArray Length[" + paramArray.length + "]");

                }
                Map<String, String> requestParam = new HashMap<String, String>();
                for (String param : paramArray) {
                    if (StringUtils.isNotEmpty(param)) {
                        String[] kvs = param.split("=");
                        if (kvs != null && kvs.length == 2) {
                            if ("null".equals(kvs[1])) {
                                LOGGER.info("Illegal Value, Key is[" + kvs[0] + "],Value is [" + kvs[1] + "]");
                            } else {
                                LOGGER.info("Key is[" + kvs[0] + "],Value is [" + kvs[1] + "]");
                                requestParam.put(kvs[0], kvs[1]);
                            }
                        } else {
                            LOGGER.info("KVS is NULL Or Kvs Length Illegal");
                        }
                    } else {
                        LOGGER.info("Analysis Param IS NULL");
                    }
                }
                outTradeNo = requestParam.get("out_trade_no");

            } catch (Exception e) {
                LOGGER.info("处理单条tradeInfo信息异常,处理单条tradeInfo信息异常[" + tradeInfo + "]", e);
            }

        }

        LOGGER.info("同步异常回调 outTradeNo[" + outTradeNo + "],errorCode["+errorCode+"]");
        MongoOrderDetail mongoOrderDetail;
        try {
            Tenant tenant = Tenant.getTenant(Integer.parseInt(shopId));

            if (StringUtils.isNotEmpty(outTradeNo)) {
                RemoteResult<MongoOrderDetail> mongoOrderResult = openOrderService.getMongoOrderDetail(tenant,outTradeNo);
                if(mongoOrderResult == null || !mongoOrderResult.isSuccess()){
                    LOGGER.info("Cashierpay Original mongoOrderResult Is Null, mongoOrderResult【"+ mongoOrderResult +"】，outTradeNo[" + outTradeNo + "]");
                    paraMap.put("error_msg", "支付同步异常通知异常，订单查询失败");
                    return getSyncbackRedirect(shopId,terminal,"fail");
                }
                mongoOrderDetail = mongoOrderResult.getT();
                LOGGER.info("Cashierpay Original mongoOrderDetail [" + mongoOrderDetail + "]");
            } else {
                LOGGER.info("Cashierpay Original outTradeNo Is Null");
                paraMap.put("error_msg", "支付同步异常通知异常，订单号为空");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }
            if (mongoOrderDetail == null) {
                LOGGER.info("Cashierpay Original mongoOrderDetail Is Null, outTradeNo[" + outTradeNo + "]");
                paraMap.put("error_msg", "支付同步异常通知异常，订单为空");
                return getSyncbackRedirect(shopId,terminal,"fail");
            }

        } catch (Exception e) {
            LOGGER.info("支付同步回调获取订单平台信息异常", e);
            paraMap.put("error_msg", "支付同步异常回调获取订单支付平台信息异常");
            return getSyncbackRedirect(shopId,terminal,"fail");
        }
        boolean verifyFlag;
        try {
            verifyFlag = verifyNotify(request,shopId);
        } catch (Exception e) {
            LOGGER.error("Cashierpay Notify Check Signature EXCEPTION，outTradeNo[" + outTradeNo + "]", e);
            paraMap.put("error_msg", "支付同步异常回调，签名验证失败");
            return getSyncbackRedirect(shopId,terminal,"fail");
        }
        if (verifyFlag) {
            LOGGER.info("Cashierpay TRADE_SUCCESS ,outTradeNo[" + outTradeNo + "]");
            try {
                paraMap.put("error_msg", getErrorMsg(errorCode));
                return getSyncbackRedirect(shopId,terminal,"fail");

            } catch (Exception ex) {
                LOGGER.error("Cashierpay Call MiddleWare FAIL, outTradeNo[" + outTradeNo + "]", ex);
                paraMap.put("error_msg", "支付异常");
            }
        } else {
            LOGGER.info("Cashierpay Check Signature FAIL，outTradeNo[" + outTradeNo + "]");
            paraMap.put("error_msg", "支付异常");
        }
        return getSyncbackRedirect(shopId,terminal,"fail");
    }

    /**
     * 全额信用支付
     * @param request
     * @param response
     */
    @RequestMapping("/allCreditToPay")
    public String cashierToPay(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {

        String orderMainCode = request.getParameter("orderMainCode");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        Tenant tenant = getTenant();
        String lenovoId = getLenovoId();
        SessionUser user = ThreadLocalSessionUser.getUser();
        MongoOrderDetail mongoOrderDetail = null;
        LOGGER.info("Https Pay Router Ready To Go! orderMainCode[" + orderMainCode + "],shopId[" + shopId + "],terminal[" + terminal + "]");
        if (user == null || StringUtil.isEmpty(user.getUsername()) || StringUtil.isEmpty(lenovoId)) {
            //单点登录开启，且没有登录，需要先去登录
            LOGGER.info("Invoke Pay Router,but user is not loaded!");
            paraMap.put("resultReason", "用户未登录！");
            return getSyncbackRedirect(shopId, terminal,"fail");
        } else {

            //判断当前的用户是否是当前经销商的主账号
            if (!SSOUtil.isMainAccount(user.getUsername())){
                LOGGER.info("Invoke Pay Router,but user is not main user=="+user.getUsername());
                paraMap.put("resultReason", "当前登陆用户不是主账号！");
                return getSyncbackRedirect(shopId, terminal,"fail");
            }
            if (StringUtils.isNotEmpty(orderMainCode)) {

                RemoteResult<MongoOrderDetail> mongoOrderResult = openOrderService.getMongoOrderDetail(tenant,orderMainCode);
                if(mongoOrderResult == null || !mongoOrderResult.isSuccess()){
                    LOGGER.info("Cashierpay Original mongoOrderResult Is Null, mongoOrderResult【"+ mongoOrderResult +"】，orderMainCode[" + orderMainCode + "]");
                    paraMap.put("resultReason", "订单为空！");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }
                mongoOrderDetail = mongoOrderResult.getT();
                LOGGER.info("Cashierpay Original mongoOrderDetail [" + mongoOrderDetail + "]");
                if (mongoOrderDetail == null ||PeakConstant.ORDER_CREDIT_USE_ALL != mongoOrderDetail.getCreditLineWay() || BigDecimal.valueOf(0.0).compareTo(mongoOrderDetail.getAmountMoney().getAmount()) != 0){
                    //当前为全额信用支付，所以当前的订单金额应该为0
                    paraMap.put("resultReason", "订单支付异常！");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }

                if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
                    LOGGER.error("订单已支付，订单号[" + orderMainCode + "]");
                    paraMap.put("resultReason","订单已支付，请到订单列表页确认。");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }
                if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(mongoOrderDetail.getOrderStatus()))) {
                    LOGGER.error("主订单已失效，订单号[" + orderMainCode + "]");
                    paraMap.put("resultReason","订单已失效，请到订单列表页确认");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }

                //是否已签订合同
                if (!PeakConstant.ORDER_AUDIT_SIGNED_CONTRACT.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
                    LOGGER.info("支付异常,当前订单未签订合同,orderMainCode--" + orderMainCode);
                    paraMap.put("resultReason", "订单支付异常！");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }
            } else {
                LOGGER.info("Cashierpay Original outTradeNo Is Null");
                paraMap.put("resultReason", "订单号为空！");
                return getSyncbackRedirect(shopId, terminal,"fail");
            }

            try {
                //设置付款金额为0
                request.getParameterMap().put("total_fee", new String[]{"0.00"});
                request.getParameterMap().put("gmt_payment", new String[]{DateFormatUtils.format(new Date(),"yyyyMMddHHmmss")});
                request.getParameterMap().put("transaction_no", new String[]{"0000"});
                request.getParameterMap().put("trade_no", new String[]{"0000"});
                request.getParameterMap().put("payment", new String[]{"42"});

                RemoteResult<String> updateResult = cashierManager.callUpdate(tenant,orderMainCode,request,mongoOrderDetail);
                if(updateResult.isSuccess()){
                    LOGGER.info("全额信用支付，修改订单状态为已支付，调用修改接口修改成功,orderMainCode[" + orderMainCode + "]");
                    paraMap.put("resultReason", "支付成功，请尽快归还信用额度！");
                    return getSyncbackRedirect(shopId, terminal,"success");
                }else{
                    LOGGER.info("全额信用支付，修改订单状态为已支付，调用修改接口修改失败,orderMainCode[" + orderMainCode + "],updateResult[" + updateResult.getResultMsg() + "]");
                }
            } catch (Exception ex) {
                LOGGER.error("Cashierpay Call MiddleWare FAIL, orderMainCode[" + orderMainCode + "]", ex);
                paraMap.put("resultReason", "支付异常！");
                return getSyncbackRedirect(shopId, terminal,"fail");
            }

            paraMap.put("resultReason", "支付失败！");
            return getSyncbackRedirect(shopId, terminal,"fail");
        }





//        return getSyncbackRedirect(shopId,terminal,"fail");
    }

    @RequestMapping("/waitOfflinePay")
    public String waitOfflinePay(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {

        String orderMainCode = request.getParameter("orderMainCode");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        Tenant tenant = getTenant();
        String lenovoId = getLenovoId();
        SessionUser user = ThreadLocalSessionUser.getUser();
        MongoOrderDetail mongoOrderDetail = null;
        LOGGER.info("Https Pay Router Ready To Go! orderMainCode[" + orderMainCode + "],shopId[" + shopId + "],terminal[" + terminal + "]");
        if (user == null || StringUtil.isEmpty(user.getUsername()) || StringUtil.isEmpty(lenovoId)) {
            //单点登录开启，且没有登录，需要先去登录
            LOGGER.info("Invoke Pay Router,but user is not loaded!");
            paraMap.put("resultReason", "用户未登录！");
            return getSyncbackRedirect(shopId, terminal,"fail");
        } else {


            if (StringUtils.isNotEmpty(orderMainCode)) {

                RemoteResult<MongoOrderDetail> mongoOrderResult = openOrderService.getMongoOrderDetail(tenant,orderMainCode);
                if(mongoOrderResult == null || !mongoOrderResult.isSuccess() || mongoOrderResult.getT() == null){
                    LOGGER.info("Cashierpay Original mongoOrderResult Is Null, mongoOrderResult【"+ mongoOrderResult +"】，orderMainCode[" + orderMainCode + "]");
                    paraMap.put("resultReason", "订单为空！");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }
                mongoOrderDetail = mongoOrderResult.getT();
                LOGGER.info("Cashierpay Original mongoOrderDetail [" + mongoOrderDetail + "]");
                if (PeakConstant.ORDER_CREDIT_USE_PART == mongoOrderDetail.getCreditLineWay() ){
                    //当前为部分信用支付，需要判断主账号
                    //判断当前的用户是否是当前经销商的主账号
                    if (!SSOUtil.isMainAccount(user.getUsername())){
//                    if (false){
                        LOGGER.info("Invoke Pay Router,but user is not main user=="+user.getUsername());
                        paraMap.put("resultReason", "当前登陆用户不是主账号！");
                        return getSyncbackRedirect(shopId, terminal,"fail");
                    }
                    //是否已签订合同
                    if (!PeakConstant.ORDER_AUDIT_SIGNED_CONTRACT.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
                        LOGGER.info("支付异常,当前订单未签订合同,orderMainCode--" + orderMainCode);
                        paraMap.put("resultReason", "订单支付异常！");
                        return getSyncbackRedirect(shopId, terminal,"fail");
                    }

                }

                if (!PeakConstant.ORDER_PAYMENTTYPE_OFFLINE_ZH.equals(String.valueOf(mongoOrderDetail.getPaymentType()))) {
                    LOGGER.info("订单支付类型异常,,orderMainCode--" + orderMainCode +"--paymenttype="+mongoOrderDetail.getPaymentType());
                    paraMap.put("resultReason", "订单支付类型异常！");
                    return getSyncbackRedirect(shopId, terminal,"fail");





                }
                //// 2017/7/8 线下打款，待判断是否新加字段，是否已经可以上传支付资料，即是否已经在收银台点击过支付了
                if(PeakConstant.ORDER_CREDIT_USE_ALL != mongoOrderDetail.getCreditLineWay()
                        && PeakConstant.ORDER_OFFLINE_UPLOADSTATUS_NULL != mongoOrderDetail.getUploadStatus()) {
                    //若不是全额信用支付,且资料上传状态不是null，则跳转到错误异常页
                    LOGGER.info("Illegal Status,orderno[" + orderMainCode + "],CreditLineWay[" + mongoOrderDetail.getCreditLineWay() + "]，" +
                            "uploadStatus="+mongoOrderDetail.getUploadStatus()+"");
                    paraMap.put("resultReason", "订单线下支付资料上传异常，请到订单列表查看详情！");
                    return getSyncbackRedirect(shopId, terminal,"fail");

                }

                if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
                    LOGGER.error("订单已支付，订单号[" + orderMainCode + "]");
                    paraMap.put("resultReason","订单已支付，请到订单列表页确认。");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }
                if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(mongoOrderDetail.getOrderStatus()))) {
                    LOGGER.error("主订单已失效，订单号[" + orderMainCode + "]");
                    paraMap.put("resultReason","订单已失效，请到订单列表页确认");
                    return getSyncbackRedirect(shopId, terminal,"fail");
                }


            } else {
                LOGGER.info("Cashierpay Original outTradeNo Is Null");
                paraMap.put("resultReason", "订单号为空！");
                return getSyncbackRedirect(shopId, terminal,"fail");
            }

            try {

                RemoteResult updateResult = new RemoteResult<>();
                String status = PeakConstant.ORDER_OFFLINE_UPLOADSTATUS_START;
//                RemoteResult<String> updateResult = cashierManager.callUpdate(tenant,orderMainCode,request,mongoOrderDetail);
                updateResult = openOrderService.updatePayRecordsUploadStatus(orderMainCode,status);
                if(updateResult.isSuccess()){
                    LOGGER.info("线下银行支付，调用修改接口修改成功,orderMainCode[" + orderMainCode + "]");
                    paraMap.put("resultReason", "确认成功，请尽快到订单列表上传线下转账资料！");
                    return getSyncbackRedirect(shopId, terminal,"success");
                }else{
                    LOGGER.info("线下银行支付，调用修改接口修改失败,orderMainCode[" + orderMainCode + "],updateResult[" + updateResult.getResultMsg() + "]");
                }
            } catch (Exception ex) {
                LOGGER.error("Cashierpay Call MiddleWare FAIL, orderMainCode[" + orderMainCode + "]", ex);
                paraMap.put("resultReason", "支付异常！");
                return getSyncbackRedirect(shopId, terminal,"fail");
            }

            paraMap.put("resultReason", "确认失败！");
            return getSyncbackRedirect(shopId, terminal,"fail");
        }

    }


    /**
     * 验证回调参数数据
     * @param request
     * @return
     */
    private boolean verifyNotify(HttpServletRequest request, String shopId){
        boolean verify = false;
        Map<String,String> reqParamMap =  PaySignUtils.parseRequestParams(request.getParameterMap());
        String sign_type = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String notify_type = request.getParameter("notify_type");//异步通知类型
        reqParamMap.put("sign_type",null);
        reqParamMap.put("sign",null);
        reqParamMap.put("_input_charset",null);
        reqParamMap.put("shopId",null);//InitTenantInterceptor中加入了shopId
        if (StringUtil.isNotEmpty(notify_type) && "trade_status_async".equals(notify_type)){
            reqParamMap.put("terminal",null);//异步通知参数terminal不加入验签
        }
//        reqParamMap.put("input_charset",null);
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("cashier_pay.properties");
        String signKey = (String)commonParam.get(shopId);;
        LOGGER.info("支付回调参数(代验签)："+reqParamMap);
        String checkSign = PaySignUtils.buildSignKey(reqParamMap,sign_type,signKey);
        if (checkSign != null && !"".equals(checkSign)){
            verify = checkSign.equals(sign);
        }
        if(!verify){
            LOGGER.info("签名验证失败。生成的签名["+checkSign+"],sign["+sign+"]");
        }

        return verify;
    }

/*

    private boolean verifyNotify(HttpServletRequest request, String notifyTye, String shopId, MongoOrderDetail mongoOrderDetail){
        boolean verify = false;
        Map<String,String> requestMap =  PaySignUtils.parseRequestParams(request.getParameterMap());

        String payment = request.getParameter("payment");
        String shop_id = request.getParameter("shop_id");
        String sign_type = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String notify_type = request.getParameter("notify_type");
        String out_trade_no = request.getParameter("out_trade_no");
        String fa_id = request.getParameter("fa_id");
        String total_fee = request.getParameter("total_fee");
        String trade_no = request.getParameter("trade_no");
        String transaction_no = request.getParameter("transaction_no");
        String trade_status = request.getParameter("trade_status");
        String terminal = request.getParameter("terminal");

        Map<String,String> reqParamMap = new HashMap<>();
        reqParamMap.put("payment",payment);
        reqParamMap.put("shop_id",shop_id);


        if ("return".equals(notifyTye)){
            String is_success = request.getParameter("is_success");

            reqParamMap.put("is_success",is_success);
            reqParamMap.put("notify_type",notify_type);
            reqParamMap.put("out_trade_no",out_trade_no);
            reqParamMap.put("fa_id",fa_id);
            reqParamMap.put("terminal",terminal);
            reqParamMap.put("total_fee",total_fee);
            reqParamMap.put("trade_no",trade_no);
            reqParamMap.put("transaction_no",transaction_no);
            reqParamMap.put("trade_status",trade_status);
        }else if ("notify".equals(notifyTye)){
            String notify_time = request.getParameter("notify_time");
            String gmt_create = request.getParameter("gmt_create");
            String gmt_payment = request.getParameter("gmt_payment");

            reqParamMap.put("notify_type",notify_type);
            reqParamMap.put("out_trade_no",out_trade_no);
            reqParamMap.put("fa_id",fa_id);
            reqParamMap.put("total_fee",total_fee);
            reqParamMap.put("trade_no",trade_no);
            reqParamMap.put("transaction_no",transaction_no);
            reqParamMap.put("trade_status",trade_status);
            reqParamMap.put("notify_time",notify_time);
            reqParamMap.put("gmt_create",gmt_create);
            reqParamMap.put("gmt_payment",gmt_payment);
        } else if ("exception".equals(notifyTye)){
            String service = request.getParameter("service");
            String input_charset = request.getParameter("input_charset");
            String trade_info = request.getParameter("trade_info");
            String error_code = request.getParameter("error_code");
            reqParamMap.put("service",service);
            reqParamMap.put("terminal",terminal);
            reqParamMap.put("input_charset",input_charset);
            reqParamMap.put("trade_info",trade_info);
            reqParamMap.put("error_code",error_code);
            //异常回调，不用验证金额
            total_fee = mongoOrderDetail.getAmountMoney().getAmount().toString();
        }
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
        String signKey = (String)commonParam.get(shopId);;
        LOGGER.info("支付回调参数："+reqParamMap);
        String checkSign = PaySignUtils.buildSignKey(reqParamMap,sign_type,signKey);
        if (checkSign != null && !"".equals(checkSign)){
            verify = checkSign.equals(sign);
        }else{
            logger.info("签名验证失败。生成的签名["+checkSign+"],sign["+sign+"]");
        }


        return verify;
    }
*/

    /**
     * 异常回调状态码对应异常信息
     * @param errorCode
     * @return
     */
    private String getErrorMsg(String errorCode) {
        String msg = "支付失败";
        if ("ILLEGAL_SHOP_ID".equals(errorCode)){
            msg = "非法商户信息";
        }else if ("ILLEGAL_TRADE_INFO".equals(errorCode)){
            msg = "请求参数异常“trade_info”";
        }else if ("ILLEGAL_SIGN_OR_SIGN_TYPE".equals(errorCode)){
            msg = "签名或签名类型异常";
        }else if ("ILLEGAL_SIGN".equals(errorCode)){
            msg = "验证签名失败";
        }else if ("ILLEGAL_ORDER_STATUS".equals(errorCode)){
            msg = "订单已失效";
        }else if ("ORDER_ALREADY_PAID".equals(errorCode)){
            msg = "订单已支付";
        }else if ("ILLEGAL_ORDER".equals(errorCode)){
            msg = "异常订单";
        }else if ("SYSTEM_ERROR".equals(errorCode)){
            msg = "系统异常";
        }

        return msg;
    }


    private void buildOrderInvalidTime(MongoOrderDetail mongoOrderDetail, Map<String, Object> commonParam,Map paraMap) {
        Date expirationTime = null;
        try {
            expirationTime = DateUtil.parseDate(mongoOrderDetail.getCreateTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT);
        }catch (Exception e){
            expirationTime = new Date();
        }
        if (expirationTime == null) {
            expirationTime = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(expirationTime);
        try {
            if (commonParam == null) {
                LOGGER.info("Invoke buildOrderInvalidTime commonParam Is NULL");
                if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                    calendar.add(Calendar.DATE, 15);
                    paraMap.put("expirationHour","15天");
                } else {
                    calendar.add(Calendar.HOUR, 24);
                    paraMap.put("expirationHour","24小时");
                }
                paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            } else {
                String queryStr = "ORDER_INVALID_TIME_" + mongoOrderDetail.getShopId() + "_" + mongoOrderDetail.getOrderAddType();
                String invalidTimeStr = (String) commonParam.get(queryStr);
                LOGGER.info("Invoke buildOrderInvalidTime Query[" + queryStr + "],invalidTime[" + invalidTimeStr + "]");
                if (StringUtils.isNotEmpty(invalidTimeStr) && !("null".equals(invalidTimeStr))) {
                    int invalidTimeInt = Integer.parseInt(invalidTimeStr);
                    calendar.add(Calendar.MINUTE, invalidTimeInt);
                    paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                    if (invalidTimeInt > 1440) {
                        invalidTimeInt = invalidTimeInt / 1440;
                        paraMap.put("expirationHour",invalidTimeInt + "天");
                    } else if (invalidTimeInt <= 60) {
                        paraMap.put("expirationHour",invalidTimeInt + "分钟");
                    } else {
                        invalidTimeInt = invalidTimeInt / 60;
                        paraMap.put("expirationHour",invalidTimeInt + "小时");
                    }
                } else {
                    LOGGER.info("Invoke buildOrderInvalidTime invalidTimeStr Is NULL");
                    if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                        calendar.add(Calendar.DATE, 15);
                        paraMap.put("expirationHour","15天");
                    } else {
                        calendar.add(Calendar.HOUR, 24);
                        paraMap.put("expirationHour","24小时");
                    }
                    paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                }
            }
        } catch (Exception e) {
            if (PeakConstant.SHOPID_SMB.equals(mongoOrderDetail.getShopId())) {
                calendar.add(Calendar.DATE, 15);
                paraMap.put("expirationHour","15天");
            } else {
                calendar.add(Calendar.HOUR, 24);
                paraMap.put("expirationHour","24小时");
            }
            paraMap.put("expirationTime",DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
        }
    }

    /**
     * 基于SHOPID Terminal 跳转失败页
     *
     * @param shopId   shopId
     * @param terminal terminal
     * @param type  "fail"失败页；"success"成功页
     * @return String
     */
    private String getSyncbackRedirect(String shopId, String terminal, String type) {
        String url = null;
        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_pc_"+type;
        } else {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/syncback/allinpay_wap_"+type;
        }
        return url;
    }

    /**
     * Go Cashier
     */
    private String getCashierRedirect(String shopId, String terminal, String paymentType) {
        String url = null;
        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/allinpay_pc";
        } else {
            url = ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"pay/allinpay_wap";
        }
        return url;
    }

    /**
     * 查询银行列表返回失败信息
     * @param errCode
     * @return
     */
    public String getBanksErrorMsg(String errCode){
        String errorMsg = "查询银行列表返回参数错误";
        if ("10001".equals(errCode)){
            errorMsg = "错误的请求参数";
        }else if ("10002".equals(errCode)){
            errorMsg = "签名验证失败";
        }else if ("10003".equals(errCode)){
            errorMsg = "订单金额错误";
        }else if ("10004".equals(errCode)){
            errorMsg = "交易类型错误";
        }else if ("10005".equals(errCode)){
            errorMsg = "服务器出现异常";
        }
        return errorMsg;
    }


}