package com.lenovo.m2.web.webapp.controller.cart.api.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.domain.my.address.view.RegionView;
import com.lenovo.m2.web.domain.purchase.address.view.CityView;
import com.lenovo.m2.web.domain.purchase.address.view.ProvinceView;
import com.lenovo.m2.web.remote.purchase.address.AddressRemoteService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * <br> 实现获取省市区列表
 * @author shenjc
 *
 */

@Controller
@RequestMapping(value = "/api/address")
public class AddressApiController extends BaseController{

	public static Logger log=  LogManager.getLogger(AddressApiController.class.getName());
	
    private static Map<String,String> provinceCache = new ConcurrentHashMap<>();
    private static Map<String,String> cityCache = new ConcurrentHashMap<>();
    private static Map<String,String> townCache = new ConcurrentHashMap<>();
    @Autowired
    private AddressRemoteService addressService;
	/**
	 * <br> 获取省份列表
	 * @param request
	 * @param response
	 * @return
	 */
    @RequestMapping("/getprovince")
    @ResponseBody
    public String getProvince(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<List<PartAddress>> remoteResult = new RemoteResult<>(false);
        String provinceStr = provinceCache.get("province");
        if(StringUtils.isEmpty(provinceStr)){
            remoteResult = addressService.getProvinceList(getTenantCN());
        }
        return this.ajaxWriteStr(JsonUtil.toJson(remoteResult), response);
    }
	
	/**
	 * <br> 获取市列表
	 * @param plat
	 * @param provincename
	 * @return
	 */
    @RequestMapping("/getcities")
    @ResponseBody
    public String getCitiesz(String plat, String provincename,HttpServletResponse response) {
        RemoteResult<List<PartAddress>> result = new RemoteResult<>();
        if (StringUtils.isNotEmpty(provincename)) {
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");

            } catch (UnsupportedEncodingException e) {
                log.error(e);
            }
            String cityStr = cityCache.get(provincename);
            if(StringUtils.isEmpty(cityStr)){
                ProvinceParam provinceParam = new ProvinceParam();
                provinceParam.setProvince(provincename);
                result = addressService.getCityList(getTenantCN(), provinceParam);
            }
        }
        return this.ajaxWriteStr(JsonUtil.toJson(result),response);
    }

    /**
     * <br> 获取区县列表
     * @param provincename
     * @param cityname
     * @return
     */
    @RequestMapping("/getcounties")
    @ResponseBody
    public String getCountiesz(String provincename,String cityname,HttpServletResponse response){
        RemoteResult<List<PartAddress>> result = new RemoteResult<>();
        if(StringUtils.isNotEmpty(provincename)&& StringUtils.isNotEmpty(cityname)){
            try {
                provincename = URLDecoder.decode(provincename, "utf-8");
                cityname = URLDecoder.decode(cityname, "utf-8");
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                log.error(e);
            }
            String key = provincename + cityname;
            String townListStr = townCache.get(key);
            if(StringUtils.isEmpty(townListStr)) {
                ProvinceParam provinceParam = new ProvinceParam();
                provinceParam.setProvince(provincename);
                provinceParam.setCity(cityname);
                result = addressService.getRegionList(getTenantCN(), provinceParam);
            }
        }
        return this.ajaxWriteStr(JsonUtil.toJson(result),response);
    }

    @ResponseBody
	@RequestMapping("/reloadArea")
	 public void reloadArea(Integer shopId){
        addressService.reloadArea(getTenantCN());
     }
}
