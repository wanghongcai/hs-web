package com.lenovo.m2.web.webapp.controller.my;

import com.lenovo.m2.web.webapp.controller.BaseController;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/sn")
public class SnCheckController extends BaseController {

    // *****************临时调用 sn-Check 开始***************************z
    @RequestMapping(value="/sn-check", produces = "application/json; charset=utf-8")
    public Object snCheck(String machineNo, String materialNo, String callback) {
        RestTemplate restTemplate = new RestTemplate();
        String forObject = restTemplate.getForObject("http://10.96.111.192:8523/sn-check?machineNo=" + machineNo + "&materialNo=" + materialNo, String.class);
        MappingJacksonValue mappingJacksonValue = new MappingJacksonValue(forObject);
        mappingJacksonValue.setJsonpFunction(callback);
        return mappingJacksonValue;
    }
    // *****************临时调用 sn-Check 结束***************************
}
