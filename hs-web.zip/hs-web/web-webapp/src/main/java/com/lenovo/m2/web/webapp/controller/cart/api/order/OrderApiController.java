package com.lenovo.m2.web.webapp.controller.cart.api.order;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.hsbuy.domain.purchase.param.CheckOutParam;
import com.lenovo.m2.hsbuy.domain.purchase.param.SubmitOrderParam;
import com.lenovo.m2.hsbuy.domain.purchase.result.SubmitOrderResult;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.remote.purchase.order.RemoteOrderService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;

/**
 * @author yuzj7@lenovo.com
 * @ClassName: OrderController
 * @Description: 结算中心
 * @date 2015年6月30日 下午7:56:20
 */
@Controller
@RequestMapping(value = "/api/checkout")
public class OrderApiController extends BaseController {
    public static Logger log=  LogManager.getLogger(OrderApiController.class.getName());
    @Autowired
    private RemoteOrderService remoteOrderService;

    /**
     * @param entity    结算参数
     * @return
     * @Description: 进入结算中心
     * @author yuzj7@lenovo.com
     * @date 2015年7月21日 下午9:01:31
     */
    @RequestMapping(value = "/get")
    @ResponseBody
    public String checkout(CheckOutParam entity, HttpServletResponse response) {
        entity.setUser(getApiUser());
        log.info("moto 请求参数 checkout:{},tenant:{}"+ JsonUtil.toJson(entity),getTenantCN());
        RemoteResult json  = remoteOrderService.checkout(getTenantCN(),entity);
        log.info("moto checkout return :"+json);
        return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(json, PromptEnum.CHECKOUT)), response);
    }


   
   /**
    * @Author zhanghs 【zhanghs6@lenovo.com】
    * @Description: 提交订单
    * @param entity
    * @param response
    * @date 2016/3/18 14:35
    * @return
    */
    @RequestMapping("/submitOrder")
    @ResponseBody
    public String submitOrder(SubmitOrderParam entity, HttpServletResponse response){
	    User u = getApiUser();
	    u.setUsername(entity.getLoginName());
        entity.setUser(u);
        log.info("moto 请求参数 submitOrder:"+JsonUtil.toJson(entity));
    	RemoteResult<SubmitOrderResult> json  = remoteOrderService.submitOrder(getTenantCN(),entity);
    	 log.info("moto  submitOrder return :"+json);
    	return this.ajaxWriteStr(JsonUtil.toJson(new FpsResult(json, PromptEnum.CHECKOUT)), response);
    }


}
