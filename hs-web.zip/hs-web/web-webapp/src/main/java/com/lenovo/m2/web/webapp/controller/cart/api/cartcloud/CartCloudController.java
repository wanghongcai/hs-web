package com.lenovo.m2.web.webapp.controller.cart.api.cartcloud;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.cart.CartService;
import com.lenovo.m2.hsbuy.domain.ApiResult;
import com.lenovo.m2.hsbuy.domain.cart.*;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;


@Controller
@RequestMapping(value = "/api/cart")
public class CartCloudController extends BaseController implements ApplicationContextAware {


    @Resource
    private CartService shoppingCartService;

    public static Logger log =  LogManager.getLogger(CartCloudController.class.getName());


    @RequestMapping(value = "/test1", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    void test1(AddToCartEntity request, Integer count) {
        log.info("test1--------------"+count);
    }

    @RequestMapping(value = "/test3")
    public void test3(AddToCartEntity request, Integer count) {
        log.info("test1--------------"+count);
    }

    @RequestMapping(value = "/test", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String test2(AddToCartEntity request, Integer count) {
        log.info("test2--------------"+count);
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
        request.setUser(getApiUser());
        request.setIcount(count);
        try{
            log.info("AddToCartEntityParam param:{}",JsonUtil.toJson(request));
        }catch(Exception t){
            log.error("add to cart error", t);
        }
        return JsonUtil.toJson(BaseInfo.fail());
    }


    /****************************** addCart *******************************/
    /**
     *   添加购物车
     */
    @RequestMapping(value = "/addToCart1", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String addToCart1(AddToCartEntity request, Integer count) {
        log.info("count--------------"+count);
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
        request.setUser(getApiUser());
        request.setIcount(count);
        try{
            log.info("AddToCartEntityParam param:{}",JsonUtil.toJson(request));
            RemoteResult<CartNG> result = shoppingCartService.addItemToCart(getTenantCN(),request);
            return JsonUtil.toJson(new FpsResult(result));
        }catch(Exception t){
            log.error("add to cart error", t);
            return JsonUtil.toJson(BaseInfo.fail());
        }
    }

   /**
    *   添加购物车
    */
   @RequestMapping(value = "/addToCart", produces = "application/json; charset=UTF-8")
   public @ResponseBody
   String addToCart(AddToCartEntity request, Integer count) {
       log.info("count--------------"+count);
       if(!getUser(getApiUser())){
           return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
       }
	   request.setUser(getApiUser());
       request.setIcount(count);
       try{
           log.info("AddToCartEntityParam param:{}",JsonUtil.toJson(request));
    	   RemoteResult<CartNG> result = shoppingCartService.addItemToCart(getTenantCN(),request);
    	   return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
       }catch(Exception t){
    	   log.error("add to cart error", t);
    	   return JsonUtil.toJson(BaseInfo.fail());
       }
   }

    @RequestMapping(value = "/directbuy", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String direct(AddToCartEntity request, Integer count) {
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
        request.setUser(getApiUser());
        request.setIcount(count);
        try{
            log.info("direct param:{}",JsonUtil.toJson(request));
            RemoteResult<String> result = shoppingCartService.directBuy(getTenantCN(),request);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception t){
            log.error("add to direct error", t);
            return JsonUtil.toJson(BaseInfo.fail());
        }
    }

    /**************************** operatingCart *****************************/

    /**
     *  删除购物行
     */
    @RequestMapping(value = "/deleteItem", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String removeSkuFromCart(DelItemEntity entity){
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
    	entity.setUser(getApiUser());
    	String itemid = request().getParameter("itemId");
    	entity.setItemIds(itemid);
    	try{
    		RemoteResult<CartNG> result = shoppingCartService.delItemByIds(getTenantCN(),entity);
    		return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
    	}catch(Exception t){
    		log.error("", t);
    		return JsonUtil.toJson(BaseInfo.fail());
    	}
    }





    /**
     *  清空购物车
     */
    @RequestMapping(value = "/removeAllSkuFromCart", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String removeAllSkuFromCart(EmptyCartEntity entity){
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
    	entity.setUser(getApiUser());
        RemoteResult res = shoppingCartService.emptyCart(getTenantCN(),entity);
        return JsonUtil.toJson(new FpsResult(res, PromptEnum.CHECKOUT));
    }

    /**
     *  修改购物行商品数量   changeNum
     */
    @RequestMapping(value = "/updateItemNum", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String changeNum(ModifyItemNumEntity entity){
        try{
            if(!getUser(getApiUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
            entity.setUser(getApiUser());
            RemoteResult<CartNG> result =  shoppingCartService.modifyCarItemNum(getTenant(),entity);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception e){
            logger.error("",e);
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }

    /**
     *  选中不选中购物行
     */
    @RequestMapping(value = "/selectItem", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String selectItem(ActiveItemEntity entity){
        try{
            if(!getUser(getApiUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
        	entity.setUser(getApiUser());
            RemoteResult<CartNG> result = shoppingCartService.activeItem(getTenantCN(),entity);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception e){
            logger.error("", e);
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }

    /**
     *  全选，反选
     */
    @RequestMapping(value = "/selectAllItem", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String selectAllItem(ActiveItemEntity entity){
        try{
            if(!getUser(getApiUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
        	entity.setUser(getApiUser());
            RemoteResult<CartNG> result = shoppingCartService.checkedAllOnOff(getTenantCN(),entity);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception e){
            logger.error("",e);
            return toJson(new BaseInfo(ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION));
        }
    }

    /********************************* YB *********************************/

    /**
     *  获取服务列表  queryProductYb
     */
    @RequestMapping(value = "/queryProductYb", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String queryProductYb(GetGoodServiceEntity entity){
        try{
            if(!getUser(getApiUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
        	entity.setUser(getApiUser());
            RemoteResult<List<ServiceProductView>> result = shoppingCartService.getServiceListByGcode(getTenantCN(),entity);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception e){
            log.error("",e);
            return toJson(BaseInfo.errInfo(1));
        }
    }

    /**
     *  更新延保服务    updateSkuYbsToCart
     **/
    @RequestMapping(value = "/updateSkuYbsToCart", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String updateSkuYbsToCart(UpdateItemServiceEntity entity){
        try{
            if(!getUser(getApiUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
        	entity.setUser(getApiUser());
            RemoteResult<CartNG> result =  shoppingCartService.updateItemService(getTenant(),entity);
            return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
        }catch(Exception e){
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }

    /********************************* getCartMessage **********************************/

    /**
     *  获取mini购物车
     */
    @RequestMapping(value = "/miniCartServiceNew", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String miniCartServiceNew(){
        return "ok!";
    }

    /**
     *  获取购物车
     */
    @RequestMapping(value = "/getCart", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public  String cartInformation(GetCartNGEntity entity){
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
        entity.setUser(getApiUser());
        logger.info("api get cart, {}", JsonUtil.toJson(entity));
        RemoteResult<CartNG> result = null;
        try {
            result = shoppingCartService.getCart(getTenantCN(),entity);
        } catch (Exception e) {
            logger.error("api get cart error", e);
        }
        return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT));
    }





    /**
     *  清空购物车
     */
    @RequestMapping(value = "/emptyCart", produces = "application/json; charset=UTF-8")
    public @ResponseBody
    String emptyCart(EmptyCartEntity entity){
        if(!getUser(getApiUser())){
            return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
        }
    	entity.setUser(getApiUser());
        ApiResult<CartNG> result  = null;
        logger.info("emptyCart");
        try {
            RemoteResult res  = shoppingCartService.emptyCart(getTenantCN(),entity);
            return JsonUtil.toJson(new FpsResult(res, PromptEnum.CHECKOUT));
        } catch (Exception e) {
            logger.info("emptyCart error", e);
        }
        return JsonUtil.toJson(result);
    }


    private ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }

}
