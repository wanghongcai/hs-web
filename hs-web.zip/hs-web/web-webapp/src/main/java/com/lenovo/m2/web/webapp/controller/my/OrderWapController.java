package com.lenovo.m2.web.webapp.controller.my;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.credit.api.model.CreditInfoApi;
import com.lenovo.m2.credit.api.model.CreditPartitionBillsApi;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.ordercenter.OrderLogistics;
import com.lenovo.m2.hsbuy.domain.ordercenter.PayRecordsDetailResult;
import com.lenovo.m2.hsbuy.logistics.LogisticApiService;
import com.lenovo.m2.web.common.my.CommonConstant;
import com.lenovo.m2.web.common.my.model.useroperationlog.UserOperationLog;
import com.lenovo.m2.web.common.my.order.OrderMainConstant;
import com.lenovo.m2.web.common.my.utils.NumberFormatUtils;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.my.utils.math.Coder;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.ErrorEnumUtil;
import com.lenovo.m2.web.common.purchase.util.FpsResult;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.SSOUtil;
import com.lenovo.m2.web.domain.my.MobileMsg;
import com.lenovo.m2.web.domain.my.PackageLogistics;
import com.lenovo.m2.web.domain.my.order.OrderDetailDesc;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderList;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderListGlist;
import com.lenovo.m2.web.manager.my.order.OrderManager;
import com.lenovo.m2.web.remote.captcha.SmsCerpService;
import com.lenovo.m2.web.remote.my.order.OrderService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.util.CheckRequestUrlUtil;
import com.lenovo.m2.web.webapp.util.PaginatedUtils;
import com.lenovo.m2.web.webapp.util.ThreadLocalSessionUser;
import com.lenovo.m2.web.webapp.util.UserOperationLogUtil;

/**
 * wap  订单中心
 * Created by yyduff on 2016/3/15.
 */
@Controller
@Scope("prototype")
@RequestMapping("/center")
public class OrderWapController extends BaseController {

    private static final Logger logger = LogManager.getLogger(OrderWapController.class);
    private static final int pageSize = 5;
    @Autowired
    private OrderManager orderManager;
    @Autowired
    private OrderService orderService;
    @Autowired
    private LogisticApiService logisticApiService;
    @Autowired
    private SmsCerpService smsCerpService;
    
    @RequestMapping("/wap/orderlist")
    public String orderlist(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
       String lenovoId = getLenovoId();
        try {
            Map<String,String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain",domain);
            if (isNull(shopId)) {
                logger.error("###获取订单列表 merchantId为空");
                return "/cn/my/wap/index";
            }
            //将待评价页面链接放入到map中
            if(OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                map.put("wapWaitEvaluateUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.order.wapWaitEvaluate.url"));
            }
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
        } catch (Exception e) {
            logger.error(e.toString());
        }
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        return "/cn/my/wap/order/orderlist";
    }

    @RequestMapping("/wap/orderlistdata")
    public String orderlistdata(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String lenovoId = getLenovoId();
        PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
        String orderstatus = request.getParameter("orderstatus");
        String searchtext = request.getParameter("searchtext");

        map.put("orderstatus", orderstatus == null ? "all" : orderstatus);//将订单查询条件回推给前台，用于前台操作后，带条件刷新
        map.put("searchtext", searchtext == null ? "" : searchtext);
//      String searchstatus = request.getParameter("searchstatus");
        String orderType = request.getParameter("orderType");
        Map<String,String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
        String shopId = getTenant().getShopId().toString();
        String domain = resultMap.get("domain");
        map.put("domain",domain);

            if (isNull(shopId)) {
                logger.error("###获取订单列表 merchantId为空");
                return "/cn/my/wap/index";
            }
        if (searchtext != null && "".equals(searchtext.trim())) {
            searchtext = null;
        }
        if (searchtext != null) {
            try {
                searchtext = URLDecoder.decode(searchtext, "UTF-8");
            } catch (Exception e) {
                searchtext = null;
                logger.error("我的订单查询searchtext参数汉字解码异常", e);
            }
        }
        RemoteResult<PageModel2<OrderDetailListJSONOrderList>> re = orderManager.queryOrder(shopId, lenovoId, pageQuery, null, searchtext, orderstatus, orderType);
        if (re != null && re.getT() != null && re.isSuccess()) {
            PageModel2<OrderDetailListJSONOrderList> pageModel2 = re.getT();
            logger.info("------json:" + JsonUtil.toJson(re.getT()));

            List<OrderDetailListJSONOrderList> listJSONOrderLists = pageModel2.getDatas();

            //懂得充值单独判断订单状态
            for (OrderDetailListJSONOrderList p : listJSONOrderLists){
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    if ((p.getCreditLine() != null ? p.getCreditLine().getCent() : 0) > 0){
                        //判断用户主账号信息
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())){
                            p.setIsMainAccount("1");
                        }
                    }
                }
            }

            map.put("orderlistPaginated", new PaginatedUtils<OrderDetailListJSONOrderList>(pageModel2));
            if (re.getT().getTotalCount() > getPage(request) * pageSize)
                map.put("hasmore", "1");
            else
                map.put("hasmore", "0");
            map.put("page",getPage(request));
            map.put("totalPage",re.getT().getTotalPageNum());
            //支付信息
            if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
            }else if(OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)){
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.m.pay.url"));
            }else{
                map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
            }
            //商品信息
            String isApp = request.getParameter("isApp");
            String terminal = request.getParameter("terminal");
            logger.info("isApp-----"+isApp+",terminal:["+terminal+"]");
            boolean isAppBool = false;
            if(StringUtils.equals("TURE",isApp)){
                isAppBool = true;
            }
            if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
                if(isAppBool){
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.android.url"));
                    map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
                }else{
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.m.url"));
                    map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
                }
            } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
                if(isAppBool){
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.android.url"));
                }else{
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.m.url"));
                }
            } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
                if(isAppBool){
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
                }else{
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
                }
            } else if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)) {
                if(isAppBool){
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.android.url"));
                }else{
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.m.url"));
                }
            }else if (OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)) {
                if(isAppBool){
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.android.url"));
                }else{
                    map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.m.url"));
                }
            }
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("terminal", terminal);
            request().getSession().setAttribute("isApp",isApp);
            request().getSession().setAttribute("terminal",terminal);
        }
            return "/cn/my/wap/order/content/orderlistdata";
    }

    @RequestMapping("/wap/orderdetail")
    public String orderdetail(HttpServletRequest request, String passkey, String orderno,
                              Map<String, Object> map) {
        String  lenovoId = getLenovoId();
        OrderDetailDesc orderDetail = null;
        try {
            Map<String,String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain",domain);
                if (isNull(orderno, passkey, shopId)) {
                    logger.error("###获取订单详情 orderNo为空");
                    return "/cn/my/wap/index";
                }

            String confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.ORDERDETAIL_TYPE);
            if (passkey.equals(confirmPasskey)) {

                RemoteResult<OrderDetailDesc> remoteResult = orderManager.getOrderDetailDescByOrdercode(orderno, shopId);
                if (!remoteResult.isSuccess()){
                    return "/cn/my/pc/index";
                }
                orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                //判断用户主账号信息
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    if ((orderDetail.getCreditLine() != null ? orderDetail.getCreditLine().getCent() : 0) > 0){
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
                            orderDetail.setIsMainAccount("1");
                        }
                    }
                }
                makedateilforwaporder(orderno,shopId,lenovoId,map,request,orderDetail);

            } else {
                logger.error("###无权访问");
                return "/cn/my/wap/index";
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "/cn/my/wap/index";
        }
        return "/cn/my/wap/order/orderdetail";
    }

    private void makedateilforwaporder(String orderno, String shopId, String lenovoId, Map<String, Object> map, HttpServletRequest request, OrderDetailDesc orderDetail )throws Exception{

        //获取发票
        if ("3".equals(orderDetail.getOrderstatuscode()) || "10".equals(orderDetail.getOrderstatuscode())) {
            map.put("invoiceurl", "/center/getinvoiceurl.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE));
        }
        //支付信息
        if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
        }else if(OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)){
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.m.pay.url"));
        }else{
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
        }
        map.put("printurl", "/center/print.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE));
        map.put("orderDetail", orderDetail);
        //商品信息
        String isApp = (String)request.getSession().getAttribute("isApp");
        String terminal = (String)request.getSession().getAttribute("terminal");

        boolean isAppBool = false;
        if(StringUtils.equals("TURE",isApp)){
            isAppBool = true;
            terminal = String.valueOf(OrderMainConstant.TERMINAL_APP);
        }else{
            terminal = String.valueOf(OrderMainConstant.TERMINAL_WAP);
        }
        if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.android.url"));
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.m.url"));
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
            }
        } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.m.url"));
            }
        } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
            if(isAppBool){
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
            }else{
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
            }
        } else if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.product.m.url"));
            }
        }else if (OrderMainConstant.MERCHANT_ID_HUIMALLJF.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("huimalljf.product.m.url"));
            }
        }
        //支付信息
//        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);
        map.put("isApp",isApp);
        map.put("terminal",terminal);
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), JsonUtil.toJson(orderDetail), getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
    }

    private void takeLnenovoMakefororder(String orderno, String shopId, String lenovoId, Map<String, Object> map, HttpServletRequest request, OrderDetailDesc orderDetail )throws Exception{

        //获取发票
        if ("3".equals(orderDetail.getOrderstatuscode()) || "10".equals(orderDetail.getOrderstatuscode())) {
            map.put("invoiceurl", "/center/getinvoiceurl.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.INVOICE_TYPE));
        }
        //支付信息
        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
        map.put("printurl", "/center/print.jhtm?orderno=" + orderno + "&passkey=" + Coder.encryptHMAC(lenovoId, orderno, CommonConstant.PRINT_TYPE));
        map.put("orderDetail", orderDetail);
        //商品信息
        String isApp = (String)request.getSession().getAttribute("isApp");
        String terminal = (String)request.getSession().getAttribute("terminal");

        boolean isAppBool = false;
        if(StringUtils.equals("TURE",isApp)){
            isAppBool = true;
            terminal = String.valueOf(OrderMainConstant.TERMINAL_APP);
        }else{
            terminal = String.valueOf(OrderMainConstant.TERMINAL_WAP);
        }
        if (OrderMainConstant.MERCHANT_ID_LENOVO.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.android.url"));
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("shop.product.m.url"));
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
            }
        } else if (OrderMainConstant.MERCHANT_ID_EPP.equals(shopId)) {
            if(isAppBool){
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.android.url"));
            }else{
                map.put("productUrl", CustomizedPropertyConfigurer.getContextProperty("product.m.url"));
            }
        } else if (OrderMainConstant.MERCHANT_ID_THINK.equals(shopId)) {
            if(isAppBool){
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.android.url"));
            }else{
                map.put("productThinkUrl", CustomizedPropertyConfigurer.getContextProperty("tk.product.m.url"));
            }
        }
        //支付信息
        map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("m.pay.url"));
        map.put("merchantId", shopId);
        map.put("lenovoId", lenovoId);
        map.put("isApp",isApp);
        map.put("terminal",terminal);
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), JsonUtil.toJson(orderDetail), getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
    }

    //物流信息
    @RequestMapping(value = "/wap/getOrderTrackInfo", method = {RequestMethod.POST, RequestMethod.GET})
    public String getOrderTrackInfo(HttpServletRequest request, String orderNo, String typeKey, Map<String, Object> map,String passKey) {

        String lenovoId =  getLenovoId();
        String confirmPasskey = null;
        try {
            confirmPasskey = Coder.encryptHMAC(lenovoId, orderNo, CommonConstant.TRACKINFO_TYPE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!StringUtils.equals(confirmPasskey, passKey)) {
            logger.info("###lenovoId not  match the current:" + lenovoId);
            return null;
        }
        Map<String, String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
        String domain = resultMap.get("domain");
        map.put("domain", domain);
        RemoteResult<Map<String, Object>> remoteResult = orderManager.getOrderTrackInfo(orderNo,getTenant());
        OrderDetailDesc orderDetail = orderManager.getOrderDetailDescByOrdercode(orderNo, getTenant().getShopId()+"").getT();
        if(CollectionUtils.isNotEmpty(orderDetail.getGlist())){
            OrderDetailListJSONOrderListGlist gGood = orderDetail.getGlist().get(0);
            map.put("productGphoto",gGood.getGphoto());
        }else{
            OrderDetailListJSONOrderListGlist gGood = orderDetail.getSlist().get(0);
            map.put("productGphoto",gGood.getGphoto());
        }
        RemoteResult<List<OrderLogistics>> remoteResult1 = logisticApiService.getOrderLogisticsByOrderCenter(orderNo);

        List<OrderLogistics> logisticsList = remoteResult1.getT();
        Map<String, Object> m = remoteResult.getT();
        logger.info("remoteResult1={}", JsonUtil.toJson(remoteResult1));
        if (logisticsList != null && logisticsList.size() > 1){
            for (int i = 0 ; i < logisticsList.size(); i++){
                map.put("logisticNo" + i+1,logisticsList.get(i).getLogisticsCompanyName());
                map.put("logisticName" + i+1,logisticsList.get(i).getLogisticsNo());
            }
        }else if(logisticsList != null && logisticsList.size() == 1){
            map.put("logisticNo0",logisticsList.get(0).getLogisticsNo());
            map.put("logisticName0",logisticsList.get(0).getLogisticsCompanyName());
        }
        logger.info("remoteResult={}",JsonUtil.toJson(remoteResult));
        if (m != null && !"".equals(m) && logisticsList != null && logisticsList.size() > 1){
            List<PackageLogistics> p = (List<PackageLogistics>)m.get("packageLogisticses");
            map.put("logtype", 1);
            map.put("packageLogisticses", p);
            for (int i = 0; i < p.size(); i++){
                String str = "logistics" + (i + 1);
                map.put(str, m.get(str));
            }
        }else if (m != null && !"".equals(m)){
            map.put("logtype", 0);
            map.put("logistics0", m.get("logistics0"));
        }else {

        }
        switch (Integer.parseInt(typeKey)) {
            case 1:
                return "/cn/my/wap/order/content/orderTrackInfoList";
            case 2:
                return "/cn/my/wap/order/content/orderTrackInfoDetail";
        }
        return null;
    }
    /**
     * assemble package list
     */
    private List<PackageLogistics> assemblePackageLogistics(List<OrderLogistics> orderLogisticses, String invoiceLogisticNo) {
        List<PackageLogistics> packageLogisticses = new ArrayList<>();
        for (int i = 0; i < orderLogisticses.size(); i++) {
            if (StringUtils.equals(invoiceLogisticNo, orderLogisticses.get(i).getLogisticsNo())) {
                continue;
            }
            PackageLogistics packageLogistics = new PackageLogistics();
            packageLogistics.setPackageNo(i + 1);
            packageLogistics.setPackageDesc("包裹" + NumberFormatUtils.foematInteger(i + 1));
            packageLogisticses.add(packageLogistics);
        }
        if (!StringUtil.isEmpty(invoiceLogisticNo)) {
            PackageLogistics packageLogistics = new PackageLogistics();
            packageLogistics.setPackageNo(packageLogisticses.size() + 1);
            packageLogistics.setPackageDesc("发票物流");
            packageLogisticses.add(packageLogistics);
        }
        return packageLogisticses;
    }



    @RequestMapping("/wap/huimallcredit")
    public String huimallcredit(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        try {
            String  lenovoId = getLenovoId();
            PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
            Map<String,Object> HuiMallCreditMap = new HashMap<>();
            logger.info("huimallcredit.lenovoId={}",lenovoId);
            try {
                HuiMallCreditMap = orderService.getWapHuiMallMessage(lenovoId,pageQuery);
            }catch (Exception e){
                logger.info("e",e);
            }
            logger.info("HuiMallCreditMap={}",JsonUtil.toJson(HuiMallCreditMap));
            //获取信用列表
            PageModel2<CreditInfoApi> creditInfoApi = HuiMallCreditMap.get("creditInfoApi") != null && !"".equals(HuiMallCreditMap.get("creditInfoApi")) ? (PageModel2<CreditInfoApi>) HuiMallCreditMap.get("creditInfoApi") : null;
            PageModel2<CreditPartitionBillsApi>  creditPartitionBillsApiFalse = HuiMallCreditMap.get("creditPartitionBillsApiFalse") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiFalse")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiFalse") : null;
            PageModel2<CreditPartitionBillsApi> creditPartitionBillsApiTrue = HuiMallCreditMap.get("creditPartitionBillsApiTrue") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiTrue")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiTrue") : null;
            logger.info("creditList={}",JsonUtil.toJson(creditInfoApi));
            logger.info("creditDetailListNoPay={}",JsonUtil.toJson(creditPartitionBillsApiFalse));
            logger.info("creditDetailListPayFor={}",JsonUtil.toJson(creditPartitionBillsApiTrue));
            if (creditInfoApi != null){
                map.put("creditList",new PaginatedUtils<CreditInfoApi>(creditInfoApi));
                logger.info("creditList={}",JsonUtil.toJson(new PaginatedUtils<CreditInfoApi>(creditInfoApi)));
            }else{
                map.put("creditList", "");
            }
            if (creditPartitionBillsApiFalse != null){
                //获取未付款信用使用详情
                map.put("creditDetailListNoPay",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse));
                logger.info("creditDetailListNoPay={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiFalse)));

            }else{
                map.put("creditDetailListNoPay", "");
            }
            if (creditPartitionBillsApiTrue != null){
                //获取已付款信用使用详情
                map.put("creditDetailListPayFor",new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue));
                logger.info("creditDetailListPayFor={}",JsonUtil.toJson(new PaginatedUtils<CreditPartitionBillsApi>(creditPartitionBillsApiTrue)));
            }else{
                map.put("creditDetailListPayFor", "");
            }
            map.put("orderUrl", CustomizedPropertyConfigurer.getContextProperty("m.huimall.doamin.url"));
            map.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
            UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
            UserOperationLogUtil.log(userOperationLog);
        }catch (Exception e){
            e.printStackTrace();
        }
        return "cn/my/wap/order/waphuimall/creditList";
    }
    /**
     * 获取更多订单
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/wap/huimallWapCreditDetailList")
    @ResponseBody
    public String huimallWapCreditDetailList(HttpServletRequest request, HttpServletResponse response){
        String lenovoId = getLenovoId();
        PageQuery pageQuery = new PageQuery(getPage(request), pageSize);
        String payflag = request.getParameter("payflag");
        logger.info("Ajax 调用 /wap/huimallWapCreditDetailList lenovoId[" + lenovoId + "],pageQuery[" + pageQuery + "]");
        Map<String,Object> HuiMallCreditMap = new HashMap<>();
        Map<String, Object> paraMap = new HashMap<>();
        try {
            HuiMallCreditMap = orderService.getWapHuiMallMessage(lenovoId,pageQuery);
        }catch (Exception e){
            logger.info("e",e);
        }
        logger.info("HuiMallCreditMap={}",JsonUtil.toJson(HuiMallCreditMap));
        //获取信用列表
        PageModel2<CreditPartitionBillsApi>  creditPartitionBillsApiFalse = HuiMallCreditMap.get("creditPartitionBillsApiFalse") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiFalse")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiFalse") : null;
        PageModel2<CreditPartitionBillsApi> creditPartitionBillsApiTrue = HuiMallCreditMap.get("creditPartitionBillsApiTrue") != null  && !"".equals(HuiMallCreditMap.get("creditPartitionBillsApiTrue")) ? (PageModel2<CreditPartitionBillsApi>) HuiMallCreditMap.get("creditPartitionBillsApiTrue") : null;
        logger.info("creditDetailListNoPay={}",JsonUtil.toJson(creditPartitionBillsApiFalse));
        logger.info("creditDetailListPayFor={}",JsonUtil.toJson(creditPartitionBillsApiTrue));
        int rc = 0;
        if("nopay".equals(payflag)){
            if (creditPartitionBillsApiFalse != null){
                //获取未付款信用使用详情
                List<CreditPartitionBillsApi> creditPartitionBillsApiList = new ArrayList<CreditPartitionBillsApi>();
                creditPartitionBillsApiList = creditPartitionBillsApiFalse.getDatas();
                paraMap.put("creditDetailListNoPay", creditPartitionBillsApiList);
                rc = creditPartitionBillsApiList == null || creditPartitionBillsApiList.size() == 0 ? 0 : 1;
                logger.info("creditDetailListNoPay={}",JsonUtil.toJson(creditPartitionBillsApiList));
            }else{
                paraMap.put("creditDetailListNoPay", "");
                rc = 0;
            }
        } else {
            if (creditPartitionBillsApiTrue != null){
                //获取已付款信用使用详情
                List<CreditPartitionBillsApi> creditPartitionBillsApiList = new ArrayList<CreditPartitionBillsApi>();
                creditPartitionBillsApiList = creditPartitionBillsApiTrue.getDatas();
                paraMap.put("creditDetailListPayFor", creditPartitionBillsApiList);
                rc = creditPartitionBillsApiList == null || creditPartitionBillsApiList.size() == 0 ? 0 : 1;
                logger.info("creditDetailListPayFor={}",JsonUtil.toJson(creditPartitionBillsApiList));
            }else{
                paraMap.put("creditDetailListPayFor", "");
                rc = 0;
            }
        }
        paraMap.put("rc", rc);
        paraMap.put("orderUrl", CustomizedPropertyConfigurer.getContextProperty("m.huimall.doamin.url"));
        paraMap.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
        UserOperationLog userOperationLog = new UserOperationLog(lenovoId, request.getRequestURI(), "", getIp(), request.getParameterMap());
        UserOperationLogUtil.log(userOperationLog);
        return JsonUtil.toJson(paraMap);
    }
    /**
     * 信用支付部分还款
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/wap/huimallWapPartialRepayment")
    @ResponseBody
    public String huimallWapPartialRepayment(HttpServletRequest request, HttpServletResponse response){
        String lenovoId = getLenovoId();
        String billNo = request.getParameter("billNo");
        String faCode = request.getParameter("faCode");
        String unpaidAmount = request.getParameter("unpaidAmount");
        String returnAmount = request.getParameter("returnAmount");
        logger.info("Ajax 调用 /wap/huimallWapPartialRepayment billNo[" + billNo + "],buyerId[" + lenovoId + "],faCode[" + faCode + "],unpaidAmount[" + unpaidAmount + "],returnAmount[" + returnAmount + "]");
        Map<String, String> paraMap = new HashMap<>();
        try{
            paraMap = orderService.savePayTracking(billNo, Long.parseLong(lenovoId), faCode, unpaidAmount, returnAmount);
            paraMap.put("payUrl", CustomizedPropertyConfigurer.getContextProperty("huimall.m.pay.url"));
        } catch(Exception e){
            logger.info("WAP信用支付部分还款，调用后台新订单号接口异常", e.getMessage());
            paraMap.put("rc", "0");
            paraMap.put("msg", "服务器异常，请重新发起");
        }
        logger.info("Ajax 调用 /wap/huimallWapPartialRepayment 完成,Result[" + paraMap + "]");
        return JsonUtil.toJson(paraMap);
    }
    @RequestMapping("/wap/huimallcreditdetail")
    public String huimallcreditdetail(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map,String creditPartitionBillsApiCode) {
        logger.info("wap-creditPartitionBillsApiCode--request={}",request.getParameter("creditPartitionBillsApiCode"));
        logger.info("wap-creditPartitionBillsApiCode={}",creditPartitionBillsApiCode);
        RemoteResult<CreditPartitionBillsApi> creditPartitionBillsApi = orderService.getHuiMallDetailMessage(creditPartitionBillsApiCode);
        CreditPartitionBillsApi c = creditPartitionBillsApi.getT();

        String billNo = request.getParameter("creditPartitionBillsApiCode"); //
        String faCode = request.getParameter("faCode"); //分销商
        String buyerId = request.getParameter("buyerId"); //
        if (StringUtils.isNotBlank(billNo) && StringUtils.isNotBlank(faCode) &&StringUtils.isNotBlank(buyerId)&& StringUtils.isNumeric(buyerId)){
            logger.info("huimallcredit.billNo ",billNo);
            RemoteResult<List<PayTrackingApi>> result=new RemoteResult<List<PayTrackingApi>>(false);
            try {
                result = orderService.getHuimallcreditPaidData(billNo,faCode,Long.parseLong(buyerId));
                if(result!=null && result.isSuccess() && !result.getT().isEmpty()) {
                    map.put("payTrackingApi", result.getT());
                }
            }catch (Exception e){
                logger.error(e.getMessage(),e);
            }
        }else {
            logger.info("wap get data params error");
        }
        map.put("creditPartitionBillsApi",c);
        logger.info("wap-creditPartitionBillsApi={}",JsonUtil.toJson(creditPartitionBillsApi));
        return "cn/my/wap/order/waphuimall/creditdetail";
    }

    @RequestMapping("/wap/getBigImage")
    public String getBigImage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map,String url) {
        map.put("imageurl",url);
        return "cn/my/wap/order/dzimage";
    }

    /**
     * 进入上传线下银行转账凭证页面
     * @param request
     * @param passkey
     * @param orderno
     * @param map
     * @return
     */
    @RequestMapping("/wap/offlineUpload")
    public String offlineUpload(HttpServletRequest request, String passkey, String orderno,String payId,
                              Map<String, Object> map) {
//        map.put("username",username);
        String  lenovoId = getLenovoId();
        OrderDetailDesc orderDetail = null;
        try {
            Map<String,String> resultMap = CheckRequestUrlUtil.getMerchantIdByHostNameForPc(request);
            String shopId = getTenant().getShopId().toString();
            String domain = resultMap.get("domain");
            map.put("domain",domain);
            map.put("payId",payId);
//            if (isNull(orderno, passkey, shopId)) {
            if (isNull(orderno,  shopId)) {
                logger.error("###获取订单详情 orderNo为空");
                return "/cn/my/wap/index";
            }

//            String confirmPasskey = Coder.encryptHMAC(lenovoId, orderno, CommonConstant.ORDERDETAIL_TYPE);
            if (true) {

                RemoteResult<OrderDetailDesc> remoteResult = orderManager.getOrderDetailDescByOrdercode(orderno, shopId);
                if (!remoteResult.isSuccess()){
                    return "/cn/my/pc/index";
                }
//                //判断用户主账号信息
//                if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
//                    map.put("isMainAccount", "1");
//                }
                orderDetail = orderManager.getOrderDetailDescByOrdercode(orderno, shopId).getT();
                //判断用户主账号信息
                if (OrderMainConstant.MERCHANT_ID_HUIMALL.equals(shopId)){
                    if ((orderDetail.getCreditLine() != null ? orderDetail.getCreditLine().getCent() : 0) > 0){
                        if (!SSOUtil.isMainAccount(ThreadLocalSessionUser.getUser().getUsername())) {
                            orderDetail.setIsMainAccount("1");
                        }
                    }
                }
                makedateilforwaporder(orderno,shopId,lenovoId,map,request,orderDetail);

            } else {
                logger.error("###无权访问");
                return "/cn/my/wap/index";
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "/cn/my/wap/index";
        }
        return "/cn/my/wap/order/waphuimall/offlineupload";
    }

    @RequestMapping("/wap/huimallofflinelist")
    public String huimallofflinelist(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        DownlinePayListParam downlinePayListParam = new DownlinePayListParam();
        String  lenovoId = getLenovoId();
        logger.info("orderdetail.lenovoId={}",lenovoId);
        String shopId = getTenant().getShopId().toString();
        downlinePayListParam.setShopId(Integer.parseInt(shopId));
//        String status = request.getParameter("status");
//        downlinePayListParam.setStatus(Integer.parseInt((!status.equals("") && status != null ? status : "5")));//审核状态 0初始状态，1 审核通过，2审核拒绝
        downlinePayListParam.setPaymentUser(lenovoId);
        downlinePayListParam.setPageNum(getPage(request));
        downlinePayListParam.setPageSize(pageSize);
        RemoteResult<PageModel2<PayRecords>> remoteResult = new RemoteResult<>();
        try {
            remoteResult = orderManager.queryDownlinePayList(downlinePayListParam);
        }catch (Exception e){
            logger.error("e={}",e);
        }
        logger.info("RemoteResult<PageModel2<PayRecords>>={}",JsonUtil.toJson(remoteResult));
        if (remoteResult.isSuccess()){
            String isApp = request.getParameter("isApp");
            map.put("isApp", isApp);
            map.put("page",getPage(request));
            map.put("totalPage",remoteResult.getT().getTotalPageNum());
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
            map.put("offlinelistdata", new PaginatedUtils<OrderDetailListJSONOrderList>(remoteResult.getT()));
        }else{
            map.put("offlinelistdata", new PaginatedUtils<OrderDetailListJSONOrderList>(new PageModel2<PayRecords>()));
        }
        return "cn/my/wap/order/waphuimall/waphuimallofflinelistdata";
    }

    @RequestMapping("/wap/huimallofflinedetail")
    public String huimallofflinedetail(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String p = request.getParameter("payId");
        RemoteResult<PayRecordsDetailResult> recordsDetail = new RemoteResult<>();
        try {
            recordsDetail = orderManager.payRecordsDetail(p,getTenant());
        }catch (Exception e){
            logger.error("e={}",e);
        }        logger.info("recordsDetail={}",JsonUtil.toJson(recordsDetail));
        if (recordsDetail.isSuccess()){
            String  lenovoId = getLenovoId();
            logger.info("orderdetail.lenovoId={}",lenovoId);
            String shopId = getTenant().getShopId().toString();
            map.put("merchantId", shopId);
            map.put("lenovoId", lenovoId);
        }
        map.put("offlinedetail",recordsDetail.getT());
        return "cn/my/wap/order/waphuimall/waphuimallofflinedetail";
    }

    /**
     * 获取短信验证码
     * @return
     */
    @ResponseBody
    @RequestMapping("/wap/sendCaptcha")
    public String sendMobileCaptcha(HttpServletResponse response) {
        Map<String, Object> result = new HashMap<>();
        MobileMsg mobileMsg = new MobileMsg();
        mobileMsg.setMobile(user().getUsername());
        mobileMsg.setShopId("14");
        mobileMsg.setInner(false);
        boolean flag = smsCerpService.sendSmsCaptcha(mobileMsg);
        if(flag) {
            result.put("ret", true);
        }else {
            result.put("ret", false);
            result.put("msg", "验证码发送失败，请重试！");
        }
        return this.ajaxWriteStr(JsonUtil.toJson(result), response);
    }

    /**
     * 校验手机验证码
     * @param captcha
     * @return
     */
    @ResponseBody
    @RequestMapping("/wap/checkMobileCaptcha")
    public String checkMobileCaptcha(String captcha,HttpServletResponse response) {
        if(StringUtil.isEmpty(captcha)){
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_PARAM"))),response);
        }
        if (isNull(user())) {
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_NOT_LOGIN"))),response);
        }
        MobileMsg mobile = new MobileMsg();
        mobile.setMobile(user().getUsername());
        mobile.setCaptcha(captcha);
        mobile.setShopId("14");
        boolean flag = smsCerpService.verifySmsCaptcha(mobile);
        if (!flag) {
            return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_CAPTCHA"))),response);
        }
        return ajaxWriteStr(JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"SUCCESS"))),response);
    }
    
}
