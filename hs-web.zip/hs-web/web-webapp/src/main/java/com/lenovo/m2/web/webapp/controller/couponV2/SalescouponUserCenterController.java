package com.lenovo.m2.web.webapp.controller.couponV2;

import com.alibaba.dubbo.common.json.JSON;
import com.alibaba.dubbo.common.json.ParseException;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.usercenter.PageShowBean;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.common.purchase.util.ViewPathUtil;
import com.lenovo.m2.web.manager.couponV2.SalescouponFrontService;
import com.lenovo.m2.web.webapp.controller.BaseController;
import com.lenovo.m2.web.webapp.controller.couponV2.domain.HttpClient;
import com.lenovo.m2.web.webapp.controller.couponV2.domain.JsonObject;
import com.lenovo.m2.web.webapp.controller.couponV2.domain.PaginatedUtils2;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 会员中心我的优惠券Controller
 * Created by yezhenyue on 2016/3/10.
 */

@Controller
@Scope("prototype")
public class SalescouponUserCenterController extends BaseController{
    private static final Logger LOGGER = LogManager.getLogger(SalescouponUserCenterController.class);
    @Autowired
    private SalescouponFrontService salescouponFrontService;
    //每页的最大页容量
    public static final int PAGE_SIZE=3;
    /**
     * 根据商城、状态查询app端优惠券
     * @param request
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param status 0未使用 1已使用 不传查全部
     * @param mv
     * @return
     */
    @RequestMapping(value = "/app/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String getAppSaleCoupons(HttpServletRequest request, String shopid,String status, Model mv) {
        try {
            String lenovoId = SSOUserInfoUtil.getLenovoId(request);
            String memberCode = SSOUserInfoUtil.getLoginname(request);
            String groupCode = SSOUserInfoUtil.getGroupCode(request);
//            String groupCode = "all";
//            String lenovoId = "1005";
//            String memberId = "2f7fcfb6-16e1-4b6e-825e-ea59a9a7a765";
//            String memberCode ="15620954566";
            if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
                groupCode = "all";
            }
            LOGGER.info("The Login info: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode+" shopid="+shopid);
            List<MembercouponrelsApi> usedList = new ArrayList<MembercouponrelsApi>();//已使用优惠券列表
            List<MembercouponrelsApi> unUsedList = new ArrayList<MembercouponrelsApi>();//未使用且未过期优惠券列表
            List<MembercouponrelsApi> expireList = new ArrayList<MembercouponrelsApi>();//已过期且未使用列表
            //绑定全员券
            salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);
            PageQuery pageQuery = new PageQuery(getPage(request), 500);//app暂未做分页，一次最多请求500条
            RemoteResult<PageModel2<MembercouponrelsApi>> re = salescouponFrontService.getAppSaleCoupons(lenovoId,shopid,"3",status,pageQuery);
            if (re != null && re.getT() != null && re.isSuccess()) {
                PageModel2<MembercouponrelsApi> pageModel2 = re.getT();
                List<MembercouponrelsApi> list = pageModel2.getDatas();
                for (MembercouponrelsApi api:list){
                    if (api.getStatus()==1){
                        usedList.add(api);
                        continue;
                    }
                    if (api.getStatus()==0 && api.getTotime().getTime()>new Date().getTime()){
                        unUsedList.add(api);
                        continue;
                    }
                    expireList.add(api);
                }
            }
            sortListByDate(usedList);
            sortListByDate(unUsedList);
            sortListByDate(expireList);
            mv.addAttribute("usedList", usedList);
            mv.addAttribute("unUsedList", unUsedList);
            mv.addAttribute("expireList", expireList);

        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        String terminal = request.getParameter("terminal");
        if ("14".equals(shopid)){
            return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponhsappList";
        }
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponappList";
    }

    private void sortListByDate(List<MembercouponrelsApi> usedList) {
        Collections.sort(usedList, new Comparator<MembercouponrelsApi>() {
            @Override
            public int compare(MembercouponrelsApi o1, MembercouponrelsApi o2) {
                return o2.getCreatetime().compareTo(o1.getCreatetime());
            }
        });
    }

    @RequestMapping(value = "/wap/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String getWapSaleCoupons(HttpServletRequest request, String shopid, String terminal,String status,String page, String time, Model mv) {
        try {
            String lenovoId = SSOUserInfoUtil.getLenovoId(request);
//            String memberId = SSOUserInfoUtil.getMemberId(request);
            String memberCode = SSOUserInfoUtil.getLoginname(request);
            String groupCode = SSOUserInfoUtil.getGroupCode(request);
//            String groupCode = "all";
//            String lenovoId = "10067161490";
//            String memberId = "4ccb63fc-7ab5-4b9b-b3ba-7416ccfbf8e3";
//            String memberCode ="zuoyf2@lenovo.com";

            String host = request.getHeader("host");
            if ("mcoupon.lenovo.com.cn".equals(host)){
                shopid = "1";
            }else if ("m.coupon.thinkworldshop.com.cn".equals(host)||"m.coupon.thinkworld.com.cn".equals(host)){
                shopid = "2";
            }else if("mcoupon.lenovovip.com.cn".equals(host)){
                shopid = "3";
            }else if("mbuy.itplace.com.cn".equals(host)){
                shopid = "14";
            }
            if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
                groupCode = "all";
            }
            LOGGER.info("saleCoupons : lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode+",shopid="+shopid+",page="+page);
            if(StringUtils.isEmpty(lenovoId) ||  StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode) || StringUtils.isEmpty(shopid)){
                mv.addAttribute("canbeUser", 0);//未使用
                mv.addAttribute("InvalueableCount", 0);//已经使用
                mv.addAttribute("expirecount", 0);//已经过期的

                return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponwapList";
            }
            PageQuery pageQuery = new PageQuery(1, PAGE_SIZE);//
            PageModel2 pageModel = null;
            PageModel2 pageModelused = null;
            PageModel2 pageModelexpire = null;
            PaginatedUtils2 paginatedUtils2 = null;//未使用
            PaginatedUtils2 paginatedUtils2used = null;//已使用
            PaginatedUtils2 paginatedUtils2expire = null;//已经过期
            RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;//未使用
            RemoteLenovo<PageModel2<MembercouponrelsApi>> reused = null;//已使用
            RemoteLenovo<PageModel2<MembercouponrelsApi>> reexpire = null;//已经过期
            try {
                //绑定全员券
                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);
                //查询未使用的券
                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, "0",time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                    mv.addAttribute("couponslistPaginated", paginatedUtils2);
                    if(re.getT().getTotalCount() >= getPage(page)*PAGE_SIZE){
                        mv.addAttribute("hasmore", "1");
                    }else {
                        mv.addAttribute("hasmore", "0");
                    }
                    mv.addAttribute("page", page);
                    mv.addAttribute("totalPage", re.getAllCount());//总数
                    mv.addAttribute("canbeUser", re.getCanUserCount());//未使用
                    mv.addAttribute("InvalueableCount", re.getInvalueableCount());//已经使用
                    mv.addAttribute("expirecount", re.getExpireCount());//已经过期的
                    mv.addAttribute("shopid", shopid);
                    mv.addAttribute("terminal", terminal);
                    mv.addAttribute("status", status);
                }
                //已经使用
                reused = salescouponFrontService.getMemberCouponrelsPage4WapUserCenter(lenovoId,shopid,terminal,"1",pageQuery);
                if (reused != null && reused.getT() != null && reused.isSuccess()) {
                    pageModelused = (PageModel2) reused.getT();
                    paginatedUtils2used = new PaginatedUtils2<MembercouponrelsApi>(pageModelused);
                    mv.addAttribute("couponslistPaginatedused", paginatedUtils2used);
                }
                //过期
                reexpire = salescouponFrontService.getMemberCouponrelsPage4WapUserCenter(lenovoId,shopid,terminal,"2",pageQuery);
                if (reexpire != null && reexpire.getT() != null && reexpire.isSuccess()) {
                    pageModelexpire = (PageModel2) reexpire.getT();
                    paginatedUtils2expire = new PaginatedUtils2<MembercouponrelsApi>(pageModelexpire);
                    mv.addAttribute("couponslistPaginatedexpire", paginatedUtils2expire);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }

            mv.addAttribute("shopid", shopid);
            mv.addAttribute("status", 0);
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }

        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponwapList";
    }

    /**
     * 根据商城、状态查询app端优惠券
     * @param request
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param status 0未使用 1已使用 不传查全部
     * @param mv
     * @return
     */
    @RequestMapping(value = "/wap/saleCouponsdata", method = {RequestMethod.POST, RequestMethod.GET})
    public String getWapSaleCouponsdata(HttpServletRequest request, String shopid, String terminal,String status,String page, String time, Model mv) {
        try {
            String lenovoId = SSOUserInfoUtil.getLenovoId(request);
            String memberCode = SSOUserInfoUtil.getLoginname(request);
            String groupCode = SSOUserInfoUtil.getGroupCode(request);

            String host = request.getHeader("host");
            if ("mcoupon.lenovo.com.cn".equals(host)){
                shopid = "1";
            }else if ("m.coupon.thinkworldshop.com.cn".equals(host)||"m.coupon.thinkworld.com.cn".equals(host)){
                shopid = "2";
            }else if("mcoupon.lenovovip.com.cn".equals(host)){
                shopid = "3";
            }else if("mbuy.itplace.com.cn".equals(host)){
                shopid = "14";
            }
            if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
                groupCode = "all";
            }
            LOGGER.info("saleCouponsdata: lenovoId=" + lenovoId +  ", memberCode=" + memberCode + ", groupCode=" + groupCode+",shopid="+shopid+",status="+status+",page="+page);

            PageQuery pageQuery = new PageQuery(Integer.valueOf(page.toString()), PAGE_SIZE);//
            PageModel2 pageModel = null;
            PaginatedUtils2 paginatedUtils2 = null;
            RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
            try {
                //绑定全员券
//                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberId,memberCode,groupCode,shopid);

                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                    mv.addAttribute("couponslistPaginated", paginatedUtils2);
                    if(re.getT().getTotalCount() >= getPage(page)*PAGE_SIZE){
                        mv.addAttribute("hasmore", "1");
                    }else {
                        mv.addAttribute("hasmore", "0");
                    }
                    mv.addAttribute("page", page);
                    mv.addAttribute("totalPage", re.getT().getTotalPageNum());
                    mv.addAttribute("shopid", shopid);
                    mv.addAttribute("terminal", terminal);
                    mv.addAttribute("status", status);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponwapListdata";
    }

    @RequestMapping(value = "/lenovo/obtainimg", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String getImgUrl(String lenovoid) {
        try {
            ResourceBundle resb = ResourceBundle.getBundle("ssocfg", Locale.getDefault());
            String json = HttpClient.executeGet(resb.getString("shop_image_url") + "&lenovoid=" + lenovoid);
            JsonObject jsonObject = JSON.parse(json, JsonObject.class);
            return jsonObject.getBigimg();
        } catch (ParseException e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return null;
    }

    @RequestMapping(value = "/tk/obtainimg", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String getTkImgUrl(String lenovoid) {
        try {
            ResourceBundle resb = ResourceBundle.getBundle("ssocfg", Locale.getDefault());
            String json = HttpClient.executeGet(resb.getString("tk_image_url") + "&lenovoid=" + lenovoid);
            JsonObject jsonObject = JSON.parse(json, JsonObject.class);
            return jsonObject.getBigimg();
        } catch (ParseException e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return null;
    }
    @RequestMapping(value = "/epp/obtainimg", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public String getEppImgUrl(String lenovoid) {
        try {
            ResourceBundle resb = ResourceBundle.getBundle("ssocfg", Locale.getDefault());
            String json = HttpClient.executeGet(resb.getString("epp_image_url") + "&lenovoid=" + lenovoid);
            JsonObject jsonObject = JSON.parse(json, JsonObject.class);
            return jsonObject.getBigimg();
        } catch (ParseException e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return null;
    }

    /**
     * 商城获取优惠卷
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "lenovo/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String getLenovoCouponlist(HttpServletRequest request,String shopid, String terminal, String status, String time, String cur_page, Model mv) {
        //处理传入参数
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        String memberCode = SSOUserInfoUtil.getLoginname(request);
        String groupCode = SSOUserInfoUtil.getGroupCode(request);
//        String groupCode = "all";
//        String lenovoId = "10043606186";
//        String memberCode ="fenglg1@lenovo.com";

        if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
            groupCode = "all";
        }
        shopid ="1";
        terminal="1";
        LOGGER.info("lenovo/saleCoupons: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode);
        cur_page = StringUtils.isBlank(cur_page) ? "1" : cur_page;
        time = StringUtils.isBlank(time) ? "0" : time;
        status = dealstatus(status);
        PageQuery pageQuery = new PageQuery(Integer.valueOf(cur_page.toString()), 5);//
        PageModel2 pageModel = null;
        PaginatedUtils2 paginatedUtils2 = null;
        RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
        if(StringUtils.isEmpty(lenovoId) ||  StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode)){
            re = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        }else {
            try {
                //绑定全员券
                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);

                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }
        }

        //页面参数处理
        PageShowBean pageBean = getPageShowBean(cur_page, time, status, memberCode, lenovoId, re);
        //返回页面
        mv.addAttribute("paginatedUtils", paginatedUtils2);
        mv.addAttribute("pageBean", pageBean);

        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponlenovoList";

    }


    /**
     * SMB商城
     * @param request
     * @param shopid
     * @param terminal
     * @param status
     * @param time
     * @param cur_page
     * @param mv
     * @return
     */
    @RequestMapping(value = "smb/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String getSMBCouponlist(HttpServletRequest request,String shopid, String terminal, String status, String time, String cur_page, Model mv) {
        //处理传入参数
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        String memberCode = SSOUserInfoUtil.getLoginname(request);
        String groupCode = SSOUserInfoUtil.getGroupCode(request);
//        String lenovoId = "10077449573";
//        String memberCode = "yuzn1@lenovo.com";
//        String groupCode = "all";
        if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
            groupCode = "all";
        }
        shopid ="8";
        terminal="1";
        LOGGER.info("smb/saleCoupons: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode);
        cur_page = StringUtils.isBlank(cur_page) ? "1" : cur_page;
        time = StringUtils.isBlank(time) ? "0" : time;
        status = dealstatus(status);
        PageQuery pageQuery = new PageQuery(Integer.valueOf(cur_page.toString()), 5);//
        PageModel2 pageModel = null;
        PaginatedUtils2 paginatedUtils2 = null;
        RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
        if(StringUtils.isEmpty(lenovoId) ||  StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode)){
            re = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        }else {
            try {
                //绑定全员券
                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);

                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }
        }

        //页面参数处理
        PageShowBean pageBean = getPageShowBean(cur_page, time, status, memberCode, lenovoId, re);
        //返回页面
        mv.addAttribute("paginatedUtils", paginatedUtils2);
        mv.addAttribute("pageBean", pageBean);
        logger.info("请求成功：paginatedUtils2 = " + ToStringBuilder.reflectionToString(paginatedUtils2) + "pageBean=" + ToStringBuilder.reflectionToString(pageBean));
//        return "/couponSMB/couponSMBList";
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponSMBList";

    }

    @RequestMapping(value = "mbuy/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String getMBuyCouponlist(HttpServletRequest request,String shopid, String terminal, String status, String time, String cur_page, Model mv) {
        //处理传入参数
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        String memberCode = SSOUserInfoUtil.getLoginname(request);
        String groupCode = SSOUserInfoUtil.getGroupCode(request);
        if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
            groupCode = "all";
        }
        shopid ="14";
        terminal="1";
        LOGGER.info("mbuy/saleCoupons: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode);
        cur_page = StringUtils.isBlank(cur_page) ? "1" : cur_page;
        time = StringUtils.isBlank(time) ? "0" : time;
        status = dealstatus(status);
        PageQuery pageQuery = new PageQuery(Integer.valueOf(cur_page.toString()), 5);//
        PageModel2 pageModel = null;
        PaginatedUtils2 paginatedUtils2 = null;
        RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
        if(StringUtils.isEmpty(lenovoId) ||  StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode)){
            re = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        }else {
            try {
                //绑定全员券
                //salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);

                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }
        }

        //页面参数处理
        PageShowBean pageBean = getPageShowBean(cur_page, time, status, memberCode, lenovoId, re);
        //返回页面
        mv.addAttribute("paginatedUtils", paginatedUtils2);
        mv.addAttribute("pageBean", pageBean);
        LOGGER.info("请求成功：paginatedUtils2 = " + ToStringBuilder.reflectionToString(paginatedUtils2) + "pageBean=" + ToStringBuilder.reflectionToString(pageBean));
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/couponMBuyList";
    }

    /**
     * think商城获取优惠卷
     *
     * @param request
     * @return
     */
//    @RequestMapping(value = "tklenovo/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
//    public String gettkLenovoCouponlist(HttpServletRequest request,String shopid, String terminal, String status, String time, String cur_page, Model mv) {
//        //处理传入参数
//        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
////        String lenovoId = "10074780393";
////        String memberid = SSOUserInfoUtil.getMemberId(request);
//        String memberCode = SSOUserInfoUtil.getLoginname(request);
////        String memberCode = "changliang3@lenovo.com";
////        String memberid = "c10a0557-f56c-463a-aa01-6883707a62a7";
//        String groupCode = SSOUserInfoUtil.getGroupCode(request);
////        String groupCode ="groupCode";
//        if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
//            groupCode = "all";
//        }
//        shopid ="2";
//        terminal="1";
//        LOGGER.info("tklenovo/saleCoupons: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode);
//
//        cur_page = StringUtils.isBlank(cur_page) ? "1" : cur_page;
//        time = StringUtils.isBlank(time) ? "0" : time;
//        status = dealstatus(status);
//        PageQuery pageQuery = new PageQuery(Integer.valueOf(cur_page.toString()), 5);//app暂未做分页，一次最多请求500条
//        PageModel2 pageModel = null;
//        PaginatedUtils2 paginatedUtils2 = null;
//        RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
//        if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode)){
//            re = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
//        }else {
//            try {
//                //绑定全员券
//                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);
//
//                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
//                if (re != null && re.getT() != null && re.isSuccess()) {
//                    pageModel = (PageModel2) re.getT();
//                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
//                }
//            } catch (Exception e) {
//                LOGGER.error(ExceptionUtil.getStackTrace(e));
//            }
//        }
//
//        //页面参数处理
//        PageShowBean pageBean = getPageShowBean(cur_page, time, status, memberCode, lenovoId, re);
//        //返回页面
//        mv.addAttribute("paginatedUtils", paginatedUtils2);
//        mv.addAttribute("pageBean", pageBean);
//
//        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"/coupontk/tkcouponlenovoList";
//
//    }

    /**
     * think商城获取优惠卷
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "epplenovo/saleCoupons", method = {RequestMethod.POST, RequestMethod.GET})
    public String geteppLenovoCouponlist(HttpServletRequest request,String shopid, String terminal, String status, String time, String cur_page, Model mv) {
        //处理传入参数
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
//        String lenovoId = "10074780393";
//        String memberid = SSOUserInfoUtil.getMemberId(request);
        String memberCode = SSOUserInfoUtil.getLoginname(request);
//        String memberCode = "changliang3@lenovo.com";
//        String memberid = "c10a0557-f56c-463a-aa01-6883707a62a7";
        String groupCode = SSOUserInfoUtil.getGroupCode(request);
//        String groupCode ="groupCode";
        if (!"3".equals(shopid)){//非epp用户组默认为all 3代表epp
            groupCode = "all";
        }
        shopid ="3";
        terminal="1";
        LOGGER.info("The Login info: lenovoId=" + lenovoId + ", memberCode=" + memberCode + ", groupCode=" + groupCode);
        cur_page = StringUtils.isBlank(cur_page) ? "1" : cur_page;
        time = StringUtils.isBlank(time) ? "0" : time;
        status = dealstatus(status);
        logger.info("***********the input value memberid is:: "  + "*" + lenovoId + "*" + groupCode);
        PageQuery pageQuery = new PageQuery(Integer.valueOf(cur_page.toString()), 5);//app暂未做分页，一次最多请求500条
        PageModel2 pageModel = null;
        PaginatedUtils2 paginatedUtils2 = null;
        RemoteLenovo<PageModel2<MembercouponrelsApi>> re = null;
        if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(memberCode) || StringUtils.isEmpty(groupCode)){
            re = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        }else {
            try {
                //绑定全员券
                salescouponFrontService.bindAllMemberSalesCoupons(lenovoId,memberCode,groupCode,shopid);

                re = salescouponFrontService.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status,time, pageQuery);
                if (re != null && re.getT() != null && re.isSuccess()) {
                    pageModel = (PageModel2) re.getT();
                    paginatedUtils2 = new PaginatedUtils2<MembercouponrelsApi>(pageModel);
                }
            } catch (Exception e) {
                LOGGER.error(ExceptionUtil.getStackTrace(e));
            }
        }

        //页面参数处理
        PageShowBean pageBean = getPageShowBean(cur_page, time, status, memberCode, lenovoId, re);
        //返回页面
        mv.addAttribute("paginatedUtils", paginatedUtils2);
        mv.addAttribute("pageBean", pageBean);

        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(terminal))+"coupon/eppcouponlenovoList";

    }

    private PageShowBean getPageShowBean(String cur_page, String time, String status, String lenovoName, String lenovoid, RemoteLenovo remoteResult) {
        PageShowBean pageBean = new PageShowBean();
        String ss = StringUtils.isBlank(status) ? "4" : status;
        pageBean.setStatus(ss);
        pageBean.setTime(time);
        pageBean.setPageNum(cur_page);
        pageBean.setLenovoName(StringUtils.isBlank(lenovoName) ? "0" : lenovoName);
        pageBean.setLenovoId(StringUtils.isBlank(lenovoid) ? "0" : lenovoid);
        if (remoteResult != null){
            pageBean.setAllCount(remoteResult.getAllCount() == null ? 0 : remoteResult.getAllCount());
            pageBean.setCanUserCount(remoteResult.getCanUserCount() == null ? 0 : remoteResult.getCanUserCount());
            pageBean.setInvalueableCount(remoteResult.getInvalueableCount() == null ? 0 : remoteResult.getInvalueableCount());
            pageBean.setExpireCount(remoteResult.getExpireCount() == null ? 0 : remoteResult.getExpireCount());
        }
        return pageBean;
    }

    private String dealstatus(String status){
        if(StringUtil.isEmpty(status)||"4".equals(status)){
            return null; //查询全部的券
        }
        return status;
    }
    //获取页码
    public int getPage(String page) {
        if(page==null){
            return 1;
        }
        return Integer.parseInt(page);
    }
}