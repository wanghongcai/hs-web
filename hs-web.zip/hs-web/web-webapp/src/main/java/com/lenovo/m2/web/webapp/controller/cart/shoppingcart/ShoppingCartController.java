package com.lenovo.m2.web.webapp.controller.cart.shoppingcart;

import com.lenovo.enums.ENUM;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.cart.CartService;
import com.lenovo.m2.hsbuy.common.enums.ShopIdEnum;
import com.lenovo.m2.hsbuy.domain.cart.*;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.my.utils.*;
import com.lenovo.m2.web.common.purchase.annotation.CheckRefer;
import com.lenovo.m2.web.common.purchase.annotation.NeedLogin;
import com.lenovo.m2.web.common.purchase.constants.ViewConstants;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.domain.my.order.ServiceProductListForReturn;
import com.lenovo.m2.web.webapp.controller.BaseController;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.velocity.VelocityConfigurer;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author wangrq1
 *
 */
@Controller
public class ShoppingCartController extends BaseController implements ApplicationContextAware {

    @Resource
    private CartService shoppingCartService;
    
    private static Integer SUCCESS = 0;
    private static Integer FAILED = 1;

    private static final String BUYTYPE_DIRECTBUY = "1";
    
    private static final String BUYTYPE_DIRECTPAY = "2";
    
    public static Logger log =  LogManager.getLogger(ShoppingCartController.class.getName());


    /**
     * 购物车-添加行 向购物车添加行（添加的行可能是个商某品，也可能是主商品+选件的组合 套餐）
     *
     *  opgcode
     *            可选赠品code	多个拿逗号(,)分隔,如果没有传""或者null
     *  plat
     *            平台号 1:wap, 2:weixin, 3:app, 4:pc
     *  itemtype  购物行类型
     * 			0	购买普通商品，没有赠品或者可选赠品
     *			1	购物带赠品或者可选赠品的商品
     *			2	表示选件搭售
     *			3	表示购买套餐
     *			4	立即购买	(不带赠品或者可选赠品)
     *			5	立即购买	(带赠品或者可选赠品)	(立即购买不支持选件搭售和套餐)
     *			6	表示通过sn购买服务 (服务都属于单品)
     *			7	标识批量购买(只支持单品)
     *  gcodes商品值
     * 		            商品code集合	格式：code,code	多个以逗号分隔，如格式："60021,60023"
     *          itemtype =0|4：gcodes 单个商品code 例如：60021
     *          itemtype =1|5：gcodes首个为主品，后面的为赠品 	例如：60021(主),50001(赠),50002(赠)
     *          itemtype =2：gcodes	商品的code集合	首个为主品，后面的为选件 例如：60021(主),60023(选件),60023(选件)
     *          itemtype =3：gcodes  表示套餐id 例如 d00c60d5-109c-4426-8073-823a050d5365
     *  servicecode
     * 			 服务商品code	格式：code,code	多个以逗号分隔
     *  shopcomefrom
     * 			 商户来源	暂不详
     *  icounts
     *            购买数量（如果gcodes内条目是一个则代表的是购买的此商品的数据，如果是多个则代表的是购买的组合或套餐的数量）
     * @return
     */
    @RequestMapping(value = "/additemtocart", produces = "application/json; charset=UTF-8")
    @CheckRefer
    public @ResponseBody String addItemToCart(AddToCartEntity entity, HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        BasePara b  = getBasePara();
//        if(!getUser(b.getUser())){
//            //  return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
//            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
//        }
    	copyBasePara(b, entity);
        Integer type = 0;
        String name = "";
        StringBuffer sb = new StringBuffer();
        if(b.getBeemobile() != null && !"".equals(b.getBeemobile())){
            type = 3;
        }else{
            for(Cookie c:cookies){
                sb.append(c.getName()+":"+c.getValue()+" | ");
                name = c.getName();
                if("wi".equals(name)||"cid".equals(name)||"target".equals(name)||"channel".equals(name)
                        ||"source".equals(name)){
                    type = 2;
                }
            }
            if(type !=2){
                sb = new StringBuffer();
                for(Cookie c:cookies){
                    sb.append(c.getName()+":"+c.getValue()+" | ");
                    name = c.getName();
                    if("c2clenovo".equals(name)){
                        type = 1;
                    }
                }
            }
        }
        log.info("additemtocart - cookie 值为{}",sb.toString());
        if(type == 3){
            entity.setComefrom("3");
        }else if(type == 1){
            entity.setComefrom("2");
        }else if(type == 2){
            entity.setComefrom("1");
        }else{
            entity.setComefrom("0");
        }
        log.info("additemtocart - 参数 tenant:{} ,entity:{}",getTenant(),JsonUtil.toJson(entity));

        //增加对闪购商品和限时抢购商品的判断，防范提前抢购
        String ss = request.getParameter("ss");
        String code = entity.getGcodes();
        log.info("additemtocart - 参数 code:{},ss:{}",code,ss);
        if(null!=ss && !"".equals(ss) && null!=code && !"".equals(code)){
            String activityType = "";
            Long buyStartTime = 0L;
            //测试：http://shop.17.lenovouat.com/cache/detail?code=xxx&ss=xxx
            //生产：https://shop.baiying.cn/cache/detail?code=xxx&ss=xxx
            String url = CustomizedPropertyConfigurer.getContextProperty("lenovo.shop.detail")+"?code="+code+"&ss="+ss;
            String jsonStr = HttpClientUtil.getStrs(url);
            log.info("additemtocart - 参数 resultStr:{}",jsonStr);
            String regex = "\"activityType\":(.*?)\\s*(,|})";
            Matcher matcher= Pattern.compile(regex).matcher(jsonStr);
            if(matcher.find()){
                activityType = matcher.group(1);
            }
            log.info("additemtocart - 参数 activityType:{}",activityType);
            regex = "\"buyStartTime\":(.*?)\\s*(,|})";
            matcher= Pattern.compile(regex).matcher(jsonStr);
            if(matcher.find()){
                buyStartTime = Long.parseLong(matcher.group(1));
            }
            log.info("additemtocart - 参数 buyStartTime:{}",buyStartTime);
            //activityType=2 闪购商品；activityType=3 限时促销商品
            if(("2".equals(activityType) || "3".equals(activityType)) && buyStartTime!=0){
                //如果当前时间在闪购或限时促销开始时间之前，返回错误
                if(System.currentTimeMillis()<buyStartTime){
                    String callbackparams = entity.getCallbackparam();
                    return JsonUtil.toJson(new FpsResult(1, "不允许提前抢购"), callbackparams);
                }
            }
        }

        RemoteResult<CartNG> result = shoppingCartService.addItemToCart(getTenant(),entity);
        String callbackparam = entity.getCallbackparam();
        return JsonUtil.toJson(new FpsResult(result, PromptEnum.CHECKOUT), callbackparam);
    }


    /**
     * 购物车-立即购买
     *
     *  opgcode
     *            可选赠品code	多个拿逗号(,)分隔,如果没有传""或者null
     *  plat
     *            平台号 1:wap, 2:weixin, 3:app, 4:pc
     *  itemtype  购物行类型
     * 			0	购买普通商品，没有赠品或者可选赠品
     *			1	购物带赠品或者可选赠品的商品
     *			2	表示选件搭售
     *			3	表示购买套餐
     *			6	表示通过sn购买服务 (服务都属于单品)
     *			7	标识批量购买(只支持单品)
     *  gcodes商品值
     * 		            商品code集合	格式：code,code	多个以逗号分隔，如格式："60021,60023"
     *          itemtype =0|4：gcodes 单个商品code 例如：60021
     *          itemtype =1|5：gcodes首个为主品，后面的为赠品 	例如：60021(主),50001(赠),50002(赠)
     *          itemtype =2：gcodes	主品code集合	例如：60021(主),60023(主),
     *          itemtype =3：gcodes  表示套餐id 例如 d00c60d5-109c-4426-8073-823a050d5365
     *  servicecode
     * 			 服务商品code	格式：code,code	多个以逗号分隔
     *  shopcomefrom
     * 			 商户来源	暂不详
     *  icount
     *            购买数量（如果gcodes内条目是一个则代表的是购买的此商品的数据，如果是多个则代表的是购买的组合或套餐的数量）
     *
     */
    @RequestMapping(value = "/directbuy"/* ,method=RequestMethod.GET */)
    @NeedLogin
    public ModelAndView directbuy(AddToCartEntity entity, HttpServletResponse response,HttpServletRequest request) {
        log.info("<===========directbuy - 参数 entity:{},param:{}===========>",JsonUtil.toJson(entity),request.getParameterMap());
        int terminal = entity.getTerminal();
        try {
            BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                ModelAndView mav = new ModelAndView(ViewConstants.getCommonErrorPath(base.getTerminal()));
                //mav.addObject("detail", ErrorMessageEnum.ERROR_USER_ILLEGAL.getCommon());
                mav.addObject("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL").getCommon());
                return mav;
            }
            if(entity.getPersonalization() != null && !"".equals(entity.getPersonalization())){
                String personlization = entity.getPersonalization();
                log.info("personlization 1--------------{}",personlization);
                personlization = personlization.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
                personlization = personlization.replaceAll("\\+", "%2B");
                log.info("personlization 2--------------{}",personlization);
                String newPersonlization = null;
                    newPersonlization = URLDecoder.decode(personlization,"UTF-8");
                entity.setPersonalization(newPersonlization);
                log.info("Personalization old:{},new:{}",personlization,newPersonlization);

            }
            copyBasePara(base, entity);
            Cookie[] cookies = request.getCookies();
            Integer type = 0;
            String name = "";
            StringBuffer sb = new StringBuffer();
            if(base.getBeemobile() != null && !"".equals(base.getBeemobile())){
                type = 3;
            }else{
                for(Cookie c:cookies){
                    sb.append(c.getName()+":"+c.getValue()+" | ");
                    name = c.getName();
                    if("wi".equals(name)||"cid".equals(name)||"target".equals(name)||"channel".equals(name)
                            ||"source".equals(name)){
                        type = 2;
                    }
                }
                if(type !=2){
                    sb = new StringBuffer();
                    for(Cookie c:cookies){
                        sb.append(c.getName()+":"+c.getValue()+" | ");
                        name = c.getName();
                        if("c2clenovo".equals(name)){
                            type = 1;
                        }
                    }
                }
            }
            log.info("directbuy - cookie 值为{}",sb.toString());
            if(type == 3){
                entity.setComefrom("3");
            }else if(type == 1){
                entity.setComefrom("2");
            }else if(type == 2){
                entity.setComefrom("1");
            }else{
                entity.setComefrom("0");
            }
        	boolean dongde = false;
        	if(StringUtils.isNotEmpty(entity.getDpackageId()) && StringUtils.isNotEmpty(entity.getPhoneServiceNumber())){
        		dongde = true;
        	}
        	RemoteResult<String> result = null;
            log.info("directbuy - 参数 tenant:{},entity:{}",getTenant(),JsonUtil.toJson(entity));

            result = shoppingCartService.directBuy(getTenant(),entity);

            log.info("directbuy result:{}",JsonUtil.toJson(result));
            if("0".equals(result.getResultCode()) ){
                String url = getOrderUrl(getTenant().getShopId(), terminal, dongde);
                if(dongde){
                	url = String.format("%s?phoneServiceNumber=%s&buyType=%s&softReservationId=%s", url, entity.getPhoneServiceNumber(), BUYTYPE_DIRECTBUY, result.getT());
                }else if("6".equals(entity.getItemtype())){
                	url = String.format("%s?terminal=%s&buyType=%s", url, terminal, BUYTYPE_DIRECTPAY);
                }else{
                	url = String.format("%s?terminal=%s&buyType=%s", url, terminal, BUYTYPE_DIRECTBUY);
                }
                response.sendRedirect(url);
                return null;
            }else{
                ModelAndView mav = new ModelAndView(ViewConstants.getCommonErrorPath(terminal));
                mav.addObject("detail", result.getResultMsg());
                return mav;
            }
        }catch(Exception e){
            logger.error("directbuy 异常", e);
            return new ModelAndView(ViewConstants.getCommonErrorPath(terminal));
        }

    }

    private static final String SUBMIT_ORDER_URI = "/checkout.jhtm";
    private static final String SUBMIT_ORDER_WAP_URI = "/checkout.jhtm";
    private static final String SUBMIT_ORDER_DONGDE_URI = "/toIdentity.jhtm";
    

    private String getOrderUrl(int shopid, Integer terminal){
        String url = "";
        if(ShopIdEnum.isB2C(shopid)){
            if(Terminal.isPC(terminal)){
                url = CustomizedPropertyConfigurer.getContextProperty("b2c.pc.home.url") + SUBMIT_ORDER_URI;
            }else{
                url = CustomizedPropertyConfigurer.getContextProperty("b2c.wap.home.url") + SUBMIT_ORDER_WAP_URI;
            }
        }else if(ShopIdEnum.isThink(shopid)){
            if(Terminal.isPC(terminal)){
                url = CustomizedPropertyConfigurer.getContextProperty("think.pc.home.url") + SUBMIT_ORDER_URI;
            }else{
                url = CustomizedPropertyConfigurer.getContextProperty("think.wap.home.url")+ SUBMIT_ORDER_WAP_URI;
            }
        }else if(ShopIdEnum.isEpp(shopid)){
            if(Terminal.isPC(terminal)){
                url = CustomizedPropertyConfigurer.getContextProperty("epp.pc.home.url") +  SUBMIT_ORDER_URI;
            }else{
                url = CustomizedPropertyConfigurer.getContextProperty("epp.wap.home.url")+  SUBMIT_ORDER_WAP_URI;
            }
        }else if(ShopIdEnum.isSmb(shopid)){
        	url = CustomizedPropertyConfigurer.getContextProperty("smb.pc.home.url") +  SUBMIT_ORDER_URI;
        }else if(ShopIdEnum.isSmb_Score(shopid)){
        	url = CustomizedPropertyConfigurer.getContextProperty("smb.score.pc.home.url") +  SUBMIT_ORDER_URI;
        }else if(ShopIdEnum.isHuiShang(shopid)){
            if(Terminal.isPC(terminal)){
                url =CustomizedPropertyConfigurer.getContextProperty("hs.pc.home.url") +SUBMIT_ORDER_URI;
            }else{
                url = CustomizedPropertyConfigurer.getContextProperty("hs.wap.home.url")+SUBMIT_ORDER_URI;
            }
        }
        return url;
    }
    
    
    private String getOrderUrl(int shopid, Integer terminal, boolean dongde){
    	if(dongde){
    		return CustomizedPropertyConfigurer.getContextProperty("b2c.pc.home.url") +  SUBMIT_ORDER_DONGDE_URI;
    	}else{
    		return getOrderUrl(shopid, terminal);
    	}
    	
    }


    /**
     * 购物车-删除行 从购物车删除行
     * author mahao -->已完成
     */
    @RequestMapping(value = "/deleteitemfromcart"/* ,method=RequestMethod.GET */,produces = "application/json; charset=utf-8")
    @CheckRefer
    public @ResponseBody String deleteItemFromCart(DelItemEntity entity){
    	BasePara base = getBasePara();
        if(!getUser(base.getUser())){
           // return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
        }
    	copyBasePara(base, entity);
        RemoteResult<CartNG> result =  shoppingCartService.delItemByIds(getTenant(),entity);
        CartNG cart = result.getT();
        String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty(), false, getTenant().getShopId());
        String html = "";
        if (cart.isEmpty()){
            html = merge( getTenant().getShopId(), entity.getTerminal(), templat, "terminal", entity.getTerminal());
        }else{
            html = merge( getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
        }

        Map<String,Object> ret = new HashMap<>();
        ret.put("rc", 0);
        ret.put("html", html);
        return toJson(ret);
    }

    /**
     * 购物车-清空购物车 清空购物车
     * author mahao -->已完成
     */
    @RequestMapping(value = "/deleteallitemfromcart"/* ,methlod=RequestMethod.GET */)
    @ResponseBody 
    public String deleteAllItemFromCart(EmptyCartEntity entity) {
    	BasePara base = getBasePara();
        if(!getUser(base.getUser())){
            //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
        }
    	copyBasePara(base, entity);
        RemoteResult<CartNG> res = shoppingCartService.emptyCart(getTenant(),entity);
        CartNG cart = res.getT();
        String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty(), false, getTenant().getShopId());
        String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
        Map<String,Object> ret = new HashMap<>();
        ret.put("rc", 0);
        ret.put("html", html);
        return toJson(ret);
    }
    
    
    
    /**
     * 购物车-清空购物车 清空购物车
     * author mahao -->已完成
     */
    @RequestMapping(value = "/activeAll"/* ,methlod=RequestMethod.GET */)
    @ResponseBody 
    public String activeAll(EmptyCartEntity entity) {
    	BasePara base = getBasePara();
        if(!getUser(base.getUser())){
           // return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
        }
    	copyBasePara(base, entity);
        RemoteResult<CartNG> res = shoppingCartService.emptyCart(getTenant(),entity);
        CartNG cart = res.getT();
        String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty(), false,getTenant().getShopId());
        String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
        Map<String,Object> ret = new HashMap<>();
        ret.put("rc", 0);
        ret.put("html", html);
        return toJson(ret);
    }
    
    

    /**
     * 购物车-修改行数量 修改购物车行数量
     * author mahao -->已完成
     */
    @RequestMapping(value = "/modifycaritemcount"/* ,method=RequestMethod.GET */ , produces = "application/json; charset=utf-8")
    public @ResponseBody String modifyCarItemCount(ModifyItemNumEntity entity) {
        try{
        	BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
        	copyBasePara(base, entity);
            RemoteResult<CartNG> result =  shoppingCartService.modifyCarItemNum(getTenant(),entity);
            if(!"0".equals(result.getResultCode()) ){
            	return toJson(new FpsResult(result, PromptEnum.CHECKOUT));
            }
            CartNG cart = result.getT();
            String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty(), false, getTenant().getShopId());
            String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
            Map<String,Object> ret = new HashMap<>();
            ret.put("rc", 0);
            ret.put("html", html);
            return toJson(ret);
        }catch(Exception e){
            logger.error("",e);
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }


    /**
     * 更新行服务
     */
    @RequestMapping(value = "/updateitemservice"/* ,method=RequestMethod.GET */ , produces = "application/json; charset=utf-8")
    public @ResponseBody String upateItemService(UpdateItemServiceEntity entity) {
        try{
        	BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
        	copyBasePara(base, entity);
            RemoteResult<CartNG> result =  shoppingCartService.updateItemService(getTenant(),entity);
//            CartApiResult result = JsonUtil.fromJson(res, CartApiResult.class);
            CartNG cart = result.getT();
            String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty() ,false, getTenant().getShopId());
            String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
            Map<String,Object> ret = new HashMap<>();
            ret.put("rc", 0);
            ret.put("html", html);
            return toJson(ret);
        }catch(Exception e){
        	logger.error("upateItemService error", e);
            return toJson(BaseInfo.fail());
        }
    }


    /**
     *
     * @param --plat  平台号
     * @param --itemid   购物行id
     * @param --servicecode 要删除的服务编码
     * @return
     * @author wangrq1
     */
       @RequestMapping(value = "/deleteservice", produces = "application/json; charset=utf-8")
       public @ResponseBody String deleteService(DelItemServiceEntity entity) {
        try{
        	BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
        	copyBasePara(base, entity);
            RemoteResult<CartNG> result =  shoppingCartService.deleteItemService(getTenant(),entity);
//            CartApiResult result = JsonUtil.fromJson(res, CartApiResult.class);
            CartNG cart = result.getT();
            String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty() ,false, getTenant().getShopId());
            String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", cart);
            Map<String,Object> ret = new HashMap<>();
            ret.put("rc", 0);
            ret.put("html", html);
            return toJson(ret);
        }catch(Exception e){
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }



    /**
     * 购物车-获取购物车 获取购物车信息
     *
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    @RequestMapping(value = "/getcart"/* ,method=RequestMethod.GET */)
    public ModelAndView getCart(HttpServletResponse response) {
        ModelAndView mav = new ModelAndView();
        BasePara para = getBasePara();
//        if(!getUser(para.getUser())){
//            ModelAndView mav1 = new ModelAndView(ViewConstants.getCommonErrorPath(para.getTerminal()));
//            //mav1.addObject("detail", ErrorMessageEnum.ERROR_USER_ILLEGAL.getCommon());
//            mav1.addObject("detail", ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL").getCommon());
//            return mav1;
//        }
        GetCartNGEntity entity = new GetCartNGEntity();
    	copyBasePara(para, entity);

        User u = para.getUser();

        mav.addObject("islenovo", u.isLenovo());
        
        mav.addObject("cartSingleRowLimit", getCartSingleRowLimit(para.getShopId()));

        try {
//            if(ENUM.MallType.EPP.getCode() == para.getShopId()){
//                initHeadParam(mav);
//            }
            log.info("cart entity:{},tenant:{}",JsonUtil.toJson(entity),getTenant());
            RemoteResult<CartNG> result = shoppingCartService.getCart(getTenant(),entity);

            CartNG cart = result.getT();

            log.info("cart return {}", JsonUtil.toJson(cart));
            if(cart!=null && !cart.isEmpty()){
                mav.setViewName(ViewConstants.getShopingCardPath(para.getShopId(), para.getTerminal()));
                mav.addObject("cart", cart);
            }else{
                mav.setViewName(ViewConstants.getShopingCardEmptyPath(para.getShopId(), para.getTerminal()));
            }
            //禁止服务器端缓存，点击浏览器前进、后退键时刷新页面而不读取缓存
            response.setHeader("Pragma", "No-cache");
            response.setHeader("Cache-Control", "No-cache");
            response.setDateHeader("Expires", -1);
            response.setHeader("Cache-Control", "No-store");
            //end
            return mav;
        } catch (Exception e) {
            log.error("getcart异常", e);
            mav.setViewName(ViewConstants.getCommonErrorPath(para.getShopId()));
            return mav;
        }
    	/*
    	 */

    }

    private int getCartSingleRowLimit(int shopId){
    	if(shopId == ShopIdEnum.SMB.getType()){
    		return 999;
    	}else{
    		return 5;
    	}
    }

    @ResponseBody
    @RequestMapping(value = "/activeItem" , produces = "application/json; charset=utf-8")
    public String activeItem(ActiveItemEntity entity){
        try{
        	BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
        	copyBasePara(base, entity);
            RemoteResult<CartNG> result = shoppingCartService.activeItem(getTenant(),entity);
            CartNG cart = result.getT();
            
            String template = ViewConstants.getAjaxCartTemplate(entity.getTerminal(), cart.isEmpty(), false, getTenant().getShopId());
            String html =  merge(getTenant().getShopId(), entity.getTerminal(), template, "cart", cart);
            Map map = ajaxMap(SUCCESS, "");
            map.put("html", html);
            String returnStr = toJson(map);
            log.info("activeItem return:{}",returnStr);
            return returnStr;
        }catch(Exception e){
            logger.error("activeItem异常", e);
            return toJson(new BaseInfo(1,e.getMessage()));
        }
    }

//
//    private void initHeadParam(ModelAndView mav){
//        mav.addObject("epp_regist_url", CustomizedPropertyConfigurer.getContextProperty("epp.regist.url"));
//        mav.addObject("epp_active_url", CustomizedPropertyConfigurer.getContextProperty("epp.active.url"));
//        mav.addObject("epp_waplogin_url", CustomizedPropertyConfigurer.getContextProperty("epp.waplogin.url"));
//        mav.addObject("geteppuserinfo_url", CustomizedPropertyConfigurer.getContextProperty("geteppuserinfo.url"));
//        mav.addObject("epp_ticked", CustomizedPropertyConfigurer.getContextProperty("epp.ticked"));
//    }

    //获取购物车商品数量
    @RequestMapping("/getshoppingcartcount")
    @ResponseBody
    public String getshoppingcartcount(GetCartCountEntity entity){
    	BasePara base = getBasePara();
        if(!getUser(base.getUser())){
            //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
        }
    	copyBasePara(base, entity);
    	try{
            log.info("getshoppingcartcount param:tenant:{},entity:{}",JsonUtil.toJson(getTenant()),JsonUtil.toJson(entity));
    		RemoteResult<Integer> result = shoppingCartService.getCartCount(getTenant(),entity);
    		Map map = ajaxMap(Integer.parseInt(result.getResultCode()), result.getResultMsg());
    		map.put("count", result.getT());
    		return toJson(map, entity.getCallbackparam());
    	}catch(Exception e){
    		logger.error("",e);
    		Map map = ajaxMap(FAILED, e.getMessage());
    		return toJson(map,entity.getCallbackparam());
    	}
    }




    
    private Map<String, Object> ajaxMap(int rc, String msg){
    	Map<String,Object> map = new HashMap<>();
    	map.put("rc", rc);
    	map.put("msg", msg);
    	return map;
    }


    private ApplicationContext context;


	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.context = arg0;
	}
	
	private String merge(int shopid, Integer terminal, String template, String key, Object obj){ //todo 为了找的时候方便，看看是咋做的 ---mahao
		VelocityConfigurer vconfig = (VelocityConfigurer)context.getBean("velocityConfigurer");
		VelocityEngine ve = vconfig.getVelocityEngine();
		Template t = ve.getTemplate(template);
		t.setEncoding("utf-8");
		VelocityContext context = new VelocityContext();
		exposeToolAttributes(shopid, terminal, context);
		StringWriter writer = new StringWriter();
		context.put(key, obj);
		t.merge(context, writer);
		return writer.toString();
	}
	
	private void exposeToolAttributes(int shopid, int terminal, VelocityContext velocityContext) {
		// Expose generic attributes.
		HashMap<String,Object> urls = (HashMap<String,Object>)context.getBean("velocityUrl");
		if (urls != null) {
			for (Map.Entry<String, Object> entry : urls.entrySet()) {
				String attributeName = entry.getKey();
				Object toolClass = entry.getValue();
				velocityContext.put(attributeName, toolClass);
			}
		}

        velocityContext.put("shopId",shopid);
		if(ShopIdEnum.isB2C(shopid)){
			if(ENUM.BigPlatform.PC.getCode() == terminal){
				velocityContext.put("product_index", urls.get("b2cProductIndexModule"));
                velocityContext.put("product_index_https", urls.get("b2cProductIndexModuleHttps"));
			//	velocityContext.put("product_detail", urls.get("b2cProductDetailModule"));
			}else{
				velocityContext.put("product_index", urls.get("wapB2cProductIndexModule"));
                velocityContext.put("product_index_https", urls.get("wapB2cProductIndexModuleHttps"));
			//	velocityContext.put("product_detail", urls.get("wapB2cProductDetailModule"));
            //    velocityContext.put("product_detail_thinkwap", urls.get("wapThinkProductDetailModuleNew"));
           //     velocityContext.put("product_detail_thinkwap_android", urls.get("wapThinkProductDetailModuleNewAndroid"));
			}
		}else if(ShopIdEnum.isThink(shopid)){
			if(ENUM.BigPlatform.PC.getCode() == terminal){
				velocityContext.put("product_index", urls.get("thinkProductIndexModule"));
			//	velocityContext.put("product_detail", urls.get("thinkProductDetailModule"));
			}else{
				velocityContext.put("product_index", urls.get("wapThinkProductIndexModule"));
			//	velocityContext.put("product_detail", urls.get("wapThinkProductDetailModule"));
			}
		}else if(ShopIdEnum.isEpp(shopid)){
			if(ENUM.BigPlatform.PC.getCode() == terminal){
				velocityContext.put("product_index", urls.get("eppProductIndexModule"));
			//	velocityContext.put("product_detail", urls.get("eppProductDetailModule"));
			}else{
				velocityContext.put("product_index", urls.get("wapEppProductIndexModule"));
			//	velocityContext.put("product_detail", urls.get("wapEppProductDetailModule"));
			}
		}else if(ShopIdEnum.isSmb(shopid)){   //wap端没有17lenovo
            if(ENUM.BigPlatform.PC.getCode() == terminal){
                velocityContext.put("product_index", urls.get("s17ProductIndexModule"));
             //   velocityContext.put("product_detail", urls.get("s17ProductDetailModule"));
            }
        }else if(ShopIdEnum.isHuiShang(shopid)){
            if(ENUM.BigPlatform.WAP.getCode() == terminal){
                velocityContext.put("product_index", urls.get("hswapIndexModule"));
            //    velocityContext.put("product_detail", urls.get("hswapIndexModule"));
            }else{
                velocityContext.put("product_index", urls.get("hspcIndexModule"));
            //    velocityContext.put("product_detail", urls.get("hspcIndexModule"));
            }
        }else if(ShopIdEnum.isHuiShang_score(shopid)){
            if(ENUM.BigPlatform.WAP.getCode() == terminal){
                velocityContext.put("product_index", urls.get("hswapIndexModule"));
            //    velocityContext.put("product_detail", urls.get("hswapIndexModule"));
            }else{
                velocityContext.put("product_index", urls.get("hspcIndexModule"));
            //    velocityContext.put("product_detail", urls.get("hspcIndexModule"));
            }
        }

		HashMap<String,Object> tools = (HashMap<String,Object>)context.getBean("velocityTools");
		if (tools != null) {
			for (Map.Entry<String, Object> entry : tools.entrySet()) {
				String attributeName = entry.getKey();
				Object toolClass = entry.getValue();
				velocityContext.put(attributeName, toolClass);
			}
		}
	}


    /***************************************************************************************/
    @RequestMapping(value = "checkedAllOnOff", produces = "application/json; charset=utf-8")
    public @ResponseBody String checkedAllOnOff(ActiveItemEntity entity){
        try{
            BasePara para = getBasePara();
            if(!getUser(para.getUser())){
                //return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
                return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_USER_ILLEGAL")));
            }
            copyBasePara(para, entity);
            RemoteResult<CartNG> result = shoppingCartService.checkedAllOnOff(getTenant(),entity);
            String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(),result.getT().isEmpty(),false, getTenant().getShopId());
            String html = merge(getTenant().getShopId(), entity.getTerminal(), templat, "cart", result.getT());
            Map<String,Object> ret = new HashMap<>();
            ret.put("rc", 0);
            ret.put("html", html);
            return toJson(ret);
        }catch(Exception e){
            logger.error("",e);
//            return toJson(new BaseInfo(ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION));
            return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(getTenant(),"ERROR_SYSTEM_EXCEPTION")));

        }
    }

    /**
     * 获取主品的所有服务信息
     * @param --plat
     * @param --gcode
     * @return
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @author wangrq1
     */
    @RequestMapping(value="/getservicelist",produces = "plain/text; charset=UTF-8")
    @ResponseBody
    public String getServiceLists(GetGoodServiceEntity entity) throws Exception {
        try{
            BasePara base = getBasePara();
            if(!getUser(base.getUser())){
                return JsonUtil.toJson(new FpsResult(ErrorMessageEnum.ERROR_USER_ILLEGAL));
            }
            copyBasePara(base, entity);
            logger.info("entity1-------->"+toJson(entity));
            String gcode = entity.getGcode();
            if(gcode == null || gcode.length()<=1){
                return "";
            }
            entity.setGcode(gcode.split(",")[0]);
            logger.info("entity2-------->"+toJson(entity));
            RemoteResult<List<ServiceProductView>> result = shoppingCartService.getServiceListByGcode(getTenant(),entity);
            logger.info("调用getservicelist  soa 结束"+JsonUtil.toJson(result));
            List<ServiceProductView> services = result.getT();
            for (ServiceProductView s : services){
                s.setGcode(gcode);
            }
            Map<String,Object> ret = new HashMap<>();
            ret.put("rc", 0);
            if (entity.getTerminal() == com.lenovo.m2.hsbuy.common.enums.Terminal.PC.getType()){
                ret.put("servicelist", services);
                return toJson(ret);
            }else {
                ServiceProductListForReturn serviceProductListForReturn = new ServiceProductListForReturn();
                serviceProductListForReturn.setGcode(gcode);
                serviceProductListForReturn.setServicelist(services);
                logger.info("serviceProductListForReturn--->"+toJson(serviceProductListForReturn));
                if (services.size() == 0){
                    ret.put("isnull",0);
                }else{
                    ret.put("isnull",1);
                }
                String templat = ViewConstants.getAjaxCartTemplate(entity.getTerminal(),services.isEmpty(),true, getTenant().getShopId());
                String html = merge(getTenant().getShopId(),entity.getTerminal(), templat, "services", serviceProductListForReturn);
                ret.put("html", html);
                return toJson(ret);
            }
        }catch(Exception e){
            log.error("",e);
            return toJson(BaseInfo.errInfo(1));
        }
    }

}