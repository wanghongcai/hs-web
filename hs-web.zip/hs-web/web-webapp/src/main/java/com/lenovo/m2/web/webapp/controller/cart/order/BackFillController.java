package com.lenovo.m2.web.webapp.controller.cart.order;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;
import com.lenovo.m2.web.domain.purchase.order.backfill.UpdateItemTypeEnum;
import com.lenovo.m2.web.manager.purchase.order.BackFillService;
import com.lenovo.m2.web.webapp.controller.BaseController;

/**
 * @author zhanghs
 * @version V1.0
 * @Title: ${file_name}
 * @Description: 订单回填和去参数化控制器
 * @date 2016年2月17日 下午7:56:20
 */
@Controller
public class BackFillController extends BaseController{
	private static Logger log =  LogManager.getLogger(BackFillController.class.getName());

    @Autowired
    private BackFillService backFillService;


    @RequestMapping(value = "/updateCheckOutCache")
    @ResponseBody
    public String updateCheckOutCache(Integer shopId,Integer terminal,String lid,Integer cacheItem, String content,HttpServletResponse response){
        logger.info("更新结算缓存----------------------------shopId:"+shopId+"terminal:"+terminal+"lid:"+lid+"---cacheItem:"+cacheItem+"----content:"+content);
        if (isNull(shopId,terminal,cacheItem)) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_PARAM)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_NOT_LOGIN)), response);
        }
        try{
            BackFillOrderVo result = backFillService.updateCheckOutCache(user().getLenovoid(),terminal,shopId,lid,content, UpdateItemTypeEnum.getValue(cacheItem));
            if (null == result){
                return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_BACKFILL_UPDATE_FALL)),response);
            }
        }catch (Exception e){
            logger.error("更新结算缓存",e );
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_SYSTEM_BUSY)), response);
        }
        return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.SUCCESS)), response);
    }

    @RequestMapping(value = "/updateMoreCheckOutCache",produces = "application/json; charset=UTF-8")
    @ResponseBody
    public String updateMoreCheckOutCache(Integer shopId,Integer terminal,String lid,@RequestParam("cacheItems[]") List<Integer> cacheItems, BackFillOrderVo backFillOrderVo ,HttpServletResponse response){
        logger.info("更新结算缓存----------------------------shopId:"+shopId+"lid:"+lid+"terminal:"+terminal+"---cacheItems:"+cacheItems+"----backFillOrderVo:"+backFillOrderVo);
        if (isNull(shopId,terminal,cacheItems,backFillOrderVo)) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_PARAM)), response);
        }
        if (isNull(user())) {
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_NOT_LOGIN)), response);
        }
        try{
            List<UpdateItemTypeEnum> updateItemTypeEnums = new ArrayList();
            for (int cacheItem:cacheItems){
                updateItemTypeEnums.add(UpdateItemTypeEnum.getValue(cacheItem));
            }
            BackFillOrderVo result = backFillService.updateCheckOutCache(user().getLenovoid(),terminal,shopId,lid,backFillOrderVo, updateItemTypeEnums);
            if (null==result){
                return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_BACKFILL_UPDATE_FALL)),response);
            }
        }catch (Exception e){
            logger.error("更新结算缓存",e );
            return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.ERROR_SYSTEM_BUSY)), response);
        }
        return this.ajaxWriteStr(toJson(new BaseInfo(ErrorMessageEnum.SUCCESS)), response);
    }
}


