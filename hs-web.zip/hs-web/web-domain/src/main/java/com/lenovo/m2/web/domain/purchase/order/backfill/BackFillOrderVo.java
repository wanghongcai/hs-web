package com.lenovo.m2.web.domain.purchase.order.backfill;


/**
 * @author zhanghs
 * @ClassName: BackFillOrderVo
 * @Description: 订单回填去参数化对象
 * @date 2015年10月13日 下午3:48:14
 */
public class BackFillOrderVo implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    //收货人id
    private String consigneeId;
    // 付款方式
    private String paytype;
    //发票信息
    private String invoice;

    //使用的优惠卷id
    private String couponids;
    //优惠码
    private String couponcode;
    //c2c 分享数据
    private String sharecode;
    //内购额度信息
    private String innerBuyMoney;
    //礼品卡信息
    private String giftCards;
    //乐豆
    private Integer happyBeanNum;
    //客服经理编码
    //private String cmanagercode;
    //订单备注
    //private String orderremark;
    //sn码
    private String servicesn;
    //购买类型0：普通，1：立即购买
    private Integer buyType;
    //证件id
    private long identityId;
    //结算页类型【能标示是懂得通信或是一些特殊订单信息】
    private String checkOutType;
    //数据恢复险
    private String datarecovery;
    //收票地址ID
    private String invoiceAddressId;
    //收票地址同收货地址 1表示同收货地址 0表示不同收货地址
    private String invoiceIsConsigneeId;
    //合同地址ID
    private String contractAddressId;
    //合同地址同收货地址 1表示同收货地址 0表示不同收货地址
    private String contractIsConsigneeId;
    // 是否寄送合同  1表示寄送 0表示不寄送
    private String isSendContract;
    //预售电话
    private String presellTel;
    //信用信息
    private String creditInfo;

    public String getCreditInfo() {
        return creditInfo;
    }

    public void setCreditInfo(String creditInfo) {
        this.creditInfo = creditInfo;
    }

    public String getPresellTel(){
        return presellTel;
    }
    public void setPresellTel(String presellTel){
        this.presellTel = presellTel;
    }

/*
    *//**
     *当前订单可用优惠券id集合
     *//*
    private String allCoupons;
	*//**
     *用户总内购额度
     *//*
    private String allInnerLimit;
	*//**
     *当前订单可用内购额度
     *//*
    private String avbleInnerLimit;
	*//**
     *用户总的乐豆数量
     *//*
    private String allHappyBean;
	*//**
     *当前订单可用乐豆数量
     *//*
    private String avbleHappyBean;
	*//**
     *用户全部可用地址id集合
     *//*
    private String allAddressIds;*/

    /**
     * 用户所有礼品卡id集合
     */
//	private String allCashCardIds;
    public String getCheckOutType() {
        return checkOutType;
    }

    public void setCheckOutType(String checkOutType) {
        this.checkOutType = checkOutType;
    }

    public long getIdentityId() {
        return identityId;
    }

    public void setIdentityId(long identityId) {
        this.identityId = identityId;
    }

    public String getServicesn() {
        return servicesn;
    }

    public void setServicesn(String servicesn) {
        this.servicesn = servicesn;
    }

    public String getConsigneeId() {
        return consigneeId;
    }

    public void setConsigneeId(String consigneeId) {
        this.consigneeId = consigneeId;
    }

    public String getPaytype() {
        return paytype;
    }

    public void setPaytype(String paytype) {
        this.paytype = paytype;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

	/*public String getItemids() {
		return itemids;
	}

	public void setItemids(String itemids) {
		this.itemids = itemids;
	}*/

    public String getCouponids() {
        return couponids;
    }

    public void setCouponids(String couponids) {
        this.couponids = couponids;
    }

    public String getCouponcode() {
        return couponcode;
    }

    public void setCouponcode(String couponcode) {
        this.couponcode = couponcode;
    }

    public String getSharecode() {
        return sharecode;
    }

    public void setSharecode(String sharecode) {
        this.sharecode = sharecode;
    }

    public String getInnerBuyMoney() {
        return innerBuyMoney;
    }

    public void setInnerBuyMoney(String innerBuyMoney) {
        this.innerBuyMoney = innerBuyMoney;
    }

    public String getGiftCards() {
        return giftCards;
    }

    public void setGiftCards(String giftCards) {
        this.giftCards = giftCards;
    }

    public Integer getHappyBeanNum() {
        return happyBeanNum;
    }

    public void setHappyBeanNum(Integer happyBeanNum) {
        this.happyBeanNum = happyBeanNum;
    }

	/*public String getCmanagercode() {
		return cmanagercode;
	}

	public void setCmanagercode(String cmanagercode) {
		this.cmanagercode = cmanagercode;
	}

	public String getOrderremark() {
		return orderremark;
	}

	public void setOrderremark(String orderremark) {
		this.orderremark = orderremark;
	}*/

    public Integer getBuyType() {
        return buyType;
    }

    public void setBuyType(Integer buyType) {
        this.buyType = buyType;
    }

    public String getDatarecovery() {
        return datarecovery;
    }

    public void setDatarecovery(String datarecovery) {
        this.datarecovery = datarecovery;
    }

    public String getInvoiceAddressId() {
        return invoiceAddressId;
    }

    public void setInvoiceAddressId(String invoiceAddressId) {
        this.invoiceAddressId = invoiceAddressId;
    }


    public String getContractAddressId() {
        return contractAddressId;
    }

    public void setContractAddressId(String contractAddressId) {
        this.contractAddressId = contractAddressId;
    }

    public String getInvoiceIsConsigneeId() {
        return invoiceIsConsigneeId;
    }

    public void setInvoiceIsConsigneeId(String invoiceIsConsigneeId) {
        this.invoiceIsConsigneeId = invoiceIsConsigneeId;
    }

    public String getContractIsConsigneeId() {
        return contractIsConsigneeId;
    }

    public void setContractIsConsigneeId(String contractIsConsigneeId) {
        this.contractIsConsigneeId = contractIsConsigneeId;
    }

    public String getIsSendContract() {
        return isSendContract;
    }

    public void setIsSendContract(String isSendContract) {
        this.isSendContract = isSendContract;
    }

    @Override
    public String toString() {
        return "BackFillOrderVo{" +
                "consigneeId='" + consigneeId + '\'' +
                ", paytype='" + paytype + '\'' +
                ", invoice='" + invoice + '\'' +
                ", couponids='" + couponids + '\'' +
                ", couponcode='" + couponcode + '\'' +
                ", sharecode='" + sharecode + '\'' +
                ", innerBuyMoney='" + innerBuyMoney + '\'' +
                ", giftCards='" + giftCards + '\'' +
                ", happyBeanNum=" + happyBeanNum +
                ", servicesn='" + servicesn + '\'' +
                ", buyType=" + buyType +
                ", identityId=" + identityId +
                ", checkOutType='" + checkOutType + '\'' +
                ", datarecovery='" + datarecovery + '\'' +
                ", invoiceAddressId='" + invoiceAddressId + '\'' +
                ", invoiceIsConsigneeId='" + invoiceIsConsigneeId + '\'' +
                ", contractAddressId='" + contractAddressId + '\'' +
                ", contractIsConsigneeId='" + contractIsConsigneeId + '\'' +
                ", isSendContract='" + isSendContract + '\'' +
                '}';
    }


}
