package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2014年12月15日
 */
public class OrderNumInfo implements Serializable {
	
	Integer productNumber;
	
	Date rReceiptDate;
	
	Integer isreturn;

	

	public Integer getIsreturn() {
		return isreturn;
	}

	public void setIsreturn(Integer isreturn) {
		this.isreturn = isreturn;
	}

	public Integer getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(Integer productNumber) {
		this.productNumber = productNumber;
	}

	public Date getrReceiptDate() {
		return rReceiptDate;
	}

	public void setrReceiptDate(Date rReceiptDate) {
		this.rReceiptDate = rReceiptDate;
	}

	

	

}
