package com.lenovo.m2.web.domain.my.ordermessage.ordermessageforsmb;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by zhangzhen on 2016-08-11 20:59:27.
 */
public class Goods implements Serializable {

    private String name;//商品名称
    private String imageUrl;//商品图片url
    private Money price;//商品单价
    private int num;//商品数量
    private Money amount;//小计

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Money getPrice() {
        return price;
    }

    public void setPrice(Money price) {
        this.price = price;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }
}
