package com.lenovo.m2.web.domain.purchase.pay;

/**
 * 银联账号
 * @author shily
 *
 */
public class UnionPay {
	private String union_cono;

	public String getUnion_cono() {
		return union_cono;
	}

	public void setUnion_cono(String union_cono) {
		this.union_cono = union_cono;
	}
	
	
}
