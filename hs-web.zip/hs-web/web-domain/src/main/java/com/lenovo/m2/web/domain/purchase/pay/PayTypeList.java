package com.lenovo.m2.web.domain.purchase.pay;

import com.lenovo.m2.web.common.purchase.util.BaseInfo;

import java.util.List;


public class PayTypeList extends BaseInfo {
	private List<PayType> list;
	
	public PayTypeList(int rc, String msg, List<PayType> list) {
		super(rc, msg);
		this.list = list;
	}
	
	public PayTypeList() {
		super(0, "");
	}
	
	public List<PayType> getList() {
		return list;
	}

	public void setList(List<PayType> list) {
		this.list = list;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("paytypes:" + this.list.size()+";");
		return buffer.toString();
	}
}
