package com.lenovo.m2.web.domain.my.logistics;

import java.sql.Timestamp;

/**
 * Created by yyduff on 2016/3/9.
 */
public class OrderLogisticsDirectInfoes {

    private String logisticsName;



    private int id;



    private String logisticsNo;



    private String logisticsDate;



    private String logisticsContent;



    private String logisticsStatus;



    private Boolean isRead;



    private Timestamp createTime;



    private String ordercode;

    public String getLogisticsName() {
        return logisticsName;
    }

    public void setLogisticsName(String logisticsName) {
        this.logisticsName = logisticsName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogisticsNo() {
        return logisticsNo;
    }

    public void setLogisticsNo(String logisticsNo) {
        this.logisticsNo = logisticsNo;
    }

    public String getLogisticsDate() {
        return logisticsDate;
    }

    public void setLogisticsDate(String logisticsDate) {
        this.logisticsDate = logisticsDate;
    }

    public String getLogisticsContent() {
        return logisticsContent;
    }

    public void setLogisticsContent(String logisticsContent) {
        this.logisticsContent = logisticsContent;
    }

    public String getLogisticsStatus() {
        return logisticsStatus;
    }

    public void setLogisticsStatus(String logisticsStatus) {
        this.logisticsStatus = logisticsStatus;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }
}
