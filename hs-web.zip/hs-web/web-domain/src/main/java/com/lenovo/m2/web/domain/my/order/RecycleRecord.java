package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by yezhenyue on 2016/1/13.
 */
public class RecycleRecord implements Serializable {
    private String recyclePlat;//回收平台：1爱回收 2有的卖
    private String productName;//商品名称
    private Money realPrice;//实际回收价格
    private String createTime;//订单创建时间
    private String orderId;//订单编号
    private String status;//订单状态

    public String getRecyclePlat() {
        return recyclePlat;
    }

    public void setRecyclePlat(String recyclePlat) {
        this.recyclePlat = recyclePlat;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Money getRealPrice() {
        return realPrice;
    }

    public void setRealPrice(Money realPrice) {
        this.realPrice = realPrice;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
