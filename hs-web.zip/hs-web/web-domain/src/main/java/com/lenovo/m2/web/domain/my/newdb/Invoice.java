package com.lenovo.m2.web.domain.my.newdb;

import java.io.Serializable;
import java.util.Date;

public class Invoice implements Serializable {
    /**
     * 增值发票审核状态-1:审批通过
     */
    public static final int REVIEW_STATUS_ACCEPT = 1;
    /**
     * 增值发票审核状态-2:审批驳回
     */
    public static final int REVIEW_STATUS_REJECTED = 2;

    /**
     * 增值发票审核状态 1--未审批
     */
    public final static int REVIEW_STATUS_UNAUDITED = 3;


    private Long orderId;

    private Integer type;

    private String category;

    private String title;

    private String taxpayerIdentity;

    private String registerAddress;

    private String registerPhone;

    private String depositBank;

    private String bankNo;

    private String pictureUrl;

    private Integer isNeedMerge;

    private Integer reviewStatus;

    private Integer throwStatus;

    private Date throwTime;

    private Integer throwTimes;

    private String failureReason;

    private String zCode;

    private Date createTime;

    private String createBy;

    private Date updateTime;

    private String updateBy;

    private Integer version;

    private Main main;

    private DeliveryAddress deliveryaddress;

    private String zid;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category == null ? null : category.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getTaxpayerIdentity() {
        return taxpayerIdentity;
    }

    public void setTaxpayerIdentity(String taxpayerIdentity) {
        this.taxpayerIdentity = taxpayerIdentity == null ? null : taxpayerIdentity.trim();
    }

    public String getRegisterAddress() {
        return registerAddress;
    }

    public void setRegisterAddress(String registerAddress) {
        this.registerAddress = registerAddress == null ? null : registerAddress.trim();
    }

    public String getRegisterPhone() {
        return registerPhone;
    }

    public void setRegisterPhone(String registerPhone) {
        this.registerPhone = registerPhone == null ? null : registerPhone.trim();
    }

    public String getDepositBank() {
        return depositBank;
    }

    public void setDepositBank(String depositBank) {
        this.depositBank = depositBank == null ? null : depositBank.trim();
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo == null ? null : bankNo.trim();
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl == null ? null : pictureUrl.trim();
    }

    public Integer getIsNeedMerge() {
        return isNeedMerge;
    }

    public void setIsNeedMerge(Integer isNeedMerge) {
        this.isNeedMerge = isNeedMerge;
    }

    public Integer getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(Integer reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public Integer getThrowStatus() {
        return throwStatus;
    }

    public void setThrowStatus(Integer throwStatus) {
        this.throwStatus = throwStatus;
    }

    public Date getThrowTime() {
        return throwTime;
    }

    public void setThrowTime(Date throwTime) {
        this.throwTime = throwTime;
    }

    public Integer getThrowTimes() {
        return throwTimes;
    }

    public void setThrowTimes(Integer throwTimes) {
        this.throwTimes = throwTimes;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason == null ? null : failureReason.trim();
    }

    public String getZCode() {
        return zCode;
    }

    public void setZCode(String zCode) {
        this.zCode = zCode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public DeliveryAddress getDeliveryaddress() {
        return deliveryaddress;
    }

    public void setDeliveryaddress(DeliveryAddress deliveryaddress) {
        this.deliveryaddress = deliveryaddress;
    }

    public String getZid() {
        return zid;
    }

    public void setZid(String zid) {
        this.zid = zid;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "orderId=" + orderId +
                ", type=" + type +
                ", category='" + category + '\'' +
                ", title='" + title + '\'' +
                ", taxpayerIdentity='" + taxpayerIdentity + '\'' +
                ", registerAddress='" + registerAddress + '\'' +
                ", registerPhone='" + registerPhone + '\'' +
                ", depositBank='" + depositBank + '\'' +
                ", bankNo='" + bankNo + '\'' +
                ", pictureUrl='" + pictureUrl + '\'' +
                ", isNeedMerge=" + isNeedMerge +
                ", reviewStatus=" + reviewStatus +
                ", throwStatus=" + throwStatus +
                ", throwTime=" + throwTime +
                ", throwTimes=" + throwTimes +
                ", failureReason='" + failureReason + '\'' +
                ", zCode='" + zCode + '\'' +
                ", createTime=" + createTime +
                ", createBy='" + createBy + '\'' +
                ", updateTime=" + updateTime +
                ", updateBy='" + updateBy + '\'' +
                ", version=" + version +
                ", main=" + main +
                ", deliveryaddress=" + deliveryaddress +
                ", zid='" + zid + '\'' +
                '}';
    }
}