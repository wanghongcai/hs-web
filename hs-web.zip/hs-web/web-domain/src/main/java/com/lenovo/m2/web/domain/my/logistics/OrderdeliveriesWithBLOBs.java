package com.lenovo.m2.web.domain.my.logistics;

public class OrderdeliveriesWithBLOBs extends Orderdeliveries {
    private String shipemail;

    private String remark;

    private String btcpcode;

    private String sendfactory;

    private String descriptionquestion;

    private String isadvancefreight;

    private String distributeleafletscode;

    private String switchcode;

    private String switchsenddate;

    private String refusereason;

    private String deliveryname;

    private String exceptionreason;

    public String getShipemail() {
        return shipemail;
    }

    public void setShipemail(String shipemail) {
        this.shipemail = shipemail == null ? null : shipemail.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getBtcpcode() {
        return btcpcode;
    }

    public void setBtcpcode(String btcpcode) {
        this.btcpcode = btcpcode == null ? null : btcpcode.trim();
    }

    public String getSendfactory() {
        return sendfactory;
    }

    public void setSendfactory(String sendfactory) {
        this.sendfactory = sendfactory == null ? null : sendfactory.trim();
    }

    public String getDescriptionquestion() {
        return descriptionquestion;
    }

    public void setDescriptionquestion(String descriptionquestion) {
        this.descriptionquestion = descriptionquestion == null ? null : descriptionquestion.trim();
    }

    public String getIsadvancefreight() {
        return isadvancefreight;
    }

    public void setIsadvancefreight(String isadvancefreight) {
        this.isadvancefreight = isadvancefreight == null ? null : isadvancefreight.trim();
    }

    public String getDistributeleafletscode() {
        return distributeleafletscode;
    }

    public void setDistributeleafletscode(String distributeleafletscode) {
        this.distributeleafletscode = distributeleafletscode == null ? null : distributeleafletscode.trim();
    }

    public String getSwitchcode() {
        return switchcode;
    }

    public void setSwitchcode(String switchcode) {
        this.switchcode = switchcode == null ? null : switchcode.trim();
    }

    public String getSwitchsenddate() {
        return switchsenddate;
    }

    public void setSwitchsenddate(String switchsenddate) {
        this.switchsenddate = switchsenddate == null ? null : switchsenddate.trim();
    }

    public String getRefusereason() {
        return refusereason;
    }

    public void setRefusereason(String refusereason) {
        this.refusereason = refusereason == null ? null : refusereason.trim();
    }

    public String getDeliveryname() {
        return deliveryname;
    }

    public void setDeliveryname(String deliveryname) {
        this.deliveryname = deliveryname == null ? null : deliveryname.trim();
    }

    public String getExceptionreason() {
        return exceptionreason;
    }

    public void setExceptionreason(String exceptionreason) {
        this.exceptionreason = exceptionreason == null ? null : exceptionreason.trim();
    }
}