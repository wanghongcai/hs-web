package com.lenovo.m2.web.domain.purchase.member;

/**
 *
 * 远程调用跟新用户的参数实体类
 * Created by zhanghongsheng on 2015/7/13.
 */
public class MemberRemote {

    private String lenovoId;  //	用户ID
    private String realname;  //	实名
    private String gender;    //	性别 (0:保密 1:男 2:女)
    private String birthyear;  //	出生年份
    private String birthmonth;  //	出生月份
    private String birthday;  //	出生日
    private String constellation;  //	星座(根据生日自动计算)
    private String zodiac; //	生肖(根据生日自动计算)
    private String telephone;//	固定电话
    private String mobile;  //	手机
    private String idcardtype;  //	证件类型：身份证 护照 军官证等
    private String idcard;  //	证件号码
    private String address;  //	邮寄地址
    private String zipcode;  //	邮编
    private String nationality;  //	国籍
    private String birthprovince;  //	出生省份
    private String birthcity;  //	出生城市
    private String birthdist;  //	出生行政区/县
    private String birthcommunity;  //	出生小区
    private String resideprovince;  //	居住省份
    private String residecity;  //	居住城市
    private String residedist;  //	居住行政区/县
    private String residecommunity;  //	居住小区
    private String residesuite;  //	小区、写字楼门牌号
    private String graduateschool;  //	毕业学校
    private String company;  //	公司
    private String education;  //	学历
    private String occupation;  //	职业
    private String position;  //	职位
    private String revenue;  //	年收入
    private String affectivestatus;  //	情感状态
    private String lookingfor;  //	交友目的（交友类型）
    private String bloodtype;  //	血型
    private String height;  //	身高
    private String weight;  //	体重
    private String alipay;  //	支付宝帐号
    private String qq;  //	QQ
    private String site;  //	主页
    private String bio;  //	自我介绍 来自论坛bio字段
    private String interest;  //	兴趣爱好
    private String islenovo;  //	是否联想员工
    private String lenovocode;  //	员工编码
    private String lenovoname;  //	员工姓名
    private String iscombine;  //	是否整合
    private String usertype;  //	用户所属原社区
    private String usermark;  //	用户标签（用于区分用户属于那个原社区）
    private String uid;  //	用户uid
    private String itcode;  //	用户itcode
    private String History_score;  //	历史积分
    private String loginname;  //	登录名
    private String username;  //	昵称
    private String credits;  //	信誉
    private String email;  //	邮箱
    private String unionid;  //	微信编号
    private String memberId;   //memberId


    private String score;           //积分
    private String enterpriseEmail; //
    private String empStatus;       //
    private String ret;             //返回结果状态

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthyear() {
        return birthyear;
    }

    public void setBirthyear(String birthyear) {
        this.birthyear = birthyear;
    }

    public String getBirthmonth() {
        return birthmonth;
    }

    public void setBirthmonth(String birthmonth) {
        this.birthmonth = birthmonth;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getConstellation() {
        return constellation;
    }

    public void setConstellation(String constellation) {
        this.constellation = constellation;
    }

    public String getZodiac() {
        return zodiac;
    }

    public void setZodiac(String zodiac) {
        this.zodiac = zodiac;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getIdcardtype() {
        return idcardtype;
    }

    public void setIdcardtype(String idcardtype) {
        this.idcardtype = idcardtype;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getBirthprovince() {
        return birthprovince;
    }

    public void setBirthprovince(String birthprovince) {
        this.birthprovince = birthprovince;
    }

    public String getBirthcity() {
        return birthcity;
    }

    public void setBirthcity(String birthcity) {
        this.birthcity = birthcity;
    }

    public String getBirthdist() {
        return birthdist;
    }

    public void setBirthdist(String birthdist) {
        this.birthdist = birthdist;
    }

    public String getBirthcommunity() {
        return birthcommunity;
    }

    public void setBirthcommunity(String birthcommunity) {
        this.birthcommunity = birthcommunity;
    }

    public String getResideprovince() {
        return resideprovince;
    }

    public void setResideprovince(String resideprovince) {
        this.resideprovince = resideprovince;
    }

    public String getResidecity() {
        return residecity;
    }

    public void setResidecity(String residecity) {
        this.residecity = residecity;
    }

    public String getResidedist() {
        return residedist;
    }

    public void setResidedist(String residedist) {
        this.residedist = residedist;
    }

    public String getResidecommunity() {
        return residecommunity;
    }

    public void setResidecommunity(String residecommunity) {
        this.residecommunity = residecommunity;
    }

    public String getResidesuite() {
        return residesuite;
    }

    public void setResidesuite(String residesuite) {
        this.residesuite = residesuite;
    }

    public String getGraduateschool() {
        return graduateschool;
    }

    public void setGraduateschool(String graduateschool) {
        this.graduateschool = graduateschool;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getAffectivestatus() {
        return affectivestatus;
    }

    public void setAffectivestatus(String affectivestatus) {
        this.affectivestatus = affectivestatus;
    }

    public String getLookingfor() {
        return lookingfor;
    }

    public void setLookingfor(String lookingfor) {
        this.lookingfor = lookingfor;
    }

    public String getBloodtype() {
        return bloodtype;
    }

    public void setBloodtype(String bloodtype) {
        this.bloodtype = bloodtype;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getAlipay() {
        return alipay;
    }

    public void setAlipay(String alipay) {
        this.alipay = alipay;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getIslenovo() {
        return islenovo;
    }

    public void setIslenovo(String islenovo) {
        this.islenovo = islenovo;
    }

    public String getLenovocode() {
        return lenovocode;
    }

    public void setLenovocode(String lenovocode) {
        this.lenovocode = lenovocode;
    }

    public String getLenovoname() {
        return lenovoname;
    }

    public void setLenovoname(String lenovoname) {
        this.lenovoname = lenovoname;
    }

    public String getIscombine() {
        return iscombine;
    }

    public void setIscombine(String iscombine) {
        this.iscombine = iscombine;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getUsermark() {
        return usermark;
    }

    public void setUsermark(String usermark) {
        this.usermark = usermark;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getItcode() {
        return itcode;
    }

    public void setItcode(String itcode) {
        this.itcode = itcode;
    }

    public String getHistory_score() {
        return History_score;
    }

    public void setHistory_score(String history_score) {
        History_score = history_score;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCredits() {
        return credits;
    }

    public void setCredits(String credits) {
        this.credits = credits;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getEnterpriseEmail() {
        return enterpriseEmail;
    }

    public void setEnterpriseEmail(String enterpriseEmail) {
        this.enterpriseEmail = enterpriseEmail;
    }

    public String getEmpStatus() {
        return empStatus;
    }

    public void setEmpStatus(String empStatus) {
        this.empStatus = empStatus;
    }

    public String getRet() {
        return ret;
    }

    public void setRet(String ret) {
        this.ret = ret;
    }
}
