package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * Created by jiangzh5 on 2015/8/18.
 */
public class ReOrderSimpleInfo implements Serializable {
    private String orderID;
    private String reason;
    private String content;
    private String createTime;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }
}
