package com.lenovo.m2.web.domain.my.encrypt;


import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;

/**
 * Created by jack on 2016/10/12.
 */
public class JudgeFaidForThinkUtil {

    /*
     *
     通过FA，把历史订单中的商品详情地址拼接是需要根据FA进行过滤一下think商品，think商品的FA有：
     联想（上海）有限公司:e5c62c8b-cfae-4771-b585-bfe718a5d57a
     北京佳意堂广告有限公司：373a20db-31a6-4549-adb6-284b95add7b7
     ThinkO2O服务商:365421ca-317e-4547-95fd-9c5b75c6f2ca
     think生产域名：thinkpad.lenovo.com.cn  uat域名：thinkpad.lenovouat.cn
     *
     */
    private static final String FLAG_TRUE = "0";
    private static final String FLAG_FALSE = "1";

    public String checkFadiForThink(String faid){
        if ("e5c62c8b-cfae-4771-b585-bfe718a5d57a".equals(faid) || "373a20db-31a6-4549-adb6-284b95add7b7".equals(faid) || "365421ca-317e-4547-95fd-9c5b75c6f2ca".equals(faid)){
            return FLAG_TRUE;
        }
        return FLAG_FALSE;
    }

    public String replaceUrlForWap(String pcurl){
        String WapUrl = "";
        String url = CustomizedPropertyConfigurer.getContextProperty("shop.product.m.url");
        String url1 = url.substring(0,url.length()-8);
        String[] url2 = pcurl.split("\\//");
        if (url2.length == 2){
            String[] url3 = url2[1].split("\\/");
            if (url3.length >= 2){
                String pcUrl = url2[1].substring(url3[0].length(),url2[1].length());
                WapUrl = url1 + pcUrl;
            }
        }
        return WapUrl;
    }

    public String replaceUrlForApp(String pcurl){
        String AppUrl = "";
        String url = CustomizedPropertyConfigurer.getContextProperty("shop.product.android.url");
        String url1 = url.substring(0,url.length()-8);
        String[] url2 = pcurl.split("\\//");
        if (url2.length == 2){
            String[] url3 = url2[1].split("\\/");
            if (url3.length >= 2){
                String pcUrl = url2[1].substring(url3[0].length(),url2[1].length());
                AppUrl = url1 + pcUrl;
            }
        }
        return AppUrl;
    }

    public String replaceUrlForPc(String pcurl){
        String AppUrl = "";
        if (pcurl.contains("thinkpad")){
            return pcurl;
        }
        String url = CustomizedPropertyConfigurer.getContextProperty("shop.product.url");
        String url1 = url.substring(0,url.length()-8);
        String[] url2 = pcurl.split("\\//");
        if (url2.length == 2){
            String[] url3 = url2[1].split("\\/");
            if (url3.length >= 2){
                String pcUrl = url2[1].substring(url3[0].length(),url2[1].length());
                AppUrl = url1 + pcUrl;
            }
        }
        return AppUrl;
    }

    public String getThinkPcUrl(){
        String url = CustomizedPropertyConfigurer.getContextProperty("tk.product.url");
        return url;
    }

    public String getThinkWapUrl(){
        String url = CustomizedPropertyConfigurer.getContextProperty("tk.product.url");
        return url;
    }

    public String getBtcPcUrl(){
        String url = CustomizedPropertyConfigurer.getContextProperty("shop.product.url");
        return url;
    }

    public String getBtcWapUrl(){
        String url = CustomizedPropertyConfigurer.getContextProperty("shop.product.url");
        return url;
    }
}
