package com.lenovo.m2.web.domain.my.order;


import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author kangjie
 *
 */
public class MongoOrderDetail extends MongoOrder implements Serializable {

    private Money cpaymoney;// 支付订单金额（为客户端自行计算的价格，客户端以此价格与服务器端计算的价格做校验）
    private String couponids;// 使用的优惠卷id集合（多个优惠卷用逗号分隔）
    private String deliverid;// 收货人id

    private Money discount; //优惠总价（即折扣总价）
    private Money coupon;   //优惠卷总价
    private OrderInvoiceVo invoice;//发票信息

    private String shipStatus;//退换货状态 1代表已退货 2代表已换货
    private String rreceiptDate;//签收日期

    private Integer checkSignState;//是否可退换货状态 -1不可退换 0可退可换 1只可换

    private long payPoint;//积分支付
    private Money creditLine;//信用支付额度

    private Money totalTax; //税总计

    private List<Receiver> billingDeliveries;


    public long getPayPoint() {
        return payPoint;
    }

    public void setPayPoint(long payPoint) {
        this.payPoint = payPoint;
    }

    public Money getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(Money creditLine) {
        this.creditLine = creditLine;
    }


    public OrderInvoiceVo getInvoice() {
        return invoice;
    }
    public void setInvoice(OrderInvoiceVo invoice) {
        this.invoice = invoice;
    }

    public Money getCpaymoney() {
        return cpaymoney;
    }

    public void setCpaymoney(Money cpaymoney) {
        this.cpaymoney = cpaymoney;
    }

    public Money getDiscount() {
        return discount;
    }

    public void setDiscount(Money discount) {
        this.discount = discount;
    }

    public Money getCoupon() {
        return coupon;
    }

    public void setCoupon(Money coupon) {
        this.coupon = coupon;
    }

    public String getCouponids() {
        return couponids;
    }
    public void setCouponids(String couponids) {
        this.couponids = couponids;
    }

    public String getDeliverid() {
        return deliverid;
    }
    public void setDeliverid(String deliverid) {
        this.deliverid = deliverid;
    }

    public String getShipStatus() {
        return shipStatus;
    }

    public void setShipStatus(String shipStatus) {
        this.shipStatus = shipStatus;
    }

    public String getRreceiptDate() {
        return rreceiptDate;
    }

    public void setRreceiptDate(String rreceiptDate) {
        this.rreceiptDate = rreceiptDate;
    }

    public Integer getCheckSignState() {
        return checkSignState;
    }

    public void setCheckSignState(Integer checkSignState) {
        this.checkSignState = checkSignState;
    }

    public Money getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(Money totalTax) {
        this.totalTax = totalTax;
    }

    public List<Receiver> getBillingDeliveries() {
        return billingDeliveries;
    }

    public String getPaymentWay() {
        return null;
    }

    public int getCreditLineWay() {
        return 0;
    }

    public String getPactUrl() {
        return null;
    }

    public int getAccountType() {
        return 0;
    }
}
