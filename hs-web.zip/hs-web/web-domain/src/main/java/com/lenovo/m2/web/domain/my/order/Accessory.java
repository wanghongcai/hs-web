package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * Created by yezhenyue on 2015/11/27.
 */
public class Accessory implements Serializable{
    private String option;
    private String value;
    private String isselect;
    private String picUrl;
    private String char_des;
    private String charvalue_des;

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getIsselect() {
        return isselect;
    }

    public void setIsselect(String isselect) {
        this.isselect = isselect;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getChar_des() {
        return char_des;
    }

    public void setChar_des(String char_des) {
        this.char_des = char_des;
    }

    public String getCharvalue_des() {
        return charvalue_des;
    }

    public void setCharvalue_des(String charvalue_des) {
        this.charvalue_des = charvalue_des;
    }
}
