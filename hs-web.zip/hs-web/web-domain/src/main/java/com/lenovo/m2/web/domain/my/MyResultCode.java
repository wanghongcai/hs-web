package com.lenovo.m2.web.domain.my;

/**
 * Created by jiangzh5 on 2015/8/4.
 */
public class MyResultCode {
    //订单发生异常
    public final static String ORDER_ERROR = "9999";
    //优惠券发生异常
    public final static String SALESCOUPON_ERROR = "8999";
}
