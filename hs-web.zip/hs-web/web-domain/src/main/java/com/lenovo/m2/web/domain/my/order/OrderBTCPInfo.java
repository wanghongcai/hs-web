package com.lenovo.m2.web.domain.my.order;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author wangrq1
 * 物流信息
 *
 */
public class OrderBTCPInfo {
	
	private String shipmentsNo;
	private String waybillno;
	private List<Entry> entries;
	
	public OrderBTCPInfo(){
		this.shipmentsNo = "";
		this.waybillno = "";
		this.entries = new ArrayList<>();
		
	}
	
	
	public OrderBTCPInfo(String shipmentsNo, String waybillno, List<Entry> entries){
		this.shipmentsNo = shipmentsNo;
		this.waybillno = waybillno;
		this.entries =  entries;
	} 
	
	
	
	



	public String getShipmentsNo() {
		return shipmentsNo;
	}

	public void setShipmentsNo(String shipmentsNo) {
		this.shipmentsNo = shipmentsNo;
	}

	public String getWaybillno() {
		return waybillno;
	}

	public void setWaybillno(String waybillno) {
		this.waybillno = waybillno;
	}

	public List<Entry> getEntries() {
		return entries;
	}




	public void setEntries(List<Entry> entries) {
		this.entries = entries;
	}




	public static class Entry{
		
		private String lgtime;
		private String lgdesc;
		private String operator;
		private String totalStateName;
		public String getLgtime() {
			return lgtime;
		}
		public void setLgtime(String lgtime) {
			this.lgtime = lgtime;
		}
		public String getLgdesc() {
			return lgdesc;
		}
		public void setLgdesc(String lgdesc) {
			this.lgdesc = lgdesc;
		}

		public String getTotalStateName() {
			return totalStateName;
		}

		public void setTotalStateName(String totalStateName) {
			this.totalStateName = totalStateName;
		}

		public Entry(){}

		public Entry(String lgtime, String lgdesc, String operator, String totalStateName) {
			this.lgtime = lgtime;
			this.lgdesc = lgdesc;
			this.operator = operator;
			this.totalStateName = totalStateName;
		}

		public String getOperator() {
			return operator;
		}
		public void setOperator(String operator) {
			this.operator = operator;
		}
	
		
	}
	
	
	
	
}
