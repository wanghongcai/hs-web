package com.lenovo.m2.web.domain.purchase.cashier;

import java.io.Serializable;

/**
 * 懂得充值详情
 * Created by MengQiang on 2016/7/19.
 */
public class PhoneRechargeForPay implements Serializable{
    private String amountMoney;//充值金额
    private String chargeAcct;// 手机号码，
    private String chargeCash;//充值面值/流量
    private String chargeType;//充值类型  0:手机充值 1 流量充值 2 固话 3 宽带 4 QQ游戏  5水电缴费 6  加油卡充值
    private String chargeDesc;

    public String getAmountMoney() {
        return amountMoney;
    }

    public void setAmountMoney(String amountMoney) {
        this.amountMoney = amountMoney;
    }

    public String getChargeAcct() {
        return chargeAcct;
    }

    public void setChargeAcct(String chargeAcct) {
        this.chargeAcct = chargeAcct;
    }

    public String getChargeCash() {
        return chargeCash;
    }

    public void setChargeCash(String chargeCash) {
        this.chargeCash = chargeCash;
    }

    public String getChargeType() {
        return chargeType;
    }

    public void setChargeType(String chargeType) {
        this.chargeType = chargeType;
    }

    public String getChargeDesc() {
        return chargeDesc;
    }

    public void setChargeDesc(String chargeDesc) {
        this.chargeDesc = chargeDesc;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PhoneRechargeForPay that = (PhoneRechargeForPay) o;

        if (amountMoney != null ? !amountMoney.equals(that.amountMoney) : that.amountMoney != null)
            return false;
        if (chargeAcct != null ? !chargeAcct.equals(that.chargeAcct) : that.chargeAcct != null)
            return false;
        if (chargeCash != null ? !chargeCash.equals(that.chargeCash) : that.chargeCash != null)
            return false;
        if (chargeDesc != null ? !chargeDesc.equals(that.chargeDesc) : that.chargeDesc != null)
            return false;
        if (chargeType != null ? !chargeType.equals(that.chargeType) : that.chargeType != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = amountMoney != null ? amountMoney.hashCode() : 0;
        result = 31 * result + (chargeAcct != null ? chargeAcct.hashCode() : 0);
        result = 31 * result + (chargeCash != null ? chargeCash.hashCode() : 0);
        result = 31 * result + (chargeType != null ? chargeType.hashCode() : 0);
        result = 31 * result + (chargeDesc != null ? chargeDesc.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PhoneRechargeForPay{" +
                "amountMoney='" + amountMoney + '\'' +
                ", chargeAcct='" + chargeAcct + '\'' +
                ", chargeCash='" + chargeCash + '\'' +
                ", chargeType='" + chargeType + '\'' +
                ", chargeDesc='" + chargeDesc + '\'' +
                '}';
    }
}
