package com.lenovo.m2.web.domain.purchase.pay;

public class CmbPayRes {

	/**	取值Y(成功)或N(失败)；*/
	private String Succeed;
	
	/**商户号*/
	private String CoNo;
	
	/**定单号(由支付命令送来)；*/
	private String BillNo;
	
	/**实际支付金额(由支付命令送来)；*/
	private String Amount;
	
	/**交易日期(主机交易日期)；*/
	private String Date;
	
	/**自定义参数*/
	private String MerchantPara;
	
	/**银行通知用户的支付结果消息。信息的前38个字符格式为;4位分行号＋6位商户号＋8位银行接受交易的日期＋20位银行流水号；可以利用交易日期＋银行流水号对该定单进行结帐处理；*/
	private String Msg;
	
	/**银行用自己的Private Key对通知命令的签名。*/
	private String signature;
	
	public String getSucceed() {
		return Succeed;
	}

	public void setSucceed(String succeed) {
		Succeed = succeed;
	}

	public String getBillNo() {
		return BillNo;
	}

	public void setBillNo(String billNo) {
		BillNo = billNo;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getMsg() {
		return Msg;
	}

	public void setMsg(String msg) {
		Msg = msg;
	}

	public String getCoNo() {
		return CoNo;
	}

	public void setCoNo(String coNo) {
		CoNo = coNo;
	}

	public String getMerchantPara() {
		return MerchantPara;
	}

	public void setMerchantPara(String merchantPara) {
		MerchantPara = merchantPara;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

}
