package com.lenovo.m2.web.domain.my.order;
/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2015年1月28日
 */
public class OrderGoods {

	String gcode;    //商品编码
	String gname;    //商品名称
	String isgift;    //是否赠品
	String gphoto;    //商品图片url
	String gcount;    //商品数量
	public String getGcode() {
		return gcode;
	}
	public void setGcode(String gcode) {
		this.gcode = gcode;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getIsgift() {
		return isgift;
	}
	public void setIsgift(String isgift) {
		this.isgift = isgift;
	}
	public String getGphoto() {
		return gphoto;
	}
	public void setGphoto(String gphoto) {
		this.gphoto = gphoto;
	}
	public String getGcount() {
		return gcount;
	}
	public void setGcount(String gcount) {
		this.gcount = gcount;
	}
	
	
}
