package com.lenovo.m2.web.domain.my;

import com.lenovo.sms.constants.Caller;

import java.io.Serializable;

public class MobileMsg implements Serializable {

	/**
     * 实现序列化
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 手机号
	 */
	private String mobile;
	/**
	 * 短信内容
	 */
	private String content;

	/**
	 * 空：注册 0：找回密码 1：登录
	 */
	private String type;
	
	/**
	 * 缓存到redis的验证码前缀
	 */
	private String prekey;
	
	/**
	 * 缓存到redis的验证码值
	 */
	private String captcha;
	
	/**
	 * 短信服务依赖判断来源的
	 */
	private Caller caller;
	
	/**
	 * shopId值
	 */
	private String shopId;

	/**
	 * 是否内部系统下发：用户点击获取：false
	 */
	private boolean inner;
	
	
	public boolean isInner() {
		return inner;
	}

	public void setInner(boolean inner) {
		this.inner = inner;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPrekey() {
		return prekey;
	}

	public void setPrekey(String prekey) {
		this.prekey = prekey;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public Caller getCaller() {
		return caller;
	}

	public void setCaller(Caller caller) {
		this.caller = caller;
	}

}