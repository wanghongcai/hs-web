package com.lenovo.m2.web.domain.my.logistics;

import java.sql.Timestamp;

/**
 * Created by yyduff on 2016/3/1.
 */
public class OrderLogistics {


    private Long id;



    private String ordercode;



    private Boolean shipstatus;



    private String shipdate;



    private String loginame;



    private String logino;



    private Timestamp createTime;

    private String logisticsCompanyPhone;

    public String getLogisticsCompanyPhone() {
        return logisticsCompanyPhone;
    }

    public void setLogisticsCompanyPhone(String logisticsCompanyPhone) {
        this.logisticsCompanyPhone = logisticsCompanyPhone;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }

    public Boolean getShipstatus() {
        return shipstatus;
    }

    public void setShipstatus(Boolean shipstatus) {
        this.shipstatus = shipstatus;
    }

    public String getShipdate() {
        return shipdate;
    }

    public void setShipdate(String shipdate) {
        this.shipdate = shipdate;
    }

    public String getLoginame() {
        return loginame;
    }

    public void setLoginame(String loginame) {
        this.loginame = loginame;
    }

    public String getLogino() {
        return logino;
    }

    public void setLogino(String logino) {
        this.logino = logino;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }
}
