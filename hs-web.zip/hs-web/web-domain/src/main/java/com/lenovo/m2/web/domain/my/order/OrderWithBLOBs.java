package com.lenovo.m2.web.domain.my.order;

/**
 * Created by jiangzh5 on 2015/7/28.
 */
public class OrderWithBLOBs {
    private String paymenttype;

    private String taxtype;

    private String returngoodsreason;

    private String faname;

    private String customermanagercode;

    public String getPaymenttype() {
        return paymenttype;
    }

    public void setPaymenttype(String paymenttype) {
        this.paymenttype = paymenttype == null ? null : paymenttype.trim();
    }

    public String getTaxtype() {
        return taxtype;
    }

    public void setTaxtype(String taxtype) {
        this.taxtype = taxtype == null ? null : taxtype.trim();
    }

    public String getReturngoodsreason() {
        return returngoodsreason;
    }

    public void setReturngoodsreason(String returngoodsreason) {
        this.returngoodsreason = returngoodsreason == null ? null : returngoodsreason.trim();
    }

    public String getFaname() {
        return faname;
    }

    public void setFaname(String faname) {
        this.faname = faname == null ? null : faname.trim();
    }

    public String getCustomermanagercode() {
        return customermanagercode;
    }

    public void setCustomermanagercode(String customermanagercode) {
        this.customermanagercode = customermanagercode == null ? null : customermanagercode.trim();
    }
}
