package com.lenovo.m2.web.domain.purchase.member;

import java.math.BigDecimal;
import java.util.Date;

public class Memberlevel {
    private String id;

    private String name;

    private Integer levelnumber;

    private String levellogo;

    private Integer depositfreezetime;

    private BigDecimal deposit;

    private Integer morepoint;

    private Integer showotherprice;

    private Integer orderlimit;

    private BigDecimal discount;

    private BigDecimal orderlimitprice;

    private Integer defaultlevel;

    private Integer leveltpe;

    private Integer point;

    private Integer experience;

    private String preid;

    private Integer expiretime;

    private Integer disabled;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    private String remark;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getLevelnumber() {
        return levelnumber;
    }

    public void setLevelnumber(Integer levelnumber) {
        this.levelnumber = levelnumber;
    }

    public String getLevellogo() {
        return levellogo;
    }

    public void setLevellogo(String levellogo) {
        this.levellogo = levellogo == null ? null : levellogo.trim();
    }

    public Integer getDepositfreezetime() {
        return depositfreezetime;
    }

    public void setDepositfreezetime(Integer depositfreezetime) {
        this.depositfreezetime = depositfreezetime;
    }

    public BigDecimal getDeposit() {
        return deposit;
    }

    public void setDeposit(BigDecimal deposit) {
        this.deposit = deposit;
    }

    public Integer getMorepoint() {
        return morepoint;
    }

    public void setMorepoint(Integer morepoint) {
        this.morepoint = morepoint;
    }

    public Integer getShowotherprice() {
        return showotherprice;
    }

    public void setShowotherprice(Integer showotherprice) {
        this.showotherprice = showotherprice;
    }

    public Integer getOrderlimit() {
        return orderlimit;
    }

    public void setOrderlimit(Integer orderlimit) {
        this.orderlimit = orderlimit;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getOrderlimitprice() {
        return orderlimitprice;
    }

    public void setOrderlimitprice(BigDecimal orderlimitprice) {
        this.orderlimitprice = orderlimitprice;
    }

    public Integer getDefaultlevel() {
        return defaultlevel;
    }

    public void setDefaultlevel(Integer defaultlevel) {
        this.defaultlevel = defaultlevel;
    }

    public Integer getLeveltpe() {
        return leveltpe;
    }

    public void setLeveltpe(Integer leveltpe) {
        this.leveltpe = leveltpe;
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public Integer getExperience() {
        return experience;
    }

    public void setExperience(Integer experience) {
        this.experience = experience;
    }

    public String getPreid() {
        return preid;
    }

    public void setPreid(String preid) {
        this.preid = preid == null ? null : preid.trim();
    }

    public Integer getExpiretime() {
        return expiretime;
    }

    public void setExpiretime(Integer expiretime) {
        this.expiretime = expiretime;
    }

    public Integer getDisabled() {
        return disabled;
    }

    public void setDisabled(Integer disabled) {
        this.disabled = disabled;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}