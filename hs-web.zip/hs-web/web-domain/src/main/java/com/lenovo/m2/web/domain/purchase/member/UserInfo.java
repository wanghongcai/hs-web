package com.lenovo.m2.web.domain.purchase.member;

public class UserInfo {
	private String lenovoId;
	private String usercode;//	当前用户code
	private String nickname;//昵称
	private String realname;//真实姓名
	private String gender;//	       性别 (0:保密 1:男 2:女)
	private String birthyear;//	出生年份
	private String birthmonth;//	出生月份
	private String birthday;//	出生日
	private String mobile;//	           手机
	private String email;//	          电子邮箱
	
	
	public String getLenovoId() {
		return lenovoId;
	}
	public void setLenovoId(String lenovoId) {
		this.lenovoId = lenovoId;
	}
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}

	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirthyear() {
		return birthyear;
	}
	public void setBirthyear(String birthyear) {
		this.birthyear = birthyear;
	}
	public String getBirthmonth() {
		return birthmonth;
	}
	public void setBirthmonth(String birthmonth) {
		this.birthmonth = birthmonth;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
