package com.lenovo.m2.web.domain.purchase.priceList;

/**
 * Created by D_xiao on 1/5/17.
 */
public class PriceListAdaptorParam extends com.lenovo.m2.web.domain.purchase.priceList.PriceListParam{

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String details;

    private String lenovoId;




    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

}