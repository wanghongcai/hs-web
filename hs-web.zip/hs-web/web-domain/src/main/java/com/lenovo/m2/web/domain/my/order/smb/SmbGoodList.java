package com.lenovo.m2.web.domain.my.order.smb;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderListGlist;

import java.io.Serializable;

/**
 * Created by jack on 2016/8/7.
 */
public class SmbGoodList implements Serializable {

    private String gcode;    //商品编码
    private String gname;    //商品名称
    private String gexchange;    //换货状态名称（如果为空表示不是在换货）
    private String evalstatus;    //评价状态（如果为空表示没有评价）
    private String gdesc;    //商品描述
    private String gphoto;    //商品图片url
    private Money gprice;    //商品单价
    private Money grealprice;    //成交价格
    private String gspec;    //商品规格列表，如颜色，内存大小等（按数据库标记的顺序进行排序）。	（单个规则为数组方式，索引0处为规格名，索引1处为规格值）,[[“颜色”,”红色”],[“内存”,”16G”]]
    private String gcount;    //商品数量
    private String groupingID;
    private String deatLike;
    private String isPhysical;
    private String phoneServiceNumber;
    private String feeInfo;
    private String numberDetail;
    private String araeCodeName;
    //SMB新增字段
    private String ordermaincode; //主订单号
    /**
     * 第三方订单编号 smb存po号
     */
    private String customerOrderCode;
    /**
     * 第三方订单编号子订单号 smb存小po号
     */
    private String customerOrderCodeSon;
    /**
     * 下单方式 1静默下单，2手工下单，3询价单
     */
    private int submitOrderWay;

    private String orderno;	    //订单编号

    private String salesType;

    public String getSalesType() {
        return salesType;
    }

    public void setSalesType(String salesType) {
        this.salesType = salesType;
    }

    public String getGcode() {
        return gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGexchange() {
        return gexchange;
    }

    public void setGexchange(String gexchange) {
        this.gexchange = gexchange;
    }

    public String getEvalstatus() {
        return evalstatus;
    }

    public void setEvalstatus(String evalstatus) {
        this.evalstatus = evalstatus;
    }

    public String getGdesc() {
        return gdesc;
    }

    public void setGdesc(String gdesc) {
        this.gdesc = gdesc;
    }

    public String getGphoto() {
        return gphoto;
    }

    public void setGphoto(String gphoto) {
        this.gphoto = gphoto;
    }

    public Money getGprice() {
        return gprice;
    }

    public void setGprice(Money gprice) {
        this.gprice = gprice;
    }

    public Money getGrealprice() {
        return grealprice;
    }

    public void setGrealprice(Money grealprice) {
        this.grealprice = grealprice;
    }

    public String getGspec() {
        return gspec;
    }

    public void setGspec(String gspec) {
        this.gspec = gspec;
    }

    public String getGcount() {
        return gcount;
    }

    public void setGcount(String gcount) {
        this.gcount = gcount;
    }

    public String getGroupingID() {
        return groupingID;
    }

    public void setGroupingID(String groupingID) {
        this.groupingID = groupingID;
    }

    public String getDeatLike() {
        return deatLike;
    }

    public void setDeatLike(String deatLike) {
        this.deatLike = deatLike;
    }

    public String getIsPhysical() {
        return isPhysical;
    }

    public void setIsPhysical(String isPhysical) {
        this.isPhysical = isPhysical;
    }

    public String getPhoneServiceNumber() {
        return phoneServiceNumber;
    }

    public void setPhoneServiceNumber(String phoneServiceNumber) {
        this.phoneServiceNumber = phoneServiceNumber;
    }

    public String getFeeInfo() {
        return feeInfo;
    }

    public void setFeeInfo(String feeInfo) {
        this.feeInfo = feeInfo;
    }

    public String getNumberDetail() {
        return numberDetail;
    }

    public void setNumberDetail(String numberDetail) {
        this.numberDetail = numberDetail;
    }

    public String getAraeCodeName() {
        return araeCodeName;
    }

    public void setAraeCodeName(String araeCodeName) {
        this.araeCodeName = araeCodeName;
    }

    public String getOrdermaincode() {
        return ordermaincode;
    }

    public void setOrdermaincode(String ordermaincode) {
        this.ordermaincode = ordermaincode;
    }

    public String getCustomerOrderCode() {
        return customerOrderCode;
    }

    public void setCustomerOrderCode(String customerOrderCode) {
        this.customerOrderCode = customerOrderCode;
    }

    public String getCustomerOrderCodeSon() {
        return customerOrderCodeSon;
    }

    public void setCustomerOrderCodeSon(String customerOrderCodeSon) {
        this.customerOrderCodeSon = customerOrderCodeSon;
    }

    public int getSubmitOrderWay() {
        return submitOrderWay;
    }

    public void setSubmitOrderWay(int submitOrderWay) {
        this.submitOrderWay = submitOrderWay;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public void copyGlistToSmbGood(OrderDetailListJSONOrderListGlist giftlist) {

        this.setGcode(giftlist.getGcode());

        this.setGname(giftlist.getGname());

        this.setGexchange(giftlist.getGexchange());

        this.setEvalstatus(giftlist.getEvalstatus());

        this.setGdesc(giftlist.getGdesc());

        this.setGphoto(giftlist.getGphoto());

        this.setGprice(giftlist.getGprice());

        this.setGrealprice(giftlist.getGrealprice());

        this.setGspec(giftlist.getGspec());

        this.setGcount(giftlist.getGcount());

        this.setGroupingID(giftlist.getGroupingID());

        this.setDeatLike(giftlist.getDeatLike());

        this.setIsPhysical(giftlist.getIsPhysical());

        this.setPhoneServiceNumber(giftlist.getPhoneServiceNumber());

        this.setFeeInfo(giftlist.getFeeInfo());

        this.setNumberDetail(giftlist.getNumberDetail());

        this.setAraeCodeName(giftlist.getAraeCodeName());

        this.setSalesType(giftlist.getSalesType());

    }
}
