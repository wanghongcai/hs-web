package com.lenovo.m2.web.domain.my.address.view;


import com.lenovo.m2.hsbuy.domain.BaseInfo;

/**
 * <br>返回界面的区县列表
 * @author shenjc
 *
 */
public class RegionView extends BaseInfo {
	private String counties;
	
	public RegionView(int rc, String msg, String counties) {
		super(rc, msg);
		this.counties = counties;
	}
	
	public RegionView() {
		super(0, "");
	}
	
	public String getCounties() {
		return counties;
	}

	public void setCounties(String counties) {
		this.counties = counties;
	}	
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("counties:" + this.counties+";");
		return buffer.toString();
	}
}
