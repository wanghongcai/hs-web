package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by zhaocl1 on 2016/10/17.
 */
public class Presell implements Serializable {

    //预售方式
    private Integer presellway;   //预售方式(1:全款 2:订金)
    //预售定金
    private Money deposit;
    //尾款金额
    private Money restPayment;
    //尾款支付超时日期
    private String tailPaymentDay;
    //定金支付超时日期
    private String depositEndTime;
    /**
     *  预售尾款手机号
     */
    private String preSaleMobile;

    public String getPreSaleMobile() {
        return preSaleMobile;
    }

    public void setPreSaleMobile(String preSaleMobile) {
        this.preSaleMobile = preSaleMobile;
    }

    public Integer getPresellway() {
        return presellway;
    }

    public void setPresellway(Integer presellway) {
        this.presellway = presellway;
    }

    public Money getDeposit() {
        return deposit;
    }

    public void setDeposit(Money deposit) {
        this.deposit = deposit;
    }

    public Money getRestPayment() {
        return restPayment;
    }

    public void setRestPayment(Money restPayment) {
        this.restPayment = restPayment;
    }

    public String getTailPaymentDay() {
        return tailPaymentDay;
    }

    public void setTailPaymentDay(String tailPaymentDay) {
        this.tailPaymentDay = tailPaymentDay;
    }

    public String getDepositEndTime() {
        return depositEndTime;
    }

    public void setDepositEndTime(String depositEndTime) {
        this.depositEndTime = depositEndTime;
    }
}
