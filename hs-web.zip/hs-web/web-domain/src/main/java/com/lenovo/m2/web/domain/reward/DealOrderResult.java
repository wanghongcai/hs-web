package com.lenovo.m2.web.domain.reward;

import com.lenovo.m2.hsbuy.domain.order.orderInfo.OrderInfo;

import java.util.List;

/**
 * Created by xuweihua on 2016/11/9.
 */
public class DealOrderResult {
    public int count;
    public List<OrderInfo>  orderInfos;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<OrderInfo> getOrderInfos() {
        return orderInfos;
    }

    public void setOrderInfos(List<OrderInfo> orderInfos) {
        this.orderInfos = orderInfos;
    }
}
