package com.lenovo.m2.web.domain.purchase.member;

/**
 * 会员远程调用返回结果对应类
 * Created by zhanghongsheng on 2015/7/14.
 */
public class MemberRemoteVo {
    private String ret;//返回结果状态 0：正确，1：失败
    private String msg;//如果失败则表示失败原因
    private MemberRemote memberRemote;//会员详细信息

    public String getRet() {
        return ret;
    }

    public void setRet(String ret) {
        this.ret = ret;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public MemberRemote getMemberRemote() {
        return memberRemote;
    }

    public void setMemberRemote(MemberRemote memberRemote) {
        this.memberRemote = memberRemote;
    }
}
