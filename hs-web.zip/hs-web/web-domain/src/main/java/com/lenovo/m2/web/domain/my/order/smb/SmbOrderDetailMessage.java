package com.lenovo.m2.web.domain.my.order.smb;


import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderList;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jack on 2016/8/7.
 */
public class SmbOrderDetailMessage implements Serializable {

    private List<OrderDetailListJSONOrderList> smbOrderDetailMessage = new ArrayList<>();

    public List<OrderDetailListJSONOrderList> getSmbOrderDetail() {
        return smbOrderDetailMessage;
    }

    public void setSmbOrderDetail(List<OrderDetailListJSONOrderList> smbOrderDetailMessage) {
        this.smbOrderDetailMessage = smbOrderDetailMessage;
    }
}
