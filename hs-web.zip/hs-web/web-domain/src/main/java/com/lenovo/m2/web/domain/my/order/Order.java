package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.util.Date;

/**
 * Created by jiangzh5 on 2015/7/28.
 */
public class Order {

    private String id;	//id

    private Integer source;		//订单原因

    private String payorderno;		//支付单号

    private String ordermaincode;	//主订单号

    private String ordercode;		//订单号

    private String vkorg;		//销售组织

    private String saleschannel;	//销售渠道

    public String getSalesOrderType() {
        return salesOrderType;
    }

    public void setSalesOrderType(String salesOrderType) {
        this.salesOrderType = salesOrderType;
    }

    private String salesOrderType;	//销售类型

    private String memberid;		//用户id

    private String membercode;		//用户名

    private String typeid;		//商品分类id

    private Money costitem;		//订单总价

    private Money amountmoney;		//支付总金额

    private Money giveawaycost;	//赠品优惠金额

    private Money giveawaytotal;	//优惠金额总计

    private Money credittotal;		////////可得积分

    private Integer paystatus;		//支付状态

    private Date paydatetime;		//支付时间

    private Date expectdate;	//

    private String augru;		//

    private String paymentday;

    private String biztype;

    private Boolean isdelivery;

    private Boolean istax;

    private String taxcontent;

    private String taxcompany;

    private Integer shipstatus;

    private Integer status;

    private Integer isreturn;

    private String marktext;

    private String memberdesc;

    private String addonstr;

    private String orderrefer;

    private String returngoodsremark;

    private Boolean isfaorder;

    private String faid;

    private Integer isabnormal;

    private Boolean isqualified;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    private String hasComment;

    private String paymentType;

    private Integer type;

    private int  merchantId;

    private int faType;

    private String lenovoId;

    private String c1LenovoID;

    public String getC1LenovoID() {
        return c1LenovoID;
    }

    public void setC1LenovoID(String c1LenovoID) {
        this.c1LenovoID = c1LenovoID;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public int getFaType() {
        return faType;
    }

    public void setFaType(int faType) {
        this.faType = faType;
    }

    public int getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(int merchantId) {
        this.merchantId = merchantId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getHasComment() {
        return hasComment;
    }

    public void setHasComment(String hasComment) {
        this.hasComment = hasComment;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getPayorderno() {
        return payorderno;
    }

    public void setPayorderno(String payorderno) {
        this.payorderno = payorderno == null ? null : payorderno.trim();
    }

    public String getOrdermaincode() {
        return ordermaincode;
    }

    public void setOrdermaincode(String ordermaincode) {
        this.ordermaincode = ordermaincode == null ? null : ordermaincode.trim();
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode == null ? null : ordercode.trim();
    }

    public String getVkorg() {
        return vkorg;
    }

    public void setVkorg(String vkorg) {
        this.vkorg = vkorg == null ? null : vkorg.trim();
    }

    public String getSaleschannel() {
        return saleschannel;
    }

    public void setSaleschannel(String saleschannel) {
        this.saleschannel = saleschannel == null ? null : saleschannel.trim();
    }

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid == null ? null : memberid.trim();
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode == null ? null : membercode.trim();
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid == null ? null : typeid.trim();
    }

    public Money getCostitem() {
        return costitem;
    }

    public void setCostitem(Money costitem) {
        this.costitem = costitem;
    }

    public Money getAmountmoney() {
        return amountmoney;
    }

    public void setAmountmoney(Money amountmoney) {
        this.amountmoney = amountmoney;
    }

    public Money getGiveawaycost() {
        return giveawaycost;
    }

    public void setGiveawaycost(Money giveawaycost) {
        this.giveawaycost = giveawaycost;
    }

    public Money getGiveawaytotal() {
        return giveawaytotal;
    }

    public void setGiveawaytotal(Money giveawaytotal) {
        this.giveawaytotal = giveawaytotal;
    }

    public Money getCredittotal() {
        return credittotal;
    }

    public void setCredittotal(Money credittotal) {
        this.credittotal = credittotal;
    }

    public Integer getPaystatus() {
        return paystatus;
    }

    public void setPaystatus(Integer paystatus) {
        this.paystatus = paystatus;
    }

    public Date getPaydatetime() {
        return paydatetime;
    }

    public void setPaydatetime(Date paydatetime) {
        this.paydatetime = paydatetime;
    }

    public Date getExpectdate() {
        return expectdate;
    }

    public void setExpectdate(Date expectdate) {
        this.expectdate = expectdate;
    }

    public String getAugru() {
        return augru;
    }

    public void setAugru(String augru) {
        this.augru = augru == null ? null : augru.trim();
    }

    public String getPaymentday() {
        return paymentday;
    }

    public void setPaymentday(String paymentday) {
        this.paymentday = paymentday == null ? null : paymentday.trim();
    }

    public String getBiztype() {
        return biztype;
    }

    public void setBiztype(String biztype) {
        this.biztype = biztype == null ? null : biztype.trim();
    }

    public Boolean getIsdelivery() {
        return isdelivery;
    }

    public void setIsdelivery(Boolean isdelivery) {
        this.isdelivery = isdelivery;
    }

    public Boolean getIstax() {
        return istax;
    }

    public void setIstax(Boolean istax) {
        this.istax = istax;
    }

    public String getTaxcontent() {
        return taxcontent;
    }

    public void setTaxcontent(String taxcontent) {
        this.taxcontent = taxcontent == null ? null : taxcontent.trim();
    }

    public String getTaxcompany() {
        return taxcompany;
    }

    public void setTaxcompany(String taxcompany) {
        this.taxcompany = taxcompany == null ? null : taxcompany.trim();
    }

    public Integer getShipstatus() {
        return shipstatus;
    }

    public void setShipstatus(Integer shipstatus) {
        this.shipstatus = shipstatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsreturn() {
        return isreturn;
    }

    public void setIsreturn(Integer isreturn) {
        this.isreturn = isreturn;
    }

    public String getMarktext() {
        return marktext;
    }

    public void setMarktext(String marktext) {
        this.marktext = marktext == null ? null : marktext.trim();
    }

    public String getMemberdesc() {
        return memberdesc;
    }

    public void setMemberdesc(String memberdesc) {
        this.memberdesc = memberdesc == null ? null : memberdesc.trim();
    }

    public String getAddonstr() {
        return addonstr;
    }

    public void setAddonstr(String addonstr) {
        this.addonstr = addonstr == null ? null : addonstr.trim();
    }

    public String getOrderrefer() {
        return orderrefer;
    }

    public void setOrderrefer(String orderrefer) {
        this.orderrefer = orderrefer == null ? null : orderrefer.trim();
    }

    public String getReturngoodsremark() {
        return returngoodsremark;
    }

    public void setReturngoodsremark(String returngoodsremark) {
        this.returngoodsremark = returngoodsremark == null ? null : returngoodsremark.trim();
    }

    public Boolean getIsfaorder() {
        return isfaorder;
    }

    public void setIsfaorder(Boolean isfaorder) {
        this.isfaorder = isfaorder;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid == null ? null : faid.trim();
    }

    public Integer getIsabnormal() {
        return isabnormal;
    }

    public void setIsabnormal(Integer isabnormal) {
        this.isabnormal = isabnormal;
    }

    public Boolean getIsqualified() {
        return isqualified;
    }

    public void setIsqualified(Boolean isqualified) {
        this.isqualified = isqualified;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
