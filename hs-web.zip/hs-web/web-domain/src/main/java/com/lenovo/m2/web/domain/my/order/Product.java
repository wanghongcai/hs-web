package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by chenww3 on 2015/6/14.
 * 产品表
 */
public class Product implements Serializable {
    private String productCode;// 商品编号
    private String productID = "";// 产品ID
    private String productName;// 商品名称
    private String productNumber;// 商品数量
    private Money volumePay;// 优惠券金额
    private Money productPay;// 商品单价
    private Money favourablePay;// 折扣总金额
    private Money paySubtotal;// 商品价钱小计
    private Money discountRate;// 折扣比例
    private Money productCredit;// 商品积分 暂时不用，固定传0
    private String groupingID;//购物车一行（主件/选件/赠品）生产同一字符串标识
    private String isGift;//0否1是
    private String productPhoto;//商品图片
    private String productDesc;//商品描述
    private String specification;//商品规格
    private String stockstatus;//库存状态名称

    //物料信息
    private String goodsMaterialID = "";//物料id
    private String lenovoProductCode = "";//联想物料编码
    private String unit = "";//单位
    private String deatLike = "";//产品组
    private String factoryCode = "";//交货工厂
    private String warehouseCode = "";//库存地
    private String storageCode = "";//仓库
    private String salesChannel;
    private String faid;
    private String faname;
    private String fatype;
    //慧商线下银行转账新增分销商编码
    private String faCode;
    private Money voucherTotalAmount;//代金券总金额
    private String note;//大礼包金额对应的code，代金券id,多个使用逗号隔开，
    
    private String salesOrganization;//销售组织
    
    private String gexchange;//商品换货标识 为空或0代表未换货，1代表换货

    private String skuExtend;
    private String url;
    //产品表信息
    private String salesType;
    /**
     * 二期新增
     */
    // 区分实物非实物 0 非实物；1 实物
    private int isPhysical;

    // 是否服务 1 服务产品;2 非服务产品
    private int isServiceProd;

    // 购买服务时，绑定的SN号。
    private String machineSN;

    private String serviceCode;

    private String lsProductCode;
    /**
     * think 新增
     * @return
     */
    private String thinkRemark="";

    private String phoneServiceNumber;

    //懂得
    private String cacGoodsinfoes;
    private String dongPackInfo;

    private String skuType;

    public String getSkuType() {
        return skuType;
    }

    public void setSkuType(String skuType) {
        this.skuType = skuType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public Money getVolumePay() {
        return volumePay;
    }

    public void setVolumePay(Money volumePay) {
        this.volumePay = volumePay;
    }

    public Money getProductPay() {
        return productPay;
    }

    public void setProductPay(Money productPay) {
        this.productPay = productPay;
    }

    public Money getFavourablePay() {
        return favourablePay;
    }

    public void setFavourablePay(Money favourablePay) {
        this.favourablePay = favourablePay;
    }

    public Money getPaySubtotal() {
        return paySubtotal;
    }

    public void setPaySubtotal(Money paySubtotal) {
        this.paySubtotal = paySubtotal;
    }

    public Money getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(Money discountRate) {
        this.discountRate = discountRate;
    }

    public Money getProductCredit() {
        return productCredit;
    }

    public void setProductCredit(Money productCredit) {
        this.productCredit = productCredit;
    }

    public String getGroupingID() {
        return groupingID;
    }

    public void setGroupingID(String groupingID) {
        this.groupingID = groupingID;
    }

    public String getIsGift() {
        return isGift;
    }

    public void setIsGift(String isGift) {
        this.isGift = isGift;
    }

    public String getProductPhoto() {
        return productPhoto;
    }

    public void setProductPhoto(String productPhoto) {
        this.productPhoto = productPhoto;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getStockstatus() {
        return stockstatus;
    }

    public void setStockstatus(String stockstatus) {
        this.stockstatus = stockstatus;
    }

    public String getGoodsMaterialID() {
        return goodsMaterialID;
    }

    public void setGoodsMaterialID(String goodsMaterialID) {
        this.goodsMaterialID = goodsMaterialID;
    }

    public String getLenovoProductCode() {
        return lenovoProductCode;
    }

    public void setLenovoProductCode(String lenovoProductCode) {
        this.lenovoProductCode = lenovoProductCode;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDeatLike() {
        return deatLike;
    }

    public void setDeatLike(String deatLike) {
        this.deatLike = deatLike;
    }

    public String getFactoryCode() {
        return factoryCode;
    }

    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }

    public String getWarehouseCode() {
        return warehouseCode;
    }

    public void setWarehouseCode(String warehouseCode) {
        this.warehouseCode = warehouseCode;
    }

    public String getStorageCode() {
        return storageCode;
    }

    public void setStorageCode(String storageCode) {
        this.storageCode = storageCode;
    }

    public String getSalesChannel() {
        return salesChannel;
    }

    public void setSalesChannel(String salesChannel) {
        this.salesChannel = salesChannel;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    public String getFaname() {
        return faname;
    }

    public void setFaname(String faname) {
        this.faname = faname;
    }

    public String getFatype() {
        return fatype;
    }

    public void setFatype(String fatype) {
        this.fatype = fatype;
    }

    public Money getVoucherTotalAmount() {
        return voucherTotalAmount;
    }

    public void setVoucherTotalAmount(Money voucherTotalAmount) {
        this.voucherTotalAmount = voucherTotalAmount;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSalesOrganization() {
        return salesOrganization;
    }

    public void setSalesOrganization(String salesOrganization) {
        this.salesOrganization = salesOrganization;
    }

    public String getGexchange() {
        return gexchange;
    }

    public void setGexchange(String gexchange) {
        this.gexchange = gexchange;
    }

    public String getSkuExtend() {
        return skuExtend;
    }

    public void setSkuExtend(String skuExtend) {
        this.skuExtend = skuExtend;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSalesType() {
        return salesType;
    }

    public void setSalesType(String salesType) {
        this.salesType = salesType;
    }

    public int getIsPhysical() {
        return isPhysical;
    }

    public void setIsPhysical(int isPhysical) {
        this.isPhysical = isPhysical;
    }

    public int getIsServiceProd() {
        return isServiceProd;
    }

    public void setIsServiceProd(int isServiceProd) {
        this.isServiceProd = isServiceProd;
    }

    public String getMachineSN() {
        return machineSN;
    }

    public void setMachineSN(String machineSN) {
        this.machineSN = machineSN;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getLsProductCode() {
        return lsProductCode;
    }

    public void setLsProductCode(String lsProductCode) {
        this.lsProductCode = lsProductCode;
    }

    public String getThinkRemark() {
        return thinkRemark;
    }

    public void setThinkRemark(String thinkRemark) {
        this.thinkRemark = thinkRemark;
    }

    public String getPhoneServiceNumber() {
        return phoneServiceNumber;
    }

    public void setPhoneServiceNumber(String phoneServiceNumber) {
        this.phoneServiceNumber = phoneServiceNumber;
    }

    public String getCacGoodsinfoes() {
        return cacGoodsinfoes;
    }

    public void setCacGoodsinfoes(String cacGoodsinfoes) {
        this.cacGoodsinfoes = cacGoodsinfoes;
    }

    public String getDongPackInfo() {
        return dongPackInfo;
    }

    public void setDongPackInfo(String dongPackInfo) {
        this.dongPackInfo = dongPackInfo;
    }

    public String getFaCode() {
        return faCode;
    }

    public void setFaCode(String faCode) {
        this.faCode = faCode;
    }
}
