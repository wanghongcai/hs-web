package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by chenww3 on 2015/6/14.
 * 支付表
 */
public class PayCount implements Serializable {

    private String gatheringBank;// 收款银行
    private String gatheringCode;// 收款账号
    private Money gatheringNum;// 收款金额
    private String gatheringName;// 收款人
    private String paymentLX;// 付款类型  1线上支付 2线下支付
    private String payment;// 支付方式  0 招商银行, 1支付宝, 4支付宝直连支付,2银联支付
    private String paymentUser;// 付款人
    private String gatheringDesc;// 收款单备注
    private String zForTK;//支付0、退款1
    private String payStatus;//支付状态 0未支付  1支付成功 推入mq

    public String getGatheringBank() {
        return gatheringBank;
    }

    public void setGatheringBank(String gatheringBank) {
        this.gatheringBank = gatheringBank;
    }

    public String getGatheringCode() {
        return gatheringCode;
    }

    public void setGatheringCode(String gatheringCode) {
        this.gatheringCode = gatheringCode;
    }

    public Money getGatheringNum() {
        return gatheringNum;
    }

    public void setGatheringNum(Money gatheringNum) {
        this.gatheringNum = gatheringNum;
    }

    public String getGatheringName() {
        return gatheringName;
    }

    public void setGatheringName(String gatheringName) {
        this.gatheringName = gatheringName;
    }

    public String getPaymentLX() {
        return paymentLX;
    }

    public void setPaymentLX(String paymentLX) {
        this.paymentLX = paymentLX;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPaymentUser() {
        return paymentUser;
    }

    public void setPaymentUser(String paymentUser) {
        this.paymentUser = paymentUser;
    }

    public String getGatheringDesc() {
        return gatheringDesc;
    }

    public void setGatheringDesc(String gatheringDesc) {
        this.gatheringDesc = gatheringDesc;
    }

    public String getzForTK() {
        return zForTK;
    }

    public void setzForTK(String zForTK) {
        this.zForTK = zForTK;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

}
