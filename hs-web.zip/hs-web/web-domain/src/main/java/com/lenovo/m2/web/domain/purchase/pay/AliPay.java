package com.lenovo.m2.web.domain.purchase.pay;

/**
 * <br> 支付宝账号Bean
 * @author jinchen
 *
 */
public class AliPay {
	private String seller_mail;
	private String partner;
	private String md5_key;
	private String seller_id;
	
	public String getSeller_mail() {
		return seller_mail;
	}
	public void setSeller_mail(String seller_mail) {
		this.seller_mail = seller_mail;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getMd5_key() {
		return md5_key;
	}
	public void setMd5_key(String md5_key) {
		this.md5_key = md5_key;
	}
	public String getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(String seller_id) {
		this.seller_id = seller_id;
	}
	public String toString() {
		
		return "";
	}
}
