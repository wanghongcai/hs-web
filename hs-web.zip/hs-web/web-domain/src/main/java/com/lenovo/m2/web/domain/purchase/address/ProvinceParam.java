package com.lenovo.m2.web.domain.purchase.address;

import java.io.Serializable;

public class ProvinceParam implements Serializable {
    private java.lang.String province;
    private java.lang.String city;
    private java.lang.String county;
    private java.lang.String township;

    @Override
    public String toString() {
        return "ProvinceParam{" +
                "province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", township='" + township + '\'' +
                '}';
    }

    public ProvinceParam() {
    }

    public ProvinceParam(String province, String city, String county, String township) {
        this.province = province;
        this.city = city;
        this.county = county;
        this.township = township;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTownship() {
        return township;
    }

    public void setTownship(String township) {
        this.township = township;
    }
}
