package com.lenovo.m2.web.domain.purchase.member;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MemberExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private int pageIndex;

    private int pageSize;

    public MemberExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex=pageIndex;
    }

    public int getPageIndex() {
        return this.pageIndex;
    }

    public void setPageSize(int pageSize) {
        this.pageSize=pageSize;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public MemberExample(int pageIndex, int pageSize) {
        this();
        this.pageIndex=pageIndex;
        this.pageSize=pageSize;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andLenovoidIsNull() {
            addCriterion("LenovoID is null");
            return (Criteria) this;
        }

        public Criteria andLenovoidIsNotNull() {
            addCriterion("LenovoID is not null");
            return (Criteria) this;
        }

        public Criteria andLenovoidEqualTo(String value) {
            addCriterion("LenovoID =", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotEqualTo(String value) {
            addCriterion("LenovoID <>", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidGreaterThan(String value) {
            addCriterion("LenovoID >", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidGreaterThanOrEqualTo(String value) {
            addCriterion("LenovoID >=", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLessThan(String value) {
            addCriterion("LenovoID <", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLessThanOrEqualTo(String value) {
            addCriterion("LenovoID <=", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLike(String value) {
            addCriterion("LenovoID like", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotLike(String value) {
            addCriterion("LenovoID not like", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidIn(List<String> values) {
            addCriterion("LenovoID in", values, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotIn(List<String> values) {
            addCriterion("LenovoID not in", values, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidBetween(String value1, String value2) {
            addCriterion("LenovoID between", value1, value2, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotBetween(String value1, String value2) {
            addCriterion("LenovoID not between", value1, value2, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNull() {
            addCriterion("MemberCode is null");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNotNull() {
            addCriterion("MemberCode is not null");
            return (Criteria) this;
        }

        public Criteria andMembercodeEqualTo(String value) {
            addCriterion("MemberCode =", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotEqualTo(String value) {
            addCriterion("MemberCode <>", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThan(String value) {
            addCriterion("MemberCode >", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThanOrEqualTo(String value) {
            addCriterion("MemberCode >=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThan(String value) {
            addCriterion("MemberCode <", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThanOrEqualTo(String value) {
            addCriterion("MemberCode <=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLike(String value) {
            addCriterion("MemberCode like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotLike(String value) {
            addCriterion("MemberCode not like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeIn(List<String> values) {
            addCriterion("MemberCode in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotIn(List<String> values) {
            addCriterion("MemberCode not in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeBetween(String value1, String value2) {
            addCriterion("MemberCode between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotBetween(String value1, String value2) {
            addCriterion("MemberCode not between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidIsNull() {
            addCriterion("MemberLevelID is null");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidIsNotNull() {
            addCriterion("MemberLevelID is not null");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidEqualTo(String value) {
            addCriterion("MemberLevelID =", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidNotEqualTo(String value) {
            addCriterion("MemberLevelID <>", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidGreaterThan(String value) {
            addCriterion("MemberLevelID >", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidGreaterThanOrEqualTo(String value) {
            addCriterion("MemberLevelID >=", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidLessThan(String value) {
            addCriterion("MemberLevelID <", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidLessThanOrEqualTo(String value) {
            addCriterion("MemberLevelID <=", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidLike(String value) {
            addCriterion("MemberLevelID like", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidNotLike(String value) {
            addCriterion("MemberLevelID not like", value, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidIn(List<String> values) {
            addCriterion("MemberLevelID in", values, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidNotIn(List<String> values) {
            addCriterion("MemberLevelID not in", values, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidBetween(String value1, String value2) {
            addCriterion("MemberLevelID between", value1, value2, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andMemberlevelidNotBetween(String value1, String value2) {
            addCriterion("MemberLevelID not between", value1, value2, "memberlevelid");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("Name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("Name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("Name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("Name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("Name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("Name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("Name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("Name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("Name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("Name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("Name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("Name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("Name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("Name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andPointIsNull() {
            addCriterion("Point is null");
            return (Criteria) this;
        }

        public Criteria andPointIsNotNull() {
            addCriterion("Point is not null");
            return (Criteria) this;
        }

        public Criteria andPointEqualTo(Integer value) {
            addCriterion("Point =", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotEqualTo(Integer value) {
            addCriterion("Point <>", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointGreaterThan(Integer value) {
            addCriterion("Point >", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointGreaterThanOrEqualTo(Integer value) {
            addCriterion("Point >=", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointLessThan(Integer value) {
            addCriterion("Point <", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointLessThanOrEqualTo(Integer value) {
            addCriterion("Point <=", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointIn(List<Integer> values) {
            addCriterion("Point in", values, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotIn(List<Integer> values) {
            addCriterion("Point not in", values, "point");
            return (Criteria) this;
        }

        public Criteria andPointBetween(Integer value1, Integer value2) {
            addCriterion("Point between", value1, value2, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotBetween(Integer value1, Integer value2) {
            addCriterion("Point not between", value1, value2, "point");
            return (Criteria) this;
        }

        public Criteria andMembertypeIsNull() {
            addCriterion("MemberType is null");
            return (Criteria) this;
        }

        public Criteria andMembertypeIsNotNull() {
            addCriterion("MemberType is not null");
            return (Criteria) this;
        }

        public Criteria andMembertypeEqualTo(Integer value) {
            addCriterion("MemberType =", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeNotEqualTo(Integer value) {
            addCriterion("MemberType <>", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeGreaterThan(Integer value) {
            addCriterion("MemberType >", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("MemberType >=", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeLessThan(Integer value) {
            addCriterion("MemberType <", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeLessThanOrEqualTo(Integer value) {
            addCriterion("MemberType <=", value, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeIn(List<Integer> values) {
            addCriterion("MemberType in", values, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeNotIn(List<Integer> values) {
            addCriterion("MemberType not in", values, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeBetween(Integer value1, Integer value2) {
            addCriterion("MemberType between", value1, value2, "membertype");
            return (Criteria) this;
        }

        public Criteria andMembertypeNotBetween(Integer value1, Integer value2) {
            addCriterion("MemberType not between", value1, value2, "membertype");
            return (Criteria) this;
        }

        public Criteria andLastnameIsNull() {
            addCriterion("LastName is null");
            return (Criteria) this;
        }

        public Criteria andLastnameIsNotNull() {
            addCriterion("LastName is not null");
            return (Criteria) this;
        }

        public Criteria andLastnameEqualTo(String value) {
            addCriterion("LastName =", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameNotEqualTo(String value) {
            addCriterion("LastName <>", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameGreaterThan(String value) {
            addCriterion("LastName >", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameGreaterThanOrEqualTo(String value) {
            addCriterion("LastName >=", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameLessThan(String value) {
            addCriterion("LastName <", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameLessThanOrEqualTo(String value) {
            addCriterion("LastName <=", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameLike(String value) {
            addCriterion("LastName like", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameNotLike(String value) {
            addCriterion("LastName not like", value, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameIn(List<String> values) {
            addCriterion("LastName in", values, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameNotIn(List<String> values) {
            addCriterion("LastName not in", values, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameBetween(String value1, String value2) {
            addCriterion("LastName between", value1, value2, "lastname");
            return (Criteria) this;
        }

        public Criteria andLastnameNotBetween(String value1, String value2) {
            addCriterion("LastName not between", value1, value2, "lastname");
            return (Criteria) this;
        }

        public Criteria andFirstnameIsNull() {
            addCriterion("FirstName is null");
            return (Criteria) this;
        }

        public Criteria andFirstnameIsNotNull() {
            addCriterion("FirstName is not null");
            return (Criteria) this;
        }

        public Criteria andFirstnameEqualTo(String value) {
            addCriterion("FirstName =", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameNotEqualTo(String value) {
            addCriterion("FirstName <>", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameGreaterThan(String value) {
            addCriterion("FirstName >", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameGreaterThanOrEqualTo(String value) {
            addCriterion("FirstName >=", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameLessThan(String value) {
            addCriterion("FirstName <", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameLessThanOrEqualTo(String value) {
            addCriterion("FirstName <=", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameLike(String value) {
            addCriterion("FirstName like", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameNotLike(String value) {
            addCriterion("FirstName not like", value, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameIn(List<String> values) {
            addCriterion("FirstName in", values, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameNotIn(List<String> values) {
            addCriterion("FirstName not in", values, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameBetween(String value1, String value2) {
            addCriterion("FirstName between", value1, value2, "firstname");
            return (Criteria) this;
        }

        public Criteria andFirstnameNotBetween(String value1, String value2) {
            addCriterion("FirstName not between", value1, value2, "firstname");
            return (Criteria) this;
        }

        public Criteria andAreaIsNull() {
            addCriterion("Area is null");
            return (Criteria) this;
        }

        public Criteria andAreaIsNotNull() {
            addCriterion("Area is not null");
            return (Criteria) this;
        }

        public Criteria andAreaEqualTo(String value) {
            addCriterion("Area =", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotEqualTo(String value) {
            addCriterion("Area <>", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThan(String value) {
            addCriterion("Area >", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThanOrEqualTo(String value) {
            addCriterion("Area >=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThan(String value) {
            addCriterion("Area <", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThanOrEqualTo(String value) {
            addCriterion("Area <=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLike(String value) {
            addCriterion("Area like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotLike(String value) {
            addCriterion("Area not like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaIn(List<String> values) {
            addCriterion("Area in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotIn(List<String> values) {
            addCriterion("Area not in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaBetween(String value1, String value2) {
            addCriterion("Area between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotBetween(String value1, String value2) {
            addCriterion("Area not between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andAddrIsNull() {
            addCriterion("Addr is null");
            return (Criteria) this;
        }

        public Criteria andAddrIsNotNull() {
            addCriterion("Addr is not null");
            return (Criteria) this;
        }

        public Criteria andAddrEqualTo(String value) {
            addCriterion("Addr =", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrNotEqualTo(String value) {
            addCriterion("Addr <>", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrGreaterThan(String value) {
            addCriterion("Addr >", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrGreaterThanOrEqualTo(String value) {
            addCriterion("Addr >=", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrLessThan(String value) {
            addCriterion("Addr <", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrLessThanOrEqualTo(String value) {
            addCriterion("Addr <=", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrLike(String value) {
            addCriterion("Addr like", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrNotLike(String value) {
            addCriterion("Addr not like", value, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrIn(List<String> values) {
            addCriterion("Addr in", values, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrNotIn(List<String> values) {
            addCriterion("Addr not in", values, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrBetween(String value1, String value2) {
            addCriterion("Addr between", value1, value2, "addr");
            return (Criteria) this;
        }

        public Criteria andAddrNotBetween(String value1, String value2) {
            addCriterion("Addr not between", value1, value2, "addr");
            return (Criteria) this;
        }

        public Criteria andMobileIsNull() {
            addCriterion("Mobile is null");
            return (Criteria) this;
        }

        public Criteria andMobileIsNotNull() {
            addCriterion("Mobile is not null");
            return (Criteria) this;
        }

        public Criteria andMobileEqualTo(String value) {
            addCriterion("Mobile =", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotEqualTo(String value) {
            addCriterion("Mobile <>", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileGreaterThan(String value) {
            addCriterion("Mobile >", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileGreaterThanOrEqualTo(String value) {
            addCriterion("Mobile >=", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLessThan(String value) {
            addCriterion("Mobile <", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLessThanOrEqualTo(String value) {
            addCriterion("Mobile <=", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileLike(String value) {
            addCriterion("Mobile like", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotLike(String value) {
            addCriterion("Mobile not like", value, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileIn(List<String> values) {
            addCriterion("Mobile in", values, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotIn(List<String> values) {
            addCriterion("Mobile not in", values, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileBetween(String value1, String value2) {
            addCriterion("Mobile between", value1, value2, "mobile");
            return (Criteria) this;
        }

        public Criteria andMobileNotBetween(String value1, String value2) {
            addCriterion("Mobile not between", value1, value2, "mobile");
            return (Criteria) this;
        }

        public Criteria andTelIsNull() {
            addCriterion("Tel is null");
            return (Criteria) this;
        }

        public Criteria andTelIsNotNull() {
            addCriterion("Tel is not null");
            return (Criteria) this;
        }

        public Criteria andTelEqualTo(String value) {
            addCriterion("Tel =", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotEqualTo(String value) {
            addCriterion("Tel <>", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThan(String value) {
            addCriterion("Tel >", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelGreaterThanOrEqualTo(String value) {
            addCriterion("Tel >=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThan(String value) {
            addCriterion("Tel <", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLessThanOrEqualTo(String value) {
            addCriterion("Tel <=", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelLike(String value) {
            addCriterion("Tel like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotLike(String value) {
            addCriterion("Tel not like", value, "tel");
            return (Criteria) this;
        }

        public Criteria andTelIn(List<String> values) {
            addCriterion("Tel in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotIn(List<String> values) {
            addCriterion("Tel not in", values, "tel");
            return (Criteria) this;
        }

        public Criteria andTelBetween(String value1, String value2) {
            addCriterion("Tel between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andTelNotBetween(String value1, String value2) {
            addCriterion("Tel not between", value1, value2, "tel");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("Email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("Email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("Email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("Email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("Email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("Email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("Email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("Email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("Email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("Email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("Email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("Email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("Email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("Email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andZipIsNull() {
            addCriterion("ZIP is null");
            return (Criteria) this;
        }

        public Criteria andZipIsNotNull() {
            addCriterion("ZIP is not null");
            return (Criteria) this;
        }

        public Criteria andZipEqualTo(String value) {
            addCriterion("ZIP =", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotEqualTo(String value) {
            addCriterion("ZIP <>", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThan(String value) {
            addCriterion("ZIP >", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipGreaterThanOrEqualTo(String value) {
            addCriterion("ZIP >=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThan(String value) {
            addCriterion("ZIP <", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLessThanOrEqualTo(String value) {
            addCriterion("ZIP <=", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipLike(String value) {
            addCriterion("ZIP like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotLike(String value) {
            addCriterion("ZIP not like", value, "zip");
            return (Criteria) this;
        }

        public Criteria andZipIn(List<String> values) {
            addCriterion("ZIP in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotIn(List<String> values) {
            addCriterion("ZIP not in", values, "zip");
            return (Criteria) this;
        }

        public Criteria andZipBetween(String value1, String value2) {
            addCriterion("ZIP between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andZipNotBetween(String value1, String value2) {
            addCriterion("ZIP not between", value1, value2, "zip");
            return (Criteria) this;
        }

        public Criteria andOrdernumIsNull() {
            addCriterion("OrderNum is null");
            return (Criteria) this;
        }

        public Criteria andOrdernumIsNotNull() {
            addCriterion("OrderNum is not null");
            return (Criteria) this;
        }

        public Criteria andOrdernumEqualTo(Integer value) {
            addCriterion("OrderNum =", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumNotEqualTo(Integer value) {
            addCriterion("OrderNum <>", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumGreaterThan(Integer value) {
            addCriterion("OrderNum >", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumGreaterThanOrEqualTo(Integer value) {
            addCriterion("OrderNum >=", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumLessThan(Integer value) {
            addCriterion("OrderNum <", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumLessThanOrEqualTo(Integer value) {
            addCriterion("OrderNum <=", value, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumIn(List<Integer> values) {
            addCriterion("OrderNum in", values, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumNotIn(List<Integer> values) {
            addCriterion("OrderNum not in", values, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumBetween(Integer value1, Integer value2) {
            addCriterion("OrderNum between", value1, value2, "ordernum");
            return (Criteria) this;
        }

        public Criteria andOrdernumNotBetween(Integer value1, Integer value2) {
            addCriterion("OrderNum not between", value1, value2, "ordernum");
            return (Criteria) this;
        }

        public Criteria andReferidIsNull() {
            addCriterion("ReferID is null");
            return (Criteria) this;
        }

        public Criteria andReferidIsNotNull() {
            addCriterion("ReferID is not null");
            return (Criteria) this;
        }

        public Criteria andReferidEqualTo(String value) {
            addCriterion("ReferID =", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidNotEqualTo(String value) {
            addCriterion("ReferID <>", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidGreaterThan(String value) {
            addCriterion("ReferID >", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidGreaterThanOrEqualTo(String value) {
            addCriterion("ReferID >=", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidLessThan(String value) {
            addCriterion("ReferID <", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidLessThanOrEqualTo(String value) {
            addCriterion("ReferID <=", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidLike(String value) {
            addCriterion("ReferID like", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidNotLike(String value) {
            addCriterion("ReferID not like", value, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidIn(List<String> values) {
            addCriterion("ReferID in", values, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidNotIn(List<String> values) {
            addCriterion("ReferID not in", values, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidBetween(String value1, String value2) {
            addCriterion("ReferID between", value1, value2, "referid");
            return (Criteria) this;
        }

        public Criteria andReferidNotBetween(String value1, String value2) {
            addCriterion("ReferID not between", value1, value2, "referid");
            return (Criteria) this;
        }

        public Criteria andReferurlIsNull() {
            addCriterion("ReferURL is null");
            return (Criteria) this;
        }

        public Criteria andReferurlIsNotNull() {
            addCriterion("ReferURL is not null");
            return (Criteria) this;
        }

        public Criteria andReferurlEqualTo(String value) {
            addCriterion("ReferURL =", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlNotEqualTo(String value) {
            addCriterion("ReferURL <>", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlGreaterThan(String value) {
            addCriterion("ReferURL >", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlGreaterThanOrEqualTo(String value) {
            addCriterion("ReferURL >=", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlLessThan(String value) {
            addCriterion("ReferURL <", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlLessThanOrEqualTo(String value) {
            addCriterion("ReferURL <=", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlLike(String value) {
            addCriterion("ReferURL like", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlNotLike(String value) {
            addCriterion("ReferURL not like", value, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlIn(List<String> values) {
            addCriterion("ReferURL in", values, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlNotIn(List<String> values) {
            addCriterion("ReferURL not in", values, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlBetween(String value1, String value2) {
            addCriterion("ReferURL between", value1, value2, "referurl");
            return (Criteria) this;
        }

        public Criteria andReferurlNotBetween(String value1, String value2) {
            addCriterion("ReferURL not between", value1, value2, "referurl");
            return (Criteria) this;
        }

        public Criteria andBirthyearIsNull() {
            addCriterion("BirthYear is null");
            return (Criteria) this;
        }

        public Criteria andBirthyearIsNotNull() {
            addCriterion("BirthYear is not null");
            return (Criteria) this;
        }

        public Criteria andBirthyearEqualTo(Integer value) {
            addCriterion("BirthYear =", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearNotEqualTo(Integer value) {
            addCriterion("BirthYear <>", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearGreaterThan(Integer value) {
            addCriterion("BirthYear >", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearGreaterThanOrEqualTo(Integer value) {
            addCriterion("BirthYear >=", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearLessThan(Integer value) {
            addCriterion("BirthYear <", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearLessThanOrEqualTo(Integer value) {
            addCriterion("BirthYear <=", value, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearIn(List<Integer> values) {
            addCriterion("BirthYear in", values, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearNotIn(List<Integer> values) {
            addCriterion("BirthYear not in", values, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearBetween(Integer value1, Integer value2) {
            addCriterion("BirthYear between", value1, value2, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthyearNotBetween(Integer value1, Integer value2) {
            addCriterion("BirthYear not between", value1, value2, "birthyear");
            return (Criteria) this;
        }

        public Criteria andBirthmonthIsNull() {
            addCriterion("BirthMonth is null");
            return (Criteria) this;
        }

        public Criteria andBirthmonthIsNotNull() {
            addCriterion("BirthMonth is not null");
            return (Criteria) this;
        }

        public Criteria andBirthmonthEqualTo(Integer value) {
            addCriterion("BirthMonth =", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthNotEqualTo(Integer value) {
            addCriterion("BirthMonth <>", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthGreaterThan(Integer value) {
            addCriterion("BirthMonth >", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthGreaterThanOrEqualTo(Integer value) {
            addCriterion("BirthMonth >=", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthLessThan(Integer value) {
            addCriterion("BirthMonth <", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthLessThanOrEqualTo(Integer value) {
            addCriterion("BirthMonth <=", value, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthIn(List<Integer> values) {
            addCriterion("BirthMonth in", values, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthNotIn(List<Integer> values) {
            addCriterion("BirthMonth not in", values, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthBetween(Integer value1, Integer value2) {
            addCriterion("BirthMonth between", value1, value2, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthmonthNotBetween(Integer value1, Integer value2) {
            addCriterion("BirthMonth not between", value1, value2, "birthmonth");
            return (Criteria) this;
        }

        public Criteria andBirthdayIsNull() {
            addCriterion("BirthDay is null");
            return (Criteria) this;
        }

        public Criteria andBirthdayIsNotNull() {
            addCriterion("BirthDay is not null");
            return (Criteria) this;
        }

        public Criteria andBirthdayEqualTo(Integer value) {
            addCriterion("BirthDay =", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayNotEqualTo(Integer value) {
            addCriterion("BirthDay <>", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayGreaterThan(Integer value) {
            addCriterion("BirthDay >", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayGreaterThanOrEqualTo(Integer value) {
            addCriterion("BirthDay >=", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayLessThan(Integer value) {
            addCriterion("BirthDay <", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayLessThanOrEqualTo(Integer value) {
            addCriterion("BirthDay <=", value, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayIn(List<Integer> values) {
            addCriterion("BirthDay in", values, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayNotIn(List<Integer> values) {
            addCriterion("BirthDay not in", values, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayBetween(Integer value1, Integer value2) {
            addCriterion("BirthDay between", value1, value2, "birthday");
            return (Criteria) this;
        }

        public Criteria andBirthdayNotBetween(Integer value1, Integer value2) {
            addCriterion("BirthDay not between", value1, value2, "birthday");
            return (Criteria) this;
        }

        public Criteria andSexIsNull() {
            addCriterion("Sex is null");
            return (Criteria) this;
        }

        public Criteria andSexIsNotNull() {
            addCriterion("Sex is not null");
            return (Criteria) this;
        }

        public Criteria andSexEqualTo(Integer value) {
            addCriterion("Sex =", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotEqualTo(Integer value) {
            addCriterion("Sex <>", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThan(Integer value) {
            addCriterion("Sex >", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThanOrEqualTo(Integer value) {
            addCriterion("Sex >=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThan(Integer value) {
            addCriterion("Sex <", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThanOrEqualTo(Integer value) {
            addCriterion("Sex <=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexIn(List<Integer> values) {
            addCriterion("Sex in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotIn(List<Integer> values) {
            addCriterion("Sex not in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexBetween(Integer value1, Integer value2) {
            addCriterion("Sex between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotBetween(Integer value1, Integer value2) {
            addCriterion("Sex not between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andWedlockIsNull() {
            addCriterion("WedLock is null");
            return (Criteria) this;
        }

        public Criteria andWedlockIsNotNull() {
            addCriterion("WedLock is not null");
            return (Criteria) this;
        }

        public Criteria andWedlockEqualTo(Integer value) {
            addCriterion("WedLock =", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockNotEqualTo(Integer value) {
            addCriterion("WedLock <>", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockGreaterThan(Integer value) {
            addCriterion("WedLock >", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockGreaterThanOrEqualTo(Integer value) {
            addCriterion("WedLock >=", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockLessThan(Integer value) {
            addCriterion("WedLock <", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockLessThanOrEqualTo(Integer value) {
            addCriterion("WedLock <=", value, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockIn(List<Integer> values) {
            addCriterion("WedLock in", values, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockNotIn(List<Integer> values) {
            addCriterion("WedLock not in", values, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockBetween(Integer value1, Integer value2) {
            addCriterion("WedLock between", value1, value2, "wedlock");
            return (Criteria) this;
        }

        public Criteria andWedlockNotBetween(Integer value1, Integer value2) {
            addCriterion("WedLock not between", value1, value2, "wedlock");
            return (Criteria) this;
        }

        public Criteria andEducationIsNull() {
            addCriterion("Education is null");
            return (Criteria) this;
        }

        public Criteria andEducationIsNotNull() {
            addCriterion("Education is not null");
            return (Criteria) this;
        }

        public Criteria andEducationEqualTo(String value) {
            addCriterion("Education =", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationNotEqualTo(String value) {
            addCriterion("Education <>", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationGreaterThan(String value) {
            addCriterion("Education >", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationGreaterThanOrEqualTo(String value) {
            addCriterion("Education >=", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationLessThan(String value) {
            addCriterion("Education <", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationLessThanOrEqualTo(String value) {
            addCriterion("Education <=", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationLike(String value) {
            addCriterion("Education like", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationNotLike(String value) {
            addCriterion("Education not like", value, "education");
            return (Criteria) this;
        }

        public Criteria andEducationIn(List<String> values) {
            addCriterion("Education in", values, "education");
            return (Criteria) this;
        }

        public Criteria andEducationNotIn(List<String> values) {
            addCriterion("Education not in", values, "education");
            return (Criteria) this;
        }

        public Criteria andEducationBetween(String value1, String value2) {
            addCriterion("Education between", value1, value2, "education");
            return (Criteria) this;
        }

        public Criteria andEducationNotBetween(String value1, String value2) {
            addCriterion("Education not between", value1, value2, "education");
            return (Criteria) this;
        }

        public Criteria andVocationIsNull() {
            addCriterion("Vocation is null");
            return (Criteria) this;
        }

        public Criteria andVocationIsNotNull() {
            addCriterion("Vocation is not null");
            return (Criteria) this;
        }

        public Criteria andVocationEqualTo(String value) {
            addCriterion("Vocation =", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationNotEqualTo(String value) {
            addCriterion("Vocation <>", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationGreaterThan(String value) {
            addCriterion("Vocation >", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationGreaterThanOrEqualTo(String value) {
            addCriterion("Vocation >=", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationLessThan(String value) {
            addCriterion("Vocation <", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationLessThanOrEqualTo(String value) {
            addCriterion("Vocation <=", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationLike(String value) {
            addCriterion("Vocation like", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationNotLike(String value) {
            addCriterion("Vocation not like", value, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationIn(List<String> values) {
            addCriterion("Vocation in", values, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationNotIn(List<String> values) {
            addCriterion("Vocation not in", values, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationBetween(String value1, String value2) {
            addCriterion("Vocation between", value1, value2, "vocation");
            return (Criteria) this;
        }

        public Criteria andVocationNotBetween(String value1, String value2) {
            addCriterion("Vocation not between", value1, value2, "vocation");
            return (Criteria) this;
        }

        public Criteria andAdvanceIsNull() {
            addCriterion("Advance is null");
            return (Criteria) this;
        }

        public Criteria andAdvanceIsNotNull() {
            addCriterion("Advance is not null");
            return (Criteria) this;
        }

        public Criteria andAdvanceEqualTo(BigDecimal value) {
            addCriterion("Advance =", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceNotEqualTo(BigDecimal value) {
            addCriterion("Advance <>", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceGreaterThan(BigDecimal value) {
            addCriterion("Advance >", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Advance >=", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceLessThan(BigDecimal value) {
            addCriterion("Advance <", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Advance <=", value, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceIn(List<BigDecimal> values) {
            addCriterion("Advance in", values, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceNotIn(List<BigDecimal> values) {
            addCriterion("Advance not in", values, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Advance between", value1, value2, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvanceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Advance not between", value1, value2, "advance");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeIsNull() {
            addCriterion("AdvanceFreeze is null");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeIsNotNull() {
            addCriterion("AdvanceFreeze is not null");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreeze =", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeNotEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreeze <>", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeGreaterThan(BigDecimal value) {
            addCriterion("AdvanceFreeze >", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreeze >=", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeLessThan(BigDecimal value) {
            addCriterion("AdvanceFreeze <", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeLessThanOrEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreeze <=", value, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeIn(List<BigDecimal> values) {
            addCriterion("AdvanceFreeze in", values, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeNotIn(List<BigDecimal> values) {
            addCriterion("AdvanceFreeze not in", values, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AdvanceFreeze between", value1, value2, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andAdvancefreezeNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AdvanceFreeze not between", value1, value2, "advancefreeze");
            return (Criteria) this;
        }

        public Criteria andScorerateIsNull() {
            addCriterion("ScoreRate is null");
            return (Criteria) this;
        }

        public Criteria andScorerateIsNotNull() {
            addCriterion("ScoreRate is not null");
            return (Criteria) this;
        }

        public Criteria andScorerateEqualTo(BigDecimal value) {
            addCriterion("ScoreRate =", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateNotEqualTo(BigDecimal value) {
            addCriterion("ScoreRate <>", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateGreaterThan(BigDecimal value) {
            addCriterion("ScoreRate >", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ScoreRate >=", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateLessThan(BigDecimal value) {
            addCriterion("ScoreRate <", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ScoreRate <=", value, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateIn(List<BigDecimal> values) {
            addCriterion("ScoreRate in", values, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateNotIn(List<BigDecimal> values) {
            addCriterion("ScoreRate not in", values, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ScoreRate between", value1, value2, "scorerate");
            return (Criteria) this;
        }

        public Criteria andScorerateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ScoreRate not between", value1, value2, "scorerate");
            return (Criteria) this;
        }

        public Criteria andRegipIsNull() {
            addCriterion("RegIP is null");
            return (Criteria) this;
        }

        public Criteria andRegipIsNotNull() {
            addCriterion("RegIP is not null");
            return (Criteria) this;
        }

        public Criteria andRegipEqualTo(String value) {
            addCriterion("RegIP =", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipNotEqualTo(String value) {
            addCriterion("RegIP <>", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipGreaterThan(String value) {
            addCriterion("RegIP >", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipGreaterThanOrEqualTo(String value) {
            addCriterion("RegIP >=", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipLessThan(String value) {
            addCriterion("RegIP <", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipLessThanOrEqualTo(String value) {
            addCriterion("RegIP <=", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipLike(String value) {
            addCriterion("RegIP like", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipNotLike(String value) {
            addCriterion("RegIP not like", value, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipIn(List<String> values) {
            addCriterion("RegIP in", values, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipNotIn(List<String> values) {
            addCriterion("RegIP not in", values, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipBetween(String value1, String value2) {
            addCriterion("RegIP between", value1, value2, "regip");
            return (Criteria) this;
        }

        public Criteria andRegipNotBetween(String value1, String value2) {
            addCriterion("RegIP not between", value1, value2, "regip");
            return (Criteria) this;
        }

        public Criteria andRegtimeIsNull() {
            addCriterion("RegTime is null");
            return (Criteria) this;
        }

        public Criteria andRegtimeIsNotNull() {
            addCriterion("RegTime is not null");
            return (Criteria) this;
        }

        public Criteria andRegtimeEqualTo(Integer value) {
            addCriterion("RegTime =", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeNotEqualTo(Integer value) {
            addCriterion("RegTime <>", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeGreaterThan(Integer value) {
            addCriterion("RegTime >", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("RegTime >=", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeLessThan(Integer value) {
            addCriterion("RegTime <", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeLessThanOrEqualTo(Integer value) {
            addCriterion("RegTime <=", value, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeIn(List<Integer> values) {
            addCriterion("RegTime in", values, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeNotIn(List<Integer> values) {
            addCriterion("RegTime not in", values, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeBetween(Integer value1, Integer value2) {
            addCriterion("RegTime between", value1, value2, "regtime");
            return (Criteria) this;
        }

        public Criteria andRegtimeNotBetween(Integer value1, Integer value2) {
            addCriterion("RegTime not between", value1, value2, "regtime");
            return (Criteria) this;
        }

        public Criteria andStateIsNull() {
            addCriterion("State is null");
            return (Criteria) this;
        }

        public Criteria andStateIsNotNull() {
            addCriterion("State is not null");
            return (Criteria) this;
        }

        public Criteria andStateEqualTo(Integer value) {
            addCriterion("State =", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotEqualTo(Integer value) {
            addCriterion("State <>", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThan(Integer value) {
            addCriterion("State >", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("State >=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThan(Integer value) {
            addCriterion("State <", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThanOrEqualTo(Integer value) {
            addCriterion("State <=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateIn(List<Integer> values) {
            addCriterion("State in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotIn(List<Integer> values) {
            addCriterion("State not in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateBetween(Integer value1, Integer value2) {
            addCriterion("State between", value1, value2, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotBetween(Integer value1, Integer value2) {
            addCriterion("State not between", value1, value2, "state");
            return (Criteria) this;
        }

        public Criteria andPaytimeIsNull() {
            addCriterion("PayTime is null");
            return (Criteria) this;
        }

        public Criteria andPaytimeIsNotNull() {
            addCriterion("PayTime is not null");
            return (Criteria) this;
        }

        public Criteria andPaytimeEqualTo(Integer value) {
            addCriterion("PayTime =", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeNotEqualTo(Integer value) {
            addCriterion("PayTime <>", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeGreaterThan(Integer value) {
            addCriterion("PayTime >", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("PayTime >=", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeLessThan(Integer value) {
            addCriterion("PayTime <", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeLessThanOrEqualTo(Integer value) {
            addCriterion("PayTime <=", value, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeIn(List<Integer> values) {
            addCriterion("PayTime in", values, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeNotIn(List<Integer> values) {
            addCriterion("PayTime not in", values, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeBetween(Integer value1, Integer value2) {
            addCriterion("PayTime between", value1, value2, "paytime");
            return (Criteria) this;
        }

        public Criteria andPaytimeNotBetween(Integer value1, Integer value2) {
            addCriterion("PayTime not between", value1, value2, "paytime");
            return (Criteria) this;
        }

        public Criteria andBizmoneyIsNull() {
            addCriterion("Bizmoney is null");
            return (Criteria) this;
        }

        public Criteria andBizmoneyIsNotNull() {
            addCriterion("Bizmoney is not null");
            return (Criteria) this;
        }

        public Criteria andBizmoneyEqualTo(BigDecimal value) {
            addCriterion("Bizmoney =", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyNotEqualTo(BigDecimal value) {
            addCriterion("Bizmoney <>", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyGreaterThan(BigDecimal value) {
            addCriterion("Bizmoney >", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Bizmoney >=", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyLessThan(BigDecimal value) {
            addCriterion("Bizmoney <", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Bizmoney <=", value, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyIn(List<BigDecimal> values) {
            addCriterion("Bizmoney in", values, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyNotIn(List<BigDecimal> values) {
            addCriterion("Bizmoney not in", values, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Bizmoney between", value1, value2, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andBizmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Bizmoney not between", value1, value2, "bizmoney");
            return (Criteria) this;
        }

        public Criteria andCurIsNull() {
            addCriterion("Cur is null");
            return (Criteria) this;
        }

        public Criteria andCurIsNotNull() {
            addCriterion("Cur is not null");
            return (Criteria) this;
        }

        public Criteria andCurEqualTo(String value) {
            addCriterion("Cur =", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurNotEqualTo(String value) {
            addCriterion("Cur <>", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurGreaterThan(String value) {
            addCriterion("Cur >", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurGreaterThanOrEqualTo(String value) {
            addCriterion("Cur >=", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurLessThan(String value) {
            addCriterion("Cur <", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurLessThanOrEqualTo(String value) {
            addCriterion("Cur <=", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurLike(String value) {
            addCriterion("Cur like", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurNotLike(String value) {
            addCriterion("Cur not like", value, "cur");
            return (Criteria) this;
        }

        public Criteria andCurIn(List<String> values) {
            addCriterion("Cur in", values, "cur");
            return (Criteria) this;
        }

        public Criteria andCurNotIn(List<String> values) {
            addCriterion("Cur not in", values, "cur");
            return (Criteria) this;
        }

        public Criteria andCurBetween(String value1, String value2) {
            addCriterion("Cur between", value1, value2, "cur");
            return (Criteria) this;
        }

        public Criteria andCurNotBetween(String value1, String value2) {
            addCriterion("Cur not between", value1, value2, "cur");
            return (Criteria) this;
        }

        public Criteria andLangIsNull() {
            addCriterion("Lang is null");
            return (Criteria) this;
        }

        public Criteria andLangIsNotNull() {
            addCriterion("Lang is not null");
            return (Criteria) this;
        }

        public Criteria andLangEqualTo(String value) {
            addCriterion("Lang =", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangNotEqualTo(String value) {
            addCriterion("Lang <>", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangGreaterThan(String value) {
            addCriterion("Lang >", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangGreaterThanOrEqualTo(String value) {
            addCriterion("Lang >=", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangLessThan(String value) {
            addCriterion("Lang <", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangLessThanOrEqualTo(String value) {
            addCriterion("Lang <=", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangLike(String value) {
            addCriterion("Lang like", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangNotLike(String value) {
            addCriterion("Lang not like", value, "lang");
            return (Criteria) this;
        }

        public Criteria andLangIn(List<String> values) {
            addCriterion("Lang in", values, "lang");
            return (Criteria) this;
        }

        public Criteria andLangNotIn(List<String> values) {
            addCriterion("Lang not in", values, "lang");
            return (Criteria) this;
        }

        public Criteria andLangBetween(String value1, String value2) {
            addCriterion("Lang between", value1, value2, "lang");
            return (Criteria) this;
        }

        public Criteria andLangNotBetween(String value1, String value2) {
            addCriterion("Lang not between", value1, value2, "lang");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgIsNull() {
            addCriterion("Unreadmsg is null");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgIsNotNull() {
            addCriterion("Unreadmsg is not null");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgEqualTo(Integer value) {
            addCriterion("Unreadmsg =", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgNotEqualTo(Integer value) {
            addCriterion("Unreadmsg <>", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgGreaterThan(Integer value) {
            addCriterion("Unreadmsg >", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgGreaterThanOrEqualTo(Integer value) {
            addCriterion("Unreadmsg >=", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgLessThan(Integer value) {
            addCriterion("Unreadmsg <", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgLessThanOrEqualTo(Integer value) {
            addCriterion("Unreadmsg <=", value, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgIn(List<Integer> values) {
            addCriterion("Unreadmsg in", values, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgNotIn(List<Integer> values) {
            addCriterion("Unreadmsg not in", values, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgBetween(Integer value1, Integer value2) {
            addCriterion("Unreadmsg between", value1, value2, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andUnreadmsgNotBetween(Integer value1, Integer value2) {
            addCriterion("Unreadmsg not between", value1, value2, "unreadmsg");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNull() {
            addCriterion("Disabled is null");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNotNull() {
            addCriterion("Disabled is not null");
            return (Criteria) this;
        }

        public Criteria andDisabledEqualTo(Integer value) {
            addCriterion("Disabled =", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotEqualTo(Integer value) {
            addCriterion("Disabled <>", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThan(Integer value) {
            addCriterion("Disabled >", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThanOrEqualTo(Integer value) {
            addCriterion("Disabled >=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThan(Integer value) {
            addCriterion("Disabled <", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThanOrEqualTo(Integer value) {
            addCriterion("Disabled <=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledIn(List<Integer> values) {
            addCriterion("Disabled in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotIn(List<Integer> values) {
            addCriterion("Disabled not in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledBetween(Integer value1, Integer value2) {
            addCriterion("Disabled between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotBetween(Integer value1, Integer value2) {
            addCriterion("Disabled not between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andRemarktypeIsNull() {
            addCriterion("RemarkType is null");
            return (Criteria) this;
        }

        public Criteria andRemarktypeIsNotNull() {
            addCriterion("RemarkType is not null");
            return (Criteria) this;
        }

        public Criteria andRemarktypeEqualTo(String value) {
            addCriterion("RemarkType =", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeNotEqualTo(String value) {
            addCriterion("RemarkType <>", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeGreaterThan(String value) {
            addCriterion("RemarkType >", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeGreaterThanOrEqualTo(String value) {
            addCriterion("RemarkType >=", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeLessThan(String value) {
            addCriterion("RemarkType <", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeLessThanOrEqualTo(String value) {
            addCriterion("RemarkType <=", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeLike(String value) {
            addCriterion("RemarkType like", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeNotLike(String value) {
            addCriterion("RemarkType not like", value, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeIn(List<String> values) {
            addCriterion("RemarkType in", values, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeNotIn(List<String> values) {
            addCriterion("RemarkType not in", values, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeBetween(String value1, String value2) {
            addCriterion("RemarkType between", value1, value2, "remarktype");
            return (Criteria) this;
        }

        public Criteria andRemarktypeNotBetween(String value1, String value2) {
            addCriterion("RemarkType not between", value1, value2, "remarktype");
            return (Criteria) this;
        }

        public Criteria andLogincountIsNull() {
            addCriterion("LoginCount is null");
            return (Criteria) this;
        }

        public Criteria andLogincountIsNotNull() {
            addCriterion("LoginCount is not null");
            return (Criteria) this;
        }

        public Criteria andLogincountEqualTo(Integer value) {
            addCriterion("LoginCount =", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountNotEqualTo(Integer value) {
            addCriterion("LoginCount <>", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountGreaterThan(Integer value) {
            addCriterion("LoginCount >", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountGreaterThanOrEqualTo(Integer value) {
            addCriterion("LoginCount >=", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountLessThan(Integer value) {
            addCriterion("LoginCount <", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountLessThanOrEqualTo(Integer value) {
            addCriterion("LoginCount <=", value, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountIn(List<Integer> values) {
            addCriterion("LoginCount in", values, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountNotIn(List<Integer> values) {
            addCriterion("LoginCount not in", values, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountBetween(Integer value1, Integer value2) {
            addCriterion("LoginCount between", value1, value2, "logincount");
            return (Criteria) this;
        }

        public Criteria andLogincountNotBetween(Integer value1, Integer value2) {
            addCriterion("LoginCount not between", value1, value2, "logincount");
            return (Criteria) this;
        }

        public Criteria andExperienceIsNull() {
            addCriterion("Experience is null");
            return (Criteria) this;
        }

        public Criteria andExperienceIsNotNull() {
            addCriterion("Experience is not null");
            return (Criteria) this;
        }

        public Criteria andExperienceEqualTo(Integer value) {
            addCriterion("Experience =", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotEqualTo(Integer value) {
            addCriterion("Experience <>", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceGreaterThan(Integer value) {
            addCriterion("Experience >", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceGreaterThanOrEqualTo(Integer value) {
            addCriterion("Experience >=", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceLessThan(Integer value) {
            addCriterion("Experience <", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceLessThanOrEqualTo(Integer value) {
            addCriterion("Experience <=", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceIn(List<Integer> values) {
            addCriterion("Experience in", values, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotIn(List<Integer> values) {
            addCriterion("Experience not in", values, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceBetween(Integer value1, Integer value2) {
            addCriterion("Experience between", value1, value2, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotBetween(Integer value1, Integer value2) {
            addCriterion("Experience not between", value1, value2, "experience");
            return (Criteria) this;
        }

        public Criteria andResetpwdIsNull() {
            addCriterion("ResetPwd is null");
            return (Criteria) this;
        }

        public Criteria andResetpwdIsNotNull() {
            addCriterion("ResetPwd is not null");
            return (Criteria) this;
        }

        public Criteria andResetpwdEqualTo(String value) {
            addCriterion("ResetPwd =", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdNotEqualTo(String value) {
            addCriterion("ResetPwd <>", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdGreaterThan(String value) {
            addCriterion("ResetPwd >", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdGreaterThanOrEqualTo(String value) {
            addCriterion("ResetPwd >=", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdLessThan(String value) {
            addCriterion("ResetPwd <", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdLessThanOrEqualTo(String value) {
            addCriterion("ResetPwd <=", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdLike(String value) {
            addCriterion("ResetPwd like", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdNotLike(String value) {
            addCriterion("ResetPwd not like", value, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdIn(List<String> values) {
            addCriterion("ResetPwd in", values, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdNotIn(List<String> values) {
            addCriterion("ResetPwd not in", values, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdBetween(String value1, String value2) {
            addCriterion("ResetPwd between", value1, value2, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdNotBetween(String value1, String value2) {
            addCriterion("ResetPwd not between", value1, value2, "resetpwd");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeIsNull() {
            addCriterion("ResetPwdTime is null");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeIsNotNull() {
            addCriterion("ResetPwdTime is not null");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeEqualTo(Integer value) {
            addCriterion("ResetPwdTime =", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeNotEqualTo(Integer value) {
            addCriterion("ResetPwdTime <>", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeGreaterThan(Integer value) {
            addCriterion("ResetPwdTime >", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("ResetPwdTime >=", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeLessThan(Integer value) {
            addCriterion("ResetPwdTime <", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeLessThanOrEqualTo(Integer value) {
            addCriterion("ResetPwdTime <=", value, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeIn(List<Integer> values) {
            addCriterion("ResetPwdTime in", values, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeNotIn(List<Integer> values) {
            addCriterion("ResetPwdTime not in", values, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeBetween(Integer value1, Integer value2) {
            addCriterion("ResetPwdTime between", value1, value2, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andResetpwdtimeNotBetween(Integer value1, Integer value2) {
            addCriterion("ResetPwdTime not between", value1, value2, "resetpwdtime");
            return (Criteria) this;
        }

        public Criteria andSourceplatformIsNull() {
            addCriterion("SourcePlatform is null");
            return (Criteria) this;
        }

        public Criteria andSourceplatformIsNotNull() {
            addCriterion("SourcePlatform is not null");
            return (Criteria) this;
        }

        public Criteria andSourceplatformEqualTo(Integer value) {
            addCriterion("SourcePlatform =", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformNotEqualTo(Integer value) {
            addCriterion("SourcePlatform <>", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformGreaterThan(Integer value) {
            addCriterion("SourcePlatform >", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformGreaterThanOrEqualTo(Integer value) {
            addCriterion("SourcePlatform >=", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformLessThan(Integer value) {
            addCriterion("SourcePlatform <", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformLessThanOrEqualTo(Integer value) {
            addCriterion("SourcePlatform <=", value, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformIn(List<Integer> values) {
            addCriterion("SourcePlatform in", values, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformNotIn(List<Integer> values) {
            addCriterion("SourcePlatform not in", values, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformBetween(Integer value1, Integer value2) {
            addCriterion("SourcePlatform between", value1, value2, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andSourceplatformNotBetween(Integer value1, Integer value2) {
            addCriterion("SourcePlatform not between", value1, value2, "sourceplatform");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}