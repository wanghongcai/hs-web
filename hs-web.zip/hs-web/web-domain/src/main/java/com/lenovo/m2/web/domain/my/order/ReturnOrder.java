package com.lenovo.m2.web.domain.my.order;

import java.util.Date;

/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2015年1月20日
 */
public class ReturnOrder {
	
	String rorderno; //退货单号 k号
	String orderno ;//原订单号
	Date applytime;  //申请时间
	String statename; //当前状态名称
	String rlgname;
	String rlgno;
	Integer isapplyok;
	public String getRlgname() {
		return rlgname;
	}
	public void setRlgname(String rlgname) {
		this.rlgname = rlgname;
	}
	public String getRlgno() {
		return rlgno;
	}
	public void setRlgno(String rlgno) {
		this.rlgno = rlgno;
	}
	public Integer getIsapplyok() {
		return isapplyok;
	}
	public void setIsapplyok(Integer isapplyok) {
		this.isapplyok = isapplyok;
	}
	public String getRorderno() {
		return rorderno;
	}
	public void setRorderno(String rorderno) {
		this.rorderno = rorderno;
	}
	public String getOrderno() {
		return orderno;
	}
	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}
	public Date getApplytime() {
		return applytime;
	}
	public void setApplytime(Date applytime) {
		this.applytime = applytime;
	}
	public String getStatename() {
		return statename;
	}
	public void setStatename(String statename) {
		this.statename = statename;
	}
	
	
	

}
