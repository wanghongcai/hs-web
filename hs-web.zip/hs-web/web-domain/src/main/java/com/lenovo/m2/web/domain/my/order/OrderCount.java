package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * Created by yyduff on 2016/3/17.
 */
public class OrderCount implements Serializable{

    private  int unPayCount;

    private  int unShipCount;

    private  int unConfirmCount;

    private  int returnCount;


    public int getUnPayCount() {
        return unPayCount;
    }

    public void setUnPayCount(int unPayCount) {
        this.unPayCount = unPayCount;
    }

    public int getUnShipCount() {
        return unShipCount;
    }

    public void setUnShipCount(int unShipCount) {
        this.unShipCount = unShipCount;
    }

    public int getUnConfirmCount() {
        return unConfirmCount;
    }

    public void setUnConfirmCount(int unConfirmCount) {
        this.unConfirmCount = unConfirmCount;
    }

    public int getReturnCount() {
        return returnCount;
    }

    public void setReturnCount(int returnCount) {
        this.returnCount = returnCount;
    }
}
