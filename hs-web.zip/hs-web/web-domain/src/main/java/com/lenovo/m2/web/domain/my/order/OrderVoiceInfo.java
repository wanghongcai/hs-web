package com.lenovo.m2.web.domain.my.order;

import java.util.Date;

/**
 * Created by mayan3 on 2015/9/18.
 */
public class OrderVoiceInfo {

	private String url;//发票下载url

	private String orderCode;//订单号

	private String btcpCode;//

	private int status;//状态，0代表库中未生成url 1代表已生成

	private Date createTime;

	private Date updateTime;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getBtcpCode() {
		return btcpCode;
	}

	public void setBtcpCode(String btcpCode) {
		this.btcpCode = btcpCode;
	}
}
