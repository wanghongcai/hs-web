package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * <br>返回界面的城市列表
 * @author shenjc
 *
 */
public class CityView extends BaseInfo {
	private String cities;
	
	public CityView(int rc, String msg, String cities) {
		super(rc, msg);
		this.cities = cities;
	}
	
	public CityView() {
		super(0, "");
	}
	
	public String getCities() {
		return cities;
	}

	public void setCities(String cities) {
		this.cities = cities;
	}	
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("cities:" + this.cities+";");
		return buffer.toString();
	}
}
