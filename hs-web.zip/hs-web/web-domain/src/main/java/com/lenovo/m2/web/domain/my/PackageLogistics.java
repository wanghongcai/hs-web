package com.lenovo.m2.web.domain.my;

/**
 * Created by yyduff on 2016/3/1.
 */
public class PackageLogistics {
    private int packageNo;

    private String packageDesc;

    public int getPackageNo() {
        return packageNo;
    }

    public void setPackageNo(int packageNo) {
        this.packageNo = packageNo;
    }

    public String getPackageDesc() {
        return packageDesc;
    }

    public void setPackageDesc(String packageDesc) {
        this.packageDesc = packageDesc;
    }
}
