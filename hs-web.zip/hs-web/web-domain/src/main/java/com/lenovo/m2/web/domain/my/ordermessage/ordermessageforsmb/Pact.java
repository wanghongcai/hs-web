package com.lenovo.m2.web.domain.my.ordermessage.ordermessageforsmb;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zhangzhen on 16/8/11.
 */
public class Pact implements Serializable {

    private String lenovoId;
    private int shopId;

    private boolean needToSend;//是否需要寄送合同
    private Date takeEffectTime;//合同生效日
    private String code;//合同编号

    /**
     * 卖方
     */
    private String sellerName = "联想(北京)有限公司";//卖方名称
    private String sellerAddress = "联想(北京)有限公司";//卖方地址
    private String sellerZip = "100000";//卖方邮政编码
    private String sellerLinkMan;//卖方联系人
    private String sellerPhone;//卖方电话
    private String sellerFax;//卖方传真

    /**
     * 买方
     */
    private String buyerName;//买方名称
    private String buyerAddress;//买方地址
    private String buyerLinkMan;//买方联系人
    private String buyerMobile;//买方电话
    private String buyerZip;//买方邮编

    /**
     * 收货地址
     */
    private String shipCompany;//送货单位
    private String shipAddress;//送货地址
    private String shipName;//送货联系人
    private String shipMobile;//送货电话
    private String shipZip;//送货邮编

    /**
     * 发票
     */
    private String invoiceType;//发票类型。0—电子票;1—普通票;2--增值票
    private String invoiceTitle;//发票抬头 = CustomerName
    private String invoiceTaxpayerIdentity;//发票税号
    private String invoiceDepositBank;//发票开户行
    private String invoiceBankNo;//发票开户行账号
    private String invoiceRegisterAddress;//发票注册地址
    private String invoiceRegisterPhone;//发票注册电话

    private String invoiceShipAddress;//发票收货
    private String invoiceShipName;//发票收货
    private String invoiceShipMobile;//发票收货
    private String invoiceShipZip;//发票收货

    /**
     * 收款信息
     */
    private String gatheringBank = "招商银行北京大屯路支行";// 收款银行
    private String gatheringCode = "866180558810001800800";// 收款账号
    private String gatheringName = "联想(北京)有限公司";// 收款人
    private Money gatheringNum;// 收款金额

    private List<Goods> goodsList;//商品列表

    public String getSellerLinkMan() {
        return sellerLinkMan;
    }

    public void setSellerLinkMan(String sellerLinkMan) {
        this.sellerLinkMan = sellerLinkMan;
    }

    public String getSellerPhone() {
        return sellerPhone;
    }

    public void setSellerPhone(String sellerPhone) {
        this.sellerPhone = sellerPhone;
    }

    public String getSellerFax() {
        return sellerFax;
    }

    public void setSellerFax(String sellerFax) {
        this.sellerFax = sellerFax;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public boolean isNeedToSend() {
        return needToSend;
    }

    public void setNeedToSend(boolean needToSend) {
        this.needToSend = needToSend;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerAddress() {
        return sellerAddress;
    }

    public void setSellerAddress(String sellerAddress) {
        this.sellerAddress = sellerAddress;
    }

    public String getSellerZip() {
        return sellerZip;
    }

    public void setSellerZip(String sellerZip) {
        this.sellerZip = sellerZip;
    }

    public Date getTakeEffectTime() {
        return takeEffectTime;
    }

    public void setTakeEffectTime(Date takeEffectTime) {
        this.takeEffectTime = takeEffectTime;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getBuyerAddress() {
        return buyerAddress;
    }

    public void setBuyerAddress(String buyerAddress) {
        this.buyerAddress = buyerAddress;
    }

    public String getBuyerLinkMan() {
        return buyerLinkMan;
    }

    public void setBuyerLinkMan(String buyerLinkMan) {
        this.buyerLinkMan = buyerLinkMan;
    }

    public String getBuyerMobile() {
        return buyerMobile;
    }

    public void setBuyerMobile(String buyerMobile) {
        this.buyerMobile = buyerMobile;
    }

    public String getBuyerZip() {
        return buyerZip;
    }

    public void setBuyerZip(String buyerZip) {
        this.buyerZip = buyerZip;
    }

    public String getShipCompany() {
        return shipCompany;
    }

    public void setShipCompany(String shipCompany) {
        this.shipCompany = shipCompany;
    }

    public String getShipAddress() {
        return shipAddress;
    }

    public void setShipAddress(String shipAddress) {
        this.shipAddress = shipAddress;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public String getShipMobile() {
        return shipMobile;
    }

    public void setShipMobile(String shipMobile) {
        this.shipMobile = shipMobile;
    }

    public String getShipZip() {
        return shipZip;
    }

    public void setShipZip(String shipZip) {
        this.shipZip = shipZip;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getInvoiceTaxpayerIdentity() {
        return invoiceTaxpayerIdentity;
    }

    public void setInvoiceTaxpayerIdentity(String invoiceTaxpayerIdentity) {
        this.invoiceTaxpayerIdentity = invoiceTaxpayerIdentity;
    }

    public String getInvoiceDepositBank() {
        return invoiceDepositBank;
    }

    public void setInvoiceDepositBank(String invoiceDepositBank) {
        this.invoiceDepositBank = invoiceDepositBank;
    }

    public String getInvoiceBankNo() {
        return invoiceBankNo;
    }

    public void setInvoiceBankNo(String invoiceBankNo) {
        this.invoiceBankNo = invoiceBankNo;
    }

    public String getInvoiceRegisterAddress() {
        return invoiceRegisterAddress;
    }

    public void setInvoiceRegisterAddress(String invoiceRegisterAddress) {
        this.invoiceRegisterAddress = invoiceRegisterAddress;
    }

    public String getInvoiceRegisterPhone() {
        return invoiceRegisterPhone;
    }

    public void setInvoiceRegisterPhone(String invoiceRegisterPhone) {
        this.invoiceRegisterPhone = invoiceRegisterPhone;
    }

    public String getInvoiceShipAddress() {
        return invoiceShipAddress;
    }

    public void setInvoiceShipAddress(String invoiceShipAddress) {
        this.invoiceShipAddress = invoiceShipAddress;
    }

    public String getInvoiceShipName() {
        return invoiceShipName;
    }

    public void setInvoiceShipName(String invoiceShipName) {
        this.invoiceShipName = invoiceShipName;
    }

    public String getInvoiceShipMobile() {
        return invoiceShipMobile;
    }

    public void setInvoiceShipMobile(String invoiceShipMobile) {
        this.invoiceShipMobile = invoiceShipMobile;
    }

    public String getInvoiceShipZip() {
        return invoiceShipZip;
    }

    public void setInvoiceShipZip(String invoiceShipZip) {
        this.invoiceShipZip = invoiceShipZip;
    }

    public String getGatheringBank() {
        return gatheringBank;
    }

    public void setGatheringBank(String gatheringBank) {
        this.gatheringBank = gatheringBank;
    }

    public String getGatheringCode() {
        return gatheringCode;
    }

    public void setGatheringCode(String gatheringCode) {
        this.gatheringCode = gatheringCode;
    }

    public Money getGatheringNum() {
        return gatheringNum;
    }

    public void setGatheringNum(Money gatheringNum) {
        this.gatheringNum = gatheringNum;
    }

    public String getGatheringName() {
        return gatheringName;
    }

    public void setGatheringName(String gatheringName) {
        this.gatheringName = gatheringName;
    }

    public List<Goods> getGoodsList() {
        return goodsList;
    }

    public void setGoodsList(List<Goods> goodsList) {
        this.goodsList = goodsList;
    }

    public void setGoods(Goods goods) {
        if (goodsList == null) {
            goodsList = new ArrayList<Goods>();
        }
        goodsList.add(goods);
    }
}
