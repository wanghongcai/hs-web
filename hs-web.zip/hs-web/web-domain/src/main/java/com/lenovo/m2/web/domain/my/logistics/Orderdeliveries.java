package com.lenovo.m2.web.domain.my.logistics;

import com.lenovo.m2.arch.framework.domain.Money;
import org.joda.time.DateTime;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Random;

public class Orderdeliveries implements Serializable {
    private String id;

    private String orderid;

    private String newordercode;

    private String rapplyk;

    private Date rapplydate;

    private String rinvoiceno;

    private String rreason;

    private String rcategory;

    private String rsales;

    private String raddress;

    private Date rreceiptdate;

    private Boolean isrefunded;

    private BigDecimal ramount= new BigDecimal("0.00");;

    private String servicemode;

    private String ordertype;

    private String oldshipmentsno;

    private String rstoragecode;

    private String deliveryno;

    private Money money;

    private Boolean isprotect;

    private Money protectmoney;

    private Integer productg;

    private String deliverytypeid;

    private String deliverytypename;

    private String logiid;

    private String loginame;

    private String logino;

    private String custno;

    private String custname;

    private String custaddress;

    private String custpost;

    private String custcity;

    private String custcounty;

    private String custarea;

    private String custareaname;

    private String custtel;

    private String shipcode;

    private String shipname;

    private String shipaddr;

    private String shipzip;

    private String shipcity;

    private String shiparea;

    private String delivercounty;

    private String deliverarea;

    private String deliverareaname;

    private String shipmobile;

    private String shiptel;

    private String shipnameno;

    private Integer deliverydate;

    private String opname;

    private Date tbegin;

    private Integer reviewstatus;

    private Boolean disabled;

    private Boolean isthrowing;

    private Date throwingtime;

    private Integer throwingstatus;

    private Date verificationtime;

    private Date factorydeliverydate;

    private Boolean isquality;

    private Money advancefreightmoney;

    private Boolean isdistributeleaflets;

    private Date switchcreatetime;

    private Boolean isrevoked;

    private Date senddate;

    private Date exceptiondate;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String invoiceLogiNo;

    private String invoiceLogiName;

    private String btcpCode;

    private String refuseReason;

    private String Mobile;

    private String phone;

    private String Province;

    private String City;

    private String County;

    private String Address;

    private String logisticsCompanyPhone;

    public String getLogisticsCompanyPhone() {
        return logisticsCompanyPhone;
    }

    public void setLogisticsCompanyPhone(String logisticsCompanyPhone) {
        this.logisticsCompanyPhone = logisticsCompanyPhone;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProvince() {
        return Province;
    }

    public void setProvince(String province) {
        Province = province;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getCounty() {
        return County;
    }

    public void setCounty(String county) {
        County = county;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getRefuseReason() {
        return refuseReason;
    }

    public void setRefuseReason(String refuseReason) {
        this.refuseReason = refuseReason;
    }

    public String getBtcpCode() {
        return btcpCode;
    }

    public void setBtcpCode(String btcpCode) {
        this.btcpCode = btcpCode;
    }

    public String genRApplyK(String prefix){
        return prefix + newordercode + new DateTime().toString("MMdd")+new Random(System.currentTimeMillis()).nextInt(9999);
    }

    public String getInvoiceLogiNo() {
        return invoiceLogiNo;
    }

    public void setInvoiceLogiNo(String invoiceLogiNo) {
        this.invoiceLogiNo = invoiceLogiNo;
    }

    public String getInvoiceLogiName() {
        return invoiceLogiName;
    }

    public void setInvoiceLogiName(String invoiceLogiName) {
        this.invoiceLogiName = invoiceLogiName;
    }

    public Integer getIsPackagingComplete() {
		return isPackagingComplete;
	}

	public void setIsPackagingComplete(Integer isPackagingComplete) {
		this.isPackagingComplete = isPackagingComplete;
	}

	private String updateby;
    
    Integer isPackagingComplete; //包装箱配件是否齐全

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid == null ? null : orderid.trim();
    }

    public String getNewordercode() {
        return newordercode;
    }

    public void setNewordercode(String newordercode) {
        this.newordercode = newordercode == null ? null : newordercode.trim();
    }

    public String getRapplyk() {
        return rapplyk;
    }

    public void setRapplyk(String rapplyk) {
        this.rapplyk = rapplyk == null ? null : rapplyk.trim();
    }

    public Date getRapplydate() {
        return rapplydate;
    }

    public void setRapplydate(Date rapplydate) {
        this.rapplydate = rapplydate;
    }

    public String getRinvoiceno() {
        return rinvoiceno;
    }

    public void setRinvoiceno(String rinvoiceno) {
        this.rinvoiceno = rinvoiceno == null ? null : rinvoiceno.trim();
    }

    public String getRreason() {
        return rreason;
    }

    public void setRreason(String rreason) {
        this.rreason = rreason == null ? null : rreason.trim();
    }

    public String getRcategory() {
        return rcategory;
    }

    public void setRcategory(String rcategory) {
        this.rcategory = rcategory == null ? null : rcategory.trim();
    }

    public String getRsales() {
        return rsales;
    }

    public void setRsales(String rsales) {
        this.rsales = rsales == null ? null : rsales.trim();
    }

    public String getRaddress() {
        return raddress;
    }

    public void setRaddress(String raddress) {
        this.raddress = raddress == null ? null : raddress.trim();
    }

    public Date getRreceiptdate() {
        return rreceiptdate;
    }

    public void setRreceiptdate(Date rreceiptdate) {
        this.rreceiptdate = rreceiptdate;
    }

    public Boolean getIsrefunded() {
        return isrefunded;
    }

    public void setIsrefunded(Boolean isrefunded) {
        this.isrefunded = isrefunded;
    }

    public BigDecimal getRamount() {
        return ramount;
    }

    public void setRamount(BigDecimal ramount) {
        this.ramount = ramount;
    }

    public String getServicemode() {
        return servicemode;
    }

    public void setServicemode(String servicemode) {
        this.servicemode = servicemode == null ? null : servicemode.trim();
    }

    public String getOrdertype() {
        return ordertype;
    }

    public void setOrdertype(String ordertype) {
        this.ordertype = ordertype == null ? null : ordertype.trim();
    }

    public String getOldshipmentsno() {
        return oldshipmentsno;
    }

    public void setOldshipmentsno(String oldshipmentsno) {
        this.oldshipmentsno = oldshipmentsno == null ? null : oldshipmentsno.trim();
    }

    public String getRstoragecode() {
        return rstoragecode;
    }

    public void setRstoragecode(String rstoragecode) {
        this.rstoragecode = rstoragecode == null ? null : rstoragecode.trim();
    }

    public String getDeliveryno() {
        return deliveryno;
    }

    public void setDeliveryno(String deliveryno) {
        this.deliveryno = deliveryno == null ? null : deliveryno.trim();
    }

    public Boolean getIsprotect() {
        return isprotect;
    }

    public void setIsprotect(Boolean isprotect) {
        this.isprotect = isprotect;
    }

    public Integer getProductg() {
        return productg;
    }

    public void setProductg(Integer productg) {
        this.productg = productg;
    }

    public String getDeliverytypeid() {
        return deliverytypeid;
    }

    public void setDeliverytypeid(String deliverytypeid) {
        this.deliverytypeid = deliverytypeid == null ? null : deliverytypeid.trim();
    }

    public String getDeliverytypename() {
        return deliverytypename;
    }

    public void setDeliverytypename(String deliverytypename) {
        this.deliverytypename = deliverytypename == null ? null : deliverytypename.trim();
    }

    public String getLogiid() {
        return logiid;
    }

    public void setLogiid(String logiid) {
        this.logiid = logiid == null ? null : logiid.trim();
    }

    public String getLoginame() {
        return loginame;
    }

    public void setLoginame(String loginame) {
        this.loginame = loginame == null ? null : loginame.trim();
    }

    public String getLogino() {
        return logino;
    }

    public void setLogino(String logino) {
        this.logino = logino == null ? null : logino.trim();
    }

    public String getCustno() {
        return custno;
    }

    public void setCustno(String custno) {
        this.custno = custno == null ? null : custno.trim();
    }

    public String getCustname() {
        return custname;
    }

    public void setCustname(String custname) {
        this.custname = custname == null ? null : custname.trim();
    }

    public String getCustaddress() {
        return custaddress;
    }

    public void setCustaddress(String custaddress) {
        this.custaddress = custaddress == null ? null : custaddress.trim();
    }

    public String getCustpost() {
        return custpost;
    }

    public void setCustpost(String custpost) {
        this.custpost = custpost == null ? null : custpost.trim();
    }

    public String getCustcity() {
        return custcity;
    }

    public void setCustcity(String custcity) {
        this.custcity = custcity == null ? null : custcity.trim();
    }

    public String getCustcounty() {
        return custcounty;
    }

    public void setCustcounty(String custcounty) {
        this.custcounty = custcounty == null ? null : custcounty.trim();
    }

    public String getCustarea() {
        return custarea;
    }

    public void setCustarea(String custarea) {
        this.custarea = custarea == null ? null : custarea.trim();
    }

    public String getCustareaname() {
        return custareaname;
    }

    public void setCustareaname(String custareaname) {
        this.custareaname = custareaname == null ? null : custareaname.trim();
    }

    public String getCusttel() {
        return custtel;
    }

    public void setCusttel(String custtel) {
        this.custtel = custtel == null ? null : custtel.trim();
    }

    public String getShipcode() {
        return shipcode;
    }

    public void setShipcode(String shipcode) {
        this.shipcode = shipcode == null ? null : shipcode.trim();
    }

    public String getShipname() {
        return shipname;
    }

    public void setShipname(String shipname) {
        this.shipname = shipname == null ? null : shipname.trim();
    }

    public String getShipaddr() {
        return shipaddr;
    }

    public void setShipaddr(String shipaddr) {
        this.shipaddr = shipaddr == null ? null : shipaddr.trim();
    }

    public String getShipzip() {
        return shipzip;
    }

    public void setShipzip(String shipzip) {
        this.shipzip = shipzip == null ? null : shipzip.trim();
    }

    public String getShipcity() {
        return shipcity;
    }

    public void setShipcity(String shipcity) {
        this.shipcity = shipcity == null ? null : shipcity.trim();
    }

    public String getShiparea() {
        return shiparea;
    }

    public void setShiparea(String shiparea) {
        this.shiparea = shiparea == null ? null : shiparea.trim();
    }

    public String getDelivercounty() {
        return delivercounty;
    }

    public void setDelivercounty(String delivercounty) {
        this.delivercounty = delivercounty == null ? null : delivercounty.trim();
    }

    public String getDeliverarea() {
        return deliverarea;
    }

    public void setDeliverarea(String deliverarea) {
        this.deliverarea = deliverarea == null ? null : deliverarea.trim();
    }

    public String getDeliverareaname() {
        return deliverareaname;
    }

    public void setDeliverareaname(String deliverareaname) {
        this.deliverareaname = deliverareaname == null ? null : deliverareaname.trim();
    }

    public String getShipmobile() {
        return shipmobile;
    }

    public void setShipmobile(String shipmobile) {
        this.shipmobile = shipmobile == null ? null : shipmobile.trim();
    }

    public String getShiptel() {
        return shiptel;
    }

    public void setShiptel(String shiptel) {
        this.shiptel = shiptel == null ? null : shiptel.trim();
    }

    public String getShipnameno() {
        return shipnameno;
    }

    public void setShipnameno(String shipnameno) {
        this.shipnameno = shipnameno == null ? null : shipnameno.trim();
    }

    public Integer getDeliverydate() {
        return deliverydate;
    }

    public void setDeliverydate(Integer deliverydate) {
        this.deliverydate = deliverydate;
    }

    public String getOpname() {
        return opname;
    }

    public void setOpname(String opname) {
        this.opname = opname == null ? null : opname.trim();
    }

    public Date getTbegin() {
        return tbegin;
    }

    public void setTbegin(Date tbegin) {
        this.tbegin = tbegin;
    }

    public Integer getReviewstatus() {
        return reviewstatus;
    }

    public void setReviewstatus(Integer reviewstatus) {
        this.reviewstatus = reviewstatus;
    }

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public Boolean getIsthrowing() {
        return isthrowing;
    }

    public void setIsthrowing(Boolean isthrowing) {
        this.isthrowing = isthrowing;
    }

    public Date getThrowingtime() {
        return throwingtime;
    }

    public void setThrowingtime(Date throwingtime) {
        this.throwingtime = throwingtime;
    }

    public Integer getThrowingstatus() {
        return throwingstatus;
    }

    public void setThrowingstatus(Integer throwingstatus) {
        this.throwingstatus = throwingstatus;
    }

    public Date getVerificationtime() {
        return verificationtime;
    }

    public void setVerificationtime(Date verificationtime) {
        this.verificationtime = verificationtime;
    }

    public Date getFactorydeliverydate() {
        return factorydeliverydate;
    }

    public void setFactorydeliverydate(Date factorydeliverydate) {
        this.factorydeliverydate = factorydeliverydate;
    }

    public Boolean getIsquality() {
        return isquality;
    }

    public void setIsquality(Boolean isquality) {
        this.isquality = isquality;
    }

    public Boolean getIsdistributeleaflets() {
        return isdistributeleaflets;
    }

    public void setIsdistributeleaflets(Boolean isdistributeleaflets) {
        this.isdistributeleaflets = isdistributeleaflets;
    }

    public Date getSwitchcreatetime() {
        return switchcreatetime;
    }

    public void setSwitchcreatetime(Date switchcreatetime) {
        this.switchcreatetime = switchcreatetime;
    }

    public Boolean getIsrevoked() {
        return isrevoked;
    }

    public void setIsrevoked(Boolean isrevoked) {
        this.isrevoked = isrevoked;
    }

    public Date getSenddate() {
        return senddate;
    }

    public void setSenddate(Date senddate) {
        this.senddate = senddate;
    }

    public Date getExceptiondate() {
        return exceptiondate;
    }

    public void setExceptiondate(Date exceptiondate) {
        this.exceptiondate = exceptiondate;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }

    public Money getMoney() {
        return money;
    }

    public void setMoney(Money money) {
        this.money = money;
    }

    public Money getProtectmoney() {
        return protectmoney;
    }

    public void setProtectmoney(Money protectmoney) {
        this.protectmoney = protectmoney;
    }

    public Money getAdvancefreightmoney() {
        return advancefreightmoney;
    }

    public void setAdvancefreightmoney(Money advancefreightmoney) {
        this.advancefreightmoney = advancefreightmoney;
    }
}