package com.lenovo.m2.web.domain.purchase.member;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MemberlevelExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private int pageIndex;

    private int pageSize;

    public MemberlevelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex=pageIndex;
    }

    public int getPageIndex() {
        return this.pageIndex;
    }

    public void setPageSize(int pageSize) {
        this.pageSize=pageSize;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public MemberlevelExample(int pageIndex, int pageSize) {
        this();
        this.pageIndex=pageIndex;
        this.pageSize=pageSize;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("Name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("Name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("Name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("Name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("Name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("Name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("Name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("Name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("Name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("Name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("Name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("Name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("Name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("Name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andLevelnumberIsNull() {
            addCriterion("LevelNumber is null");
            return (Criteria) this;
        }

        public Criteria andLevelnumberIsNotNull() {
            addCriterion("LevelNumber is not null");
            return (Criteria) this;
        }

        public Criteria andLevelnumberEqualTo(Integer value) {
            addCriterion("LevelNumber =", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberNotEqualTo(Integer value) {
            addCriterion("LevelNumber <>", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberGreaterThan(Integer value) {
            addCriterion("LevelNumber >", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("LevelNumber >=", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberLessThan(Integer value) {
            addCriterion("LevelNumber <", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberLessThanOrEqualTo(Integer value) {
            addCriterion("LevelNumber <=", value, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberIn(List<Integer> values) {
            addCriterion("LevelNumber in", values, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberNotIn(List<Integer> values) {
            addCriterion("LevelNumber not in", values, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberBetween(Integer value1, Integer value2) {
            addCriterion("LevelNumber between", value1, value2, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevelnumberNotBetween(Integer value1, Integer value2) {
            addCriterion("LevelNumber not between", value1, value2, "levelnumber");
            return (Criteria) this;
        }

        public Criteria andLevellogoIsNull() {
            addCriterion("LevelLogo is null");
            return (Criteria) this;
        }

        public Criteria andLevellogoIsNotNull() {
            addCriterion("LevelLogo is not null");
            return (Criteria) this;
        }

        public Criteria andLevellogoEqualTo(String value) {
            addCriterion("LevelLogo =", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoNotEqualTo(String value) {
            addCriterion("LevelLogo <>", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoGreaterThan(String value) {
            addCriterion("LevelLogo >", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoGreaterThanOrEqualTo(String value) {
            addCriterion("LevelLogo >=", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoLessThan(String value) {
            addCriterion("LevelLogo <", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoLessThanOrEqualTo(String value) {
            addCriterion("LevelLogo <=", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoLike(String value) {
            addCriterion("LevelLogo like", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoNotLike(String value) {
            addCriterion("LevelLogo not like", value, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoIn(List<String> values) {
            addCriterion("LevelLogo in", values, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoNotIn(List<String> values) {
            addCriterion("LevelLogo not in", values, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoBetween(String value1, String value2) {
            addCriterion("LevelLogo between", value1, value2, "levellogo");
            return (Criteria) this;
        }

        public Criteria andLevellogoNotBetween(String value1, String value2) {
            addCriterion("LevelLogo not between", value1, value2, "levellogo");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeIsNull() {
            addCriterion("DepositFreezetime is null");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeIsNotNull() {
            addCriterion("DepositFreezetime is not null");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeEqualTo(Integer value) {
            addCriterion("DepositFreezetime =", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeNotEqualTo(Integer value) {
            addCriterion("DepositFreezetime <>", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeGreaterThan(Integer value) {
            addCriterion("DepositFreezetime >", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("DepositFreezetime >=", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeLessThan(Integer value) {
            addCriterion("DepositFreezetime <", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeLessThanOrEqualTo(Integer value) {
            addCriterion("DepositFreezetime <=", value, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeIn(List<Integer> values) {
            addCriterion("DepositFreezetime in", values, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeNotIn(List<Integer> values) {
            addCriterion("DepositFreezetime not in", values, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeBetween(Integer value1, Integer value2) {
            addCriterion("DepositFreezetime between", value1, value2, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositfreezetimeNotBetween(Integer value1, Integer value2) {
            addCriterion("DepositFreezetime not between", value1, value2, "depositfreezetime");
            return (Criteria) this;
        }

        public Criteria andDepositIsNull() {
            addCriterion("Deposit is null");
            return (Criteria) this;
        }

        public Criteria andDepositIsNotNull() {
            addCriterion("Deposit is not null");
            return (Criteria) this;
        }

        public Criteria andDepositEqualTo(BigDecimal value) {
            addCriterion("Deposit =", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositNotEqualTo(BigDecimal value) {
            addCriterion("Deposit <>", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositGreaterThan(BigDecimal value) {
            addCriterion("Deposit >", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Deposit >=", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositLessThan(BigDecimal value) {
            addCriterion("Deposit <", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Deposit <=", value, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositIn(List<BigDecimal> values) {
            addCriterion("Deposit in", values, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositNotIn(List<BigDecimal> values) {
            addCriterion("Deposit not in", values, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Deposit between", value1, value2, "deposit");
            return (Criteria) this;
        }

        public Criteria andDepositNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Deposit not between", value1, value2, "deposit");
            return (Criteria) this;
        }

        public Criteria andMorepointIsNull() {
            addCriterion("MorePoint is null");
            return (Criteria) this;
        }

        public Criteria andMorepointIsNotNull() {
            addCriterion("MorePoint is not null");
            return (Criteria) this;
        }

        public Criteria andMorepointEqualTo(Integer value) {
            addCriterion("MorePoint =", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointNotEqualTo(Integer value) {
            addCriterion("MorePoint <>", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointGreaterThan(Integer value) {
            addCriterion("MorePoint >", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointGreaterThanOrEqualTo(Integer value) {
            addCriterion("MorePoint >=", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointLessThan(Integer value) {
            addCriterion("MorePoint <", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointLessThanOrEqualTo(Integer value) {
            addCriterion("MorePoint <=", value, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointIn(List<Integer> values) {
            addCriterion("MorePoint in", values, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointNotIn(List<Integer> values) {
            addCriterion("MorePoint not in", values, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointBetween(Integer value1, Integer value2) {
            addCriterion("MorePoint between", value1, value2, "morepoint");
            return (Criteria) this;
        }

        public Criteria andMorepointNotBetween(Integer value1, Integer value2) {
            addCriterion("MorePoint not between", value1, value2, "morepoint");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceIsNull() {
            addCriterion("ShowOtherPrice is null");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceIsNotNull() {
            addCriterion("ShowOtherPrice is not null");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceEqualTo(Integer value) {
            addCriterion("ShowOtherPrice =", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceNotEqualTo(Integer value) {
            addCriterion("ShowOtherPrice <>", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceGreaterThan(Integer value) {
            addCriterion("ShowOtherPrice >", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceGreaterThanOrEqualTo(Integer value) {
            addCriterion("ShowOtherPrice >=", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceLessThan(Integer value) {
            addCriterion("ShowOtherPrice <", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceLessThanOrEqualTo(Integer value) {
            addCriterion("ShowOtherPrice <=", value, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceIn(List<Integer> values) {
            addCriterion("ShowOtherPrice in", values, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceNotIn(List<Integer> values) {
            addCriterion("ShowOtherPrice not in", values, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceBetween(Integer value1, Integer value2) {
            addCriterion("ShowOtherPrice between", value1, value2, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andShowotherpriceNotBetween(Integer value1, Integer value2) {
            addCriterion("ShowOtherPrice not between", value1, value2, "showotherprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitIsNull() {
            addCriterion("OrderLimit is null");
            return (Criteria) this;
        }

        public Criteria andOrderlimitIsNotNull() {
            addCriterion("OrderLimit is not null");
            return (Criteria) this;
        }

        public Criteria andOrderlimitEqualTo(Integer value) {
            addCriterion("OrderLimit =", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitNotEqualTo(Integer value) {
            addCriterion("OrderLimit <>", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitGreaterThan(Integer value) {
            addCriterion("OrderLimit >", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitGreaterThanOrEqualTo(Integer value) {
            addCriterion("OrderLimit >=", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitLessThan(Integer value) {
            addCriterion("OrderLimit <", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitLessThanOrEqualTo(Integer value) {
            addCriterion("OrderLimit <=", value, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitIn(List<Integer> values) {
            addCriterion("OrderLimit in", values, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitNotIn(List<Integer> values) {
            addCriterion("OrderLimit not in", values, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitBetween(Integer value1, Integer value2) {
            addCriterion("OrderLimit between", value1, value2, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andOrderlimitNotBetween(Integer value1, Integer value2) {
            addCriterion("OrderLimit not between", value1, value2, "orderlimit");
            return (Criteria) this;
        }

        public Criteria andDiscountIsNull() {
            addCriterion("Discount is null");
            return (Criteria) this;
        }

        public Criteria andDiscountIsNotNull() {
            addCriterion("Discount is not null");
            return (Criteria) this;
        }

        public Criteria andDiscountEqualTo(BigDecimal value) {
            addCriterion("Discount =", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountNotEqualTo(BigDecimal value) {
            addCriterion("Discount <>", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountGreaterThan(BigDecimal value) {
            addCriterion("Discount >", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Discount >=", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountLessThan(BigDecimal value) {
            addCriterion("Discount <", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Discount <=", value, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountIn(List<BigDecimal> values) {
            addCriterion("Discount in", values, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountNotIn(List<BigDecimal> values) {
            addCriterion("Discount not in", values, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Discount between", value1, value2, "discount");
            return (Criteria) this;
        }

        public Criteria andDiscountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Discount not between", value1, value2, "discount");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceIsNull() {
            addCriterion("OrderLimitPrice is null");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceIsNotNull() {
            addCriterion("OrderLimitPrice is not null");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceEqualTo(BigDecimal value) {
            addCriterion("OrderLimitPrice =", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceNotEqualTo(BigDecimal value) {
            addCriterion("OrderLimitPrice <>", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceGreaterThan(BigDecimal value) {
            addCriterion("OrderLimitPrice >", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("OrderLimitPrice >=", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceLessThan(BigDecimal value) {
            addCriterion("OrderLimitPrice <", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("OrderLimitPrice <=", value, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceIn(List<BigDecimal> values) {
            addCriterion("OrderLimitPrice in", values, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceNotIn(List<BigDecimal> values) {
            addCriterion("OrderLimitPrice not in", values, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OrderLimitPrice between", value1, value2, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andOrderlimitpriceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("OrderLimitPrice not between", value1, value2, "orderlimitprice");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelIsNull() {
            addCriterion("DefaultLevel is null");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelIsNotNull() {
            addCriterion("DefaultLevel is not null");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelEqualTo(Integer value) {
            addCriterion("DefaultLevel =", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelNotEqualTo(Integer value) {
            addCriterion("DefaultLevel <>", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelGreaterThan(Integer value) {
            addCriterion("DefaultLevel >", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelGreaterThanOrEqualTo(Integer value) {
            addCriterion("DefaultLevel >=", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelLessThan(Integer value) {
            addCriterion("DefaultLevel <", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelLessThanOrEqualTo(Integer value) {
            addCriterion("DefaultLevel <=", value, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelIn(List<Integer> values) {
            addCriterion("DefaultLevel in", values, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelNotIn(List<Integer> values) {
            addCriterion("DefaultLevel not in", values, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelBetween(Integer value1, Integer value2) {
            addCriterion("DefaultLevel between", value1, value2, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andDefaultlevelNotBetween(Integer value1, Integer value2) {
            addCriterion("DefaultLevel not between", value1, value2, "defaultlevel");
            return (Criteria) this;
        }

        public Criteria andLeveltpeIsNull() {
            addCriterion("LevelTpe is null");
            return (Criteria) this;
        }

        public Criteria andLeveltpeIsNotNull() {
            addCriterion("LevelTpe is not null");
            return (Criteria) this;
        }

        public Criteria andLeveltpeEqualTo(Integer value) {
            addCriterion("LevelTpe =", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeNotEqualTo(Integer value) {
            addCriterion("LevelTpe <>", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeGreaterThan(Integer value) {
            addCriterion("LevelTpe >", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeGreaterThanOrEqualTo(Integer value) {
            addCriterion("LevelTpe >=", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeLessThan(Integer value) {
            addCriterion("LevelTpe <", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeLessThanOrEqualTo(Integer value) {
            addCriterion("LevelTpe <=", value, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeIn(List<Integer> values) {
            addCriterion("LevelTpe in", values, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeNotIn(List<Integer> values) {
            addCriterion("LevelTpe not in", values, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeBetween(Integer value1, Integer value2) {
            addCriterion("LevelTpe between", value1, value2, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andLeveltpeNotBetween(Integer value1, Integer value2) {
            addCriterion("LevelTpe not between", value1, value2, "leveltpe");
            return (Criteria) this;
        }

        public Criteria andPointIsNull() {
            addCriterion("Point is null");
            return (Criteria) this;
        }

        public Criteria andPointIsNotNull() {
            addCriterion("Point is not null");
            return (Criteria) this;
        }

        public Criteria andPointEqualTo(Integer value) {
            addCriterion("Point =", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotEqualTo(Integer value) {
            addCriterion("Point <>", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointGreaterThan(Integer value) {
            addCriterion("Point >", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointGreaterThanOrEqualTo(Integer value) {
            addCriterion("Point >=", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointLessThan(Integer value) {
            addCriterion("Point <", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointLessThanOrEqualTo(Integer value) {
            addCriterion("Point <=", value, "point");
            return (Criteria) this;
        }

        public Criteria andPointIn(List<Integer> values) {
            addCriterion("Point in", values, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotIn(List<Integer> values) {
            addCriterion("Point not in", values, "point");
            return (Criteria) this;
        }

        public Criteria andPointBetween(Integer value1, Integer value2) {
            addCriterion("Point between", value1, value2, "point");
            return (Criteria) this;
        }

        public Criteria andPointNotBetween(Integer value1, Integer value2) {
            addCriterion("Point not between", value1, value2, "point");
            return (Criteria) this;
        }

        public Criteria andExperienceIsNull() {
            addCriterion("Experience is null");
            return (Criteria) this;
        }

        public Criteria andExperienceIsNotNull() {
            addCriterion("Experience is not null");
            return (Criteria) this;
        }

        public Criteria andExperienceEqualTo(Integer value) {
            addCriterion("Experience =", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotEqualTo(Integer value) {
            addCriterion("Experience <>", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceGreaterThan(Integer value) {
            addCriterion("Experience >", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceGreaterThanOrEqualTo(Integer value) {
            addCriterion("Experience >=", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceLessThan(Integer value) {
            addCriterion("Experience <", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceLessThanOrEqualTo(Integer value) {
            addCriterion("Experience <=", value, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceIn(List<Integer> values) {
            addCriterion("Experience in", values, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotIn(List<Integer> values) {
            addCriterion("Experience not in", values, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceBetween(Integer value1, Integer value2) {
            addCriterion("Experience between", value1, value2, "experience");
            return (Criteria) this;
        }

        public Criteria andExperienceNotBetween(Integer value1, Integer value2) {
            addCriterion("Experience not between", value1, value2, "experience");
            return (Criteria) this;
        }

        public Criteria andPreidIsNull() {
            addCriterion("PreID is null");
            return (Criteria) this;
        }

        public Criteria andPreidIsNotNull() {
            addCriterion("PreID is not null");
            return (Criteria) this;
        }

        public Criteria andPreidEqualTo(String value) {
            addCriterion("PreID =", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidNotEqualTo(String value) {
            addCriterion("PreID <>", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidGreaterThan(String value) {
            addCriterion("PreID >", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidGreaterThanOrEqualTo(String value) {
            addCriterion("PreID >=", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidLessThan(String value) {
            addCriterion("PreID <", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidLessThanOrEqualTo(String value) {
            addCriterion("PreID <=", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidLike(String value) {
            addCriterion("PreID like", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidNotLike(String value) {
            addCriterion("PreID not like", value, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidIn(List<String> values) {
            addCriterion("PreID in", values, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidNotIn(List<String> values) {
            addCriterion("PreID not in", values, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidBetween(String value1, String value2) {
            addCriterion("PreID between", value1, value2, "preid");
            return (Criteria) this;
        }

        public Criteria andPreidNotBetween(String value1, String value2) {
            addCriterion("PreID not between", value1, value2, "preid");
            return (Criteria) this;
        }

        public Criteria andExpiretimeIsNull() {
            addCriterion("ExpireTime is null");
            return (Criteria) this;
        }

        public Criteria andExpiretimeIsNotNull() {
            addCriterion("ExpireTime is not null");
            return (Criteria) this;
        }

        public Criteria andExpiretimeEqualTo(Integer value) {
            addCriterion("ExpireTime =", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeNotEqualTo(Integer value) {
            addCriterion("ExpireTime <>", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeGreaterThan(Integer value) {
            addCriterion("ExpireTime >", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("ExpireTime >=", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeLessThan(Integer value) {
            addCriterion("ExpireTime <", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeLessThanOrEqualTo(Integer value) {
            addCriterion("ExpireTime <=", value, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeIn(List<Integer> values) {
            addCriterion("ExpireTime in", values, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeNotIn(List<Integer> values) {
            addCriterion("ExpireTime not in", values, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeBetween(Integer value1, Integer value2) {
            addCriterion("ExpireTime between", value1, value2, "expiretime");
            return (Criteria) this;
        }

        public Criteria andExpiretimeNotBetween(Integer value1, Integer value2) {
            addCriterion("ExpireTime not between", value1, value2, "expiretime");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNull() {
            addCriterion("Disabled is null");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNotNull() {
            addCriterion("Disabled is not null");
            return (Criteria) this;
        }

        public Criteria andDisabledEqualTo(Integer value) {
            addCriterion("Disabled =", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotEqualTo(Integer value) {
            addCriterion("Disabled <>", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThan(Integer value) {
            addCriterion("Disabled >", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThanOrEqualTo(Integer value) {
            addCriterion("Disabled >=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThan(Integer value) {
            addCriterion("Disabled <", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThanOrEqualTo(Integer value) {
            addCriterion("Disabled <=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledIn(List<Integer> values) {
            addCriterion("Disabled in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotIn(List<Integer> values) {
            addCriterion("Disabled not in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledBetween(Integer value1, Integer value2) {
            addCriterion("Disabled between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotBetween(Integer value1, Integer value2) {
            addCriterion("Disabled not between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}