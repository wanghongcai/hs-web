package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.hsbuy.domain.BaseInfo;
import com.lenovo.m2.hsbuy.domain.cart.ServiceProductView;

import java.util.List;

public class ServiceProductListForReturn extends BaseInfo {
    private String gcode;
    private List<ServiceProductView> servicelist;

    public ServiceProductListForReturn() {
    }

    public String getGcode() {
        return this.gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }

    public List<ServiceProductView> getServicelist() {
        return this.servicelist;
    }

    public void setServicelist(List<ServiceProductView> servicelist) {
        this.servicelist = servicelist;
    }
}
