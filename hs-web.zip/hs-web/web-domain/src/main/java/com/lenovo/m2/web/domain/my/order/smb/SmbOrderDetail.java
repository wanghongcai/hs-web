package com.lenovo.m2.web.domain.my.order.smb;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderList;
import com.lenovo.m2.web.domain.my.order.OrderDetailListJSONOrderListGlist;
import com.lenovo.m2.web.domain.my.order.Receiver;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jack on 2016/8/7.
 */
public class SmbOrderDetail implements Serializable {

    //SMB新增字段
    public String ordermaincode; //主订单号
    /**
    * 第三方订单编号 smb存po号
    */
    public String customerOrderCode;
    /**
    * 第三方订单编号子订单号 smb存小po号
    */
    public String customerOrderCodeSon;
    /**
    * 下单方式 1静默下单，2手工下单，3询价单
    */
    public int submitOrderWay;

    public String orderno;	    //订单编号
    public String ordertime;	//下单时间
    public String orderstatus;	//订单状态（包含物流状态，是否退货状态）
    public String orderstatuscode; //订单状态编号，和订单状态相对应
    public Money paymoney;	//订单支付金额
    public boolean withinsevendays;//是否七天之内
    public List<SmbGoodList> glist;	//商品列表
    public List<SmbGoodList> slist;	//服务列表
    public List<SmbGoodList> giftList;	//赠品列表
    public List<SmbGoodList> singleServerList;	//单独购买服务列表
    public String takeperson;  //收货人
    public String paymode;     //支付方式
    public String istelord;    //是否是手机订单,1是，0否
    public String canreturn = "0";//是否可退换货，0可退换货，1可以换货（根据用户签收后的第二天零时起计算时间，超过15个自然天）的无法申请退货
    public String salestype;
    public String payStatus;   //  支付状态；
    public String statusBar;   //  定制状态   （是否到达购买时间）
    public String orderAddType;//订单类型
    public String dbid;
    public String reOrderTime;
    public String reOrderReason;
    public String returnStatus;//退换货状态 1退货 2换货
    public String invoiceType;//发票类型
    public String payTime;//支付时间
    public String faType;//第三方类型
    public String isDelete;//订单删除标记 0或空未删除 1删除(回收站可还原) 2彻底删除
    public String hasComment;//订单评论标记 0代表包含未评价商品 1代表该订单所有商品均已评价
    public String timeline;//订单流转时间轴  0-提交订单 1-已支付 2-已发货 3-已签收
    public int totalGoodsCount;//订单下商品数量
    public Money costItem;//商品总价格
    public String terminal;

    public String feeInfo;
    public String numberDetail;
    public String accessLuckyWheel;

    //单独判断懂得充值订单状态 新增字段

    public String shipStatus;

    //smb拓展字段
    private String vatHeader;//增值税 发票抬头
    private String vatdepositBank;//开户银行
    private String vatBankNo;//银行账号
    private String vatTaxpayerIdentity;//纳税人识别号
    private List<Receiver> vatDeliveries = new ArrayList<Receiver>();//发票寄送地址
    private List<Receiver> contractDeliveries = new ArrayList<Receiver>();//合同寄送地址

    private String notes;

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getVatHeader() {
        return vatHeader;
    }

    public void setVatHeader(String vatHeader) {
        this.vatHeader = vatHeader;
    }

    public String getVatdepositBank() {
        return vatdepositBank;
    }

    public void setVatdepositBank(String vatdepositBank) {
        this.vatdepositBank = vatdepositBank;
    }

    public String getVatBankNo() {
        return vatBankNo;
    }

    public void setVatBankNo(String vatBankNo) {
        this.vatBankNo = vatBankNo;
    }

    public String getVatTaxpayerIdentity() {
        return vatTaxpayerIdentity;
    }

    public void setVatTaxpayerIdentity(String vatTaxpayerIdentity) {
        this.vatTaxpayerIdentity = vatTaxpayerIdentity;
    }

    public List<Receiver> getVatDeliveries() {
        return vatDeliveries;
    }

    public void setVatDeliveries(List<Receiver> vatDeliveries) {
        this.vatDeliveries = vatDeliveries;
    }

    public List<Receiver> getContractDeliveries() {
        return contractDeliveries;
    }

    public void setContractDeliveries(List<Receiver> contractDeliveries) {
        this.contractDeliveries = contractDeliveries;
    }

    public String getOrdermaincode() {
        return ordermaincode;
    }

    public void setOrdermaincode(String ordermaincode) {
        this.ordermaincode = ordermaincode;
    }

    public String getCustomerOrderCode() {
        return customerOrderCode;
    }

    public void setCustomerOrderCode(String customerOrderCode) {
        this.customerOrderCode = customerOrderCode;
    }

    public String getCustomerOrderCodeSon() {
        return customerOrderCodeSon;
    }

    public void setCustomerOrderCodeSon(String customerOrderCodeSon) {
        this.customerOrderCodeSon = customerOrderCodeSon;
    }

    public int getSubmitOrderWay() {
        return submitOrderWay;
    }

    public void setSubmitOrderWay(int submitOrderWay) {
        this.submitOrderWay = submitOrderWay;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime;
    }

    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }

    public String getOrderstatuscode() {
        return orderstatuscode;
    }

    public void setOrderstatuscode(String orderstatuscode) {
        this.orderstatuscode = orderstatuscode;
    }

    public boolean isWithinsevendays() {
        return withinsevendays;
    }

//    public boolean getWithinsevendays(){
//        return isWithinsevendays();
//    }

    public void setWithinsevendays(boolean withinsevendays) {
        this.withinsevendays = withinsevendays;
    }

    public List<SmbGoodList> getGlist() {
        return glist;
    }

    public void setGlist(List<SmbGoodList> glist) {
        this.glist = glist;
    }

    public List<SmbGoodList> getSlist() {
        return slist;
    }

    public void setSlist(List<SmbGoodList> slist) {
        this.slist = slist;
    }

    public List<SmbGoodList> getGiftList() {
        return giftList;
    }

    public void setGiftList(List<SmbGoodList> giftList) {
        this.giftList = giftList;
    }

    public List<SmbGoodList> getSingleServerList() {
        return singleServerList;
    }

    public void setSingleServerList(List<SmbGoodList> singleServerList) {
        this.singleServerList = singleServerList;
    }

    public String getTakeperson() {
        return takeperson;
    }

    public void setTakeperson(String takeperson) {
        this.takeperson = takeperson;
    }

    public String getPaymode() {
        return paymode;
    }

    public void setPaymode(String paymode) {
        this.paymode = paymode;
    }

    public String getIstelord() {
        return istelord;
    }

    public void setIstelord(String istelord) {
        this.istelord = istelord;
    }

    public String getCanreturn() {
        return canreturn;
    }

    public void setCanreturn(String canreturn) {
        this.canreturn = canreturn;
    }

    public Money getPaymoney() {
        return paymoney;
    }

    public void setPaymoney(Money paymoney) {
        this.paymoney = paymoney;
    }

    public Money getCostItem() {
        return costItem;
    }

    public void setCostItem(Money costItem) {
        this.costItem = costItem;
    }

    public String getSalestype() {
        return salestype;
    }

    public void setSalestype(String salestype) {
        this.salestype = salestype;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

    public String getStatusBar() {
        return statusBar;
    }

    public void setStatusBar(String statusBar) {
        this.statusBar = statusBar;
    }

    public String getOrderAddType() {
        return orderAddType;
    }

    public void setOrderAddType(String orderAddType) {
        this.orderAddType = orderAddType;
    }

    public String getDbid() {
        return dbid;
    }

    public void setDbid(String dbid) {
        this.dbid = dbid;
    }

    public String getReOrderTime() {
        return reOrderTime;
    }

    public void setReOrderTime(String reOrderTime) {
        this.reOrderTime = reOrderTime;
    }

    public String getReOrderReason() {
        return reOrderReason;
    }

    public void setReOrderReason(String reOrderReason) {
        this.reOrderReason = reOrderReason;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getFaType() {
        return faType;
    }

    public void setFaType(String faType) {
        this.faType = faType;
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }

    public String getHasComment() {
        return hasComment;
    }

    public void setHasComment(String hasComment) {
        this.hasComment = hasComment;
    }

    public String getTimeline() {
        return timeline;
    }

    public void setTimeline(String timeline) {
        this.timeline = timeline;
    }

    public int getTotalGoodsCount() {
        return totalGoodsCount;
    }

    public void setTotalGoodsCount(int totalGoodsCount) {
        this.totalGoodsCount = totalGoodsCount;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getFeeInfo() {
        return feeInfo;
    }

    public void setFeeInfo(String feeInfo) {
        this.feeInfo = feeInfo;
    }

    public String getNumberDetail() {
        return numberDetail;
    }

    public void setNumberDetail(String numberDetail) {
        this.numberDetail = numberDetail;
    }

    public String getAccessLuckyWheel() {
        return accessLuckyWheel;
    }

    public void setAccessLuckyWheel(String accessLuckyWheel) {
        this.accessLuckyWheel = accessLuckyWheel;
    }

    public String getShipStatus() {
        return shipStatus;
    }

    public void setShipStatus(String shipStatus) {
        this.shipStatus = shipStatus;
    }

    public void setOrderDetailListJSONOrderList(OrderDetailListJSONOrderList order, int count) {
        this.setAccessLuckyWheel(order.getAccessLuckyWheel());
        this.setCustomerOrderCode(order.getCustomerOrderCode());
        this.setCustomerOrderCodeSon(order.getCustomerOrderCodeSon());
        this.setOrdermaincode(order.getOrdermaincode());
        this.setAccessLuckyWheel(order.getAccessLuckyWheel());
        this.setCanreturn(order.getCanreturn());
        if (count != 0){
            this.setCostItem(this.getCostItem());
        }else{
            this.setCostItem(order.getCostItem());
        }
        this.setDbid(order.getDbid());
        this.setFaType(order.getFaType());
        this.setFeeInfo(order.getFeeInfo());
        if(count != 0){
            if (!"0".equals(this.getHasComment())){
                this.setHasComment(order.getHasComment());
            }
        }else{
            this.setHasComment(order.getHasComment());
        }
        this.setNotes(order.getNotes());
        this.setInvoiceType(order.getInvoiceType());
        this.setIsDelete(order.getIsDelete());
        this.setIstelord(order.getIstelord());
        this.setNumberDetail(order.getNumberDetail());
        this.setOrderAddType(order.getOrderAddType());
        this.setOrderno(order.getOrderno());
        this.setOrderstatus(order.getOrderstatus());
        this.setOrderstatuscode(order.getOrderstatuscode());
        this.setOrdertime(order.getOrdertime());
        this.setPayStatus(order.getPayStatus());
        this.setPaymode(order.getPaymode());
        if(order.getPaymoney() != null && count == 0){
            this.setPaymoney(order.getPaymoney());
        }else if (this.getPaymoney() != null && order.getPaymoney() != null){
            this.setPaymoney(this.getPaymoney().add(order.getPaymoney()));
        }
        this.setPayTime(order.getPayTime());
        this.setReOrderReason(order.getReOrderReason());
        this.setReOrderTime(order.getReOrderTime());
        this.setReturnStatus(order.getReturnStatus());
        this.setShipStatus(order.getShipStatus());
        this.setSalestype(order.getSalestype());
        this.setStatusBar(order.getStatusBar());
        this.setSubmitOrderWay(order.getSubmitOrderWay());
        this.setTakeperson(order.getTakeperson());
        this.setTerminal(order.getTerminal());
        this.setTimeline(order.getTimeline());
        this.setTotalGoodsCount(order.getTotalGoodsCount());
        this.setWithinsevendays(order.isWithinsevendays());

        this.setVatTaxpayerIdentity(order.getVatTaxpayerIdentity());
        this.setVatHeader(order.getVatHeader());
        this.setVatdepositBank(order.getVatdepositBank());
        this.setVatBankNo(order.getVatBankNo());
        this.setVatDeliveries(order.getVatDeliveries());
        this.setContractDeliveries(order.getContractDeliveries());

        if (order.getGiftList() != null && !"".equals(order.getGiftList())){
            if (count != 0 && this.getGiftList() != null && !"".equals(this.getGiftList())){
                List<SmbGoodList> lists = this.getGiftList();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getGiftList()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    lists.add(smbGoodList);
                }
                this.setGiftList(lists);

            }else{
                List<SmbGoodList> lists = new ArrayList<>();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getGiftList()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    lists.add(smbGoodList);
                }
                this.setGiftList(lists);
            }

        }
        if (order.getSlist() != null && !"".equals(order.getSlist())){
            if (count != 0 && this.getSlist() != null && !"".equals(this.getSlist())){
                List<SmbGoodList> lists = this.getSlist();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getSlist()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    lists.add(smbGoodList);
                }
                this.setSlist(lists);
            }else{
                List<SmbGoodList> lists = new ArrayList<>();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getSlist()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    lists.add(smbGoodList);
                }
                this.setSlist(lists);
            }

        }
        if (order.getSingleServerList() != null && !"".equals(order.getSingleServerList())){
            if (count != 0 && this.getSingleServerList() != null && !"".equals(this.getSingleServerList())){
                List<SmbGoodList> lists = this.getSingleServerList();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getSingleServerList()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    smbGoodList.setOrdermaincode(order.getOrdermaincode());
                    smbGoodList.setCustomerOrderCode(order.getCustomerOrderCode());
                    smbGoodList.setCustomerOrderCodeSon(order.getCustomerOrderCodeSon());
                    smbGoodList.setSubmitOrderWay(order.getSubmitOrderWay());
                    smbGoodList.setOrderno(order.getOrderno());
                    lists.add(smbGoodList);
                }
                this.setSingleServerList(lists);
            }else{
                List<SmbGoodList> lists = new ArrayList<>();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getSingleServerList()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    smbGoodList.setOrdermaincode(order.getOrdermaincode());
                    smbGoodList.setCustomerOrderCode(order.getCustomerOrderCode());
                    smbGoodList.setCustomerOrderCodeSon(order.getCustomerOrderCodeSon());
                    smbGoodList.setSubmitOrderWay(order.getSubmitOrderWay());
                    smbGoodList.setOrderno(order.getOrderno());
                    lists.add(smbGoodList);
                }
                this.setSingleServerList(lists);
            }
        }
        if (order.getGlist() != null && !"".equals(order.getGlist())){
            if (count != 0 && this.getGlist() != null && !"".equals(this.getGlist())){
                List<SmbGoodList> lists = this.getGlist();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getGlist()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    smbGoodList.setOrdermaincode(order.getOrdermaincode());
                    smbGoodList.setCustomerOrderCode(order.getCustomerOrderCode());
                    smbGoodList.setCustomerOrderCodeSon(order.getCustomerOrderCodeSon());
                    smbGoodList.setSubmitOrderWay(order.getSubmitOrderWay());
                    smbGoodList.setOrderno(order.getOrderno());
                    lists.add(smbGoodList);
                }
                this.setGlist(lists);
            }else{
                List<SmbGoodList> lists = new ArrayList<>();
                for (OrderDetailListJSONOrderListGlist giftlist : order.getGlist()){
                    SmbGoodList smbGoodList = new SmbGoodList();
                    smbGoodList.copyGlistToSmbGood(giftlist);
                    smbGoodList.setOrdermaincode(order.getOrdermaincode());
                    smbGoodList.setCustomerOrderCode(order.getCustomerOrderCode());
                    smbGoodList.setCustomerOrderCodeSon(order.getCustomerOrderCodeSon());
                    smbGoodList.setSubmitOrderWay(order.getSubmitOrderWay());
                    smbGoodList.setOrderno(order.getOrderno());
                    lists.add(smbGoodList);
                }
                this.setGlist(lists);
            }
        }
    }

}
