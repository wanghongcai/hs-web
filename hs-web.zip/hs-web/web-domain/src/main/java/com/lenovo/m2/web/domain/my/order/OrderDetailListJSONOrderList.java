package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiangzh5 on 2015/7/28.
 */
public class OrderDetailListJSONOrderList implements Serializable {

    //SMB新增字段
    private String ordermaincode; //主订单号
    /**
     * 第三方订单编号 smb存po号
     */
    private String customerOrderCode;
    /**
     * 第三方订单编号子订单号 smb存小po号
     */
    private String customerOrderCodeSon;
    /**
     * 下单方式 1静默下单，2手工下单，3询价单
     */
    private int submitOrderWay;

    //smb拓展字段
    private String vatHeader;//增值税 发票抬头
    private String vatdepositBank;//开户银行
    private String vatBankNo;//银行账号
    private String vatTaxpayerIdentity;//纳税人识别号
    /**
     * 注册地址
     */
    private String registerAddress;
    /**
     * 注册电话
     */
    private String registerPhone;

    private Money creditLine;//信用支付额度
    private long payPoint;//积分支付额度

    private Money totalTax;//税总计


    private String isMainAccount;

    public String getIsMainAccount() {
        return isMainAccount;
    }

    public void setIsMainAccount(String isMainAccount) {
        this.isMainAccount = isMainAccount;
    }

    public Money getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(Money creditLine) {
        this.creditLine = creditLine;
    }

    public long getPayPoint() {
        return payPoint;
    }

    public void setPayPoint(long payPoint) {
        this.payPoint = payPoint;
    }

    public String getRegisterAddress() {
        return registerAddress;
    }

    public void setRegisterAddress(String registerAddress) {
        this.registerAddress = registerAddress;
    }

    public String getRegisterPhone() {
        return registerPhone;
    }

    public void setRegisterPhone(String registerPhone) {
        this.registerPhone = registerPhone;
    }

    private List<Receiver> vatDeliveries = new ArrayList<Receiver>();//发票寄送地址
    private List<Receiver> contractDeliveries = new ArrayList<Receiver>();//合同寄送地址


    private String orderno;	    //订单编号
    private String ordertime;	//下单时间
    private String orderstatus;	//订单状态（包含物流状态，是否退货状态）
    private String orderstatuscode; //订单状态编号，和订单状态相对应
    private Money paymoney;	//订单支付金额
    private boolean withinsevendays;//是否七天之内
    private List<OrderDetailListJSONOrderListGlist> glist;	//商品列表
    private List<OrderDetailListJSONOrderListGlist> slist;	//服务列表
    private List<OrderDetailListJSONOrderListGlist> giftList;	//赠品列表
    private List<OrderDetailListJSONOrderListGlist> singleServerList;	//单独购买服务列表
    private String takeperson;  //收货人
    private String paymode;     //支付方式
    private String istelord;    //是否是手机订单,1是，0否
    private String canreturn = "0";//是否可退换货，0可退换货，1可以换货（根据用户签收后的第二天零时起计算时间，超过15个自然天）的无法申请退货
    private String salestype;
    private String payStatus;   //  支付状态；
    private String statusBar;   //  定制状态   （是否到达购买时间）
    private String orderAddType;//订单类型
    //惠商线下银行转账新增字段
    private String uploadStatus;//慧商线下支付订单，上传支付资料状态,null:为经过收银台确认；1：可以开始上传资料，2：已经上传完资料
    private String faid;//
    private String faname;//分销商名称
    private String faCode;//分销商编码
    private String buyerCode;//经销商名称

    private String dbid;
    private String reOrderTime;
    private String reOrderReason;
    private String returnStatus;//退换货状态 1退货 2换货
    private String invoiceType;//发票类型
    private String payTime;//支付时间
    private String faType;//第三方类型
    private String isDelete;//订单删除标记 0或空未删除 1删除(回收站可还原) 2彻底删除
    private String hasComment;//订单评论标记 0代表包含未评价商品 1代表该订单所有商品均已评价
    private String timeline;//订单流转时间轴  0-提交订单 1-已支付 2-已发货 3-已签收
    private int totalGoodsCount;//订单下商品数量
    private Money costItem;//商品总价格
    private String terminal;

    private String feeInfo;
    private String numberDetail;
    private String accessLuckyWheel;

    //单独判断懂得充值订单状态 新增字段

    private String shipStatus;

    //smbjf 商城 积分字段
    private Money score;

    private String notes;

    private String returnSorce;   //退货原因

    private String url;

    private Presell presell;

    private String auditStatus;

    private String zt;

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    /**
     * 1审核通过
     2待审核
     3审核未通过
     4待生成合同
     * */



    public String getReturnSorce() {
        return returnSorce;
    }

    public void setReturnSorce(String returnSorce) {
        this.returnSorce = returnSorce;
    }

    public Presell getPresell() {
        return presell;
    }

    public void setPresell(Presell presell) {
        this.presell = presell;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Money getScore() {
        return score;
    }

    public void setScore(Money score) {
        this.score = score;
    }

    public String getCustomerOrderCode() {
        return customerOrderCode;
    }

    public void setCustomerOrderCode(String customerOrderCode) {
        this.customerOrderCode = customerOrderCode;
    }

    public String getCustomerOrderCodeSon() {
        return customerOrderCodeSon;
    }

    public void setCustomerOrderCodeSon(String customerOrderCodeSon) {
        this.customerOrderCodeSon = customerOrderCodeSon;
    }

    public int getSubmitOrderWay() {
        return submitOrderWay;
    }

    public void setSubmitOrderWay(int submitOrderWay) {
        this.submitOrderWay = submitOrderWay;
    }

    public String getOrdermaincode() {
        return ordermaincode;
    }

    public void setOrdermaincode(String ordermaincode) {
        this.ordermaincode = ordermaincode;
    }

    public String getShipStatus() {
        return shipStatus;
    }

    public void setShipStatus(String shipStatus) {
        this.shipStatus = shipStatus;
    }

    public List<OrderDetailListJSONOrderListGlist> getSingleServerList() {
        return singleServerList;
    }

    public void setSingleServerList(List<OrderDetailListJSONOrderListGlist> singleServerList) {
        this.singleServerList = singleServerList;
    }

    public String getAccessLuckyWheel() {
        return accessLuckyWheel;
    }

    public void setAccessLuckyWheel(String accessLuckyWheel) {
        this.accessLuckyWheel = accessLuckyWheel;
    }

    public String getFeeInfo() {
        return feeInfo;
    }

    public void setFeeInfo(String feeInfo) {
        this.feeInfo = feeInfo;
    }

    public String getNumberDetail() {
        return numberDetail;
    }

    public void setNumberDetail(String numberDetail) {
        this.numberDetail = numberDetail;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public Money getCostItem() {
        return costItem;
    }

    public void setCostItem(Money costItem) {
        this.costItem = costItem;
    }

    public int getTotalGoodsCount() {
        return totalGoodsCount;
    }

    public void setTotalGoodsCount(int totalGoodsCount) {
        this.totalGoodsCount = totalGoodsCount;
    }

    public String getTimeline() {
        return timeline;
    }

    public void setTimeline(String timeline) {
        this.timeline = timeline;
    }
    public String getFaType() {
        return faType;
    }

    public void setFaType(String faType) {
        this.faType = faType;
    }
    public String getOrderAddType() {
        return orderAddType;
    }
    public void setOrderAddType(String orderAddType) {
        this.orderAddType = orderAddType;
    }

    public String getStatusBar() {
        return statusBar;
    }
    public void setStatusBar(String statusBar) {
        this.statusBar = statusBar;
    }
    public String getPayStatus() {
        return payStatus;
    }
    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }
    public String getSalestype() {
        return salestype;
    }
    public void setSalestype(String salestype) {
        this.salestype = salestype;
    }
    public String getCanreturn() {
        return canreturn;
    }
    public void setCanreturn(String canreturn) {
        this.canreturn = canreturn;
    }
    public boolean isWithinsevendays() {
        return withinsevendays;
    }
    public void setWithinsevendays(boolean withinsevendays) {
        this.withinsevendays = withinsevendays;
    }
    public String getOrderstatuscode() {
        return orderstatuscode;
    }
    public void setOrderstatuscode(String orderstatuscode) {
        this.orderstatuscode = orderstatuscode;
    }
    public String getTakeperson() {
        return takeperson;
    }
    public void setTakeperson(String takeperson) {
        this.takeperson = takeperson;
    }
    public String getPaymode() {
        return paymode;
    }
    public void setPaymode(String paymode) {
        this.paymode = paymode;
    }
    public String getIstelord() {
        return istelord;
    }
    public void setIstelord(String istelord) {
        this.istelord = istelord;
    }
    public String getOrderno() {
        return orderno;
    }
    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }
    public String getOrdertime() {
        return ordertime;
    }
    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime;
    }
    public String getOrderstatus() {
        return orderstatus;
    }
    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }

    public Money getPaymoney() {
        return paymoney;
    }

    public void setPaymoney(Money paymoney) {
        this.paymoney = paymoney;
    }

    public List<OrderDetailListJSONOrderListGlist> getGlist() {
        return glist;
    }
    public void setGlist(List<OrderDetailListJSONOrderListGlist> glist) {
        this.glist = glist;
    }

    public String getDbid() {
        return dbid;
    }

    public void setDbid(String dbid) {
        this.dbid = dbid;
    }

    public String getReOrderTime() {
        return reOrderTime;
    }

    public void setReOrderTime(String reOrderTime) {
        this.reOrderTime = reOrderTime;
    }

    public String getReOrderReason() {
        return reOrderReason;
    }

    public void setReOrderReason(String reOrderReason) {
        this.reOrderReason = reOrderReason;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    public List<OrderDetailListJSONOrderListGlist> getSlist() {
        return slist;
    }

    public void setSlist(List<OrderDetailListJSONOrderListGlist> slist) {
        this.slist = slist;
    }

    public List<OrderDetailListJSONOrderListGlist> getGiftList() {
        return giftList;
    }

    public void setGiftList(List<OrderDetailListJSONOrderListGlist> giftList) {
        this.giftList = giftList;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }

    public String getHasComment() {
        return hasComment;
    }

    public void setHasComment(String hasComment) {
        this.hasComment = hasComment;
    }

    public String getVatHeader() {
        return vatHeader;
    }

    public void setVatHeader(String vatHeader) {
        this.vatHeader = vatHeader;
    }

    public String getVatdepositBank() {
        return vatdepositBank;
    }

    public void setVatdepositBank(String vatdepositBank) {
        this.vatdepositBank = vatdepositBank;
    }

    public String getVatBankNo() {
        return vatBankNo;
    }

    public void setVatBankNo(String vatBankNo) {
        this.vatBankNo = vatBankNo;
    }

    public String getVatTaxpayerIdentity() {
        return vatTaxpayerIdentity;
    }

    public void setVatTaxpayerIdentity(String vatTaxpayerIdentity) {
        this.vatTaxpayerIdentity = vatTaxpayerIdentity;
    }

    public List<Receiver> getVatDeliveries() {
        return vatDeliveries;
    }

    public void setVatDeliveries(List<Receiver> vatDeliveries) {
        this.vatDeliveries = vatDeliveries;
    }

    public List<Receiver> getContractDeliveries() {
        return contractDeliveries;
    }

    public void setContractDeliveries(List<Receiver> contractDeliveries) {
        this.contractDeliveries = contractDeliveries;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    public String getFaname() {
        return faname;
    }

    public void setFaname(String faname) {
        this.faname = faname;
    }

    public String getFaCode() {
        return faCode;
    }

    public void setFaCode(String faCode) {
        this.faCode = faCode;
    }

    public String getBuyerCode() {
        return buyerCode;
    }

    public void setBuyerCode(String buyerCode) {
        this.buyerCode = buyerCode;
    }

    public Money getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(Money totalTax) {
        this.totalTax = totalTax;
    }
}
