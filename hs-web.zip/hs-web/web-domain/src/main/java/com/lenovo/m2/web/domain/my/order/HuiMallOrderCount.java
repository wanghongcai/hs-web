package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * Created by yyduff on 2016/3/17.
 */
public class HuiMallOrderCount implements Serializable{

    private  int unPayCount;

    private  int unShipCount;

    private  int unConfirmCount;

    private  int returnCount;

    private int payCount;

    public int getPayCount() {
        return payCount;
    }

    public void setPayCount(int payCount) {
        this.payCount = payCount;
    }

    public int getUnPayCount() {
        return unPayCount;
    }

    public void setUnPayCount(int unPayCount) {
        this.unPayCount = unPayCount;
    }

    public int getUnShipCount() {
        return unShipCount;
    }

    public void setUnShipCount(int unShipCount) {
        this.unShipCount = unShipCount;
    }

    public int getUnConfirmCount() {
        return unConfirmCount;
    }

    public void setUnConfirmCount(int unConfirmCount) {
        this.unConfirmCount = unConfirmCount;
    }

    public int getReturnCount() {
        return returnCount;
    }

    public void setReturnCount(int returnCount) {
        this.returnCount = returnCount;
    }
}
