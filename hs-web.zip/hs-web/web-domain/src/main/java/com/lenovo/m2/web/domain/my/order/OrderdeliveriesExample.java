package com.lenovo.m2.web.domain.my.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderdeliveriesExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private int pageIndex;

    private int pageSize;

    public OrderdeliveriesExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex=pageIndex;
    }

    public int getPageIndex() {
        return this.pageIndex;
    }

    public void setPageSize(int pageSize) {
        this.pageSize=pageSize;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public OrderdeliveriesExample(int pageIndex, int pageSize) {
        this();
        this.pageIndex=pageIndex;
        this.pageSize=pageSize;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOrderidIsNull() {
            addCriterion("OrderID is null");
            return (Criteria) this;
        }

        public Criteria andOrderidIsNotNull() {
            addCriterion("OrderID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderidEqualTo(String value) {
            addCriterion("OrderID =", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotEqualTo(String value) {
            addCriterion("OrderID <>", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidGreaterThan(String value) {
            addCriterion("OrderID >", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidGreaterThanOrEqualTo(String value) {
            addCriterion("OrderID >=", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLessThan(String value) {
            addCriterion("OrderID <", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLessThanOrEqualTo(String value) {
            addCriterion("OrderID <=", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLike(String value) {
            addCriterion("OrderID like", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotLike(String value) {
            addCriterion("OrderID not like", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidIn(List<String> values) {
            addCriterion("OrderID in", values, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotIn(List<String> values) {
            addCriterion("OrderID not in", values, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidBetween(String value1, String value2) {
            addCriterion("OrderID between", value1, value2, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotBetween(String value1, String value2) {
            addCriterion("OrderID not between", value1, value2, "orderid");
            return (Criteria) this;
        }

        public Criteria andNewordercodeIsNull() {
            addCriterion("NewOrderCode is null");
            return (Criteria) this;
        }

        public Criteria andNewordercodeIsNotNull() {
            addCriterion("NewOrderCode is not null");
            return (Criteria) this;
        }

        public Criteria andNewordercodeEqualTo(String value) {
            addCriterion("NewOrderCode =", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeNotEqualTo(String value) {
            addCriterion("NewOrderCode <>", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeGreaterThan(String value) {
            addCriterion("NewOrderCode >", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeGreaterThanOrEqualTo(String value) {
            addCriterion("NewOrderCode >=", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeLessThan(String value) {
            addCriterion("NewOrderCode <", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeLessThanOrEqualTo(String value) {
            addCriterion("NewOrderCode <=", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeLike(String value) {
            addCriterion("NewOrderCode like", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeNotLike(String value) {
            addCriterion("NewOrderCode not like", value, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeIn(List<String> values) {
            addCriterion("NewOrderCode in", values, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeNotIn(List<String> values) {
            addCriterion("NewOrderCode not in", values, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeBetween(String value1, String value2) {
            addCriterion("NewOrderCode between", value1, value2, "newordercode");
            return (Criteria) this;
        }

        public Criteria andNewordercodeNotBetween(String value1, String value2) {
            addCriterion("NewOrderCode not between", value1, value2, "newordercode");
            return (Criteria) this;
        }

        public Criteria andRapplykIsNull() {
            addCriterion("RApplyK is null");
            return (Criteria) this;
        }

        public Criteria andRapplykIsNotNull() {
            addCriterion("RApplyK is not null");
            return (Criteria) this;
        }

        public Criteria andRapplykEqualTo(String value) {
            addCriterion("RApplyK =", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykNotEqualTo(String value) {
            addCriterion("RApplyK <>", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykGreaterThan(String value) {
            addCriterion("RApplyK >", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykGreaterThanOrEqualTo(String value) {
            addCriterion("RApplyK >=", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykLessThan(String value) {
            addCriterion("RApplyK <", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykLessThanOrEqualTo(String value) {
            addCriterion("RApplyK <=", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykLike(String value) {
            addCriterion("RApplyK like", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykNotLike(String value) {
            addCriterion("RApplyK not like", value, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykIn(List<String> values) {
            addCriterion("RApplyK in", values, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykNotIn(List<String> values) {
            addCriterion("RApplyK not in", values, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykBetween(String value1, String value2) {
            addCriterion("RApplyK between", value1, value2, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplykNotBetween(String value1, String value2) {
            addCriterion("RApplyK not between", value1, value2, "rapplyk");
            return (Criteria) this;
        }

        public Criteria andRapplydateIsNull() {
            addCriterion("RApplyDate is null");
            return (Criteria) this;
        }

        public Criteria andRapplydateIsNotNull() {
            addCriterion("RApplyDate is not null");
            return (Criteria) this;
        }

        public Criteria andRapplydateEqualTo(Date value) {
            addCriterion("RApplyDate =", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateNotEqualTo(Date value) {
            addCriterion("RApplyDate <>", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateGreaterThan(Date value) {
            addCriterion("RApplyDate >", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateGreaterThanOrEqualTo(Date value) {
            addCriterion("RApplyDate >=", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateLessThan(Date value) {
            addCriterion("RApplyDate <", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateLessThanOrEqualTo(Date value) {
            addCriterion("RApplyDate <=", value, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateIn(List<Date> values) {
            addCriterion("RApplyDate in", values, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateNotIn(List<Date> values) {
            addCriterion("RApplyDate not in", values, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateBetween(Date value1, Date value2) {
            addCriterion("RApplyDate between", value1, value2, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRapplydateNotBetween(Date value1, Date value2) {
            addCriterion("RApplyDate not between", value1, value2, "rapplydate");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoIsNull() {
            addCriterion("RInvoiceNo is null");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoIsNotNull() {
            addCriterion("RInvoiceNo is not null");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoEqualTo(String value) {
            addCriterion("RInvoiceNo =", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoNotEqualTo(String value) {
            addCriterion("RInvoiceNo <>", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoGreaterThan(String value) {
            addCriterion("RInvoiceNo >", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoGreaterThanOrEqualTo(String value) {
            addCriterion("RInvoiceNo >=", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoLessThan(String value) {
            addCriterion("RInvoiceNo <", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoLessThanOrEqualTo(String value) {
            addCriterion("RInvoiceNo <=", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoLike(String value) {
            addCriterion("RInvoiceNo like", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoNotLike(String value) {
            addCriterion("RInvoiceNo not like", value, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoIn(List<String> values) {
            addCriterion("RInvoiceNo in", values, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoNotIn(List<String> values) {
            addCriterion("RInvoiceNo not in", values, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoBetween(String value1, String value2) {
            addCriterion("RInvoiceNo between", value1, value2, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRinvoicenoNotBetween(String value1, String value2) {
            addCriterion("RInvoiceNo not between", value1, value2, "rinvoiceno");
            return (Criteria) this;
        }

        public Criteria andRreasonIsNull() {
            addCriterion("Rreason is null");
            return (Criteria) this;
        }

        public Criteria andRreasonIsNotNull() {
            addCriterion("Rreason is not null");
            return (Criteria) this;
        }

        public Criteria andRreasonEqualTo(String value) {
            addCriterion("Rreason =", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonNotEqualTo(String value) {
            addCriterion("Rreason <>", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonGreaterThan(String value) {
            addCriterion("Rreason >", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonGreaterThanOrEqualTo(String value) {
            addCriterion("Rreason >=", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonLessThan(String value) {
            addCriterion("Rreason <", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonLessThanOrEqualTo(String value) {
            addCriterion("Rreason <=", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonLike(String value) {
            addCriterion("Rreason like", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonNotLike(String value) {
            addCriterion("Rreason not like", value, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonIn(List<String> values) {
            addCriterion("Rreason in", values, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonNotIn(List<String> values) {
            addCriterion("Rreason not in", values, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonBetween(String value1, String value2) {
            addCriterion("Rreason between", value1, value2, "rreason");
            return (Criteria) this;
        }

        public Criteria andRreasonNotBetween(String value1, String value2) {
            addCriterion("Rreason not between", value1, value2, "rreason");
            return (Criteria) this;
        }

        public Criteria andRcategoryIsNull() {
            addCriterion("Rcategory is null");
            return (Criteria) this;
        }

        public Criteria andRcategoryIsNotNull() {
            addCriterion("Rcategory is not null");
            return (Criteria) this;
        }

        public Criteria andRcategoryEqualTo(String value) {
            addCriterion("Rcategory =", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryNotEqualTo(String value) {
            addCriterion("Rcategory <>", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryGreaterThan(String value) {
            addCriterion("Rcategory >", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryGreaterThanOrEqualTo(String value) {
            addCriterion("Rcategory >=", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryLessThan(String value) {
            addCriterion("Rcategory <", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryLessThanOrEqualTo(String value) {
            addCriterion("Rcategory <=", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryLike(String value) {
            addCriterion("Rcategory like", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryNotLike(String value) {
            addCriterion("Rcategory not like", value, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryIn(List<String> values) {
            addCriterion("Rcategory in", values, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryNotIn(List<String> values) {
            addCriterion("Rcategory not in", values, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryBetween(String value1, String value2) {
            addCriterion("Rcategory between", value1, value2, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRcategoryNotBetween(String value1, String value2) {
            addCriterion("Rcategory not between", value1, value2, "rcategory");
            return (Criteria) this;
        }

        public Criteria andRsalesIsNull() {
            addCriterion("Rsales is null");
            return (Criteria) this;
        }

        public Criteria andRsalesIsNotNull() {
            addCriterion("Rsales is not null");
            return (Criteria) this;
        }

        public Criteria andRsalesEqualTo(String value) {
            addCriterion("Rsales =", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesNotEqualTo(String value) {
            addCriterion("Rsales <>", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesGreaterThan(String value) {
            addCriterion("Rsales >", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesGreaterThanOrEqualTo(String value) {
            addCriterion("Rsales >=", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesLessThan(String value) {
            addCriterion("Rsales <", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesLessThanOrEqualTo(String value) {
            addCriterion("Rsales <=", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesLike(String value) {
            addCriterion("Rsales like", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesNotLike(String value) {
            addCriterion("Rsales not like", value, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesIn(List<String> values) {
            addCriterion("Rsales in", values, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesNotIn(List<String> values) {
            addCriterion("Rsales not in", values, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesBetween(String value1, String value2) {
            addCriterion("Rsales between", value1, value2, "rsales");
            return (Criteria) this;
        }

        public Criteria andRsalesNotBetween(String value1, String value2) {
            addCriterion("Rsales not between", value1, value2, "rsales");
            return (Criteria) this;
        }

        public Criteria andRaddressIsNull() {
            addCriterion("Raddress is null");
            return (Criteria) this;
        }

        public Criteria andRaddressIsNotNull() {
            addCriterion("Raddress is not null");
            return (Criteria) this;
        }

        public Criteria andRaddressEqualTo(String value) {
            addCriterion("Raddress =", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressNotEqualTo(String value) {
            addCriterion("Raddress <>", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressGreaterThan(String value) {
            addCriterion("Raddress >", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressGreaterThanOrEqualTo(String value) {
            addCriterion("Raddress >=", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressLessThan(String value) {
            addCriterion("Raddress <", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressLessThanOrEqualTo(String value) {
            addCriterion("Raddress <=", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressLike(String value) {
            addCriterion("Raddress like", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressNotLike(String value) {
            addCriterion("Raddress not like", value, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressIn(List<String> values) {
            addCriterion("Raddress in", values, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressNotIn(List<String> values) {
            addCriterion("Raddress not in", values, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressBetween(String value1, String value2) {
            addCriterion("Raddress between", value1, value2, "raddress");
            return (Criteria) this;
        }

        public Criteria andRaddressNotBetween(String value1, String value2) {
            addCriterion("Raddress not between", value1, value2, "raddress");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateIsNull() {
            addCriterion("RReceiptDate is null");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateIsNotNull() {
            addCriterion("RReceiptDate is not null");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateEqualTo(Date value) {
            addCriterion("RReceiptDate =", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateNotEqualTo(Date value) {
            addCriterion("RReceiptDate <>", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateGreaterThan(Date value) {
            addCriterion("RReceiptDate >", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateGreaterThanOrEqualTo(Date value) {
            addCriterion("RReceiptDate >=", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateLessThan(Date value) {
            addCriterion("RReceiptDate <", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateLessThanOrEqualTo(Date value) {
            addCriterion("RReceiptDate <=", value, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateIn(List<Date> values) {
            addCriterion("RReceiptDate in", values, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateNotIn(List<Date> values) {
            addCriterion("RReceiptDate not in", values, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateBetween(Date value1, Date value2) {
            addCriterion("RReceiptDate between", value1, value2, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andRreceiptdateNotBetween(Date value1, Date value2) {
            addCriterion("RReceiptDate not between", value1, value2, "rreceiptdate");
            return (Criteria) this;
        }

        public Criteria andIsrefundedIsNull() {
            addCriterion("IsRefunded is null");
            return (Criteria) this;
        }

        public Criteria andIsrefundedIsNotNull() {
            addCriterion("IsRefunded is not null");
            return (Criteria) this;
        }

        public Criteria andIsrefundedEqualTo(Boolean value) {
            addCriterion("IsRefunded =", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedNotEqualTo(Boolean value) {
            addCriterion("IsRefunded <>", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedGreaterThan(Boolean value) {
            addCriterion("IsRefunded >", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsRefunded >=", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedLessThan(Boolean value) {
            addCriterion("IsRefunded <", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedLessThanOrEqualTo(Boolean value) {
            addCriterion("IsRefunded <=", value, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedIn(List<Boolean> values) {
            addCriterion("IsRefunded in", values, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedNotIn(List<Boolean> values) {
            addCriterion("IsRefunded not in", values, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedBetween(Boolean value1, Boolean value2) {
            addCriterion("IsRefunded between", value1, value2, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andIsrefundedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsRefunded not between", value1, value2, "isrefunded");
            return (Criteria) this;
        }

        public Criteria andRamountIsNull() {
            addCriterion("RAmount is null");
            return (Criteria) this;
        }

        public Criteria andRamountIsNotNull() {
            addCriterion("RAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRamountEqualTo(BigDecimal value) {
            addCriterion("RAmount =", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountNotEqualTo(BigDecimal value) {
            addCriterion("RAmount <>", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountGreaterThan(BigDecimal value) {
            addCriterion("RAmount >", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("RAmount >=", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountLessThan(BigDecimal value) {
            addCriterion("RAmount <", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("RAmount <=", value, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountIn(List<BigDecimal> values) {
            addCriterion("RAmount in", values, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountNotIn(List<BigDecimal> values) {
            addCriterion("RAmount not in", values, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RAmount between", value1, value2, "ramount");
            return (Criteria) this;
        }

        public Criteria andRamountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("RAmount not between", value1, value2, "ramount");
            return (Criteria) this;
        }

        public Criteria andServicemodeIsNull() {
            addCriterion("ServiceMode is null");
            return (Criteria) this;
        }

        public Criteria andServicemodeIsNotNull() {
            addCriterion("ServiceMode is not null");
            return (Criteria) this;
        }

        public Criteria andServicemodeEqualTo(String value) {
            addCriterion("ServiceMode =", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeNotEqualTo(String value) {
            addCriterion("ServiceMode <>", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeGreaterThan(String value) {
            addCriterion("ServiceMode >", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeGreaterThanOrEqualTo(String value) {
            addCriterion("ServiceMode >=", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeLessThan(String value) {
            addCriterion("ServiceMode <", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeLessThanOrEqualTo(String value) {
            addCriterion("ServiceMode <=", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeLike(String value) {
            addCriterion("ServiceMode like", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeNotLike(String value) {
            addCriterion("ServiceMode not like", value, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeIn(List<String> values) {
            addCriterion("ServiceMode in", values, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeNotIn(List<String> values) {
            addCriterion("ServiceMode not in", values, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeBetween(String value1, String value2) {
            addCriterion("ServiceMode between", value1, value2, "servicemode");
            return (Criteria) this;
        }

        public Criteria andServicemodeNotBetween(String value1, String value2) {
            addCriterion("ServiceMode not between", value1, value2, "servicemode");
            return (Criteria) this;
        }

        public Criteria andOrdertypeIsNull() {
            addCriterion("OrderType is null");
            return (Criteria) this;
        }

        public Criteria andOrdertypeIsNotNull() {
            addCriterion("OrderType is not null");
            return (Criteria) this;
        }

        public Criteria andOrdertypeEqualTo(String value) {
            addCriterion("OrderType =", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeNotEqualTo(String value) {
            addCriterion("OrderType <>", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeGreaterThan(String value) {
            addCriterion("OrderType >", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeGreaterThanOrEqualTo(String value) {
            addCriterion("OrderType >=", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeLessThan(String value) {
            addCriterion("OrderType <", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeLessThanOrEqualTo(String value) {
            addCriterion("OrderType <=", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeLike(String value) {
            addCriterion("OrderType like", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeNotLike(String value) {
            addCriterion("OrderType not like", value, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeIn(List<String> values) {
            addCriterion("OrderType in", values, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeNotIn(List<String> values) {
            addCriterion("OrderType not in", values, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeBetween(String value1, String value2) {
            addCriterion("OrderType between", value1, value2, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOrdertypeNotBetween(String value1, String value2) {
            addCriterion("OrderType not between", value1, value2, "ordertype");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoIsNull() {
            addCriterion("OldShipmentsNo is null");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoIsNotNull() {
            addCriterion("OldShipmentsNo is not null");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoEqualTo(String value) {
            addCriterion("OldShipmentsNo =", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoNotEqualTo(String value) {
            addCriterion("OldShipmentsNo <>", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoGreaterThan(String value) {
            addCriterion("OldShipmentsNo >", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoGreaterThanOrEqualTo(String value) {
            addCriterion("OldShipmentsNo >=", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoLessThan(String value) {
            addCriterion("OldShipmentsNo <", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoLessThanOrEqualTo(String value) {
            addCriterion("OldShipmentsNo <=", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoLike(String value) {
            addCriterion("OldShipmentsNo like", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoNotLike(String value) {
            addCriterion("OldShipmentsNo not like", value, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoIn(List<String> values) {
            addCriterion("OldShipmentsNo in", values, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoNotIn(List<String> values) {
            addCriterion("OldShipmentsNo not in", values, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoBetween(String value1, String value2) {
            addCriterion("OldShipmentsNo between", value1, value2, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andOldshipmentsnoNotBetween(String value1, String value2) {
            addCriterion("OldShipmentsNo not between", value1, value2, "oldshipmentsno");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeIsNull() {
            addCriterion("RStorageCode is null");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeIsNotNull() {
            addCriterion("RStorageCode is not null");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeEqualTo(String value) {
            addCriterion("RStorageCode =", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeNotEqualTo(String value) {
            addCriterion("RStorageCode <>", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeGreaterThan(String value) {
            addCriterion("RStorageCode >", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeGreaterThanOrEqualTo(String value) {
            addCriterion("RStorageCode >=", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeLessThan(String value) {
            addCriterion("RStorageCode <", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeLessThanOrEqualTo(String value) {
            addCriterion("RStorageCode <=", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeLike(String value) {
            addCriterion("RStorageCode like", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeNotLike(String value) {
            addCriterion("RStorageCode not like", value, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeIn(List<String> values) {
            addCriterion("RStorageCode in", values, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeNotIn(List<String> values) {
            addCriterion("RStorageCode not in", values, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeBetween(String value1, String value2) {
            addCriterion("RStorageCode between", value1, value2, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andRstoragecodeNotBetween(String value1, String value2) {
            addCriterion("RStorageCode not between", value1, value2, "rstoragecode");
            return (Criteria) this;
        }

        public Criteria andDeliverynoIsNull() {
            addCriterion("DeliveryNo is null");
            return (Criteria) this;
        }

        public Criteria andDeliverynoIsNotNull() {
            addCriterion("DeliveryNo is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverynoEqualTo(String value) {
            addCriterion("DeliveryNo =", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoNotEqualTo(String value) {
            addCriterion("DeliveryNo <>", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoGreaterThan(String value) {
            addCriterion("DeliveryNo >", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoGreaterThanOrEqualTo(String value) {
            addCriterion("DeliveryNo >=", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoLessThan(String value) {
            addCriterion("DeliveryNo <", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoLessThanOrEqualTo(String value) {
            addCriterion("DeliveryNo <=", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoLike(String value) {
            addCriterion("DeliveryNo like", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoNotLike(String value) {
            addCriterion("DeliveryNo not like", value, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoIn(List<String> values) {
            addCriterion("DeliveryNo in", values, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoNotIn(List<String> values) {
            addCriterion("DeliveryNo not in", values, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoBetween(String value1, String value2) {
            addCriterion("DeliveryNo between", value1, value2, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andDeliverynoNotBetween(String value1, String value2) {
            addCriterion("DeliveryNo not between", value1, value2, "deliveryno");
            return (Criteria) this;
        }

        public Criteria andMoneyIsNull() {
            addCriterion("Money is null");
            return (Criteria) this;
        }

        public Criteria andMoneyIsNotNull() {
            addCriterion("Money is not null");
            return (Criteria) this;
        }

        public Criteria andMoneyEqualTo(BigDecimal value) {
            addCriterion("Money =", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotEqualTo(BigDecimal value) {
            addCriterion("Money <>", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyGreaterThan(BigDecimal value) {
            addCriterion("Money >", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Money >=", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyLessThan(BigDecimal value) {
            addCriterion("Money <", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Money <=", value, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyIn(List<BigDecimal> values) {
            addCriterion("Money in", values, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotIn(List<BigDecimal> values) {
            addCriterion("Money not in", values, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Money between", value1, value2, "money");
            return (Criteria) this;
        }

        public Criteria andMoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Money not between", value1, value2, "money");
            return (Criteria) this;
        }

        public Criteria andIsprotectIsNull() {
            addCriterion("IsProtect is null");
            return (Criteria) this;
        }

        public Criteria andIsprotectIsNotNull() {
            addCriterion("IsProtect is not null");
            return (Criteria) this;
        }

        public Criteria andIsprotectEqualTo(Boolean value) {
            addCriterion("IsProtect =", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectNotEqualTo(Boolean value) {
            addCriterion("IsProtect <>", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectGreaterThan(Boolean value) {
            addCriterion("IsProtect >", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsProtect >=", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectLessThan(Boolean value) {
            addCriterion("IsProtect <", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectLessThanOrEqualTo(Boolean value) {
            addCriterion("IsProtect <=", value, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectIn(List<Boolean> values) {
            addCriterion("IsProtect in", values, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectNotIn(List<Boolean> values) {
            addCriterion("IsProtect not in", values, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectBetween(Boolean value1, Boolean value2) {
            addCriterion("IsProtect between", value1, value2, "isprotect");
            return (Criteria) this;
        }

        public Criteria andIsprotectNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsProtect not between", value1, value2, "isprotect");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyIsNull() {
            addCriterion("ProtectMoney is null");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyIsNotNull() {
            addCriterion("ProtectMoney is not null");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyEqualTo(BigDecimal value) {
            addCriterion("ProtectMoney =", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyNotEqualTo(BigDecimal value) {
            addCriterion("ProtectMoney <>", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyGreaterThan(BigDecimal value) {
            addCriterion("ProtectMoney >", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ProtectMoney >=", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyLessThan(BigDecimal value) {
            addCriterion("ProtectMoney <", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ProtectMoney <=", value, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyIn(List<BigDecimal> values) {
            addCriterion("ProtectMoney in", values, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyNotIn(List<BigDecimal> values) {
            addCriterion("ProtectMoney not in", values, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ProtectMoney between", value1, value2, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProtectmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ProtectMoney not between", value1, value2, "protectmoney");
            return (Criteria) this;
        }

        public Criteria andProductgIsNull() {
            addCriterion("ProductG is null");
            return (Criteria) this;
        }

        public Criteria andProductgIsNotNull() {
            addCriterion("ProductG is not null");
            return (Criteria) this;
        }

        public Criteria andProductgEqualTo(Integer value) {
            addCriterion("ProductG =", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgNotEqualTo(Integer value) {
            addCriterion("ProductG <>", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgGreaterThan(Integer value) {
            addCriterion("ProductG >", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgGreaterThanOrEqualTo(Integer value) {
            addCriterion("ProductG >=", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgLessThan(Integer value) {
            addCriterion("ProductG <", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgLessThanOrEqualTo(Integer value) {
            addCriterion("ProductG <=", value, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgIn(List<Integer> values) {
            addCriterion("ProductG in", values, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgNotIn(List<Integer> values) {
            addCriterion("ProductG not in", values, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgBetween(Integer value1, Integer value2) {
            addCriterion("ProductG between", value1, value2, "productg");
            return (Criteria) this;
        }

        public Criteria andProductgNotBetween(Integer value1, Integer value2) {
            addCriterion("ProductG not between", value1, value2, "productg");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidIsNull() {
            addCriterion("DeliveryTypeID is null");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidIsNotNull() {
            addCriterion("DeliveryTypeID is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidEqualTo(String value) {
            addCriterion("DeliveryTypeID =", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidNotEqualTo(String value) {
            addCriterion("DeliveryTypeID <>", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidGreaterThan(String value) {
            addCriterion("DeliveryTypeID >", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidGreaterThanOrEqualTo(String value) {
            addCriterion("DeliveryTypeID >=", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidLessThan(String value) {
            addCriterion("DeliveryTypeID <", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidLessThanOrEqualTo(String value) {
            addCriterion("DeliveryTypeID <=", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidLike(String value) {
            addCriterion("DeliveryTypeID like", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidNotLike(String value) {
            addCriterion("DeliveryTypeID not like", value, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidIn(List<String> values) {
            addCriterion("DeliveryTypeID in", values, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidNotIn(List<String> values) {
            addCriterion("DeliveryTypeID not in", values, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidBetween(String value1, String value2) {
            addCriterion("DeliveryTypeID between", value1, value2, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypeidNotBetween(String value1, String value2) {
            addCriterion("DeliveryTypeID not between", value1, value2, "deliverytypeid");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameIsNull() {
            addCriterion("DeliveryTypeName is null");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameIsNotNull() {
            addCriterion("DeliveryTypeName is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameEqualTo(String value) {
            addCriterion("DeliveryTypeName =", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameNotEqualTo(String value) {
            addCriterion("DeliveryTypeName <>", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameGreaterThan(String value) {
            addCriterion("DeliveryTypeName >", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameGreaterThanOrEqualTo(String value) {
            addCriterion("DeliveryTypeName >=", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameLessThan(String value) {
            addCriterion("DeliveryTypeName <", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameLessThanOrEqualTo(String value) {
            addCriterion("DeliveryTypeName <=", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameLike(String value) {
            addCriterion("DeliveryTypeName like", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameNotLike(String value) {
            addCriterion("DeliveryTypeName not like", value, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameIn(List<String> values) {
            addCriterion("DeliveryTypeName in", values, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameNotIn(List<String> values) {
            addCriterion("DeliveryTypeName not in", values, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameBetween(String value1, String value2) {
            addCriterion("DeliveryTypeName between", value1, value2, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andDeliverytypenameNotBetween(String value1, String value2) {
            addCriterion("DeliveryTypeName not between", value1, value2, "deliverytypename");
            return (Criteria) this;
        }

        public Criteria andLogiidIsNull() {
            addCriterion("LogiID is null");
            return (Criteria) this;
        }

        public Criteria andLogiidIsNotNull() {
            addCriterion("LogiID is not null");
            return (Criteria) this;
        }

        public Criteria andLogiidEqualTo(String value) {
            addCriterion("LogiID =", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidNotEqualTo(String value) {
            addCriterion("LogiID <>", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidGreaterThan(String value) {
            addCriterion("LogiID >", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidGreaterThanOrEqualTo(String value) {
            addCriterion("LogiID >=", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidLessThan(String value) {
            addCriterion("LogiID <", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidLessThanOrEqualTo(String value) {
            addCriterion("LogiID <=", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidLike(String value) {
            addCriterion("LogiID like", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidNotLike(String value) {
            addCriterion("LogiID not like", value, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidIn(List<String> values) {
            addCriterion("LogiID in", values, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidNotIn(List<String> values) {
            addCriterion("LogiID not in", values, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidBetween(String value1, String value2) {
            addCriterion("LogiID between", value1, value2, "logiid");
            return (Criteria) this;
        }

        public Criteria andLogiidNotBetween(String value1, String value2) {
            addCriterion("LogiID not between", value1, value2, "logiid");
            return (Criteria) this;
        }

        public Criteria andLoginameIsNull() {
            addCriterion("LogiName is null");
            return (Criteria) this;
        }

        public Criteria andLoginameIsNotNull() {
            addCriterion("LogiName is not null");
            return (Criteria) this;
        }

        public Criteria andLoginameEqualTo(String value) {
            addCriterion("LogiName =", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameNotEqualTo(String value) {
            addCriterion("LogiName <>", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameGreaterThan(String value) {
            addCriterion("LogiName >", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameGreaterThanOrEqualTo(String value) {
            addCriterion("LogiName >=", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameLessThan(String value) {
            addCriterion("LogiName <", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameLessThanOrEqualTo(String value) {
            addCriterion("LogiName <=", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameLike(String value) {
            addCriterion("LogiName like", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameNotLike(String value) {
            addCriterion("LogiName not like", value, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameIn(List<String> values) {
            addCriterion("LogiName in", values, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameNotIn(List<String> values) {
            addCriterion("LogiName not in", values, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameBetween(String value1, String value2) {
            addCriterion("LogiName between", value1, value2, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginameNotBetween(String value1, String value2) {
            addCriterion("LogiName not between", value1, value2, "loginame");
            return (Criteria) this;
        }

        public Criteria andLoginoIsNull() {
            addCriterion("LogiNo is null");
            return (Criteria) this;
        }

        public Criteria andLoginoIsNotNull() {
            addCriterion("LogiNo is not null");
            return (Criteria) this;
        }

        public Criteria andLoginoEqualTo(String value) {
            addCriterion("LogiNo =", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoNotEqualTo(String value) {
            addCriterion("LogiNo <>", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoGreaterThan(String value) {
            addCriterion("LogiNo >", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoGreaterThanOrEqualTo(String value) {
            addCriterion("LogiNo >=", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoLessThan(String value) {
            addCriterion("LogiNo <", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoLessThanOrEqualTo(String value) {
            addCriterion("LogiNo <=", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoLike(String value) {
            addCriterion("LogiNo like", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoNotLike(String value) {
            addCriterion("LogiNo not like", value, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoIn(List<String> values) {
            addCriterion("LogiNo in", values, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoNotIn(List<String> values) {
            addCriterion("LogiNo not in", values, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoBetween(String value1, String value2) {
            addCriterion("LogiNo between", value1, value2, "logino");
            return (Criteria) this;
        }

        public Criteria andLoginoNotBetween(String value1, String value2) {
            addCriterion("LogiNo not between", value1, value2, "logino");
            return (Criteria) this;
        }

        public Criteria andCustnoIsNull() {
            addCriterion("CustNo is null");
            return (Criteria) this;
        }

        public Criteria andCustnoIsNotNull() {
            addCriterion("CustNo is not null");
            return (Criteria) this;
        }

        public Criteria andCustnoEqualTo(String value) {
            addCriterion("CustNo =", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoNotEqualTo(String value) {
            addCriterion("CustNo <>", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoGreaterThan(String value) {
            addCriterion("CustNo >", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoGreaterThanOrEqualTo(String value) {
            addCriterion("CustNo >=", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoLessThan(String value) {
            addCriterion("CustNo <", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoLessThanOrEqualTo(String value) {
            addCriterion("CustNo <=", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoLike(String value) {
            addCriterion("CustNo like", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoNotLike(String value) {
            addCriterion("CustNo not like", value, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoIn(List<String> values) {
            addCriterion("CustNo in", values, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoNotIn(List<String> values) {
            addCriterion("CustNo not in", values, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoBetween(String value1, String value2) {
            addCriterion("CustNo between", value1, value2, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnoNotBetween(String value1, String value2) {
            addCriterion("CustNo not between", value1, value2, "custno");
            return (Criteria) this;
        }

        public Criteria andCustnameIsNull() {
            addCriterion("CustName is null");
            return (Criteria) this;
        }

        public Criteria andCustnameIsNotNull() {
            addCriterion("CustName is not null");
            return (Criteria) this;
        }

        public Criteria andCustnameEqualTo(String value) {
            addCriterion("CustName =", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameNotEqualTo(String value) {
            addCriterion("CustName <>", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameGreaterThan(String value) {
            addCriterion("CustName >", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameGreaterThanOrEqualTo(String value) {
            addCriterion("CustName >=", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameLessThan(String value) {
            addCriterion("CustName <", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameLessThanOrEqualTo(String value) {
            addCriterion("CustName <=", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameLike(String value) {
            addCriterion("CustName like", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameNotLike(String value) {
            addCriterion("CustName not like", value, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameIn(List<String> values) {
            addCriterion("CustName in", values, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameNotIn(List<String> values) {
            addCriterion("CustName not in", values, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameBetween(String value1, String value2) {
            addCriterion("CustName between", value1, value2, "custname");
            return (Criteria) this;
        }

        public Criteria andCustnameNotBetween(String value1, String value2) {
            addCriterion("CustName not between", value1, value2, "custname");
            return (Criteria) this;
        }

        public Criteria andCustaddressIsNull() {
            addCriterion("CustAddress is null");
            return (Criteria) this;
        }

        public Criteria andCustaddressIsNotNull() {
            addCriterion("CustAddress is not null");
            return (Criteria) this;
        }

        public Criteria andCustaddressEqualTo(String value) {
            addCriterion("CustAddress =", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressNotEqualTo(String value) {
            addCriterion("CustAddress <>", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressGreaterThan(String value) {
            addCriterion("CustAddress >", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressGreaterThanOrEqualTo(String value) {
            addCriterion("CustAddress >=", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressLessThan(String value) {
            addCriterion("CustAddress <", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressLessThanOrEqualTo(String value) {
            addCriterion("CustAddress <=", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressLike(String value) {
            addCriterion("CustAddress like", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressNotLike(String value) {
            addCriterion("CustAddress not like", value, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressIn(List<String> values) {
            addCriterion("CustAddress in", values, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressNotIn(List<String> values) {
            addCriterion("CustAddress not in", values, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressBetween(String value1, String value2) {
            addCriterion("CustAddress between", value1, value2, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustaddressNotBetween(String value1, String value2) {
            addCriterion("CustAddress not between", value1, value2, "custaddress");
            return (Criteria) this;
        }

        public Criteria andCustpostIsNull() {
            addCriterion("CustPost is null");
            return (Criteria) this;
        }

        public Criteria andCustpostIsNotNull() {
            addCriterion("CustPost is not null");
            return (Criteria) this;
        }

        public Criteria andCustpostEqualTo(String value) {
            addCriterion("CustPost =", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostNotEqualTo(String value) {
            addCriterion("CustPost <>", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostGreaterThan(String value) {
            addCriterion("CustPost >", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostGreaterThanOrEqualTo(String value) {
            addCriterion("CustPost >=", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostLessThan(String value) {
            addCriterion("CustPost <", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostLessThanOrEqualTo(String value) {
            addCriterion("CustPost <=", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostLike(String value) {
            addCriterion("CustPost like", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostNotLike(String value) {
            addCriterion("CustPost not like", value, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostIn(List<String> values) {
            addCriterion("CustPost in", values, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostNotIn(List<String> values) {
            addCriterion("CustPost not in", values, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostBetween(String value1, String value2) {
            addCriterion("CustPost between", value1, value2, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustpostNotBetween(String value1, String value2) {
            addCriterion("CustPost not between", value1, value2, "custpost");
            return (Criteria) this;
        }

        public Criteria andCustcityIsNull() {
            addCriterion("CustCity is null");
            return (Criteria) this;
        }

        public Criteria andCustcityIsNotNull() {
            addCriterion("CustCity is not null");
            return (Criteria) this;
        }

        public Criteria andCustcityEqualTo(String value) {
            addCriterion("CustCity =", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityNotEqualTo(String value) {
            addCriterion("CustCity <>", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityGreaterThan(String value) {
            addCriterion("CustCity >", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityGreaterThanOrEqualTo(String value) {
            addCriterion("CustCity >=", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityLessThan(String value) {
            addCriterion("CustCity <", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityLessThanOrEqualTo(String value) {
            addCriterion("CustCity <=", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityLike(String value) {
            addCriterion("CustCity like", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityNotLike(String value) {
            addCriterion("CustCity not like", value, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityIn(List<String> values) {
            addCriterion("CustCity in", values, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityNotIn(List<String> values) {
            addCriterion("CustCity not in", values, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityBetween(String value1, String value2) {
            addCriterion("CustCity between", value1, value2, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcityNotBetween(String value1, String value2) {
            addCriterion("CustCity not between", value1, value2, "custcity");
            return (Criteria) this;
        }

        public Criteria andCustcountyIsNull() {
            addCriterion("CustCounty is null");
            return (Criteria) this;
        }

        public Criteria andCustcountyIsNotNull() {
            addCriterion("CustCounty is not null");
            return (Criteria) this;
        }

        public Criteria andCustcountyEqualTo(String value) {
            addCriterion("CustCounty =", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyNotEqualTo(String value) {
            addCriterion("CustCounty <>", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyGreaterThan(String value) {
            addCriterion("CustCounty >", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyGreaterThanOrEqualTo(String value) {
            addCriterion("CustCounty >=", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyLessThan(String value) {
            addCriterion("CustCounty <", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyLessThanOrEqualTo(String value) {
            addCriterion("CustCounty <=", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyLike(String value) {
            addCriterion("CustCounty like", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyNotLike(String value) {
            addCriterion("CustCounty not like", value, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyIn(List<String> values) {
            addCriterion("CustCounty in", values, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyNotIn(List<String> values) {
            addCriterion("CustCounty not in", values, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyBetween(String value1, String value2) {
            addCriterion("CustCounty between", value1, value2, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustcountyNotBetween(String value1, String value2) {
            addCriterion("CustCounty not between", value1, value2, "custcounty");
            return (Criteria) this;
        }

        public Criteria andCustareaIsNull() {
            addCriterion("CustArea is null");
            return (Criteria) this;
        }

        public Criteria andCustareaIsNotNull() {
            addCriterion("CustArea is not null");
            return (Criteria) this;
        }

        public Criteria andCustareaEqualTo(String value) {
            addCriterion("CustArea =", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaNotEqualTo(String value) {
            addCriterion("CustArea <>", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaGreaterThan(String value) {
            addCriterion("CustArea >", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaGreaterThanOrEqualTo(String value) {
            addCriterion("CustArea >=", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaLessThan(String value) {
            addCriterion("CustArea <", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaLessThanOrEqualTo(String value) {
            addCriterion("CustArea <=", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaLike(String value) {
            addCriterion("CustArea like", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaNotLike(String value) {
            addCriterion("CustArea not like", value, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaIn(List<String> values) {
            addCriterion("CustArea in", values, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaNotIn(List<String> values) {
            addCriterion("CustArea not in", values, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaBetween(String value1, String value2) {
            addCriterion("CustArea between", value1, value2, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareaNotBetween(String value1, String value2) {
            addCriterion("CustArea not between", value1, value2, "custarea");
            return (Criteria) this;
        }

        public Criteria andCustareanameIsNull() {
            addCriterion("CustAreaName is null");
            return (Criteria) this;
        }

        public Criteria andCustareanameIsNotNull() {
            addCriterion("CustAreaName is not null");
            return (Criteria) this;
        }

        public Criteria andCustareanameEqualTo(String value) {
            addCriterion("CustAreaName =", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameNotEqualTo(String value) {
            addCriterion("CustAreaName <>", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameGreaterThan(String value) {
            addCriterion("CustAreaName >", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameGreaterThanOrEqualTo(String value) {
            addCriterion("CustAreaName >=", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameLessThan(String value) {
            addCriterion("CustAreaName <", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameLessThanOrEqualTo(String value) {
            addCriterion("CustAreaName <=", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameLike(String value) {
            addCriterion("CustAreaName like", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameNotLike(String value) {
            addCriterion("CustAreaName not like", value, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameIn(List<String> values) {
            addCriterion("CustAreaName in", values, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameNotIn(List<String> values) {
            addCriterion("CustAreaName not in", values, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameBetween(String value1, String value2) {
            addCriterion("CustAreaName between", value1, value2, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCustareanameNotBetween(String value1, String value2) {
            addCriterion("CustAreaName not between", value1, value2, "custareaname");
            return (Criteria) this;
        }

        public Criteria andCusttelIsNull() {
            addCriterion("CustTel is null");
            return (Criteria) this;
        }

        public Criteria andCusttelIsNotNull() {
            addCriterion("CustTel is not null");
            return (Criteria) this;
        }

        public Criteria andCusttelEqualTo(String value) {
            addCriterion("CustTel =", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelNotEqualTo(String value) {
            addCriterion("CustTel <>", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelGreaterThan(String value) {
            addCriterion("CustTel >", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelGreaterThanOrEqualTo(String value) {
            addCriterion("CustTel >=", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelLessThan(String value) {
            addCriterion("CustTel <", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelLessThanOrEqualTo(String value) {
            addCriterion("CustTel <=", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelLike(String value) {
            addCriterion("CustTel like", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelNotLike(String value) {
            addCriterion("CustTel not like", value, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelIn(List<String> values) {
            addCriterion("CustTel in", values, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelNotIn(List<String> values) {
            addCriterion("CustTel not in", values, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelBetween(String value1, String value2) {
            addCriterion("CustTel between", value1, value2, "custtel");
            return (Criteria) this;
        }

        public Criteria andCusttelNotBetween(String value1, String value2) {
            addCriterion("CustTel not between", value1, value2, "custtel");
            return (Criteria) this;
        }

        public Criteria andShipcodeIsNull() {
            addCriterion("ShipCode is null");
            return (Criteria) this;
        }

        public Criteria andShipcodeIsNotNull() {
            addCriterion("ShipCode is not null");
            return (Criteria) this;
        }

        public Criteria andShipcodeEqualTo(String value) {
            addCriterion("ShipCode =", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeNotEqualTo(String value) {
            addCriterion("ShipCode <>", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeGreaterThan(String value) {
            addCriterion("ShipCode >", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeGreaterThanOrEqualTo(String value) {
            addCriterion("ShipCode >=", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeLessThan(String value) {
            addCriterion("ShipCode <", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeLessThanOrEqualTo(String value) {
            addCriterion("ShipCode <=", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeLike(String value) {
            addCriterion("ShipCode like", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeNotLike(String value) {
            addCriterion("ShipCode not like", value, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeIn(List<String> values) {
            addCriterion("ShipCode in", values, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeNotIn(List<String> values) {
            addCriterion("ShipCode not in", values, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeBetween(String value1, String value2) {
            addCriterion("ShipCode between", value1, value2, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipcodeNotBetween(String value1, String value2) {
            addCriterion("ShipCode not between", value1, value2, "shipcode");
            return (Criteria) this;
        }

        public Criteria andShipnameIsNull() {
            addCriterion("ShipName is null");
            return (Criteria) this;
        }

        public Criteria andShipnameIsNotNull() {
            addCriterion("ShipName is not null");
            return (Criteria) this;
        }

        public Criteria andShipnameEqualTo(String value) {
            addCriterion("ShipName =", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameNotEqualTo(String value) {
            addCriterion("ShipName <>", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameGreaterThan(String value) {
            addCriterion("ShipName >", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameGreaterThanOrEqualTo(String value) {
            addCriterion("ShipName >=", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameLessThan(String value) {
            addCriterion("ShipName <", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameLessThanOrEqualTo(String value) {
            addCriterion("ShipName <=", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameLike(String value) {
            addCriterion("ShipName like", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameNotLike(String value) {
            addCriterion("ShipName not like", value, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameIn(List<String> values) {
            addCriterion("ShipName in", values, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameNotIn(List<String> values) {
            addCriterion("ShipName not in", values, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameBetween(String value1, String value2) {
            addCriterion("ShipName between", value1, value2, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipnameNotBetween(String value1, String value2) {
            addCriterion("ShipName not between", value1, value2, "shipname");
            return (Criteria) this;
        }

        public Criteria andShipaddrIsNull() {
            addCriterion("ShipAddr is null");
            return (Criteria) this;
        }

        public Criteria andShipaddrIsNotNull() {
            addCriterion("ShipAddr is not null");
            return (Criteria) this;
        }

        public Criteria andShipaddrEqualTo(String value) {
            addCriterion("ShipAddr =", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrNotEqualTo(String value) {
            addCriterion("ShipAddr <>", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrGreaterThan(String value) {
            addCriterion("ShipAddr >", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrGreaterThanOrEqualTo(String value) {
            addCriterion("ShipAddr >=", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrLessThan(String value) {
            addCriterion("ShipAddr <", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrLessThanOrEqualTo(String value) {
            addCriterion("ShipAddr <=", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrLike(String value) {
            addCriterion("ShipAddr like", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrNotLike(String value) {
            addCriterion("ShipAddr not like", value, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrIn(List<String> values) {
            addCriterion("ShipAddr in", values, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrNotIn(List<String> values) {
            addCriterion("ShipAddr not in", values, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrBetween(String value1, String value2) {
            addCriterion("ShipAddr between", value1, value2, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipaddrNotBetween(String value1, String value2) {
            addCriterion("ShipAddr not between", value1, value2, "shipaddr");
            return (Criteria) this;
        }

        public Criteria andShipzipIsNull() {
            addCriterion("ShipZip is null");
            return (Criteria) this;
        }

        public Criteria andShipzipIsNotNull() {
            addCriterion("ShipZip is not null");
            return (Criteria) this;
        }

        public Criteria andShipzipEqualTo(String value) {
            addCriterion("ShipZip =", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipNotEqualTo(String value) {
            addCriterion("ShipZip <>", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipGreaterThan(String value) {
            addCriterion("ShipZip >", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipGreaterThanOrEqualTo(String value) {
            addCriterion("ShipZip >=", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipLessThan(String value) {
            addCriterion("ShipZip <", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipLessThanOrEqualTo(String value) {
            addCriterion("ShipZip <=", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipLike(String value) {
            addCriterion("ShipZip like", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipNotLike(String value) {
            addCriterion("ShipZip not like", value, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipIn(List<String> values) {
            addCriterion("ShipZip in", values, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipNotIn(List<String> values) {
            addCriterion("ShipZip not in", values, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipBetween(String value1, String value2) {
            addCriterion("ShipZip between", value1, value2, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipzipNotBetween(String value1, String value2) {
            addCriterion("ShipZip not between", value1, value2, "shipzip");
            return (Criteria) this;
        }

        public Criteria andShipcityIsNull() {
            addCriterion("ShipCity is null");
            return (Criteria) this;
        }

        public Criteria andShipcityIsNotNull() {
            addCriterion("ShipCity is not null");
            return (Criteria) this;
        }

        public Criteria andShipcityEqualTo(String value) {
            addCriterion("ShipCity =", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityNotEqualTo(String value) {
            addCriterion("ShipCity <>", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityGreaterThan(String value) {
            addCriterion("ShipCity >", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityGreaterThanOrEqualTo(String value) {
            addCriterion("ShipCity >=", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityLessThan(String value) {
            addCriterion("ShipCity <", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityLessThanOrEqualTo(String value) {
            addCriterion("ShipCity <=", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityLike(String value) {
            addCriterion("ShipCity like", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityNotLike(String value) {
            addCriterion("ShipCity not like", value, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityIn(List<String> values) {
            addCriterion("ShipCity in", values, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityNotIn(List<String> values) {
            addCriterion("ShipCity not in", values, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityBetween(String value1, String value2) {
            addCriterion("ShipCity between", value1, value2, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipcityNotBetween(String value1, String value2) {
            addCriterion("ShipCity not between", value1, value2, "shipcity");
            return (Criteria) this;
        }

        public Criteria andShipareaIsNull() {
            addCriterion("ShipArea is null");
            return (Criteria) this;
        }

        public Criteria andShipareaIsNotNull() {
            addCriterion("ShipArea is not null");
            return (Criteria) this;
        }

        public Criteria andShipareaEqualTo(String value) {
            addCriterion("ShipArea =", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaNotEqualTo(String value) {
            addCriterion("ShipArea <>", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaGreaterThan(String value) {
            addCriterion("ShipArea >", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaGreaterThanOrEqualTo(String value) {
            addCriterion("ShipArea >=", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaLessThan(String value) {
            addCriterion("ShipArea <", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaLessThanOrEqualTo(String value) {
            addCriterion("ShipArea <=", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaLike(String value) {
            addCriterion("ShipArea like", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaNotLike(String value) {
            addCriterion("ShipArea not like", value, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaIn(List<String> values) {
            addCriterion("ShipArea in", values, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaNotIn(List<String> values) {
            addCriterion("ShipArea not in", values, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaBetween(String value1, String value2) {
            addCriterion("ShipArea between", value1, value2, "shiparea");
            return (Criteria) this;
        }

        public Criteria andShipareaNotBetween(String value1, String value2) {
            addCriterion("ShipArea not between", value1, value2, "shiparea");
            return (Criteria) this;
        }

        public Criteria andDelivercountyIsNull() {
            addCriterion("DeliverCounty is null");
            return (Criteria) this;
        }

        public Criteria andDelivercountyIsNotNull() {
            addCriterion("DeliverCounty is not null");
            return (Criteria) this;
        }

        public Criteria andDelivercountyEqualTo(String value) {
            addCriterion("DeliverCounty =", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyNotEqualTo(String value) {
            addCriterion("DeliverCounty <>", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyGreaterThan(String value) {
            addCriterion("DeliverCounty >", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyGreaterThanOrEqualTo(String value) {
            addCriterion("DeliverCounty >=", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyLessThan(String value) {
            addCriterion("DeliverCounty <", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyLessThanOrEqualTo(String value) {
            addCriterion("DeliverCounty <=", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyLike(String value) {
            addCriterion("DeliverCounty like", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyNotLike(String value) {
            addCriterion("DeliverCounty not like", value, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyIn(List<String> values) {
            addCriterion("DeliverCounty in", values, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyNotIn(List<String> values) {
            addCriterion("DeliverCounty not in", values, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyBetween(String value1, String value2) {
            addCriterion("DeliverCounty between", value1, value2, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDelivercountyNotBetween(String value1, String value2) {
            addCriterion("DeliverCounty not between", value1, value2, "delivercounty");
            return (Criteria) this;
        }

        public Criteria andDeliverareaIsNull() {
            addCriterion("DeliverArea is null");
            return (Criteria) this;
        }

        public Criteria andDeliverareaIsNotNull() {
            addCriterion("DeliverArea is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverareaEqualTo(String value) {
            addCriterion("DeliverArea =", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaNotEqualTo(String value) {
            addCriterion("DeliverArea <>", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaGreaterThan(String value) {
            addCriterion("DeliverArea >", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaGreaterThanOrEqualTo(String value) {
            addCriterion("DeliverArea >=", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaLessThan(String value) {
            addCriterion("DeliverArea <", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaLessThanOrEqualTo(String value) {
            addCriterion("DeliverArea <=", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaLike(String value) {
            addCriterion("DeliverArea like", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaNotLike(String value) {
            addCriterion("DeliverArea not like", value, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaIn(List<String> values) {
            addCriterion("DeliverArea in", values, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaNotIn(List<String> values) {
            addCriterion("DeliverArea not in", values, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaBetween(String value1, String value2) {
            addCriterion("DeliverArea between", value1, value2, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareaNotBetween(String value1, String value2) {
            addCriterion("DeliverArea not between", value1, value2, "deliverarea");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameIsNull() {
            addCriterion("DeliverAreaName is null");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameIsNotNull() {
            addCriterion("DeliverAreaName is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameEqualTo(String value) {
            addCriterion("DeliverAreaName =", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameNotEqualTo(String value) {
            addCriterion("DeliverAreaName <>", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameGreaterThan(String value) {
            addCriterion("DeliverAreaName >", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameGreaterThanOrEqualTo(String value) {
            addCriterion("DeliverAreaName >=", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameLessThan(String value) {
            addCriterion("DeliverAreaName <", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameLessThanOrEqualTo(String value) {
            addCriterion("DeliverAreaName <=", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameLike(String value) {
            addCriterion("DeliverAreaName like", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameNotLike(String value) {
            addCriterion("DeliverAreaName not like", value, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameIn(List<String> values) {
            addCriterion("DeliverAreaName in", values, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameNotIn(List<String> values) {
            addCriterion("DeliverAreaName not in", values, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameBetween(String value1, String value2) {
            addCriterion("DeliverAreaName between", value1, value2, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andDeliverareanameNotBetween(String value1, String value2) {
            addCriterion("DeliverAreaName not between", value1, value2, "deliverareaname");
            return (Criteria) this;
        }

        public Criteria andShipmobileIsNull() {
            addCriterion("ShipMobile is null");
            return (Criteria) this;
        }

        public Criteria andShipmobileIsNotNull() {
            addCriterion("ShipMobile is not null");
            return (Criteria) this;
        }

        public Criteria andShipmobileEqualTo(String value) {
            addCriterion("ShipMobile =", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileNotEqualTo(String value) {
            addCriterion("ShipMobile <>", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileGreaterThan(String value) {
            addCriterion("ShipMobile >", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileGreaterThanOrEqualTo(String value) {
            addCriterion("ShipMobile >=", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileLessThan(String value) {
            addCriterion("ShipMobile <", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileLessThanOrEqualTo(String value) {
            addCriterion("ShipMobile <=", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileLike(String value) {
            addCriterion("ShipMobile like", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileNotLike(String value) {
            addCriterion("ShipMobile not like", value, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileIn(List<String> values) {
            addCriterion("ShipMobile in", values, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileNotIn(List<String> values) {
            addCriterion("ShipMobile not in", values, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileBetween(String value1, String value2) {
            addCriterion("ShipMobile between", value1, value2, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShipmobileNotBetween(String value1, String value2) {
            addCriterion("ShipMobile not between", value1, value2, "shipmobile");
            return (Criteria) this;
        }

        public Criteria andShiptelIsNull() {
            addCriterion("ShipTel is null");
            return (Criteria) this;
        }

        public Criteria andShiptelIsNotNull() {
            addCriterion("ShipTel is not null");
            return (Criteria) this;
        }

        public Criteria andShiptelEqualTo(String value) {
            addCriterion("ShipTel =", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelNotEqualTo(String value) {
            addCriterion("ShipTel <>", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelGreaterThan(String value) {
            addCriterion("ShipTel >", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelGreaterThanOrEqualTo(String value) {
            addCriterion("ShipTel >=", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelLessThan(String value) {
            addCriterion("ShipTel <", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelLessThanOrEqualTo(String value) {
            addCriterion("ShipTel <=", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelLike(String value) {
            addCriterion("ShipTel like", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelNotLike(String value) {
            addCriterion("ShipTel not like", value, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelIn(List<String> values) {
            addCriterion("ShipTel in", values, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelNotIn(List<String> values) {
            addCriterion("ShipTel not in", values, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelBetween(String value1, String value2) {
            addCriterion("ShipTel between", value1, value2, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShiptelNotBetween(String value1, String value2) {
            addCriterion("ShipTel not between", value1, value2, "shiptel");
            return (Criteria) this;
        }

        public Criteria andShipnamenoIsNull() {
            addCriterion("ShipNameNo is null");
            return (Criteria) this;
        }

        public Criteria andShipnamenoIsNotNull() {
            addCriterion("ShipNameNo is not null");
            return (Criteria) this;
        }

        public Criteria andShipnamenoEqualTo(String value) {
            addCriterion("ShipNameNo =", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoNotEqualTo(String value) {
            addCriterion("ShipNameNo <>", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoGreaterThan(String value) {
            addCriterion("ShipNameNo >", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoGreaterThanOrEqualTo(String value) {
            addCriterion("ShipNameNo >=", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoLessThan(String value) {
            addCriterion("ShipNameNo <", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoLessThanOrEqualTo(String value) {
            addCriterion("ShipNameNo <=", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoLike(String value) {
            addCriterion("ShipNameNo like", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoNotLike(String value) {
            addCriterion("ShipNameNo not like", value, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoIn(List<String> values) {
            addCriterion("ShipNameNo in", values, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoNotIn(List<String> values) {
            addCriterion("ShipNameNo not in", values, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoBetween(String value1, String value2) {
            addCriterion("ShipNameNo between", value1, value2, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andShipnamenoNotBetween(String value1, String value2) {
            addCriterion("ShipNameNo not between", value1, value2, "shipnameno");
            return (Criteria) this;
        }

        public Criteria andDeliverydateIsNull() {
            addCriterion("DeliveryDate is null");
            return (Criteria) this;
        }

        public Criteria andDeliverydateIsNotNull() {
            addCriterion("DeliveryDate is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverydateEqualTo(Integer value) {
            addCriterion("DeliveryDate =", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateNotEqualTo(Integer value) {
            addCriterion("DeliveryDate <>", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateGreaterThan(Integer value) {
            addCriterion("DeliveryDate >", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateGreaterThanOrEqualTo(Integer value) {
            addCriterion("DeliveryDate >=", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateLessThan(Integer value) {
            addCriterion("DeliveryDate <", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateLessThanOrEqualTo(Integer value) {
            addCriterion("DeliveryDate <=", value, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateIn(List<Integer> values) {
            addCriterion("DeliveryDate in", values, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateNotIn(List<Integer> values) {
            addCriterion("DeliveryDate not in", values, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateBetween(Integer value1, Integer value2) {
            addCriterion("DeliveryDate between", value1, value2, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andDeliverydateNotBetween(Integer value1, Integer value2) {
            addCriterion("DeliveryDate not between", value1, value2, "deliverydate");
            return (Criteria) this;
        }

        public Criteria andOpnameIsNull() {
            addCriterion("OpName is null");
            return (Criteria) this;
        }

        public Criteria andOpnameIsNotNull() {
            addCriterion("OpName is not null");
            return (Criteria) this;
        }

        public Criteria andOpnameEqualTo(String value) {
            addCriterion("OpName =", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameNotEqualTo(String value) {
            addCriterion("OpName <>", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameGreaterThan(String value) {
            addCriterion("OpName >", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameGreaterThanOrEqualTo(String value) {
            addCriterion("OpName >=", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameLessThan(String value) {
            addCriterion("OpName <", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameLessThanOrEqualTo(String value) {
            addCriterion("OpName <=", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameLike(String value) {
            addCriterion("OpName like", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameNotLike(String value) {
            addCriterion("OpName not like", value, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameIn(List<String> values) {
            addCriterion("OpName in", values, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameNotIn(List<String> values) {
            addCriterion("OpName not in", values, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameBetween(String value1, String value2) {
            addCriterion("OpName between", value1, value2, "opname");
            return (Criteria) this;
        }

        public Criteria andOpnameNotBetween(String value1, String value2) {
            addCriterion("OpName not between", value1, value2, "opname");
            return (Criteria) this;
        }

        public Criteria andTbeginIsNull() {
            addCriterion("TBegin is null");
            return (Criteria) this;
        }

        public Criteria andTbeginIsNotNull() {
            addCriterion("TBegin is not null");
            return (Criteria) this;
        }

        public Criteria andTbeginEqualTo(Date value) {
            addCriterion("TBegin =", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginNotEqualTo(Date value) {
            addCriterion("TBegin <>", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginGreaterThan(Date value) {
            addCriterion("TBegin >", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginGreaterThanOrEqualTo(Date value) {
            addCriterion("TBegin >=", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginLessThan(Date value) {
            addCriterion("TBegin <", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginLessThanOrEqualTo(Date value) {
            addCriterion("TBegin <=", value, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginIn(List<Date> values) {
            addCriterion("TBegin in", values, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginNotIn(List<Date> values) {
            addCriterion("TBegin not in", values, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginBetween(Date value1, Date value2) {
            addCriterion("TBegin between", value1, value2, "tbegin");
            return (Criteria) this;
        }

        public Criteria andTbeginNotBetween(Date value1, Date value2) {
            addCriterion("TBegin not between", value1, value2, "tbegin");
            return (Criteria) this;
        }

        public Criteria andReviewstatusIsNull() {
            addCriterion("ReviewStatus is null");
            return (Criteria) this;
        }

        public Criteria andReviewstatusIsNotNull() {
            addCriterion("ReviewStatus is not null");
            return (Criteria) this;
        }

        public Criteria andReviewstatusEqualTo(Integer value) {
            addCriterion("ReviewStatus =", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusNotEqualTo(Integer value) {
            addCriterion("ReviewStatus <>", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusGreaterThan(Integer value) {
            addCriterion("ReviewStatus >", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("ReviewStatus >=", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusLessThan(Integer value) {
            addCriterion("ReviewStatus <", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusLessThanOrEqualTo(Integer value) {
            addCriterion("ReviewStatus <=", value, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusIn(List<Integer> values) {
            addCriterion("ReviewStatus in", values, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusNotIn(List<Integer> values) {
            addCriterion("ReviewStatus not in", values, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusBetween(Integer value1, Integer value2) {
            addCriterion("ReviewStatus between", value1, value2, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andReviewstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("ReviewStatus not between", value1, value2, "reviewstatus");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNull() {
            addCriterion("Disabled is null");
            return (Criteria) this;
        }

        public Criteria andDisabledIsNotNull() {
            addCriterion("Disabled is not null");
            return (Criteria) this;
        }

        public Criteria andDisabledEqualTo(Boolean value) {
            addCriterion("Disabled =", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotEqualTo(Boolean value) {
            addCriterion("Disabled <>", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThan(Boolean value) {
            addCriterion("Disabled >", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledGreaterThanOrEqualTo(Boolean value) {
            addCriterion("Disabled >=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThan(Boolean value) {
            addCriterion("Disabled <", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledLessThanOrEqualTo(Boolean value) {
            addCriterion("Disabled <=", value, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledIn(List<Boolean> values) {
            addCriterion("Disabled in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotIn(List<Boolean> values) {
            addCriterion("Disabled not in", values, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledBetween(Boolean value1, Boolean value2) {
            addCriterion("Disabled between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andDisabledNotBetween(Boolean value1, Boolean value2) {
            addCriterion("Disabled not between", value1, value2, "disabled");
            return (Criteria) this;
        }

        public Criteria andIsthrowingIsNull() {
            addCriterion("IsThrowing is null");
            return (Criteria) this;
        }

        public Criteria andIsthrowingIsNotNull() {
            addCriterion("IsThrowing is not null");
            return (Criteria) this;
        }

        public Criteria andIsthrowingEqualTo(Boolean value) {
            addCriterion("IsThrowing =", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingNotEqualTo(Boolean value) {
            addCriterion("IsThrowing <>", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingGreaterThan(Boolean value) {
            addCriterion("IsThrowing >", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsThrowing >=", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingLessThan(Boolean value) {
            addCriterion("IsThrowing <", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingLessThanOrEqualTo(Boolean value) {
            addCriterion("IsThrowing <=", value, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingIn(List<Boolean> values) {
            addCriterion("IsThrowing in", values, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingNotIn(List<Boolean> values) {
            addCriterion("IsThrowing not in", values, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingBetween(Boolean value1, Boolean value2) {
            addCriterion("IsThrowing between", value1, value2, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andIsthrowingNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsThrowing not between", value1, value2, "isthrowing");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeIsNull() {
            addCriterion("ThrowingTime is null");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeIsNotNull() {
            addCriterion("ThrowingTime is not null");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeEqualTo(Date value) {
            addCriterion("ThrowingTime =", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeNotEqualTo(Date value) {
            addCriterion("ThrowingTime <>", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeGreaterThan(Date value) {
            addCriterion("ThrowingTime >", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ThrowingTime >=", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeLessThan(Date value) {
            addCriterion("ThrowingTime <", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeLessThanOrEqualTo(Date value) {
            addCriterion("ThrowingTime <=", value, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeIn(List<Date> values) {
            addCriterion("ThrowingTime in", values, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeNotIn(List<Date> values) {
            addCriterion("ThrowingTime not in", values, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeBetween(Date value1, Date value2) {
            addCriterion("ThrowingTime between", value1, value2, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingtimeNotBetween(Date value1, Date value2) {
            addCriterion("ThrowingTime not between", value1, value2, "throwingtime");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusIsNull() {
            addCriterion("ThrowingStatus is null");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusIsNotNull() {
            addCriterion("ThrowingStatus is not null");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusEqualTo(Integer value) {
            addCriterion("ThrowingStatus =", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusNotEqualTo(Integer value) {
            addCriterion("ThrowingStatus <>", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusGreaterThan(Integer value) {
            addCriterion("ThrowingStatus >", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("ThrowingStatus >=", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusLessThan(Integer value) {
            addCriterion("ThrowingStatus <", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusLessThanOrEqualTo(Integer value) {
            addCriterion("ThrowingStatus <=", value, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusIn(List<Integer> values) {
            addCriterion("ThrowingStatus in", values, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusNotIn(List<Integer> values) {
            addCriterion("ThrowingStatus not in", values, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusBetween(Integer value1, Integer value2) {
            addCriterion("ThrowingStatus between", value1, value2, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andThrowingstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("ThrowingStatus not between", value1, value2, "throwingstatus");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeIsNull() {
            addCriterion("VerificationTime is null");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeIsNotNull() {
            addCriterion("VerificationTime is not null");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeEqualTo(Date value) {
            addCriterion("VerificationTime =", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeNotEqualTo(Date value) {
            addCriterion("VerificationTime <>", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeGreaterThan(Date value) {
            addCriterion("VerificationTime >", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("VerificationTime >=", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeLessThan(Date value) {
            addCriterion("VerificationTime <", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeLessThanOrEqualTo(Date value) {
            addCriterion("VerificationTime <=", value, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeIn(List<Date> values) {
            addCriterion("VerificationTime in", values, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeNotIn(List<Date> values) {
            addCriterion("VerificationTime not in", values, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeBetween(Date value1, Date value2) {
            addCriterion("VerificationTime between", value1, value2, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andVerificationtimeNotBetween(Date value1, Date value2) {
            addCriterion("VerificationTime not between", value1, value2, "verificationtime");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateIsNull() {
            addCriterion("FactoryDeliveryDate is null");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateIsNotNull() {
            addCriterion("FactoryDeliveryDate is not null");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateEqualTo(Date value) {
            addCriterion("FactoryDeliveryDate =", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateNotEqualTo(Date value) {
            addCriterion("FactoryDeliveryDate <>", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateGreaterThan(Date value) {
            addCriterion("FactoryDeliveryDate >", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateGreaterThanOrEqualTo(Date value) {
            addCriterion("FactoryDeliveryDate >=", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateLessThan(Date value) {
            addCriterion("FactoryDeliveryDate <", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateLessThanOrEqualTo(Date value) {
            addCriterion("FactoryDeliveryDate <=", value, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateIn(List<Date> values) {
            addCriterion("FactoryDeliveryDate in", values, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateNotIn(List<Date> values) {
            addCriterion("FactoryDeliveryDate not in", values, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateBetween(Date value1, Date value2) {
            addCriterion("FactoryDeliveryDate between", value1, value2, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andFactorydeliverydateNotBetween(Date value1, Date value2) {
            addCriterion("FactoryDeliveryDate not between", value1, value2, "factorydeliverydate");
            return (Criteria) this;
        }

        public Criteria andIsqualityIsNull() {
            addCriterion("IsQuality is null");
            return (Criteria) this;
        }

        public Criteria andIsqualityIsNotNull() {
            addCriterion("IsQuality is not null");
            return (Criteria) this;
        }

        public Criteria andIsqualityEqualTo(Boolean value) {
            addCriterion("IsQuality =", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityNotEqualTo(Boolean value) {
            addCriterion("IsQuality <>", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityGreaterThan(Boolean value) {
            addCriterion("IsQuality >", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsQuality >=", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityLessThan(Boolean value) {
            addCriterion("IsQuality <", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityLessThanOrEqualTo(Boolean value) {
            addCriterion("IsQuality <=", value, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityIn(List<Boolean> values) {
            addCriterion("IsQuality in", values, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityNotIn(List<Boolean> values) {
            addCriterion("IsQuality not in", values, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQuality between", value1, value2, "isquality");
            return (Criteria) this;
        }

        public Criteria andIsqualityNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQuality not between", value1, value2, "isquality");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyIsNull() {
            addCriterion("AdvanceFreightMoney is null");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyIsNotNull() {
            addCriterion("AdvanceFreightMoney is not null");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreightMoney =", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyNotEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreightMoney <>", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyGreaterThan(BigDecimal value) {
            addCriterion("AdvanceFreightMoney >", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreightMoney >=", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyLessThan(BigDecimal value) {
            addCriterion("AdvanceFreightMoney <", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("AdvanceFreightMoney <=", value, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyIn(List<BigDecimal> values) {
            addCriterion("AdvanceFreightMoney in", values, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyNotIn(List<BigDecimal> values) {
            addCriterion("AdvanceFreightMoney not in", values, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AdvanceFreightMoney between", value1, value2, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andAdvancefreightmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AdvanceFreightMoney not between", value1, value2, "advancefreightmoney");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsIsNull() {
            addCriterion("IsDistributeLeaflets is null");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsIsNotNull() {
            addCriterion("IsDistributeLeaflets is not null");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsEqualTo(Boolean value) {
            addCriterion("IsDistributeLeaflets =", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsNotEqualTo(Boolean value) {
            addCriterion("IsDistributeLeaflets <>", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsGreaterThan(Boolean value) {
            addCriterion("IsDistributeLeaflets >", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsDistributeLeaflets >=", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsLessThan(Boolean value) {
            addCriterion("IsDistributeLeaflets <", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsLessThanOrEqualTo(Boolean value) {
            addCriterion("IsDistributeLeaflets <=", value, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsIn(List<Boolean> values) {
            addCriterion("IsDistributeLeaflets in", values, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsNotIn(List<Boolean> values) {
            addCriterion("IsDistributeLeaflets not in", values, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDistributeLeaflets between", value1, value2, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andIsdistributeleafletsNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDistributeLeaflets not between", value1, value2, "isdistributeleaflets");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeIsNull() {
            addCriterion("SwitchCreateTime is null");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeIsNotNull() {
            addCriterion("SwitchCreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeEqualTo(Date value) {
            addCriterion("SwitchCreateTime =", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeNotEqualTo(Date value) {
            addCriterion("SwitchCreateTime <>", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeGreaterThan(Date value) {
            addCriterion("SwitchCreateTime >", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("SwitchCreateTime >=", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeLessThan(Date value) {
            addCriterion("SwitchCreateTime <", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("SwitchCreateTime <=", value, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeIn(List<Date> values) {
            addCriterion("SwitchCreateTime in", values, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeNotIn(List<Date> values) {
            addCriterion("SwitchCreateTime not in", values, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeBetween(Date value1, Date value2) {
            addCriterion("SwitchCreateTime between", value1, value2, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andSwitchcreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("SwitchCreateTime not between", value1, value2, "switchcreatetime");
            return (Criteria) this;
        }

        public Criteria andIsrevokedIsNull() {
            addCriterion("IsRevoked is null");
            return (Criteria) this;
        }

        public Criteria andIsrevokedIsNotNull() {
            addCriterion("IsRevoked is not null");
            return (Criteria) this;
        }

        public Criteria andIsrevokedEqualTo(Boolean value) {
            addCriterion("IsRevoked =", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedNotEqualTo(Boolean value) {
            addCriterion("IsRevoked <>", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedGreaterThan(Boolean value) {
            addCriterion("IsRevoked >", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsRevoked >=", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedLessThan(Boolean value) {
            addCriterion("IsRevoked <", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedLessThanOrEqualTo(Boolean value) {
            addCriterion("IsRevoked <=", value, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedIn(List<Boolean> values) {
            addCriterion("IsRevoked in", values, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedNotIn(List<Boolean> values) {
            addCriterion("IsRevoked not in", values, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedBetween(Boolean value1, Boolean value2) {
            addCriterion("IsRevoked between", value1, value2, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andIsrevokedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsRevoked not between", value1, value2, "isrevoked");
            return (Criteria) this;
        }

        public Criteria andSenddateIsNull() {
            addCriterion("SendDate is null");
            return (Criteria) this;
        }

        public Criteria andSenddateIsNotNull() {
            addCriterion("SendDate is not null");
            return (Criteria) this;
        }

        public Criteria andSenddateEqualTo(Date value) {
            addCriterion("SendDate =", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotEqualTo(Date value) {
            addCriterion("SendDate <>", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateGreaterThan(Date value) {
            addCriterion("SendDate >", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateGreaterThanOrEqualTo(Date value) {
            addCriterion("SendDate >=", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateLessThan(Date value) {
            addCriterion("SendDate <", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateLessThanOrEqualTo(Date value) {
            addCriterion("SendDate <=", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateIn(List<Date> values) {
            addCriterion("SendDate in", values, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotIn(List<Date> values) {
            addCriterion("SendDate not in", values, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateBetween(Date value1, Date value2) {
            addCriterion("SendDate between", value1, value2, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotBetween(Date value1, Date value2) {
            addCriterion("SendDate not between", value1, value2, "senddate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateIsNull() {
            addCriterion("ExceptionDate is null");
            return (Criteria) this;
        }

        public Criteria andExceptiondateIsNotNull() {
            addCriterion("ExceptionDate is not null");
            return (Criteria) this;
        }

        public Criteria andExceptiondateEqualTo(Date value) {
            addCriterion("ExceptionDate =", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateNotEqualTo(Date value) {
            addCriterion("ExceptionDate <>", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateGreaterThan(Date value) {
            addCriterion("ExceptionDate >", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateGreaterThanOrEqualTo(Date value) {
            addCriterion("ExceptionDate >=", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateLessThan(Date value) {
            addCriterion("ExceptionDate <", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateLessThanOrEqualTo(Date value) {
            addCriterion("ExceptionDate <=", value, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateIn(List<Date> values) {
            addCriterion("ExceptionDate in", values, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateNotIn(List<Date> values) {
            addCriterion("ExceptionDate not in", values, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateBetween(Date value1, Date value2) {
            addCriterion("ExceptionDate between", value1, value2, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andExceptiondateNotBetween(Date value1, Date value2) {
            addCriterion("ExceptionDate not between", value1, value2, "exceptiondate");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}