package com.lenovo.m2.web.domain.my.newdb;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by lzg on 2016/8/7.
 */
public class OrderLogistics implements Serializable {

    private long id;

    private long orderId;

    private String shipStatus;

    private String logisticsNo;

    private String logisticsCompanyName;

    private String logisticsCompanyCode;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;

    private String createBy;

    private String updateBy;

    private Main main;

    private List<LogisticTrack> logisticTracks;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public String getShipStatus() {
        return shipStatus;
    }

    public void setShipStatus(String shipStatus) {
        this.shipStatus = shipStatus;
    }

    public String getLogisticsNo() {
        return logisticsNo;
    }

    public void setLogisticsNo(String logisticsNo) {
        this.logisticsNo = logisticsNo;
    }

    public String getLogisticsCompanyName() {
        return logisticsCompanyName;
    }

    public void setLogisticsCompanyName(String logisticsCompanyName) {
        this.logisticsCompanyName = logisticsCompanyName;
    }

    public String getLogisticsCompanyCode() {
        return logisticsCompanyCode;
    }

    public void setLogisticsCompanyCode(String logisticsCompanyCode) {
        this.logisticsCompanyCode = logisticsCompanyCode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public List<LogisticTrack> getLogisticTracks() {
        return logisticTracks;
    }

    public void setLogisticTracks(List<LogisticTrack> logisticTracks) {
        this.logisticTracks = logisticTracks;
    }


    public String toString() {
        return "OrderLogistics{" +
                "id=" + id +
                ",orderId='" + orderId +
                ",shipStatus='" + shipStatus +
                ",logisticsNo='" + logisticsNo +
                ",logisticsCompanyName='" + logisticsCompanyName +
                ",logisticsCompanyCode='" + logisticsCompanyCode +
                ",createTime='" + createTime +
                ",updateTime='" + updateTime +
                ",createBy='" + createBy +
                ",updateBy='" + updateBy +
                '}';
    }
}
