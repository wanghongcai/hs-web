package com.lenovo.m2.web.domain.purchase.promotion;

/**
 * Created by jack on 2015/8/26.
 */
public class CodeAndDiscount {

    private String code;
    private String discount;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
}
