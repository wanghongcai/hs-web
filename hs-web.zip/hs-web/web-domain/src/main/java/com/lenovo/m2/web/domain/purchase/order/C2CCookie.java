package com.lenovo.m2.web.domain.purchase.order;

/**
 * Created by D_xiao on 2017/4/19.
 *
 */
public class C2CCookie {
    private String promotionName;
    private String promotionType;
    private String promotionChannels;
    private String memberId;
    private String type;


    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getPromotionChannels() {
        return promotionChannels;
    }

    public void setPromotionChannels(String promotionChannels) {
        this.promotionChannels = promotionChannels;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
