package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;
import java.util.Date;

public class OrderProducts implements Serializable {
    private String id;

    private String orderid;

    private String deliveryid;

    private String productcode;

    private String productid;

    private String productname;

    private String typeid;

    private String typename;

    private String unit;

    private String factorycode;

    private String warehousecode;

    private String storagecode;

    private Integer productnumber;

    private Money productpay;

    private Money favourablepay;

    private Money volumepay;

    private Money paysubtotal;

    private Money discountrate;

    private Integer productcredit;

    private Integer changestatus;

    private Integer changecount;

    private Integer isgift;

    private String groupingid;

    private String goodsmaterialid;

    private Integer salestype;

    private Integer isphysical;

    private Integer isserviceprod;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    private String ordermainId;

    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getDeliveryid() {
        return deliveryid;
    }

    public void setDeliveryid(String deliveryid) {
        this.deliveryid = deliveryid;
    }

    public String getProductcode() {
        return productcode;
    }

    public void setProductcode(String productcode) {
        this.productcode = productcode;
    }

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getTypename() {
        return typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getFactorycode() {
        return factorycode;
    }

    public void setFactorycode(String factorycode) {
        this.factorycode = factorycode;
    }

    public String getWarehousecode() {
        return warehousecode;
    }

    public void setWarehousecode(String warehousecode) {
        this.warehousecode = warehousecode;
    }

    public String getStoragecode() {
        return storagecode;
    }

    public void setStoragecode(String storagecode) {
        this.storagecode = storagecode;
    }

    public Integer getProductnumber() {
        return productnumber;
    }

    public void setProductnumber(Integer productnumber) {
        this.productnumber = productnumber;
    }

    public Money getProductpay() {
        return productpay;
    }

    public void setProductpay(Money productpay) {
        this.productpay = productpay;
    }

    public Money getFavourablepay() {
        return favourablepay;
    }

    public void setFavourablepay(Money favourablepay) {
        this.favourablepay = favourablepay;
    }

    public Money getVolumepay() {
        return volumepay;
    }

    public void setVolumepay(Money volumepay) {
        this.volumepay = volumepay;
    }

    public Money getPaysubtotal() {
        return paysubtotal;
    }

    public void setPaysubtotal(Money paysubtotal) {
        this.paysubtotal = paysubtotal;
    }

    public Money getDiscountrate() {
        return discountrate;
    }

    public void setDiscountrate(Money discountrate) {
        this.discountrate = discountrate;
    }

    public Integer getProductcredit() {
        return productcredit;
    }

    public void setProductcredit(Integer productcredit) {
        this.productcredit = productcredit;
    }

    public Integer getChangestatus() {
        return changestatus;
    }

    public void setChangestatus(Integer changestatus) {
        this.changestatus = changestatus;
    }

    public Integer getChangecount() {
        return changecount;
    }

    public void setChangecount(Integer changecount) {
        this.changecount = changecount;
    }

    public Integer getIsgift() {
        return isgift;
    }

    public void setIsgift(Integer isgift) {
        this.isgift = isgift;
    }

    public String getGroupingid() {
        return groupingid;
    }

    public void setGroupingid(String groupingid) {
        this.groupingid = groupingid;
    }

    public String getGoodsmaterialid() {
        return goodsmaterialid;
    }

    public void setGoodsmaterialid(String goodsmaterialid) {
        this.goodsmaterialid = goodsmaterialid;
    }

    public Integer getSalestype() {
        return salestype;
    }

    public void setSalestype(Integer salestype) {
        this.salestype = salestype;
    }

    public Integer getIsphysical() {
        return isphysical;
    }

    public void setIsphysical(Integer isphysical) {
        this.isphysical = isphysical;
    }

    public Integer getIsserviceprod() {
        return isserviceprod;
    }

    public void setIsserviceprod(Integer isserviceprod) {
        this.isserviceprod = isserviceprod;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public String getOrdermainId() {
        return ordermainId;
    }

    public void setOrdermainId(String ordermainId) {
        this.ordermainId = ordermainId;
    }
}