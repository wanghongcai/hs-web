package com.lenovo.m2.web.domain.my.order.smb;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.web.domain.my.order.*;

import java.io.Serializable;
import java.util.List;

/**
 * 订单详情
 * Created by jiangzh5 on 2015/8/7.
 */
public class SmbDetail extends SmbOrderDetail implements Serializable {

    private String takepersonaddr;//收货人地址
    private String takepersonmobile;//收货人手机号码
    private String takepersonemail;//收货人邮箱
    private String markText;//备注信息
    private String invoiceType;//发票类型
    private String invoiceHeader;//发票抬头
    private String invoiceContent;//发票内容
    private Money tranmoney;//运费
    private Money discount;//优惠价格
    private Money coupon;//优惠券价格
    private Money costitem;//订单金额
    private Money ordermoney;    //订单商品总金额
    private List<OrderPay> plist; //支付列表（目前二期中只有一条记录）
    private PreferredPayment preferredPayment;//优惠信息
    private List<OrderLogisticDesc> ollist;//物流信息
    private Receiver receiver;//接收人详细信息
    private String memberid;
    private String cancelTime;//订单取消时间
    private String waitReceiptDate;//等待收货
    private Money usedLeDouNum;//使用的乐豆
    private Money giveawayTotal;//优惠总金额
    private List<Accessory> cvItems;//cto 新增cv配置信息
    private String rreceiptDate;//签收时间
    private String  lenovoId;
    //y910 lenovomake 新增字段

    //封装参数
    private String  orderTime;
    private String payTime;

    public String getTakepersonaddr() {
        return takepersonaddr;
    }

    public void setTakepersonaddr(String takepersonaddr) {
        this.takepersonaddr = takepersonaddr;
    }

    public String getTakepersonmobile() {
        return takepersonmobile;
    }

    public void setTakepersonmobile(String takepersonmobile) {
        this.takepersonmobile = takepersonmobile;
    }

    public String getTakepersonemail() {
        return takepersonemail;
    }

    public void setTakepersonemail(String takepersonemail) {
        this.takepersonemail = takepersonemail;
    }

    public String getMarkText() {
        return markText;
    }

    public void setMarkText(String markText) {
        this.markText = markText;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getInvoiceHeader() {
        return invoiceHeader;
    }

    public void setInvoiceHeader(String invoiceHeader) {
        this.invoiceHeader = invoiceHeader;
    }

    public String getInvoiceContent() {
        return invoiceContent;
    }

    public void setInvoiceContent(String invoiceContent) {
        this.invoiceContent = invoiceContent;
    }

    public Money getTranmoney() {
        return tranmoney;
    }

    public void setTranmoney(Money tranmoney) {
        this.tranmoney = tranmoney;
    }

    public Money getDiscount() {
        return discount;
    }

    public void setDiscount(Money discount) {
        this.discount = discount;
    }

    public Money getCoupon() {
        return coupon;
    }

    public void setCoupon(Money coupon) {
        this.coupon = coupon;
    }

    public Money getCostitem() {
        return costitem;
    }

    public void setCostitem(Money costitem) {
        this.costitem = costitem;
    }

    public Money getOrdermoney() {
        return ordermoney;
    }

    public void setOrdermoney(Money ordermoney) {
        this.ordermoney = ordermoney;
    }

    public List<OrderPay> getPlist() {
        return plist;
    }

    public void setPlist(List<OrderPay> plist) {
        this.plist = plist;
    }

    public PreferredPayment getPreferredPayment() {
        return preferredPayment;
    }

    public void setPreferredPayment(PreferredPayment preferredPayment) {
        this.preferredPayment = preferredPayment;
    }

    public List<OrderLogisticDesc> getOllist() {
        return ollist;
    }

    public void setOllist(List<OrderLogisticDesc> ollist) {
        this.ollist = ollist;
    }

    public Receiver getReceiver() {
        return receiver;
    }

    public void setReceiver(Receiver receiver) {
        this.receiver = receiver;
    }

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getWaitReceiptDate() {
        return waitReceiptDate;
    }

    public void setWaitReceiptDate(String waitReceiptDate) {
        this.waitReceiptDate = waitReceiptDate;
    }

    public Money getUsedLeDouNum() {
        return usedLeDouNum;
    }

    public void setUsedLeDouNum(Money usedLeDouNum) {
        this.usedLeDouNum = usedLeDouNum;
    }

    public Money getGiveawayTotal() {
        return giveawayTotal;
    }

    public void setGiveawayTotal(Money giveawayTotal) {
        this.giveawayTotal = giveawayTotal;
    }

    public List<Accessory> getCvItems() {
        return cvItems;
    }

    public void setCvItems(List<Accessory> cvItems) {
        this.cvItems = cvItems;
    }

    public String getRreceiptDate() {
        return rreceiptDate;
    }

    public void setRreceiptDate(String rreceiptDate) {
        this.rreceiptDate = rreceiptDate;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }
}
