package com.lenovo.m2.web.domain.purchase.order;

import com.lenovo.m2.hsbuy.domain.purchase.param.OrderInvoiceVo;

/**
 *
 * @ClassName: TempInvoice
 * @Description: 临时发票
 * @author yuzj7@lenovo.com
 * @date 2015年6月27日 上午11:20:31
 *
 */
public class TempInvoice extends OrderInvoiceVo {

    /**
     * @Fields serialVersionUID : (用一句话描述这个变量表示什么)
     */
    private static final long serialVersionUID = 1L;

    private String memberid;//会员信息
    private String createTime;//创建时间
    //发票id
    private String vatInvoiceId;
    private String payerType; //0 个人，1 公司
    private String payerContent;//付款方名称
    
    private Boolean payerSure;//个人开票时是否确认
    
    
    
    
    
    
    
    
    
    public Boolean isPayerSure() {
		return payerSure;
	}
	public void setPayerSure(Boolean payerSure) {
		this.payerSure = payerSure;
	}
	public String getPayerType() {
		return payerType;
	}
	public void setPayerType(String payerType) {
		this.payerType = payerType;
	}
	public String getPayerContent() {
		return payerContent;
	}
	public void setPayerContent(String payerContent) {
		this.payerContent = payerContent;
	}
	public String getVatInvoiceId() {
		return vatInvoiceId;
	}
	public void setVatInvoiceId(String vatInvoiceId) {
		this.vatInvoiceId = vatInvoiceId;
	}
	public String getMemberid() {
        return memberid;
    }
    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }
    public String getCreateTime() {
        return createTime;
    }
    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }


}
