package com.lenovo.m2.web.domain.my.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by jiangzh5 on 2015/7/28.
 */
public class OrderExample {

    protected String orderByClause;

    //空或null：（默认）全部 商品编号/商品名称/订单编号
    protected String searchtext;

    public String getSearchtext() {
        return searchtext;
    }

    public void setSearchtext(String searchtext) {
        this.searchtext = searchtext;
    }

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private int pageIndex;

    private int pageSize;

    public OrderExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex=pageIndex;
    }

    public int getPageIndex() {
        return this.pageIndex;
    }

    public void setPageSize(int pageSize) {
        this.pageSize=pageSize;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public OrderExample(int pageIndex, int pageSize) {
        this();
        this.pageIndex=pageIndex;
        this.pageSize=pageSize;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSourceIsNull() {
            addCriterion("Source is null");
            return (Criteria) this;
        }

        public Criteria andSourceIsNotNull() {
            addCriterion("Source is not null");
            return (Criteria) this;
        }

        public Criteria andSourceEqualTo(Integer value) {
            addCriterion("Source =", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotEqualTo(Integer value) {
            addCriterion("Source <>", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThan(Integer value) {
            addCriterion("Source >", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThanOrEqualTo(Integer value) {
            addCriterion("Source >=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThan(Integer value) {
            addCriterion("Source <", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThanOrEqualTo(Integer value) {
            addCriterion("Source <=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceIn(List<Integer> values) {
            addCriterion("Source in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotIn(List<Integer> values) {
            addCriterion("Source not in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceBetween(Integer value1, Integer value2) {
            addCriterion("Source between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotBetween(Integer value1, Integer value2) {
            addCriterion("Source not between", value1, value2, "source");
            return (Criteria) this;
        }
        public Criteria andMerchantIdIsNull() {
            addCriterion("ShopId is null");
            return (Criteria) this;
        }

        public Criteria andMerchantIdIsNotNull() {
            addCriterion("ShopId is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantIdEqualTo(Integer value) {
            addCriterion("o.ShopId =", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotEqualTo(Integer value) {
            addCriterion("ShopId <>", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdGreaterThan(Integer value) {
            addCriterion("ShopId >", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ShopId >=", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdLessThan(Integer value) {
            addCriterion("ShopId <", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdLessThanOrEqualTo(Integer value) {
            addCriterion("ShopId <=", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdIn(List<Integer> values) {
            addCriterion("ShopId in", values, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotIn(List<Integer> values) {
            addCriterion("ShopId not in", values, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdBetween(Integer value1, Integer value2) {
            addCriterion("ShopId between", value1, value2, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ShopId not between", value1, value2, "merchantid");
            return (Criteria) this;
        }
        public Criteria andPayordernoIsNull() {
            addCriterion("BankTraceNo is null");
            return (Criteria) this;
        }

        public Criteria andPayordernoIsNotNull() {
            addCriterion("BankTraceNo is not null");
            return (Criteria) this;
        }

        public Criteria andPayordernoEqualTo(String value) {
            addCriterion("BankTraceNo =", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotEqualTo(String value) {
            addCriterion("BankTraceNo <>", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoGreaterThan(String value) {
            addCriterion("BankTraceNo >", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoGreaterThanOrEqualTo(String value) {
            addCriterion("BankTraceNo >=", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLessThan(String value) {
            addCriterion("BankTraceNo <", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLessThanOrEqualTo(String value) {
            addCriterion("BankTraceNo <=", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLike(String value) {
            addCriterion("BankTraceNo like", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotLike(String value) {
            addCriterion("BankTraceNo not like", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoIn(List<String> values) {
            addCriterion("BankTraceNo in", values, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotIn(List<String> values) {
            addCriterion("BankTraceNo not in", values, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoBetween(String value1, String value2) {
            addCriterion("BankTraceNo between", value1, value2, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotBetween(String value1, String value2) {
            addCriterion("BankTraceNo not between", value1, value2, "payorderno");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIsNull() {
            addCriterion("ParentId is null");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIsNotNull() {
            addCriterion("ParentId is not null");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeEqualTo(String value) {
            addCriterion("ParentId =", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotEqualTo(String value) {
            addCriterion("ParentId <>", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeGreaterThan(String value) {
            addCriterion("ParentId >", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeGreaterThanOrEqualTo(String value) {
            addCriterion("ParentId >=", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLessThan(String value) {
            addCriterion("ParentId <", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLessThanOrEqualTo(String value) {
            addCriterion("ParentId <=", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLike(String value) {
            addCriterion("ParentId like", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotLike(String value) {
            addCriterion("ParentId not like", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIn(List<String> values) {
            addCriterion("ParentId in", values, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotIn(List<String> values) {
            addCriterion("ParentId not in", values, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeBetween(String value1, String value2) {
            addCriterion("ParentId between", value1, value2, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotBetween(String value1, String value2) {
            addCriterion("ParentId not between", value1, value2, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrdercodeEqualTo(String value) {
            addCriterion("ID =", value, "ID");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotEqualTo(String value) {
            addCriterion("ID <>", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeGreaterThan(String value) {
            addCriterion("ID >", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLessThan(String value) {
            addCriterion("ID <", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLike(String value) {
            addCriterion("ID like", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotLike(String value) {
            addCriterion("ID not like", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIn(List<String> values) {
            addCriterion("ID in", values, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotIn(List<String> values) {
            addCriterion("ID not in", values, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "ordercode");
            return (Criteria) this;
        }

        public Criteria andVkorgIsNull() {
            addCriterion("Vkorg is null");
            return (Criteria) this;
        }

        public Criteria andVkorgIsNotNull() {
            addCriterion("Vkorg is not null");
            return (Criteria) this;
        }

        public Criteria andVkorgEqualTo(String value) {
            addCriterion("Vkorg =", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotEqualTo(String value) {
            addCriterion("Vkorg <>", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgGreaterThan(String value) {
            addCriterion("Vkorg >", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgGreaterThanOrEqualTo(String value) {
            addCriterion("Vkorg >=", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLessThan(String value) {
            addCriterion("Vkorg <", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLessThanOrEqualTo(String value) {
            addCriterion("Vkorg <=", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLike(String value) {
            addCriterion("Vkorg like", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotLike(String value) {
            addCriterion("Vkorg not like", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgIn(List<String> values) {
            addCriterion("Vkorg in", values, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotIn(List<String> values) {
            addCriterion("Vkorg not in", values, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgBetween(String value1, String value2) {
            addCriterion("Vkorg between", value1, value2, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotBetween(String value1, String value2) {
            addCriterion("Vkorg not between", value1, value2, "vkorg");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIsNull() {
            addCriterion("SalesChannel is null");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIsNotNull() {
            addCriterion("SalesChannel is not null");
            return (Criteria) this;
        }

        public Criteria andSaleschannelEqualTo(String value) {
            addCriterion("SalesChannel =", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotEqualTo(String value) {
            addCriterion("SalesChannel <>", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelGreaterThan(String value) {
            addCriterion("SalesChannel >", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelGreaterThanOrEqualTo(String value) {
            addCriterion("SalesChannel >=", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLessThan(String value) {
            addCriterion("SalesChannel <", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLessThanOrEqualTo(String value) {
            addCriterion("SalesChannel <=", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLike(String value) {
            addCriterion("SalesChannel like", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotLike(String value) {
            addCriterion("SalesChannel not like", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIn(List<String> values) {
            addCriterion("SalesChannel in", values, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotIn(List<String> values) {
            addCriterion("SalesChannel not in", values, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelBetween(String value1, String value2) {
            addCriterion("SalesChannel between", value1, value2, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotBetween(String value1, String value2) {
            addCriterion("SalesChannel not between", value1, value2, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andMemberidIsNull() {
            addCriterion("MemberID is null");
            return (Criteria) this;
        }

        public Criteria andMemberidIsNotNull() {
            addCriterion("MemberID is not null");
            return (Criteria) this;
        }

        public Criteria andMemberidEqualTo(String value) {
            addCriterion("MemberID =", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andLenovoIdEqualTo(String value) {
            addCriterion("LenovoID =", value, "lenovoId");
            return (Criteria) this;
        }

        public Criteria andMemberidNotEqualTo(String value) {
            addCriterion("MemberID <>", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidGreaterThan(String value) {
            addCriterion("MemberID >", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidGreaterThanOrEqualTo(String value) {
            addCriterion("MemberID >=", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLessThan(String value) {
            addCriterion("MemberID <", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLessThanOrEqualTo(String value) {
            addCriterion("MemberID <=", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLike(String value) {
            addCriterion("MemberID like", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotLike(String value) {
            addCriterion("MemberID not like", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidIn(List<String> values) {
            addCriterion("MemberID in", values, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotIn(List<String> values) {
            addCriterion("MemberID not in", values, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidBetween(String value1, String value2) {
            addCriterion("MemberID between", value1, value2, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotBetween(String value1, String value2) {
            addCriterion("MemberID not between", value1, value2, "memberid");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNull() {
            addCriterion("MemberCode is null");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNotNull() {
            addCriterion("MemberCode is not null");
            return (Criteria) this;
        }

        public Criteria andMembercodeEqualTo(String value) {
            addCriterion("MemberCode =", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotEqualTo(String value) {
            addCriterion("MemberCode <>", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThan(String value) {
            addCriterion("MemberCode >", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThanOrEqualTo(String value) {
            addCriterion("MemberCode >=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThan(String value) {
            addCriterion("MemberCode <", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThanOrEqualTo(String value) {
            addCriterion("MemberCode <=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLike(String value) {
            addCriterion("MemberCode like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotLike(String value) {
            addCriterion("MemberCode not like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeIn(List<String> values) {
            addCriterion("MemberCode in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotIn(List<String> values) {
            addCriterion("MemberCode not in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeBetween(String value1, String value2) {
            addCriterion("MemberCode between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotBetween(String value1, String value2) {
            addCriterion("MemberCode not between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNull() {
            addCriterion("TypeID is null");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNotNull() {
            addCriterion("TypeID is not null");
            return (Criteria) this;
        }

        public Criteria andTypeidEqualTo(String value) {
            addCriterion("TypeID =", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotEqualTo(String value) {
            addCriterion("TypeID <>", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThan(String value) {
            addCriterion("TypeID >", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThanOrEqualTo(String value) {
            addCriterion("TypeID >=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThan(String value) {
            addCriterion("TypeID <", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThanOrEqualTo(String value) {
            addCriterion("TypeID <=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLike(String value) {
            addCriterion("TypeID like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotLike(String value) {
            addCriterion("TypeID not like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidIn(List<String> values) {
            addCriterion("TypeID in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotIn(List<String> values) {
            addCriterion("TypeID not in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidBetween(String value1, String value2) {
            addCriterion("TypeID between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotBetween(String value1, String value2) {
            addCriterion("TypeID not between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andCostitemIsNull() {
            addCriterion("CostItem is null");
            return (Criteria) this;
        }

        public Criteria andCostitemIsNotNull() {
            addCriterion("CostItem is not null");
            return (Criteria) this;
        }

        public Criteria andCostitemEqualTo(BigDecimal value) {
            addCriterion("CostItem =", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotEqualTo(BigDecimal value) {
            addCriterion("CostItem <>", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemGreaterThan(BigDecimal value) {
            addCriterion("CostItem >", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("CostItem >=", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemLessThan(BigDecimal value) {
            addCriterion("CostItem <", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemLessThanOrEqualTo(BigDecimal value) {
            addCriterion("CostItem <=", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemIn(List<BigDecimal> values) {
            addCriterion("CostItem in", values, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotIn(List<BigDecimal> values) {
            addCriterion("CostItem not in", values, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CostItem between", value1, value2, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CostItem not between", value1, value2, "costitem");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIsNull() {
            addCriterion("AmountMoney is null");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIsNotNull() {
            addCriterion("AmountMoney is not null");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyEqualTo(BigDecimal value) {
            addCriterion("AmountMoney =", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotEqualTo(BigDecimal value) {
            addCriterion("AmountMoney <>", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyGreaterThan(BigDecimal value) {
            addCriterion("AmountMoney >", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("AmountMoney >=", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyLessThan(BigDecimal value) {
            addCriterion("AmountMoney <", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("AmountMoney <=", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIn(List<BigDecimal> values) {
            addCriterion("AmountMoney in", values, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotIn(List<BigDecimal> values) {
            addCriterion("AmountMoney not in", values, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AmountMoney between", value1, value2, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AmountMoney not between", value1, value2, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIsNull() {
            addCriterion("GiveawayCost is null");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIsNotNull() {
            addCriterion("GiveawayCost is not null");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost =", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost <>", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostGreaterThan(BigDecimal value) {
            addCriterion("GiveawayCost >", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost >=", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostLessThan(BigDecimal value) {
            addCriterion("GiveawayCost <", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost <=", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIn(List<BigDecimal> values) {
            addCriterion("GiveawayCost in", values, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotIn(List<BigDecimal> values) {
            addCriterion("GiveawayCost not in", values, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayCost between", value1, value2, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayCost not between", value1, value2, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIsNull() {
            addCriterion("GiveawayTotal is null");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIsNotNull() {
            addCriterion("GiveawayTotal is not null");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal =", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal <>", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalGreaterThan(BigDecimal value) {
            addCriterion("GiveawayTotal >", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal >=", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalLessThan(BigDecimal value) {
            addCriterion("GiveawayTotal <", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal <=", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIn(List<BigDecimal> values) {
            addCriterion("GiveawayTotal in", values, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotIn(List<BigDecimal> values) {
            addCriterion("GiveawayTotal not in", values, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayTotal between", value1, value2, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayTotal not between", value1, value2, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalIsNull() {
            addCriterion("CreditTotal is null");
            return (Criteria) this;
        }

        public Criteria andCredittotalIsNotNull() {
            addCriterion("CreditTotal is not null");
            return (Criteria) this;
        }

        public Criteria andCredittotalEqualTo(Integer value) {
            addCriterion("CreditTotal =", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotEqualTo(Integer value) {
            addCriterion("CreditTotal <>", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalGreaterThan(Integer value) {
            addCriterion("CreditTotal >", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalGreaterThanOrEqualTo(Integer value) {
            addCriterion("CreditTotal >=", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalLessThan(Integer value) {
            addCriterion("CreditTotal <", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalLessThanOrEqualTo(Integer value) {
            addCriterion("CreditTotal <=", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalIn(List<Integer> values) {
            addCriterion("CreditTotal in", values, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotIn(List<Integer> values) {
            addCriterion("CreditTotal not in", values, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalBetween(Integer value1, Integer value2) {
            addCriterion("CreditTotal between", value1, value2, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotBetween(Integer value1, Integer value2) {
            addCriterion("CreditTotal not between", value1, value2, "credittotal");
            return (Criteria) this;
        }

        public Criteria andPaystatusIsNull() {
            addCriterion("PayStatus is null");
            return (Criteria) this;
        }

        public Criteria andPaystatusIsNotNull() {
            addCriterion("PayStatus is not null");
            return (Criteria) this;
        }

        public Criteria andPaystatusEqualTo(Integer value) {
            addCriterion("PayStatus =", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotEqualTo(Integer value) {
            addCriterion("PayStatus <>", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusGreaterThan(Integer value) {
            addCriterion("PayStatus >", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("PayStatus >=", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusLessThan(Integer value) {
            addCriterion("PayStatus <", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusLessThanOrEqualTo(Integer value) {
            addCriterion("PayStatus <=", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusIn(List<Integer> values) {
            addCriterion("PayStatus in", values, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotIn(List<Integer> values) {
            addCriterion("PayStatus not in", values, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusBetween(Integer value1, Integer value2) {
            addCriterion("PayStatus between", value1, value2, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("PayStatus not between", value1, value2, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIsNull() {
            addCriterion("PayDatetime is null");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIsNotNull() {
            addCriterion("PayDatetime is not null");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeEqualTo(Date value) {
            addCriterion("PayDatetime =", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotEqualTo(Date value) {
            addCriterion("PayDatetime <>", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeGreaterThan(Date value) {
            addCriterion("PayDatetime >", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("PayDatetime >=", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeLessThan(Date value) {
            addCriterion("PayDatetime <", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeLessThanOrEqualTo(Date value) {
            addCriterion("PayDatetime <=", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIn(List<Date> values) {
            addCriterion("PayDatetime in", values, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotIn(List<Date> values) {
            addCriterion("PayDatetime not in", values, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeBetween(Date value1, Date value2) {
            addCriterion("PayDatetime between", value1, value2, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotBetween(Date value1, Date value2) {
            addCriterion("PayDatetime not between", value1, value2, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andExpectdateIsNull() {
            addCriterion("ExpectDate is null");
            return (Criteria) this;
        }

        public Criteria andExpectdateIsNotNull() {
            addCriterion("ExpectDate is not null");
            return (Criteria) this;
        }

        public Criteria andExpectdateEqualTo(Date value) {
            addCriterion("ExpectDate =", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotEqualTo(Date value) {
            addCriterion("ExpectDate <>", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateGreaterThan(Date value) {
            addCriterion("ExpectDate >", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ExpectDate >=", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateLessThan(Date value) {
            addCriterion("ExpectDate <", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateLessThanOrEqualTo(Date value) {
            addCriterion("ExpectDate <=", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateIn(List<Date> values) {
            addCriterion("ExpectDate in", values, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotIn(List<Date> values) {
            addCriterion("ExpectDate not in", values, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateBetween(Date value1, Date value2) {
            addCriterion("ExpectDate between", value1, value2, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotBetween(Date value1, Date value2) {
            addCriterion("ExpectDate not between", value1, value2, "expectdate");
            return (Criteria) this;
        }

        public Criteria andAugruIsNull() {
            addCriterion("Augru is null");
            return (Criteria) this;
        }

        public Criteria andAugruIsNotNull() {
            addCriterion("Augru is not null");
            return (Criteria) this;
        }

        public Criteria andAugruEqualTo(String value) {
            addCriterion("Augru =", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotEqualTo(String value) {
            addCriterion("Augru <>", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruGreaterThan(String value) {
            addCriterion("Augru >", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruGreaterThanOrEqualTo(String value) {
            addCriterion("Augru >=", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLessThan(String value) {
            addCriterion("Augru <", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLessThanOrEqualTo(String value) {
            addCriterion("Augru <=", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLike(String value) {
            addCriterion("Augru like", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotLike(String value) {
            addCriterion("Augru not like", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruIn(List<String> values) {
            addCriterion("Augru in", values, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotIn(List<String> values) {
            addCriterion("Augru not in", values, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruBetween(String value1, String value2) {
            addCriterion("Augru between", value1, value2, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotBetween(String value1, String value2) {
            addCriterion("Augru not between", value1, value2, "augru");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIsNull() {
            addCriterion("PaymentDay is null");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIsNotNull() {
            addCriterion("PaymentDay is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentdayEqualTo(String value) {
            addCriterion("PaymentDay =", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotEqualTo(String value) {
            addCriterion("PaymentDay <>", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayGreaterThan(String value) {
            addCriterion("PaymentDay >", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayGreaterThanOrEqualTo(String value) {
            addCriterion("PaymentDay >=", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLessThan(String value) {
            addCriterion("PaymentDay <", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLessThanOrEqualTo(String value) {
            addCriterion("PaymentDay <=", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLike(String value) {
            addCriterion("PaymentDay like", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotLike(String value) {
            addCriterion("PaymentDay not like", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIn(List<String> values) {
            addCriterion("PaymentDay in", values, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotIn(List<String> values) {
            addCriterion("PaymentDay not in", values, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayBetween(String value1, String value2) {
            addCriterion("PaymentDay between", value1, value2, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotBetween(String value1, String value2) {
            addCriterion("PaymentDay not between", value1, value2, "paymentday");
            return (Criteria) this;
        }

        public Criteria andBiztypeIsNull() {
            addCriterion("BizType is null");
            return (Criteria) this;
        }

        public Criteria andBiztypeIsNotNull() {
            addCriterion("BizType is not null");
            return (Criteria) this;
        }

        public Criteria andBiztypeEqualTo(String value) {
            addCriterion("BizType =", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotEqualTo(String value) {
            addCriterion("BizType <>", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeGreaterThan(String value) {
            addCriterion("BizType >", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeGreaterThanOrEqualTo(String value) {
            addCriterion("BizType >=", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLessThan(String value) {
            addCriterion("BizType <", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLessThanOrEqualTo(String value) {
            addCriterion("BizType <=", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLike(String value) {
            addCriterion("BizType like", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotLike(String value) {
            addCriterion("BizType not like", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeIn(List<String> values) {
            addCriterion("BizType in", values, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotIn(List<String> values) {
            addCriterion("BizType not in", values, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeBetween(String value1, String value2) {
            addCriterion("BizType between", value1, value2, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotBetween(String value1, String value2) {
            addCriterion("BizType not between", value1, value2, "biztype");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIsNull() {
            addCriterion("IsDelivery is null");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIsNotNull() {
            addCriterion("IsDelivery is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryEqualTo(Boolean value) {
            addCriterion("IsDelivery =", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotEqualTo(Boolean value) {
            addCriterion("IsDelivery <>", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryGreaterThan(Boolean value) {
            addCriterion("IsDelivery >", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsDelivery >=", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryLessThan(Boolean value) {
            addCriterion("IsDelivery <", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryLessThanOrEqualTo(Boolean value) {
            addCriterion("IsDelivery <=", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIn(List<Boolean> values) {
            addCriterion("IsDelivery in", values, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotIn(List<Boolean> values) {
            addCriterion("IsDelivery not in", values, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDelivery between", value1, value2, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDelivery not between", value1, value2, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIstaxIsNull() {
            addCriterion("IsTax is null");
            return (Criteria) this;
        }

        public Criteria andIstaxIsNotNull() {
            addCriterion("IsTax is not null");
            return (Criteria) this;
        }

        public Criteria andIstaxEqualTo(Boolean value) {
            addCriterion("IsTax =", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotEqualTo(Boolean value) {
            addCriterion("IsTax <>", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxGreaterThan(Boolean value) {
            addCriterion("IsTax >", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsTax >=", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxLessThan(Boolean value) {
            addCriterion("IsTax <", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxLessThanOrEqualTo(Boolean value) {
            addCriterion("IsTax <=", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxIn(List<Boolean> values) {
            addCriterion("IsTax in", values, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotIn(List<Boolean> values) {
            addCriterion("IsTax not in", values, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxBetween(Boolean value1, Boolean value2) {
            addCriterion("IsTax between", value1, value2, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsTax not between", value1, value2, "istax");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIsNull() {
            addCriterion("TaxContent is null");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIsNotNull() {
            addCriterion("TaxContent is not null");
            return (Criteria) this;
        }

        public Criteria andTaxcontentEqualTo(String value) {
            addCriterion("TaxContent =", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotEqualTo(String value) {
            addCriterion("TaxContent <>", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentGreaterThan(String value) {
            addCriterion("TaxContent >", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentGreaterThanOrEqualTo(String value) {
            addCriterion("TaxContent >=", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLessThan(String value) {
            addCriterion("TaxContent <", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLessThanOrEqualTo(String value) {
            addCriterion("TaxContent <=", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLike(String value) {
            addCriterion("TaxContent like", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotLike(String value) {
            addCriterion("TaxContent not like", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIn(List<String> values) {
            addCriterion("TaxContent in", values, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotIn(List<String> values) {
            addCriterion("TaxContent not in", values, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentBetween(String value1, String value2) {
            addCriterion("TaxContent between", value1, value2, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotBetween(String value1, String value2) {
            addCriterion("TaxContent not between", value1, value2, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIsNull() {
            addCriterion("TaxCompany is null");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIsNotNull() {
            addCriterion("TaxCompany is not null");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyEqualTo(String value) {
            addCriterion("TaxCompany =", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotEqualTo(String value) {
            addCriterion("TaxCompany <>", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyGreaterThan(String value) {
            addCriterion("TaxCompany >", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyGreaterThanOrEqualTo(String value) {
            addCriterion("TaxCompany >=", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLessThan(String value) {
            addCriterion("TaxCompany <", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLessThanOrEqualTo(String value) {
            addCriterion("TaxCompany <=", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLike(String value) {
            addCriterion("TaxCompany like", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotLike(String value) {
            addCriterion("TaxCompany not like", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIn(List<String> values) {
            addCriterion("TaxCompany in", values, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotIn(List<String> values) {
            addCriterion("TaxCompany not in", values, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyBetween(String value1, String value2) {
            addCriterion("TaxCompany between", value1, value2, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotBetween(String value1, String value2) {
            addCriterion("TaxCompany not between", value1, value2, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andShipstatusIsNull() {
            addCriterion("ShipStatus is null");
            return (Criteria) this;
        }

        public Criteria andShipstatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andShipstatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "shistatuspstatus");
            return (Criteria) this;
        }
        //------------ 是否已评论
        public Criteria andHasCommentIsNull() {
            addCriterion("hasComment is null");
            return (Criteria) this;
        }

        public Criteria andHasCommentIsNotNull() {
            addCriterion("hasComment is not null");
            return (Criteria) this;
        }

        public Criteria andHasCommentEqualTo(String value) {
            addCriterion("b.hasComment =", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andOrderTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }
        public Criteria andOrderTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andHasCommentNotEqualTo(String value) {
            addCriterion("hasComment <>", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentGreaterThan(String value) {
            addCriterion("hasComment >", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentGreaterThanOrEqualTo(String value) {
            addCriterion("hasComment >=", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentLessThan(String value) {
            addCriterion("hasComment <", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentLessThanOrEqualTo(String value) {
            addCriterion("hasComment <=", value, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentIn(List<String> values) {
            addCriterion("hasComment in", values, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentNotIn(List<String> values) {
            addCriterion("hasComment not in", values, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentBetween(String value1, String value2) {
            addCriterion("hasComment between", value1, value2, "hasComment");
            return (Criteria) this;
        }

        public Criteria andHasCommentNotBetween(String value1, String value2) {
            addCriterion("hasComment not between", value1, value2, "hasComment");
            return (Criteria) this;
        }
        //------------ 是否已评论 -END

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andIsreturnIsNull() {
            addCriterion("Isreturn is null");
            return (Criteria) this;
        }

        public Criteria andIsreturnIsNotNull() {
            addCriterion("Isreturn is not null");
            return (Criteria) this;
        }

        public Criteria andIsreturnEqualTo(Integer value) {
            addCriterion("Isreturn =", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotEqualTo(Integer value) {
            addCriterion("Isreturn <>", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnGreaterThan(Integer value) {
            addCriterion("Isreturn >", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnGreaterThanOrEqualTo(Integer value) {
            addCriterion("Isreturn >=", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnLessThan(Integer value) {
            addCriterion("Isreturn <", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnLessThanOrEqualTo(Integer value) {
            addCriterion("Isreturn <=", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnIn(List<Integer> values) {
            addCriterion("Isreturn in", values, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotIn(List<Integer> values) {
            addCriterion("Isreturn not in", values, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnBetween(Integer value1, Integer value2) {
            addCriterion("Isreturn between", value1, value2, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotBetween(Integer value1, Integer value2) {
            addCriterion("Isreturn not between", value1, value2, "isreturn");
            return (Criteria) this;
        }

        public Criteria andMarktextIsNull() {
            addCriterion("MarkText is null");
            return (Criteria) this;
        }

        public Criteria andMarktextIsNotNull() {
            addCriterion("MarkText is not null");
            return (Criteria) this;
        }

        public Criteria andMarktextEqualTo(String value) {
            addCriterion("MarkText =", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotEqualTo(String value) {
            addCriterion("MarkText <>", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextGreaterThan(String value) {
            addCriterion("MarkText >", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextGreaterThanOrEqualTo(String value) {
            addCriterion("MarkText >=", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLessThan(String value) {
            addCriterion("MarkText <", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLessThanOrEqualTo(String value) {
            addCriterion("MarkText <=", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLike(String value) {
            addCriterion("MarkText like", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotLike(String value) {
            addCriterion("MarkText not like", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextIn(List<String> values) {
            addCriterion("MarkText in", values, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotIn(List<String> values) {
            addCriterion("MarkText not in", values, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextBetween(String value1, String value2) {
            addCriterion("MarkText between", value1, value2, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotBetween(String value1, String value2) {
            addCriterion("MarkText not between", value1, value2, "marktext");
            return (Criteria) this;
        }

        public Criteria andMemberdescIsNull() {
            addCriterion("MemberDesc is null");
            return (Criteria) this;
        }

        public Criteria andMemberdescIsNotNull() {
            addCriterion("MemberDesc is not null");
            return (Criteria) this;
        }

        public Criteria andMemberdescEqualTo(String value) {
            addCriterion("MemberDesc =", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotEqualTo(String value) {
            addCriterion("MemberDesc <>", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescGreaterThan(String value) {
            addCriterion("MemberDesc >", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescGreaterThanOrEqualTo(String value) {
            addCriterion("MemberDesc >=", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLessThan(String value) {
            addCriterion("MemberDesc <", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLessThanOrEqualTo(String value) {
            addCriterion("MemberDesc <=", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLike(String value) {
            addCriterion("MemberDesc like", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotLike(String value) {
            addCriterion("MemberDesc not like", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescIn(List<String> values) {
            addCriterion("MemberDesc in", values, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotIn(List<String> values) {
            addCriterion("MemberDesc not in", values, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescBetween(String value1, String value2) {
            addCriterion("MemberDesc between", value1, value2, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotBetween(String value1, String value2) {
            addCriterion("MemberDesc not between", value1, value2, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andAddonstrIsNull() {
            addCriterion("Addonstr is null");
            return (Criteria) this;
        }

        public Criteria andAddonstrIsNotNull() {
            addCriterion("Addonstr is not null");
            return (Criteria) this;
        }

        public Criteria andAddonstrEqualTo(String value) {
            addCriterion("Addonstr =", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotEqualTo(String value) {
            addCriterion("Addonstr <>", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrGreaterThan(String value) {
            addCriterion("Addonstr >", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrGreaterThanOrEqualTo(String value) {
            addCriterion("Addonstr >=", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLessThan(String value) {
            addCriterion("Addonstr <", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLessThanOrEqualTo(String value) {
            addCriterion("Addonstr <=", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLike(String value) {
            addCriterion("Addonstr like", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotLike(String value) {
            addCriterion("Addonstr not like", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrIn(List<String> values) {
            addCriterion("Addonstr in", values, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotIn(List<String> values) {
            addCriterion("Addonstr not in", values, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrBetween(String value1, String value2) {
            addCriterion("Addonstr between", value1, value2, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotBetween(String value1, String value2) {
            addCriterion("Addonstr not between", value1, value2, "addonstr");
            return (Criteria) this;
        }

        public Criteria andOrderreferIsNull() {
            addCriterion("OrderRefer is null");
            return (Criteria) this;
        }

        public Criteria andOrderreferIsNotNull() {
            addCriterion("OrderRefer is not null");
            return (Criteria) this;
        }

        public Criteria andOrderreferEqualTo(String value) {
            addCriterion("OrderRefer =", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotEqualTo(String value) {
            addCriterion("OrderRefer <>", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferGreaterThan(String value) {
            addCriterion("OrderRefer >", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferGreaterThanOrEqualTo(String value) {
            addCriterion("OrderRefer >=", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLessThan(String value) {
            addCriterion("OrderRefer <", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLessThanOrEqualTo(String value) {
            addCriterion("OrderRefer <=", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLike(String value) {
            addCriterion("OrderRefer like", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotLike(String value) {
            addCriterion("OrderRefer not like", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferIn(List<String> values) {
            addCriterion("OrderRefer in", values, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotIn(List<String> values) {
            addCriterion("OrderRefer not in", values, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferBetween(String value1, String value2) {
            addCriterion("OrderRefer between", value1, value2, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotBetween(String value1, String value2) {
            addCriterion("OrderRefer not between", value1, value2, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIsNull() {
            addCriterion("ReturnGoodsRemark is null");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIsNotNull() {
            addCriterion("ReturnGoodsRemark is not null");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkEqualTo(String value) {
            addCriterion("ReturnGoodsRemark =", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotEqualTo(String value) {
            addCriterion("ReturnGoodsRemark <>", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkGreaterThan(String value) {
            addCriterion("ReturnGoodsRemark >", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkGreaterThanOrEqualTo(String value) {
            addCriterion("ReturnGoodsRemark >=", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLessThan(String value) {
            addCriterion("ReturnGoodsRemark <", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLessThanOrEqualTo(String value) {
            addCriterion("ReturnGoodsRemark <=", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLike(String value) {
            addCriterion("ReturnGoodsRemark like", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotLike(String value) {
            addCriterion("ReturnGoodsRemark not like", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIn(List<String> values) {
            addCriterion("ReturnGoodsRemark in", values, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotIn(List<String> values) {
            addCriterion("ReturnGoodsRemark not in", values, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkBetween(String value1, String value2) {
            addCriterion("ReturnGoodsRemark between", value1, value2, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotBetween(String value1, String value2) {
            addCriterion("ReturnGoodsRemark not between", value1, value2, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andIsfaorderIsNull() {
            addCriterion("IsFAOrder is null");
            return (Criteria) this;
        }

        public Criteria andIsfaorderIsNotNull() {
            addCriterion("IsFAOrder is not null");
            return (Criteria) this;
        }

        public Criteria andIsfaorderEqualTo(Boolean value) {
            addCriterion("IsFAOrder =", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderNotEqualTo(Boolean value) {
            addCriterion("IsFAOrder <>", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderGreaterThan(Boolean value) {
            addCriterion("IsFAOrder >", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsFAOrder >=", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderLessThan(Boolean value) {
            addCriterion("IsFAOrder <", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderLessThanOrEqualTo(Boolean value) {
            addCriterion("IsFAOrder <=", value, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderIn(List<Boolean> values) {
            addCriterion("IsFAOrder in", values, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderNotIn(List<Boolean> values) {
            addCriterion("IsFAOrder not in", values, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderBetween(Boolean value1, Boolean value2) {
            addCriterion("IsFAOrder between", value1, value2, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andIsfaorderNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsFAOrder not between", value1, value2, "isfaorder");
            return (Criteria) this;
        }

        public Criteria andFaidIsNull() {
            addCriterion("FAID is null");
            return (Criteria) this;
        }

        public Criteria andFaidIsNotNull() {
            addCriterion("FAID is not null");
            return (Criteria) this;
        }

        public Criteria andFaidEqualTo(String value) {
            addCriterion("FAID =", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotEqualTo(String value) {
            addCriterion("FAID <>", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidGreaterThan(String value) {
            addCriterion("FAID >", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidGreaterThanOrEqualTo(String value) {
            addCriterion("FAID >=", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLessThan(String value) {
            addCriterion("FAID <", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLessThanOrEqualTo(String value) {
            addCriterion("FAID <=", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLike(String value) {
            addCriterion("FAID like", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotLike(String value) {
            addCriterion("FAID not like", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidIn(List<String> values) {
            addCriterion("FAID in", values, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotIn(List<String> values) {
            addCriterion("FAID not in", values, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidBetween(String value1, String value2) {
            addCriterion("FAID between", value1, value2, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotBetween(String value1, String value2) {
            addCriterion("FAID not between", value1, value2, "faid");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIsNull() {
            addCriterion("IsAbnormal is null");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIsNotNull() {
            addCriterion("IsAbnormal is not null");
            return (Criteria) this;
        }

        public Criteria andIsabnormalEqualTo(Integer value) {
            addCriterion("IsAbnormal =", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotEqualTo(Integer value) {
            addCriterion("IsAbnormal <>", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalGreaterThan(Integer value) {
            addCriterion("IsAbnormal >", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalGreaterThanOrEqualTo(Integer value) {
            addCriterion("IsAbnormal >=", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalLessThan(Integer value) {
            addCriterion("IsAbnormal <", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalLessThanOrEqualTo(Integer value) {
            addCriterion("IsAbnormal <=", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIn(List<Integer> values) {
            addCriterion("IsAbnormal in", values, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotIn(List<Integer> values) {
            addCriterion("IsAbnormal not in", values, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalBetween(Integer value1, Integer value2) {
            addCriterion("IsAbnormal between", value1, value2, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotBetween(Integer value1, Integer value2) {
            addCriterion("IsAbnormal not between", value1, value2, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIsNull() {
            addCriterion("IsQualified is null");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIsNotNull() {
            addCriterion("IsQualified is not null");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedEqualTo(Boolean value) {
            addCriterion("IsQualified =", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotEqualTo(Boolean value) {
            addCriterion("IsQualified <>", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedGreaterThan(Boolean value) {
            addCriterion("IsQualified >", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsQualified >=", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedLessThan(Boolean value) {
            addCriterion("IsQualified <", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedLessThanOrEqualTo(Boolean value) {
            addCriterion("IsQualified <=", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIn(List<Boolean> values) {
            addCriterion("IsQualified in", values, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotIn(List<Boolean> values) {
            addCriterion("IsQualified not in", values, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQualified between", value1, value2, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQualified not between", value1, value2, "isqualified");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
