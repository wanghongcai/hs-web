package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * 返回界面的编码
 * @author licy13
 * @date 2016/7/21
 */
public class ZipView extends BaseInfo {
	private String zip;

	public ZipView(int rc, String msg, String provinces) {
		super(rc, msg);
		this.zip = provinces;
	}

	public ZipView() {
		super(0, "");
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("zip:" + this.zip+";");
		return buffer.toString();
	}
}
