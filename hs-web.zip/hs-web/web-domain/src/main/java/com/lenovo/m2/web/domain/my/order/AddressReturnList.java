package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2015年1月20日
 */
public class AddressReturnList implements Serializable {
	String addressid;
	
	String addressname;

	public String getAddressid() {
		return addressid;
	}

	public void setAddressid(String addressid) {
		this.addressid = addressid;
	}

	public String getAddressname() {
		return addressname;
	}

	public void setAddressname(String addressname) {
		this.addressname = addressname;
	}
}
