package com.lenovo.m2.web.domain.purchase.cashier;


import javax.servlet.http.HttpServletRequest;


/**
 *收银台支付请求所有参数
 *@Author wanghao,@Date 2016/11/24 18:00
 */
public class CashierPayModel extends BaseModel {

	public CashierPayModel() {
		super();
	}

	public CashierPayModel(HttpServletRequest request) {
        super(request);
        this.qrPayMode = request.getParameter("qrPayMode");
        this.bank_code = request.getParameter("bankCode");
        this.account_type = request.getParameter("accountType");
        this.card_type = request.getParameter("cardType");
        this.bank_type = request.getParameter("bankType");
        this.usedPoints = request.getParameter("usedPoints");

	}
    //客户端系统 1:ios,2:android,3:js,4:native，5，pc
    private String os;
    //卖家支付宝账号
    private String sellerEmail;
    //订单名称
    private String subject;
    //付款金额
    private String total_fee;
    //订单描述
    private String body;
    //商品展示地址
    private String show_url;
    //是否为支付宝扫码支付 add by MengQiang@2015年8月17日13:55:09 二维码图片大小
    //取值为 0(width:600px,high:300px) 1(width:300px,high:600px) 3(width:75px,high:75px)
    private String qrPayMode;
    //支付宝提供给商户的服务接入网关URL(新)
    private static final String ALIPAY_GATEWAY_NEW = "https://mapi.alipay.com/gateway.do?";
    //接口名称
    private  String service;
    //参数编码字符集
    private String input_charset;
    //签名方式
    private String sign_type;
    //签名
    private  String sign;
    //服务器异步通知页面路径
    private String notify_url;
    //页面跳转同步通知页面路径
    private String return_url;
    //请求出错时的通知页面路径
    private String error_notify_url;
    //交易类型1为B2C，2为B2B，3为C2C
    private String account_type;
    //网银编号
    private String bank_code;
    //网银类型,,1 企业网银  2 个人网银
    private String bank_type;
    //卡类型
    private String card_type;
    //使用积分
    private String usedPoints;

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getQrPayMode() {
        return qrPayMode;
    }

    public void setQrPayMode(String qrPayMode) {
        this.qrPayMode = qrPayMode;
    }

    public String getSellerEmail() {
        return sellerEmail;
    }

    public void setSellerEmail(String sellerEmail) {
        this.sellerEmail = sellerEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getShow_url() {
        return show_url;
    }

    public void setShow_url(String show_url) {
        this.show_url = show_url;
    }

    public static String getAlipayGatewayNew() {
        return ALIPAY_GATEWAY_NEW;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getInput_charset() {
        return input_charset;
    }

    public void setInput_charset(String input_charset) {
        this.input_charset = input_charset;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getReturn_url() {
        return return_url;
    }

    public void setReturn_url(String return_url) {
        this.return_url = return_url;
    }

    public String getError_notify_url() {
        return error_notify_url;
    }

    public void setError_notify_url(String error_notify_url) {
        this.error_notify_url = error_notify_url;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getBank_code() {
        return bank_code;
    }

    public void setBank_code(String bank_code) {
        this.bank_code = bank_code;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getUsedPoints() {
        return usedPoints;
    }

    public void setUsedPoints(String usedPoints) {
        this.usedPoints = usedPoints;
    }

    public String getBank_type() {
        return bank_type;
    }

    public void setBank_type(String bank_type) {
        this.bank_type = bank_type;
    }
}
