package com.lenovo.m2.web.domain.my;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by jiangzh5 on 2015/7/31.
 */
public class BaseInfo {
    private static final Map<Integer, BaseInfo> map = new HashMap<Integer, BaseInfo>();
    static {
        map.put(400, new BaseInfo(400, "请求参数错误"));
        map.put(401, new BaseInfo(401, "此操作需要登录"));
    }
    public static BaseInfo errInfo(Integer key){
        return map.get(key);
    }

    public BaseInfo() {
    }

    public BaseInfo(Integer rc, String msg) {
        this.rc = rc;
        this.msg = msg;
    }
    public BaseInfo(String msg) {
        this.msg = msg;
    }
    public BaseInfo(Integer rc) {
        this.rc = rc;
    }

    private int rc;
    private String msg = "";


    public int getRc() {
        return rc;
    }
    public void setRc(int rc) {
        this.rc = rc;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }

}
