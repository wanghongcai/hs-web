package com.lenovo.m2.web.domain.my.order;
/**
 * 
* @ClassName: OrderInvoiceVo
* @Description: 订单增值税发票
* @author yuzj7@lenovo.com
* @date 2015年5月31日 下午1:46:28
*
 */
public class OrderInvoiceVo implements java.io.Serializable{

	/**
	* @Fields serialVersionUID : (用一句话描述这个变量表示什么)
	*/ 
	private static final long serialVersionUID = 1L;
	/**
     * 订单ID
     */
    private Long orderId;
    /**
     * 发票类型 //电子发票0 ，普通发票1  2增值税发票
     */
    private Integer invoiceTypeId;
    /**
     * 发票内容
     */
    private String invoiceContent;
    /**
     * 发票抬头 0，个人  1，公司
     */
    private String invoiceHeader;
    /**
     * 纳税人识别号
     */
    private String taxpayerIdentity;
    /**
     * 注册地址
     */
    private String registerAddress;
    /**
     * 注册电话
     */
    private String registerPhone;
    /**
     * 开户银行
     */
    private String depositBank;
    /**
     * 银行帐号
     */
    private String bankNo;
    
    
    private String receiver;//收票人姓名
    private String receiverPhone;//收票人手机
    private String province;//省份
    private String city;//市
    private String county;//县
    private String receiverAddress;//收货地址
    private String zipCode;//售票人邮编
    private String pictureUrl;//资质url地址
    
  
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getPictureUrl() {
		return pictureUrl;
	}
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
	
	
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getReceiverPhone() {
		return receiverPhone;
	}
	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getReceiverAddress() {
		return receiverAddress;
	}
	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Integer getInvoiceTypeId() {
		return invoiceTypeId;
	}
	public void setInvoiceTypeId(Integer invoiceTypeId) {
		this.invoiceTypeId = invoiceTypeId;
	}
	public String getInvoiceContent() {
		return invoiceContent;
	}
	public void setInvoiceContent(String invoiceContent) {
		this.invoiceContent = invoiceContent;
	}
	public String getInvoiceHeader() {
		return invoiceHeader;
	}
	public void setInvoiceHeader(String invoiceHeader) {
		this.invoiceHeader = invoiceHeader;
	}
	public String getTaxpayerIdentity() {
		return taxpayerIdentity;
	}
	public void setTaxpayerIdentity(String taxpayerIdentity) {
		this.taxpayerIdentity = taxpayerIdentity;
	}
	public String getRegisterAddress() {
		return registerAddress;
	}
	public void setRegisterAddress(String registerAddress) {
		this.registerAddress = registerAddress;
	}
	public String getRegisterPhone() {
		return registerPhone;
	}
	public void setRegisterPhone(String registerPhone) {
		this.registerPhone = registerPhone;
	}
	public String getDepositBank() {
		return depositBank;
	}
	public void setDepositBank(String depositBank) {
		this.depositBank = depositBank;
	}
	public String getBankNo() {
		return bankNo;
	}
	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

    public String getInvoiceStr(){
        /**
         * 发票类型 //电子发票0 ，普通发票1  2增值税发票
         */
        if(invoiceTypeId==0)
            return "电子发票";
        else if(invoiceTypeId==1)
            return "普通发票";
        else if(invoiceTypeId==2)
            return "增值税发票";
        return "";
    }
    
   
	
}

