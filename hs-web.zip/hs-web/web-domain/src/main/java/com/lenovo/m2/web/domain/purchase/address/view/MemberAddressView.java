package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * <br> 返回获取的收货信息
 * @author shenjc
 *
 */
public class MemberAddressView extends BaseInfo {
	private String deliverid;
	private String delivername;
	private String deliverprovice;
	private String delivercity;
	private String delivercounty;
	private String deliverStreet;
	private String delivertele;
	private String deliverpost;
    private String delivermobile;

	public MemberAddressView(int rc, String msg, String deliverid) {
		super(rc, msg);
		this.deliverid = deliverid;
	}
	
	public MemberAddressView() {
		super(1, "查找收货信息失败");
	}
	

	/*public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("memberAddress:" + this.memberAddress+";");
		return buffer.toString();
	}*/
	
	public String getDeliverid() {
		return deliverid;
	}

	public void setDeliverid(String deliverid) {
		this.deliverid = deliverid;
	}
	
	public String getDelivername() {
		return delivername;
	}

	public void setDelivername(String delivername) {
		this.delivername = delivername;
	}

	public String getDeliverprovice() {
		return deliverprovice;
	}

	public void setDeliverprovice(String deliverprovice) {
		this.deliverprovice = deliverprovice;
	}

	public String getDelivercity() {
		return delivercity;
	}

	public void setDelivercity(String delivercity) {
		this.delivercity = delivercity;
	}

	public String getDelivercounty() {
		return delivercounty;
	}

	public void setDelivercounty(String delivercounty) {
		this.delivercounty = delivercounty;
	}

	public String getDeliverStreet() {
		return deliverStreet;
	}

	public void setDeliverStreet(String deliverStreet) {
		this.deliverStreet = deliverStreet;
	}

	public String getDelivertele() {
		return delivertele;
	}

	public void setDelivertele(String delivertele) {
		this.delivertele = delivertele;
	}

	public String getDeliverpost() {
		return deliverpost;
	}

	public void setDeliverpost(String deliverpost) {
		this.deliverpost = deliverpost;
	}

    public String getDelivermobile() {
        return delivermobile;
    }

    public void setDelivermobile(String delivermobile) {
        this.delivermobile = delivermobile;
    }
}
