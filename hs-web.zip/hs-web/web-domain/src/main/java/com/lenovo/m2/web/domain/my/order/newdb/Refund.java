package com.lenovo.m2.web.domain.my.order.newdb;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.tool.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by jiazy on 2016/6/29.
 */
public class Refund implements Serializable {



    public final static int  REFUND_STATUS_CANCEL= -1; //作废
    public final static int AUDIT_STATUS_PROCEED = 0;//退款中
    public final static int AUDIT_STATUS_SUCCESS = 1;//已退款

    private long id;

    private long reverseId;    //反向单号

    private String refundTraceNo;    //退款流水号

    private Money shouldAmount;    //应退金额

    private Money realAmount;     //实退金额

    private Money deductibleAmount;   //差额

    private String deductibleReason;   //差额原因

    private int refundStatus;    //退款订单状态

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;

    private String updateBy;

    private int version;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getReverseId() {
        return reverseId;
    }

    public void setReverseId(long reverseId) {
        this.reverseId = reverseId;
    }

    public String getRefundTraceNo() {
        return refundTraceNo;
    }

    public void setRefundTraceNo(String refundTraceNo) {
        this.refundTraceNo = refundTraceNo;
    }

    public Money getShouldAmount() {
        return shouldAmount;
    }

    public void setShouldAmount(Money shouldAmount) {
        this.shouldAmount = shouldAmount;
    }

    public Money getRealAmount() {
        return realAmount;
    }

    public void setRealAmount(Money realAmount) {
        this.realAmount = realAmount;
    }

    public Money getDeductibleAmount() {
        return deductibleAmount;
    }

    public void setDeductibleAmount(Money deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }

    public String getDeductibleReason() {
        return deductibleReason;
    }

    public void setDeductibleReason(String deductibleReason) {
        this.deductibleReason = deductibleReason;
    }

    public int getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(int refundStatus) {
        this.refundStatus = refundStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }



    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }


    @Override
    public String toString() {
        return "Refund{" +
                "id=" + id +
                ", reverseId=" + reverseId +
                ", refundTraceNo='" + refundTraceNo + '\'' +
                ", shouldAmount=" + shouldAmount +
                ", realAmount=" + realAmount +
                ", deductibleAmount=" + deductibleAmount +
                ", deductibleReason='" + deductibleReason + '\'' +
                ", refundStatus=" + refundStatus +
                ", createTime='" + createTime + '\'' +
                ", createBy='" + createBy + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", version=" + version +
                '}';
    }

    public static String getRefundTraceNo(long orderCode,String  payVoucherNo){
        if(StringUtils.isEmpty(payVoucherNo)){
            return "";
        }
        StringBuffer  stringBuffer  =new StringBuffer(String.valueOf(orderCode));
        stringBuffer.append(payVoucherNo);
        return stringBuffer.toString();
    }
}
