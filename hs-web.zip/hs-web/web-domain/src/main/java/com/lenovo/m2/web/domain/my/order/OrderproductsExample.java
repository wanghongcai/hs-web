package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderproductsExample implements Serializable {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OrderproductsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOrderidIsNull() {
            addCriterion("OrderID is null");
            return (Criteria) this;
        }

        public Criteria andOrderidIsNotNull() {
            addCriterion("OrderID is not null");
            return (Criteria) this;
        }

        public Criteria andOrderidEqualTo(String value) {
            addCriterion("OrderID =", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotEqualTo(String value) {
            addCriterion("OrderID <>", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidGreaterThan(String value) {
            addCriterion("OrderID >", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidGreaterThanOrEqualTo(String value) {
            addCriterion("OrderID >=", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLessThan(String value) {
            addCriterion("OrderID <", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLessThanOrEqualTo(String value) {
            addCriterion("OrderID <=", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidLike(String value) {
            addCriterion("OrderID like", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotLike(String value) {
            addCriterion("OrderID not like", value, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidIn(List<String> values) {
            addCriterion("OrderID in", values, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotIn(List<String> values) {
            addCriterion("OrderID not in", values, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidBetween(String value1, String value2) {
            addCriterion("OrderID between", value1, value2, "orderid");
            return (Criteria) this;
        }

        public Criteria andOrderidNotBetween(String value1, String value2) {
            addCriterion("OrderID not between", value1, value2, "orderid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidIsNull() {
            addCriterion("DeliveryID is null");
            return (Criteria) this;
        }

        public Criteria andDeliveryidIsNotNull() {
            addCriterion("DeliveryID is not null");
            return (Criteria) this;
        }

        public Criteria andDeliveryidEqualTo(String value) {
            addCriterion("DeliveryID =", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidNotEqualTo(String value) {
            addCriterion("DeliveryID <>", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidGreaterThan(String value) {
            addCriterion("DeliveryID >", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidGreaterThanOrEqualTo(String value) {
            addCriterion("DeliveryID >=", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidLessThan(String value) {
            addCriterion("DeliveryID <", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidLessThanOrEqualTo(String value) {
            addCriterion("DeliveryID <=", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidLike(String value) {
            addCriterion("DeliveryID like", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidNotLike(String value) {
            addCriterion("DeliveryID not like", value, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidIn(List<String> values) {
            addCriterion("DeliveryID in", values, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidNotIn(List<String> values) {
            addCriterion("DeliveryID not in", values, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidBetween(String value1, String value2) {
            addCriterion("DeliveryID between", value1, value2, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andDeliveryidNotBetween(String value1, String value2) {
            addCriterion("DeliveryID not between", value1, value2, "deliveryid");
            return (Criteria) this;
        }

        public Criteria andProductcodeIsNull() {
            addCriterion("ProductCode is null");
            return (Criteria) this;
        }

        public Criteria andProductcodeIsNotNull() {
            addCriterion("ProductCode is not null");
            return (Criteria) this;
        }

        public Criteria andProductcodeEqualTo(String value) {
            addCriterion("ProductCode =", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeNotEqualTo(String value) {
            addCriterion("ProductCode <>", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeGreaterThan(String value) {
            addCriterion("ProductCode >", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeGreaterThanOrEqualTo(String value) {
            addCriterion("ProductCode >=", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeLessThan(String value) {
            addCriterion("ProductCode <", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeLessThanOrEqualTo(String value) {
            addCriterion("ProductCode <=", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeLike(String value) {
            addCriterion("ProductCode like", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeNotLike(String value) {
            addCriterion("ProductCode not like", value, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeIn(List<String> values) {
            addCriterion("ProductCode in", values, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeNotIn(List<String> values) {
            addCriterion("ProductCode not in", values, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeBetween(String value1, String value2) {
            addCriterion("ProductCode between", value1, value2, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductcodeNotBetween(String value1, String value2) {
            addCriterion("ProductCode not between", value1, value2, "productcode");
            return (Criteria) this;
        }

        public Criteria andProductidIsNull() {
            addCriterion("ProductID is null");
            return (Criteria) this;
        }

        public Criteria andProductidIsNotNull() {
            addCriterion("ProductID is not null");
            return (Criteria) this;
        }

        public Criteria andProductidEqualTo(String value) {
            addCriterion("ProductID =", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotEqualTo(String value) {
            addCriterion("ProductID <>", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThan(String value) {
            addCriterion("ProductID >", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThanOrEqualTo(String value) {
            addCriterion("ProductID >=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThan(String value) {
            addCriterion("ProductID <", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThanOrEqualTo(String value) {
            addCriterion("ProductID <=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLike(String value) {
            addCriterion("ProductID like", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotLike(String value) {
            addCriterion("ProductID not like", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidIn(List<String> values) {
            addCriterion("ProductID in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotIn(List<String> values) {
            addCriterion("ProductID not in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidBetween(String value1, String value2) {
            addCriterion("ProductID between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotBetween(String value1, String value2) {
            addCriterion("ProductID not between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProductnameIsNull() {
            addCriterion("ProductName is null");
            return (Criteria) this;
        }

        public Criteria andProductnameIsNotNull() {
            addCriterion("ProductName is not null");
            return (Criteria) this;
        }

        public Criteria andProductnameEqualTo(String value) {
            addCriterion("ProductName =", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameNotEqualTo(String value) {
            addCriterion("ProductName <>", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameGreaterThan(String value) {
            addCriterion("ProductName >", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameGreaterThanOrEqualTo(String value) {
            addCriterion("ProductName >=", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameLessThan(String value) {
            addCriterion("ProductName <", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameLessThanOrEqualTo(String value) {
            addCriterion("ProductName <=", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameLike(String value) {
            addCriterion("ProductName like", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameNotLike(String value) {
            addCriterion("ProductName not like", value, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameIn(List<String> values) {
            addCriterion("ProductName in", values, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameNotIn(List<String> values) {
            addCriterion("ProductName not in", values, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameBetween(String value1, String value2) {
            addCriterion("ProductName between", value1, value2, "productname");
            return (Criteria) this;
        }

        public Criteria andProductnameNotBetween(String value1, String value2) {
            addCriterion("ProductName not between", value1, value2, "productname");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNull() {
            addCriterion("TypeID is null");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNotNull() {
            addCriterion("TypeID is not null");
            return (Criteria) this;
        }

        public Criteria andTypeidEqualTo(String value) {
            addCriterion("TypeID =", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotEqualTo(String value) {
            addCriterion("TypeID <>", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThan(String value) {
            addCriterion("TypeID >", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThanOrEqualTo(String value) {
            addCriterion("TypeID >=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThan(String value) {
            addCriterion("TypeID <", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThanOrEqualTo(String value) {
            addCriterion("TypeID <=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLike(String value) {
            addCriterion("TypeID like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotLike(String value) {
            addCriterion("TypeID not like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidIn(List<String> values) {
            addCriterion("TypeID in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotIn(List<String> values) {
            addCriterion("TypeID not in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidBetween(String value1, String value2) {
            addCriterion("TypeID between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotBetween(String value1, String value2) {
            addCriterion("TypeID not between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypenameIsNull() {
            addCriterion("TypeName is null");
            return (Criteria) this;
        }

        public Criteria andTypenameIsNotNull() {
            addCriterion("TypeName is not null");
            return (Criteria) this;
        }

        public Criteria andTypenameEqualTo(String value) {
            addCriterion("TypeName =", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameNotEqualTo(String value) {
            addCriterion("TypeName <>", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameGreaterThan(String value) {
            addCriterion("TypeName >", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameGreaterThanOrEqualTo(String value) {
            addCriterion("TypeName >=", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameLessThan(String value) {
            addCriterion("TypeName <", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameLessThanOrEqualTo(String value) {
            addCriterion("TypeName <=", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameLike(String value) {
            addCriterion("TypeName like", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameNotLike(String value) {
            addCriterion("TypeName not like", value, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameIn(List<String> values) {
            addCriterion("TypeName in", values, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameNotIn(List<String> values) {
            addCriterion("TypeName not in", values, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameBetween(String value1, String value2) {
            addCriterion("TypeName between", value1, value2, "typename");
            return (Criteria) this;
        }

        public Criteria andTypenameNotBetween(String value1, String value2) {
            addCriterion("TypeName not between", value1, value2, "typename");
            return (Criteria) this;
        }

        public Criteria andUnitIsNull() {
            addCriterion("Unit is null");
            return (Criteria) this;
        }

        public Criteria andUnitIsNotNull() {
            addCriterion("Unit is not null");
            return (Criteria) this;
        }

        public Criteria andUnitEqualTo(String value) {
            addCriterion("Unit =", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotEqualTo(String value) {
            addCriterion("Unit <>", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitGreaterThan(String value) {
            addCriterion("Unit >", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitGreaterThanOrEqualTo(String value) {
            addCriterion("Unit >=", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLessThan(String value) {
            addCriterion("Unit <", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLessThanOrEqualTo(String value) {
            addCriterion("Unit <=", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLike(String value) {
            addCriterion("Unit like", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotLike(String value) {
            addCriterion("Unit not like", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitIn(List<String> values) {
            addCriterion("Unit in", values, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotIn(List<String> values) {
            addCriterion("Unit not in", values, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitBetween(String value1, String value2) {
            addCriterion("Unit between", value1, value2, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotBetween(String value1, String value2) {
            addCriterion("Unit not between", value1, value2, "unit");
            return (Criteria) this;
        }

        public Criteria andFactorycodeIsNull() {
            addCriterion("FactoryCode is null");
            return (Criteria) this;
        }

        public Criteria andFactorycodeIsNotNull() {
            addCriterion("FactoryCode is not null");
            return (Criteria) this;
        }

        public Criteria andFactorycodeEqualTo(String value) {
            addCriterion("FactoryCode =", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeNotEqualTo(String value) {
            addCriterion("FactoryCode <>", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeGreaterThan(String value) {
            addCriterion("FactoryCode >", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeGreaterThanOrEqualTo(String value) {
            addCriterion("FactoryCode >=", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeLessThan(String value) {
            addCriterion("FactoryCode <", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeLessThanOrEqualTo(String value) {
            addCriterion("FactoryCode <=", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeLike(String value) {
            addCriterion("FactoryCode like", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeNotLike(String value) {
            addCriterion("FactoryCode not like", value, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeIn(List<String> values) {
            addCriterion("FactoryCode in", values, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeNotIn(List<String> values) {
            addCriterion("FactoryCode not in", values, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeBetween(String value1, String value2) {
            addCriterion("FactoryCode between", value1, value2, "factorycode");
            return (Criteria) this;
        }

        public Criteria andFactorycodeNotBetween(String value1, String value2) {
            addCriterion("FactoryCode not between", value1, value2, "factorycode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeIsNull() {
            addCriterion("WarehouseCode is null");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeIsNotNull() {
            addCriterion("WarehouseCode is not null");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeEqualTo(String value) {
            addCriterion("WarehouseCode =", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeNotEqualTo(String value) {
            addCriterion("WarehouseCode <>", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeGreaterThan(String value) {
            addCriterion("WarehouseCode >", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeGreaterThanOrEqualTo(String value) {
            addCriterion("WarehouseCode >=", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeLessThan(String value) {
            addCriterion("WarehouseCode <", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeLessThanOrEqualTo(String value) {
            addCriterion("WarehouseCode <=", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeLike(String value) {
            addCriterion("WarehouseCode like", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeNotLike(String value) {
            addCriterion("WarehouseCode not like", value, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeIn(List<String> values) {
            addCriterion("WarehouseCode in", values, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeNotIn(List<String> values) {
            addCriterion("WarehouseCode not in", values, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeBetween(String value1, String value2) {
            addCriterion("WarehouseCode between", value1, value2, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andWarehousecodeNotBetween(String value1, String value2) {
            addCriterion("WarehouseCode not between", value1, value2, "warehousecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeIsNull() {
            addCriterion("StorageCode is null");
            return (Criteria) this;
        }

        public Criteria andStoragecodeIsNotNull() {
            addCriterion("StorageCode is not null");
            return (Criteria) this;
        }

        public Criteria andStoragecodeEqualTo(String value) {
            addCriterion("StorageCode =", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeNotEqualTo(String value) {
            addCriterion("StorageCode <>", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeGreaterThan(String value) {
            addCriterion("StorageCode >", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeGreaterThanOrEqualTo(String value) {
            addCriterion("StorageCode >=", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeLessThan(String value) {
            addCriterion("StorageCode <", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeLessThanOrEqualTo(String value) {
            addCriterion("StorageCode <=", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeLike(String value) {
            addCriterion("StorageCode like", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeNotLike(String value) {
            addCriterion("StorageCode not like", value, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeIn(List<String> values) {
            addCriterion("StorageCode in", values, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeNotIn(List<String> values) {
            addCriterion("StorageCode not in", values, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeBetween(String value1, String value2) {
            addCriterion("StorageCode between", value1, value2, "storagecode");
            return (Criteria) this;
        }

        public Criteria andStoragecodeNotBetween(String value1, String value2) {
            addCriterion("StorageCode not between", value1, value2, "storagecode");
            return (Criteria) this;
        }

        public Criteria andProductnumberIsNull() {
            addCriterion("ProductNumber is null");
            return (Criteria) this;
        }

        public Criteria andProductnumberIsNotNull() {
            addCriterion("ProductNumber is not null");
            return (Criteria) this;
        }

        public Criteria andProductnumberEqualTo(Integer value) {
            addCriterion("ProductNumber =", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberNotEqualTo(Integer value) {
            addCriterion("ProductNumber <>", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberGreaterThan(Integer value) {
            addCriterion("ProductNumber >", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("ProductNumber >=", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberLessThan(Integer value) {
            addCriterion("ProductNumber <", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberLessThanOrEqualTo(Integer value) {
            addCriterion("ProductNumber <=", value, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberIn(List<Integer> values) {
            addCriterion("ProductNumber in", values, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberNotIn(List<Integer> values) {
            addCriterion("ProductNumber not in", values, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberBetween(Integer value1, Integer value2) {
            addCriterion("ProductNumber between", value1, value2, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductnumberNotBetween(Integer value1, Integer value2) {
            addCriterion("ProductNumber not between", value1, value2, "productnumber");
            return (Criteria) this;
        }

        public Criteria andProductpayIsNull() {
            addCriterion("ProductPay is null");
            return (Criteria) this;
        }

        public Criteria andProductpayIsNotNull() {
            addCriterion("ProductPay is not null");
            return (Criteria) this;
        }

        public Criteria andProductpayEqualTo(BigDecimal value) {
            addCriterion("ProductPay =", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayNotEqualTo(BigDecimal value) {
            addCriterion("ProductPay <>", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayGreaterThan(BigDecimal value) {
            addCriterion("ProductPay >", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ProductPay >=", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayLessThan(BigDecimal value) {
            addCriterion("ProductPay <", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ProductPay <=", value, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayIn(List<BigDecimal> values) {
            addCriterion("ProductPay in", values, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayNotIn(List<BigDecimal> values) {
            addCriterion("ProductPay not in", values, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ProductPay between", value1, value2, "productpay");
            return (Criteria) this;
        }

        public Criteria andProductpayNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ProductPay not between", value1, value2, "productpay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayIsNull() {
            addCriterion("FavourablePay is null");
            return (Criteria) this;
        }

        public Criteria andFavourablepayIsNotNull() {
            addCriterion("FavourablePay is not null");
            return (Criteria) this;
        }

        public Criteria andFavourablepayEqualTo(BigDecimal value) {
            addCriterion("FavourablePay =", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayNotEqualTo(BigDecimal value) {
            addCriterion("FavourablePay <>", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayGreaterThan(BigDecimal value) {
            addCriterion("FavourablePay >", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FavourablePay >=", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayLessThan(BigDecimal value) {
            addCriterion("FavourablePay <", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FavourablePay <=", value, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayIn(List<BigDecimal> values) {
            addCriterion("FavourablePay in", values, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayNotIn(List<BigDecimal> values) {
            addCriterion("FavourablePay not in", values, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FavourablePay between", value1, value2, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andFavourablepayNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FavourablePay not between", value1, value2, "favourablepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayIsNull() {
            addCriterion("VolumePay is null");
            return (Criteria) this;
        }

        public Criteria andVolumepayIsNotNull() {
            addCriterion("VolumePay is not null");
            return (Criteria) this;
        }

        public Criteria andVolumepayEqualTo(BigDecimal value) {
            addCriterion("VolumePay =", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayNotEqualTo(BigDecimal value) {
            addCriterion("VolumePay <>", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayGreaterThan(BigDecimal value) {
            addCriterion("VolumePay >", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("VolumePay >=", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayLessThan(BigDecimal value) {
            addCriterion("VolumePay <", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayLessThanOrEqualTo(BigDecimal value) {
            addCriterion("VolumePay <=", value, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayIn(List<BigDecimal> values) {
            addCriterion("VolumePay in", values, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayNotIn(List<BigDecimal> values) {
            addCriterion("VolumePay not in", values, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("VolumePay between", value1, value2, "volumepay");
            return (Criteria) this;
        }

        public Criteria andVolumepayNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("VolumePay not between", value1, value2, "volumepay");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalIsNull() {
            addCriterion("PaySubtotal is null");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalIsNotNull() {
            addCriterion("PaySubtotal is not null");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalEqualTo(BigDecimal value) {
            addCriterion("PaySubtotal =", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalNotEqualTo(BigDecimal value) {
            addCriterion("PaySubtotal <>", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalGreaterThan(BigDecimal value) {
            addCriterion("PaySubtotal >", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("PaySubtotal >=", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalLessThan(BigDecimal value) {
            addCriterion("PaySubtotal <", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("PaySubtotal <=", value, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalIn(List<BigDecimal> values) {
            addCriterion("PaySubtotal in", values, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalNotIn(List<BigDecimal> values) {
            addCriterion("PaySubtotal not in", values, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PaySubtotal between", value1, value2, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andPaysubtotalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("PaySubtotal not between", value1, value2, "paysubtotal");
            return (Criteria) this;
        }

        public Criteria andDiscountrateIsNull() {
            addCriterion("DiscountRate is null");
            return (Criteria) this;
        }

        public Criteria andDiscountrateIsNotNull() {
            addCriterion("DiscountRate is not null");
            return (Criteria) this;
        }

        public Criteria andDiscountrateEqualTo(BigDecimal value) {
            addCriterion("DiscountRate =", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateNotEqualTo(BigDecimal value) {
            addCriterion("DiscountRate <>", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateGreaterThan(BigDecimal value) {
            addCriterion("DiscountRate >", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("DiscountRate >=", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateLessThan(BigDecimal value) {
            addCriterion("DiscountRate <", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("DiscountRate <=", value, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateIn(List<BigDecimal> values) {
            addCriterion("DiscountRate in", values, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateNotIn(List<BigDecimal> values) {
            addCriterion("DiscountRate not in", values, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DiscountRate between", value1, value2, "discountrate");
            return (Criteria) this;
        }

        public Criteria andDiscountrateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("DiscountRate not between", value1, value2, "discountrate");
            return (Criteria) this;
        }

        public Criteria andProductcreditIsNull() {
            addCriterion("ProductCredit is null");
            return (Criteria) this;
        }

        public Criteria andProductcreditIsNotNull() {
            addCriterion("ProductCredit is not null");
            return (Criteria) this;
        }

        public Criteria andProductcreditEqualTo(Integer value) {
            addCriterion("ProductCredit =", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditNotEqualTo(Integer value) {
            addCriterion("ProductCredit <>", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditGreaterThan(Integer value) {
            addCriterion("ProductCredit >", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditGreaterThanOrEqualTo(Integer value) {
            addCriterion("ProductCredit >=", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditLessThan(Integer value) {
            addCriterion("ProductCredit <", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditLessThanOrEqualTo(Integer value) {
            addCriterion("ProductCredit <=", value, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditIn(List<Integer> values) {
            addCriterion("ProductCredit in", values, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditNotIn(List<Integer> values) {
            addCriterion("ProductCredit not in", values, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditBetween(Integer value1, Integer value2) {
            addCriterion("ProductCredit between", value1, value2, "productcredit");
            return (Criteria) this;
        }

        public Criteria andProductcreditNotBetween(Integer value1, Integer value2) {
            addCriterion("ProductCredit not between", value1, value2, "productcredit");
            return (Criteria) this;
        }

        public Criteria andChangestatusIsNull() {
            addCriterion("ChangeStatus is null");
            return (Criteria) this;
        }

        public Criteria andChangestatusIsNotNull() {
            addCriterion("ChangeStatus is not null");
            return (Criteria) this;
        }

        public Criteria andChangestatusEqualTo(Integer value) {
            addCriterion("ChangeStatus =", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotEqualTo(Integer value) {
            addCriterion("ChangeStatus <>", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusGreaterThan(Integer value) {
            addCriterion("ChangeStatus >", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("ChangeStatus >=", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusLessThan(Integer value) {
            addCriterion("ChangeStatus <", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusLessThanOrEqualTo(Integer value) {
            addCriterion("ChangeStatus <=", value, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusIn(List<Integer> values) {
            addCriterion("ChangeStatus in", values, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotIn(List<Integer> values) {
            addCriterion("ChangeStatus not in", values, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusBetween(Integer value1, Integer value2) {
            addCriterion("ChangeStatus between", value1, value2, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangestatusNotBetween(Integer value1, Integer value2) {
            addCriterion("ChangeStatus not between", value1, value2, "changestatus");
            return (Criteria) this;
        }

        public Criteria andChangecountIsNull() {
            addCriterion("ChangeCount is null");
            return (Criteria) this;
        }

        public Criteria andChangecountIsNotNull() {
            addCriterion("ChangeCount is not null");
            return (Criteria) this;
        }

        public Criteria andChangecountEqualTo(Integer value) {
            addCriterion("ChangeCount =", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountNotEqualTo(Integer value) {
            addCriterion("ChangeCount <>", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountGreaterThan(Integer value) {
            addCriterion("ChangeCount >", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountGreaterThanOrEqualTo(Integer value) {
            addCriterion("ChangeCount >=", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountLessThan(Integer value) {
            addCriterion("ChangeCount <", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountLessThanOrEqualTo(Integer value) {
            addCriterion("ChangeCount <=", value, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountIn(List<Integer> values) {
            addCriterion("ChangeCount in", values, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountNotIn(List<Integer> values) {
            addCriterion("ChangeCount not in", values, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountBetween(Integer value1, Integer value2) {
            addCriterion("ChangeCount between", value1, value2, "changecount");
            return (Criteria) this;
        }

        public Criteria andChangecountNotBetween(Integer value1, Integer value2) {
            addCriterion("ChangeCount not between", value1, value2, "changecount");
            return (Criteria) this;
        }

        public Criteria andIsgiftIsNull() {
            addCriterion("isGift is null");
            return (Criteria) this;
        }

        public Criteria andIsgiftIsNotNull() {
            addCriterion("isGift is not null");
            return (Criteria) this;
        }

        public Criteria andIsgiftEqualTo(Integer value) {
            addCriterion("isGift =", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftNotEqualTo(Integer value) {
            addCriterion("isGift <>", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftGreaterThan(Integer value) {
            addCriterion("isGift >", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftGreaterThanOrEqualTo(Integer value) {
            addCriterion("isGift >=", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftLessThan(Integer value) {
            addCriterion("isGift <", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftLessThanOrEqualTo(Integer value) {
            addCriterion("isGift <=", value, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftIn(List<Integer> values) {
            addCriterion("isGift in", values, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftNotIn(List<Integer> values) {
            addCriterion("isGift not in", values, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftBetween(Integer value1, Integer value2) {
            addCriterion("isGift between", value1, value2, "isgift");
            return (Criteria) this;
        }

        public Criteria andIsgiftNotBetween(Integer value1, Integer value2) {
            addCriterion("isGift not between", value1, value2, "isgift");
            return (Criteria) this;
        }

        public Criteria andGroupingidIsNull() {
            addCriterion("GroupingID is null");
            return (Criteria) this;
        }

        public Criteria andGroupingidIsNotNull() {
            addCriterion("GroupingID is not null");
            return (Criteria) this;
        }

        public Criteria andGroupingidEqualTo(String value) {
            addCriterion("GroupingID =", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidNotEqualTo(String value) {
            addCriterion("GroupingID <>", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidGreaterThan(String value) {
            addCriterion("GroupingID >", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidGreaterThanOrEqualTo(String value) {
            addCriterion("GroupingID >=", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidLessThan(String value) {
            addCriterion("GroupingID <", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidLessThanOrEqualTo(String value) {
            addCriterion("GroupingID <=", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidLike(String value) {
            addCriterion("GroupingID like", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidNotLike(String value) {
            addCriterion("GroupingID not like", value, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidIn(List<String> values) {
            addCriterion("GroupingID in", values, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidNotIn(List<String> values) {
            addCriterion("GroupingID not in", values, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidBetween(String value1, String value2) {
            addCriterion("GroupingID between", value1, value2, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGroupingidNotBetween(String value1, String value2) {
            addCriterion("GroupingID not between", value1, value2, "groupingid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidIsNull() {
            addCriterion("GoodsMaterialID is null");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidIsNotNull() {
            addCriterion("GoodsMaterialID is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidEqualTo(String value) {
            addCriterion("GoodsMaterialID =", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidNotEqualTo(String value) {
            addCriterion("GoodsMaterialID <>", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidGreaterThan(String value) {
            addCriterion("GoodsMaterialID >", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidGreaterThanOrEqualTo(String value) {
            addCriterion("GoodsMaterialID >=", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidLessThan(String value) {
            addCriterion("GoodsMaterialID <", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidLessThanOrEqualTo(String value) {
            addCriterion("GoodsMaterialID <=", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidLike(String value) {
            addCriterion("GoodsMaterialID like", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidNotLike(String value) {
            addCriterion("GoodsMaterialID not like", value, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidIn(List<String> values) {
            addCriterion("GoodsMaterialID in", values, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidNotIn(List<String> values) {
            addCriterion("GoodsMaterialID not in", values, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidBetween(String value1, String value2) {
            addCriterion("GoodsMaterialID between", value1, value2, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andGoodsmaterialidNotBetween(String value1, String value2) {
            addCriterion("GoodsMaterialID not between", value1, value2, "goodsmaterialid");
            return (Criteria) this;
        }

        public Criteria andSalestypeIsNull() {
            addCriterion("SalesType is null");
            return (Criteria) this;
        }

        public Criteria andSalestypeIsNotNull() {
            addCriterion("SalesType is not null");
            return (Criteria) this;
        }

        public Criteria andSalestypeEqualTo(Integer value) {
            addCriterion("SalesType =", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeNotEqualTo(Integer value) {
            addCriterion("SalesType <>", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeGreaterThan(Integer value) {
            addCriterion("SalesType >", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("SalesType >=", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeLessThan(Integer value) {
            addCriterion("SalesType <", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeLessThanOrEqualTo(Integer value) {
            addCriterion("SalesType <=", value, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeIn(List<Integer> values) {
            addCriterion("SalesType in", values, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeNotIn(List<Integer> values) {
            addCriterion("SalesType not in", values, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeBetween(Integer value1, Integer value2) {
            addCriterion("SalesType between", value1, value2, "salestype");
            return (Criteria) this;
        }

        public Criteria andSalestypeNotBetween(Integer value1, Integer value2) {
            addCriterion("SalesType not between", value1, value2, "salestype");
            return (Criteria) this;
        }

        public Criteria andIsphysicalIsNull() {
            addCriterion("IsPhysical is null");
            return (Criteria) this;
        }

        public Criteria andIsphysicalIsNotNull() {
            addCriterion("IsPhysical is not null");
            return (Criteria) this;
        }

        public Criteria andIsphysicalEqualTo(Integer value) {
            addCriterion("IsPhysical =", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalNotEqualTo(Integer value) {
            addCriterion("IsPhysical <>", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalGreaterThan(Integer value) {
            addCriterion("IsPhysical >", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalGreaterThanOrEqualTo(Integer value) {
            addCriterion("IsPhysical >=", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalLessThan(Integer value) {
            addCriterion("IsPhysical <", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalLessThanOrEqualTo(Integer value) {
            addCriterion("IsPhysical <=", value, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalIn(List<Integer> values) {
            addCriterion("IsPhysical in", values, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalNotIn(List<Integer> values) {
            addCriterion("IsPhysical not in", values, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalBetween(Integer value1, Integer value2) {
            addCriterion("IsPhysical between", value1, value2, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsphysicalNotBetween(Integer value1, Integer value2) {
            addCriterion("IsPhysical not between", value1, value2, "isphysical");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodIsNull() {
            addCriterion("IsServiceProd is null");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodIsNotNull() {
            addCriterion("IsServiceProd is not null");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodEqualTo(Integer value) {
            addCriterion("IsServiceProd =", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodNotEqualTo(Integer value) {
            addCriterion("IsServiceProd <>", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodGreaterThan(Integer value) {
            addCriterion("IsServiceProd >", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodGreaterThanOrEqualTo(Integer value) {
            addCriterion("IsServiceProd >=", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodLessThan(Integer value) {
            addCriterion("IsServiceProd <", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodLessThanOrEqualTo(Integer value) {
            addCriterion("IsServiceProd <=", value, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodIn(List<Integer> values) {
            addCriterion("IsServiceProd in", values, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodNotIn(List<Integer> values) {
            addCriterion("IsServiceProd not in", values, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodBetween(Integer value1, Integer value2) {
            addCriterion("IsServiceProd between", value1, value2, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andIsserviceprodNotBetween(Integer value1, Integer value2) {
            addCriterion("IsServiceProd not between", value1, value2, "isserviceprod");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdIsNull() {
            addCriterion("OrderMain_ID is null");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdIsNotNull() {
            addCriterion("OrderMain_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdEqualTo(String value) {
            addCriterion("OrderMain_ID =", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdNotEqualTo(String value) {
            addCriterion("OrderMain_ID <>", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdGreaterThan(String value) {
            addCriterion("OrderMain_ID >", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdGreaterThanOrEqualTo(String value) {
            addCriterion("OrderMain_ID >=", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdLessThan(String value) {
            addCriterion("OrderMain_ID <", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdLessThanOrEqualTo(String value) {
            addCriterion("OrderMain_ID <=", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdLike(String value) {
            addCriterion("OrderMain_ID like", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdNotLike(String value) {
            addCriterion("OrderMain_ID not like", value, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdIn(List<String> values) {
            addCriterion("OrderMain_ID in", values, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdNotIn(List<String> values) {
            addCriterion("OrderMain_ID not in", values, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdBetween(String value1, String value2) {
            addCriterion("OrderMain_ID between", value1, value2, "ordermainId");
            return (Criteria) this;
        }

        public Criteria andOrdermainIdNotBetween(String value1, String value2) {
            addCriterion("OrderMain_ID not between", value1, value2, "ordermainId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}