package com.lenovo.m2.web.domain.purchase.order;

import com.lenovo.m2.hsbuy.domain.purchase.result.CheckOutResult;
import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;

import java.io.Serializable;

/**
 * @Author zhanghs 【zhanghs6@lenovo.com】
 * @Description: 结算返回对象
 *
 * @date 2016/3/20 15:04
 * @return
 */
public class CheckOutOrderVo implements Serializable {

    private CheckOutResult checkOutOrder;
    private BackFillOrderVo bfOrderVo;//结算缓存对象

    public CheckOutOrderVo() {
    }

    public CheckOutOrderVo(CheckOutResult checkOutOrder, BackFillOrderVo bfOrderVo) {
        this.checkOutOrder = checkOutOrder;
        this.bfOrderVo = bfOrderVo;
    }

    public CheckOutResult getCheckOutOrder() {
        return checkOutOrder;
    }

    public void setCheckOutOrder(CheckOutResult checkOutOrder) {
        this.checkOutOrder = checkOutOrder;
    }

    public BackFillOrderVo getBfOrderVo() {
        return bfOrderVo;
    }

    public void setBfOrderVo(BackFillOrderVo bfOrderVo) {
        this.bfOrderVo = bfOrderVo;
    }

    @Override
    public String toString() {
        return "CheckOutOrderVo{" +
                "checkOutOrder=" + checkOutOrder +
                ", bfOrderVo=" + bfOrderVo +
                '}';
    }
}


