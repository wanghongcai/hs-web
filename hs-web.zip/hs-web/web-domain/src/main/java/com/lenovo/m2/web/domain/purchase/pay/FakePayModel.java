package com.lenovo.m2.web.domain.purchase.pay;

/**
 * Created by luyang on 2016/5/10.
 */
public class FakePayModel {
    private String fakeFaID;
    private String fakePayType;

    public String getFakePayType() {
        return fakePayType;
    }

    public void setFakePayType(String fakePayType) {
        this.fakePayType = fakePayType;
    }

    public String getFakeFaID() {
        return fakeFaID;
    }

    public void setFakeFaID(String fakeFaID) {
        this.fakeFaID = fakeFaID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FakePayModel)) return false;

        FakePayModel that = (FakePayModel) o;

        if (!fakeFaID.equals(that.fakeFaID)) return false;
        if (!fakePayType.equals(that.fakePayType)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fakeFaID.hashCode();
        result = 31 * result + fakePayType.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "FakePayModel{" +
                "fakeFaID='" + fakeFaID + '\'' +
                ", fakePayType='" + fakePayType + '\'' +
                '}';
    }
}
