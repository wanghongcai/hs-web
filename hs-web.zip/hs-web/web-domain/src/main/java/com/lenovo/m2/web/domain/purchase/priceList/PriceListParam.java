package com.lenovo.m2.web.domain.purchase.priceList;

/**
 * Created by D_xiao on 1/5/17.
 */

import com.lenovo.m2.hsbuy.domain.pricelist.PriceListDetail;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.common.purchase.util.BasePara;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

public class PriceListParam extends BasePara {
    private Long id;
    private String dealNo;
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date expireDate;
    private String saleOrganization;
    private String itcode;
    private String memberNo;
    private BigDecimal totalPrice;
    private String payee;
    private String openingBank;
    private String accountNumber;
    private Integer isCreatedOrder;
    private String auditFile;
    private String buyerName;
    private String buyerAddress;
    private String buyerZip;
    private String buyerPhone;
    private String buyerContacts;
    private String buyerTele;
    private String customManager;
    private String cmPhone;
    private String cmFax;
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date createTime;
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date updateTime;
    private String detail;
    private List<PriceListDetail> detailList;
    private String userId;
    private String currencyCode;
    private int shopId;

    public PriceListParam() {
    }

    public int getShopId() {
        return this.shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<PriceListDetail> getDetailList() {
        return this.detailList;
    }

    public void setDetailList(List<PriceListDetail> detailList) {
        this.detailList = detailList;
    }

    public String getDetail() {
        return this.detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDealNo() {
        return this.dealNo;
    }

    public void setDealNo(String dealNo) {
        this.dealNo = dealNo == null?null:dealNo.trim();
    }

    public Date getExpireDate() {
        return this.expireDate;
    }

    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    public String getSaleOrganization() {
        return this.saleOrganization;
    }

    public void setSaleOrganization(String saleOrganization) {
        this.saleOrganization = saleOrganization == null?null:saleOrganization.trim();
    }

    public String getItcode() {
        return this.itcode;
    }

    public void setItcode(String itcode) {
        this.itcode = itcode == null?null:itcode.trim();
    }

    public String getMemberNo() {
        return this.memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo == null?null:memberNo.trim();
    }

    public BigDecimal getTotalPrice() {
        return this.totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getPayee() {
        return this.payee;
    }

    public void setPayee(String payee) {
        this.payee = payee == null?null:payee.trim();
    }

    public String getOpeningBank() {
        return this.openingBank;
    }

    public void setOpeningBank(String openingBank) {
        this.openingBank = openingBank == null?null:openingBank.trim();
    }

    public String getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber == null?null:accountNumber.trim();
    }

    public Integer getIsCreatedOrder() {
        return this.isCreatedOrder;
    }

    public void setIsCreatedOrder(Integer isCreatedOrder) {
        this.isCreatedOrder = isCreatedOrder;
    }

    public String getAuditFile() {
        return this.auditFile;
    }

    public void setAuditFile(String auditFile) {
        this.auditFile = auditFile == null?null:auditFile.trim();
    }

    public String getBuyerName() {
        return this.buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName == null?null:buyerName.trim();
    }

    public String getBuyerAddress() {
        return this.buyerAddress;
    }

    public void setBuyerAddress(String buyerAddress) {
        this.buyerAddress = buyerAddress == null?null:buyerAddress.trim();
    }

    public String getBuyerZip() {
        return this.buyerZip;
    }

    public void setBuyerZip(String buyerZip) {
        this.buyerZip = buyerZip == null?null:buyerZip.trim();
    }

    public String getBuyerPhone() {
        return this.buyerPhone;
    }

    public void setBuyerPhone(String buyerPhone) {
        this.buyerPhone = buyerPhone == null?null:buyerPhone.trim();
    }

    public String getBuyerContacts() {
        return this.buyerContacts;
    }

    public void setBuyerContacts(String buyerContacts) {
        this.buyerContacts = buyerContacts;
    }

    public String getBuyerTele() {
        return this.buyerTele;
    }

    public void setBuyerTele(String buyerTele) {
        this.buyerTele = buyerTele;
    }

    public String getCustomManager() {
        return this.customManager;
    }

    public void setCustomManager(String customManager) {
        this.customManager = customManager == null?null:customManager.trim();
    }

    public String getCmPhone() {
        return this.cmPhone;
    }

    public void setCmPhone(String cmPhone) {
        this.cmPhone = cmPhone == null?null:cmPhone.trim();
    }

    public String getCmFax() {
        return this.cmFax;
    }

    public void setCmFax(String cmFax) {
        this.cmFax = cmFax == null?null:cmFax.trim();
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public BaseInfo validateAppPara() {
        return null;
    }
}
