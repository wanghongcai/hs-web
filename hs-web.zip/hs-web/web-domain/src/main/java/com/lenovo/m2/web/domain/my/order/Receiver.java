package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by chenww3 on 2015/6/14.
 * 收货方信息
 */
public class Receiver implements Serializable {

    private String shipCode;// 收货人编号
    private String shipName;// 收货人姓名
    private String shipAddr;// 收货人街道
    private String shipZip;// 收货人邮编
    private String shipEmail;// 收货人邮箱
    private String shipCity;// 收货人城市
    private String deliverCounty;// 收货人区县名字
    private String shipArea;// 收货人地区
    private String deliverArea;// 收货人省编号
    private String deliverAreaName;// 收货人省名称
    private String shipMobile;// 收货人手机
    private String shipTel;// 收货人电话
    private String descriptionQuestion;// 问题描述

    private String custNo;//  F, == shipCode

    private String company;//公司

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    //二期新增
    //运费
    private Money money;

    private Money advanceFreightMoney;

    public String getShipCode() {
        return shipCode;
    }

    public void setShipCode(String shipCode) {
        this.shipCode = shipCode;
    }
    public String getCustNo() {
        return custNo;
    }

    public void setCustNo(String custNo) {
        this.custNo = custNo;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public String getShipAddr() {
        return shipAddr;
    }

    public void setShipAddr(String shipAddr) {
        this.shipAddr = shipAddr;
    }

    public String getShipZip() {
        return shipZip;
    }

    public void setShipZip(String shipZip) {
        this.shipZip = shipZip;
    }

    public String getShipEmail() {
        return shipEmail;
    }

    public void setShipEmail(String shipEmail) {
        this.shipEmail = shipEmail;
    }

    public String getShipCity() {
        return shipCity;
    }

    public void setShipCity(String shipCity) {
        this.shipCity = shipCity;
    }

    public String getDeliverCounty() {
        return deliverCounty;
    }

    public void setDeliverCounty(String deliverCounty) {
        this.deliverCounty = deliverCounty;
    }

    public String getShipArea() {
        return shipArea;
    }

    public void setShipArea(String shipArea) {
        this.shipArea = shipArea;
    }

    public String getDeliverArea() {
        return deliverArea;
    }

    public void setDeliverArea(String deliverArea) {
        this.deliverArea = deliverArea;
    }

    public String getDeliverAreaName() {
        return deliverAreaName;
    }

    public void setDeliverAreaName(String deliverAreaName) {
        this.deliverAreaName = deliverAreaName;
    }

    public String getShipMobile() {
        return shipMobile;
    }

    public void setShipMobile(String shipMobile) {
        this.shipMobile = shipMobile;
    }

    public String getShipTel() {
        return shipTel;
    }

    public void setShipTel(String shipTel) {
        this.shipTel = shipTel;
    }

    public String getDescriptionQuestion() {
        return descriptionQuestion;
    }

    public void setDescriptionQuestion(String descriptionQuestion) {
        this.descriptionQuestion = descriptionQuestion;
    }

    public Money getMoney() {
        return money;
    }

    public void setMoney(Money money) {
        this.money = money;
    }

    public Money getAdvanceFreightMoney() {
        return advanceFreightMoney;
    }

    public void setAdvanceFreightMoney(Money advanceFreightMoney) {
        this.advanceFreightMoney = advanceFreightMoney;
    }

    public String getFullAddress(){
        StringBuilder sb = new StringBuilder();
        sb.append(deliverAreaName==null?"":deliverAreaName).append(shipCity==null?"":shipCity).append(deliverCounty==null?"":deliverCounty).append(shipAddr==null?"":shipAddr);
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Receiver{" +
                "shipCode='" + shipCode + '\'' +
                ", shipName='" + shipName + '\'' +
                ", shipAddr='" + shipAddr + '\'' +
                ", shipZip='" + shipZip + '\'' +
                ", shipEmail='" + shipEmail + '\'' +
                ", shipCity='" + shipCity + '\'' +
                ", deliverCounty='" + deliverCounty + '\'' +
                ", shipArea='" + shipArea + '\'' +
                ", deliverArea='" + deliverArea + '\'' +
                ", deliverAreaName='" + deliverAreaName + '\'' +
                ", shipMobile='" + shipMobile + '\'' +
                ", shipTel='" + shipTel + '\'' +
                ", descriptionQuestion='" + descriptionQuestion + '\'' +
                ", custNo='" + custNo + '\'' +
                ", money='" + money + '\'' +
                ", advanceFreightMoney='" + advanceFreightMoney + '\'' +
                '}';
    }
}
