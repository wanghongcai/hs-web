package com.lenovo.m2.web.domain.my.address;

import java.io.Serializable;

/**
 * <br> 用于前台界面的显示
 * @author shenjc
 *
 */
public class MemberAddress implements Serializable {
	private Integer isdefault;

	private String deliverid;
    
    private String delivername;

    private String deliverprovice;

    private String delivercity;

    private String delivercounty;

    private String deliverStreet;

    private String deliverpost;

    private String delivertele;
    
    public String toString() {
    	StringBuffer buffer = new StringBuffer();
    	buffer.append("isdefault:" + this.isdefault + ";")
    	.append("deliverid:" + this.deliverid + ";")
    	.append("delivername:" + this.delivername + ";")
    	.append("deliverprovice:" + this.deliverprovice + ";")
    	.append("delivercity:" + this.delivercity + ";")
    	.append("delivercounty:" + this.delivercounty + ";")
    	.append("deliverStreet:" + this.deliverStreet + ";")
    	.append("deliverpost:" + this.deliverpost + ";")
    	.append("delivertele" + this.delivertele + ";");
    	return buffer.toString();
    }

    
    public Integer getIsdefault() {
		return isdefault;
	}

	public void setIsdefault(Integer isdefault) {
		this.isdefault = isdefault;
	}
	
    public String getDeliverid() {
		return deliverid;
	}

	public void setDeliverid(String deliverid) {
		this.deliverid = deliverid;
	}

	public String getDelivername() {
		return delivername;
	}

	public void setDelivername(String delivername) {
		this.delivername = delivername;
	}

	public String getDeliverprovice() {
		return deliverprovice;
	}

	public void setDeliverprovice(String deliverprovice) {
		this.deliverprovice = deliverprovice;
	}

	public String getDelivercity() {
		return delivercity;
	}

	public void setDelivercity(String delivercity) {
		this.delivercity = delivercity;
	}

	public String getDelivercounty() {
		return delivercounty;
	}

	public void setDelivercounty(String delivercounty) {
		this.delivercounty = delivercounty;
	}

	public String getDeliverStreet() {
		return deliverStreet;
	}

	public void setDeliverStreet(String deliverStreet) {
		this.deliverStreet = deliverStreet;
	}

	public String getDeliverpost() {
		return deliverpost;
	}

	public void setDeliverpost(String deliverpost) {
		this.deliverpost = deliverpost;
	}

	public String getDelivertele() {
		return delivertele;
	}

	public void setDelivertele(String delivertele) {
		this.delivertele = delivertele;
	}

    public String getFullAddr(){
        StringBuilder sb = new StringBuilder();
        sb.append(deliverprovice==null?"":deliverprovice)
          .append(delivercity==null?"":delivercity)
          .append(delivercounty==null?"":delivercounty)
          .append(deliverStreet==null?"":deliverStreet);
        return sb.toString();
    }
}