package com.lenovo.m2.web.domain.purchase.cashier;

import javax.servlet.http.HttpServletRequest;

public class ModelUtil {
	
	public static Object getModel(HttpServletRequest request){
		if (request == null) {
			return null;
		}
		int type = -1;
        //0招商银行 1支付宝默认支付2支付宝移动端 3 支付宝纯网关 4支付宝合并支付 5支付宝分期 6移动快捷支付 9微信支付
		//12联通支付；13平安支付；16联动优势
        String payType = request.getParameter("paymentTypeCode");
		if (payType != null && !("".equals(payType))) {
			type = Integer.parseInt(payType);
		}
		Object obj = null;
        obj = new CashierPayModel(request);
		/*switch (type) {

        case 1:
            //obj = new AliPayJsModel(request);
            obj = new CashierPayModel(request);
            break;

        case 9:
            //obj = new WXPayModel(request);
            obj = new CashierPayModel(request);
            break;
		*//*case 10:
			obj = new ABCFQPayModel(request);
			break;
        case 11:
            obj = new AliPayHuaBeiModel(request);
            break;*//*
        case 21:
            break;
		default:
			break;
		}*/
		return obj;
	}
}
