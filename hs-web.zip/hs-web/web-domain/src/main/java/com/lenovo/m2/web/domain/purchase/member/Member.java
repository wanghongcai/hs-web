package com.lenovo.m2.web.domain.purchase.member;

import java.math.BigDecimal;
import java.util.Date;

public class Member {


    private String id;

    private String lenovoid;

    private String membercode;

    private String memberlevelid;

    private String name;

    private Integer point;

    private Integer membertype;

    private String lastname;

    private String firstname;

    private String area;

    private String addr;

    private String mobile;

    private String tel;

    private String email;

    private String zip;

    private Integer ordernum;

    private String referid;

    private String referurl;

    private Integer birthyear;

    private Integer birthmonth;

    private Integer birthday;

    private Integer sex;

    private Integer wedlock;

    private String education;

    private String vocation;

    private BigDecimal advance;

    private BigDecimal advancefreeze;

    private BigDecimal scorerate;

    private String regip;

    private Integer regtime;

    private Integer state;

    private Integer paytime;

    private BigDecimal bizmoney;

    private String cur;

    private String lang;

    private Integer unreadmsg;

    private Integer disabled;

    private String remarktype;

    private Integer logincount;

    private Integer experience;

    private String resetpwd;

    private Integer resetpwdtime;

    private Integer sourceplatform;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid == null ? null : lenovoid.trim();
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode == null ? null : membercode.trim();
    }

    public String getMemberlevelid() {
        return memberlevelid;
    }

    public void setMemberlevelid(String memberlevelid) {
        this.memberlevelid = memberlevelid == null ? null : memberlevelid.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public Integer getMembertype() {
        return membertype;
    }

    public void setMembertype(Integer membertype) {
        this.membertype = membertype;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname == null ? null : lastname.trim();
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname == null ? null : firstname.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr == null ? null : addr.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip == null ? null : zip.trim();
    }

    public Integer getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(Integer ordernum) {
        this.ordernum = ordernum;
    }

    public String getReferid() {
        return referid;
    }

    public void setReferid(String referid) {
        this.referid = referid == null ? null : referid.trim();
    }

    public String getReferurl() {
        return referurl;
    }

    public void setReferurl(String referurl) {
        this.referurl = referurl == null ? null : referurl.trim();
    }

    public Integer getBirthyear() {
        return birthyear;
    }

    public void setBirthyear(Integer birthyear) {
        this.birthyear = birthyear;
    }

    public Integer getBirthmonth() {
        return birthmonth;
    }

    public void setBirthmonth(Integer birthmonth) {
        this.birthmonth = birthmonth;
    }

    public Integer getBirthday() {
        return birthday;
    }

    public void setBirthday(Integer birthday) {
        this.birthday = birthday;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getWedlock() {
        return wedlock;
    }

    public void setWedlock(Integer wedlock) {
        this.wedlock = wedlock;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education == null ? null : education.trim();
    }

    public String getVocation() {
        return vocation;
    }

    public void setVocation(String vocation) {
        this.vocation = vocation == null ? null : vocation.trim();
    }

    public BigDecimal getAdvance() {
        return advance;
    }

    public void setAdvance(BigDecimal advance) {
        this.advance = advance;
    }

    public BigDecimal getAdvancefreeze() {
        return advancefreeze;
    }

    public void setAdvancefreeze(BigDecimal advancefreeze) {
        this.advancefreeze = advancefreeze;
    }

    public BigDecimal getScorerate() {
        return scorerate;
    }

    public void setScorerate(BigDecimal scorerate) {
        this.scorerate = scorerate;
    }

    public String getRegip() {
        return regip;
    }

    public void setRegip(String regip) {
        this.regip = regip == null ? null : regip.trim();
    }

    public Integer getRegtime() {
        return regtime;
    }

    public void setRegtime(Integer regtime) {
        this.regtime = regtime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getPaytime() {
        return paytime;
    }

    public void setPaytime(Integer paytime) {
        this.paytime = paytime;
    }

    public BigDecimal getBizmoney() {
        return bizmoney;
    }

    public void setBizmoney(BigDecimal bizmoney) {
        this.bizmoney = bizmoney;
    }

    public String getCur() {
        return cur;
    }

    public void setCur(String cur) {
        this.cur = cur == null ? null : cur.trim();
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang == null ? null : lang.trim();
    }

    public Integer getUnreadmsg() {
        return unreadmsg;
    }

    public void setUnreadmsg(Integer unreadmsg) {
        this.unreadmsg = unreadmsg;
    }

    public Integer getDisabled() {
        return disabled;
    }

    public void setDisabled(Integer disabled) {
        this.disabled = disabled;
    }

    public String getRemarktype() {
        return remarktype;
    }

    public void setRemarktype(String remarktype) {
        this.remarktype = remarktype == null ? null : remarktype.trim();
    }

    public Integer getLogincount() {
        return logincount;
    }

    public void setLogincount(Integer logincount) {
        this.logincount = logincount;
    }

    public Integer getExperience() {
        return experience;
    }

    public void setExperience(Integer experience) {
        this.experience = experience;
    }

    public String getResetpwd() {
        return resetpwd;
    }

    public void setResetpwd(String resetpwd) {
        this.resetpwd = resetpwd == null ? null : resetpwd.trim();
    }

    public Integer getResetpwdtime() {
        return resetpwdtime;
    }

    public void setResetpwdtime(Integer resetpwdtime) {
        this.resetpwdtime = resetpwdtime;
    }

    public Integer getSourceplatform() {
        return sourceplatform;
    }

    public void setSourceplatform(Integer sourceplatform) {
        this.sourceplatform = sourceplatform;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }
}