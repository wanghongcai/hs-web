package com.lenovo.m2.web.domain.purchase.address;

import java.io.Serializable;
import java.util.Date;

public class ConsigneeAddressParam implements Serializable {
    private java.lang.String id;
    private java.lang.String lenovoId;
    private java.lang.String addressname;
    private java.lang.String name;
    private java.lang.String provinceCode;
    private java.lang.String provinceNo;
    private java.lang.String cityCode;
    private java.lang.String cityNo;
    private java.lang.String countyCode;
    private java.lang.String countyNo;
    private java.lang.String townshipCode;
    private java.lang.String townshipNo;
    private java.lang.String address;
    private java.lang.String zip;
    private java.lang.String tel;
    private java.lang.String mobile;
    private java.lang.Integer isdefault;
    private java.util.Date createtime;
    private java.lang.String createby;
    private java.util.Date updatetime;
    private java.lang.String updateby;
    private java.lang.String email;
    private java.lang.Integer isdeleted;
    private java.lang.String type;
    private java.lang.String areaNos;
    private java.lang.String company;
    private java.lang.String guid;
    private boolean backFlag;
    private java.lang.String bigRegionNo;
    private java.lang.String bigRegionName;
    private java.lang.String regionNo;
    private java.lang.String regionName;
    private java.lang.String shortName;
    private java.lang.String taxNo;
    private java.lang.Integer shopId;

    @Override
    public String toString() {
        return "ConsigneeAddressParam{" +
                "id='" + id + '\'' +
                ", lenovoId='" + lenovoId + '\'' +
                ", addressname='" + addressname + '\'' +
                ", name='" + name + '\'' +
                ", provinceCode='" + provinceCode + '\'' +
                ", provinceNo='" + provinceNo + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", cityNo='" + cityNo + '\'' +
                ", countyCode='" + countyCode + '\'' +
                ", countyNo='" + countyNo + '\'' +
                ", townshipCode='" + townshipCode + '\'' +
                ", townshipNo='" + townshipNo + '\'' +
                ", address='" + address + '\'' +
                ", zip='" + zip + '\'' +
                ", tel='" + tel + '\'' +
                ", mobile='" + mobile + '\'' +
                ", isdefault=" + isdefault +
                ", createtime=" + createtime +
                ", createby='" + createby + '\'' +
                ", updatetime=" + updatetime +
                ", updateby='" + updateby + '\'' +
                ", email='" + email + '\'' +
                ", isdeleted=" + isdeleted +
                ", type='" + type + '\'' +
                ", areaNos='" + areaNos + '\'' +
                ", company='" + company + '\'' +
                ", guid='" + guid + '\'' +
                ", backFlag=" + backFlag +
                ", bigRegionNo='" + bigRegionNo + '\'' +
                ", bigRegionName='" + bigRegionName + '\'' +
                ", regionNo='" + regionNo + '\'' +
                ", regionName='" + regionName + '\'' +
                ", shortName='" + shortName + '\'' +
                ", taxNo='" + taxNo + '\'' +
                ", shopId=" + shopId +
                '}';
    }

    public ConsigneeAddressParam() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getAddressname() {
        return addressname;
    }

    public void setAddressname(String addressname) {
        this.addressname = addressname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getProvinceNo() {
        return provinceNo;
    }

    public void setProvinceNo(String provinceNo) {
        this.provinceNo = provinceNo;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityNo() {
        return cityNo;
    }

    public void setCityNo(String cityNo) {
        this.cityNo = cityNo;
    }

    public String getCountyCode() {
        return countyCode;
    }

    public void setCountyCode(String countyCode) {
        this.countyCode = countyCode;
    }

    public String getCountyNo() {
        return countyNo;
    }

    public void setCountyNo(String countyNo) {
        this.countyNo = countyNo;
    }

    public String getTownshipCode() {
        return townshipCode;
    }

    public void setTownshipCode(String townshipCode) {
        this.townshipCode = townshipCode;
    }

    public String getTownshipNo() {
        return townshipNo;
    }

    public void setTownshipNo(String townshipNo) {
        this.townshipNo = townshipNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getIsdefault() {
        return isdefault;
    }

    public void setIsdefault(Integer isdefault) {
        this.isdefault = isdefault;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getIsdeleted() {
        return isdeleted;
    }

    public void setIsdeleted(Integer isdeleted) {
        this.isdeleted = isdeleted;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAreaNos() {
        return areaNos;
    }

    public void setAreaNos(String areaNos) {
        this.areaNos = areaNos;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public boolean isBackFlag() {
        return backFlag;
    }

    public void setBackFlag(boolean backFlag) {
        this.backFlag = backFlag;
    }

    public String getBigRegionNo() {
        return bigRegionNo;
    }

    public void setBigRegionNo(String bigRegionNo) {
        this.bigRegionNo = bigRegionNo;
    }

    public String getBigRegionName() {
        return bigRegionName;
    }

    public void setBigRegionName(String bigRegionName) {
        this.bigRegionName = bigRegionName;
    }

    public String getRegionNo() {
        return regionNo;
    }

    public void setRegionNo(String regionNo) {
        this.regionNo = regionNo;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }
}
