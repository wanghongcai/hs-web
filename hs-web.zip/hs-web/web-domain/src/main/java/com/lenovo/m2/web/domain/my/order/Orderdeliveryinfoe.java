package com.lenovo.m2.web.domain.my.order;

import java.util.Date;

/**
 * Created by mayan3 on 2015/9/4.
 */
public class Orderdeliveryinfoe {
    private String id;

    private String ordercode;

    private String logisticscode;

    private String logino;

    private Date logidate;

    private String logiconten;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLogisticscode() {
        return logisticscode;
    }

    public void setLogisticscode(String logisticscode) {
        this.logisticscode = logisticscode == null ? null : logisticscode.trim();
    }

    public String getLogino() {
        return logino;
    }

    public void setLogino(String logino) {
        this.logino = logino == null ? null : logino.trim();
    }

    public Date getLogidate() {
        return logidate;
    }

    public void setLogidate(Date logidate) {
        this.logidate = logidate;
    }

    public String getLogiconten() {
        return logiconten;
    }

    public void setLogiconten(String logiconten) {
        this.logiconten = logiconten == null ? null : logiconten.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }
}