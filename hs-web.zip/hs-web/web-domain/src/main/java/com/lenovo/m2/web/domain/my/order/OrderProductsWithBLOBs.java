package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

public class OrderProductsWithBLOBs extends OrderProducts implements Serializable {
    private String productphoto;

    private String productdesc;

    private String deatlike;

    private String specification;

    private String sncode;

    private String changesncode;

    private String lenovoproductcode;

    private String machinesn;

    public String getProductphoto() {
        return productphoto;
    }

    public void setProductphoto(String productphoto) {
        this.productphoto = productphoto;
    }

    public String getProductdesc() {
        return productdesc;
    }

    public void setProductdesc(String productdesc) {
        this.productdesc = productdesc;
    }

    public String getDeatlike() {
        return deatlike;
    }

    public void setDeatlike(String deatlike) {
        this.deatlike = deatlike;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public String getSncode() {
        return sncode;
    }

    public void setSncode(String sncode) {
        this.sncode = sncode;
    }

    public String getChangesncode() {
        return changesncode;
    }

    public void setChangesncode(String changesncode) {
        this.changesncode = changesncode;
    }

    public String getLenovoproductcode() {
        return lenovoproductcode;
    }

    public void setLenovoproductcode(String lenovoproductcode) {
        this.lenovoproductcode = lenovoproductcode;
    }

    public String getMachinesn() {
        return machinesn;
    }

    public void setMachinesn(String machinesn) {
        this.machinesn = machinesn;
    }
}