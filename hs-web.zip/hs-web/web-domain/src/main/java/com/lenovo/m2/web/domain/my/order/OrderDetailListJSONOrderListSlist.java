package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;

/**
 * Created by mayan3 on 2015/11/24.
 */
public class OrderDetailListJSONOrderListSlist extends OrderDetailListJSONOrderListGlist implements Serializable  {
}
