package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenww3 on 2015/6/14.
 */
@Document(collection = "mongoorder")
public class MongoOrder implements Cloneable {

    // 订单
    private String payOrderNo;// 用户支付订单号
    private String orderMainCode;// 主订单号
    private String orderCode;// 订单号
    private String vkorg;// 销售组织
    private String salesChannel = "";// 销售渠道
    private String memberID;// 会员ID
    private String memberCode;//会员编码
    private Money costItem;// 订单总价
    private Money amountMoney;// 支付订单总金额
    private Money giveawayCost;// 赠品优惠金额
    private Money giveawayTotal;// 优惠金额总计
    private Money creditTotal;// 可得积分
    private String paymentType;// 支付类型0:在线支付1:货到付款2:线下打款
    private String payStatus;// 支付状态 0表示正在支付，1表示支付中，2表示完成
    private String orderStatus;//订单状态 活动订单0 作废订单1 已完成2
    private String augru = "";//订单原因
    private String payDatetime;// 支付时间
    private String isTax;
    private String taxContent = "";// 发票内容
    private String taxType = "";// 发票类型
    private String taxCompanyType = "";//发票抬头类型
    private String taxCompany = "";// 发票抬头
    private String isRevoked;// 是否撤单
    private String markText = "";// 订单备注
    private String memberDesc = "";// 会员备注
    private String addonstr = "";// 订单附言
    private String orderRefer;// 订单来源
    private String faType;// 是否FA订单
    private String faid;// faid
    private String faname;// fa名称
    private String customerManagerCode;// 客户经理
    private String createTime;//下单时间
    private String source;//平台 1、2、3、4
    private String isAbnormal; //异常订单 0为正常订单，1为异常订单
    private String productPhoto;//商品图片
    private String productDesc;//商品描述
    private String hasComment = "0";//是否已评论
    private String ordercomefrom;    //订单来源
    private String cancelTime;//订单取消时间
    private String waitReceiptDate;//等待收货
    private Money usedLeDouNum;//使用的乐豆

    private String orderAddType;//订单类型
    private String uploadStatus;//慧商线下支付订单，上传支付资料状态,null:为经过收银台确认；1：可以开始上传资料，2：已经上传完资料
    private String buyerCode;//慧商经销商名称
    private Money voucherTotalAmount;//代金券金额，多个用逗号隔开
    private String note;//大礼包金额对应的code，代金券id,多个使用逗号隔开，

    private String C1lenovoid;
    private List<Accessory> cvItems;//cto 新增cv配置信息

    private String isDelete;//订单删除标记 0或空未删除 1删除(回收站可还原) 2彻底删除

    //新增众筹活动关联信息
    private String raiseId;//众筹活动id
    private String raiseModeId;//支持方式id

    //cps新增字段
    private String wi;
    private String cid;
    //商品平台打通
    private String  terminal;//终端
    private String activeStatus;//1标识有效订单0标识无效
    private String shopId;
    private String lenovoId;

    /**
     * 第三方订单编号 smb存po号
     */
    private String customerOrderCode;
    /**
     * 第三方订单编号子订单号 smb存小po号
     */
    private String customerOrderCodeSon;
    /**
     * 下单方式 1静默下单，2手工下单，3询价单
     */
    private int submitOrderWay;
    //smb拓展字段
    private String vatHeader;//增值税 发票抬头
    private String vatdepositBank;//开户银行
    private String vatBankNo;//银行账号
    private String vatTaxpayerIdentity;//纳税人识别号
    private List<Receiver> vatDeliveries = new ArrayList<Receiver>();//发票寄送地址
    private List<Receiver> contractDeliveries = new ArrayList<Receiver>();//合同寄送地址
    /**
     * 注册地址
     */
    private String registerAddress;
    /**
     * 注册电话
     */
    private String registerPhone;
    /**
     * 收票人邮编
     */
    private String zipCode;


    private String notes;

    //smbhf 新增字段
    private Money score;

    /**
     * 是否寄送合同1是 0否
     */
    private int isSendHt;
    private String payName;//付款方名称

    private String url;

    private Presell presell;

    private String auditStatus;

    private int taxNoType;// 纳税识别号类型


    private Money creditLine;

    public Money getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(Money creditLine) {
        this.creditLine = creditLine;
    }


    public int getTaxNoType() {
        return taxNoType;
    }

    public void setTaxNoType(int taxNoType) {
        this.taxNoType = taxNoType;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    /**
     * 1审核通过
     2待审核
     3审核未通过
     4待生成合同
     * */

    public Presell getPresell() {
        return presell;
    }

    public void setPresell(Presell presell) {
        this.presell = presell;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRegisterAddress() {
        return registerAddress;
    }

    public void setRegisterAddress(String registerAddress) {
        this.registerAddress = registerAddress;
    }

    public String getRegisterPhone() {
        return registerPhone;
    }

    public void setRegisterPhone(String registerPhone) {
        this.registerPhone = registerPhone;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }

    public int getIsSendHt() {
        return isSendHt;
    }

    public void setIsSendHt(int isSendHt) {
        this.isSendHt = isSendHt;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getVatHeader() {
        return vatHeader;
    }

    public void setVatHeader(String vatHeader) {
        this.vatHeader = vatHeader;
    }

    public String getVatdepositBank() {
        return vatdepositBank;
    }

    public void setVatdepositBank(String vatdepositBank) {
        this.vatdepositBank = vatdepositBank;
    }

    public String getVatBankNo() {
        return vatBankNo;
    }

    public void setVatBankNo(String vatBankNo) {
        this.vatBankNo = vatBankNo;
    }

    public String getVatTaxpayerIdentity() {
        return vatTaxpayerIdentity;
    }

    public void setVatTaxpayerIdentity(String vatTaxpayerIdentity) {
        this.vatTaxpayerIdentity = vatTaxpayerIdentity;
    }

    public List<Receiver> getVatDeliveries() {
        return vatDeliveries;
    }

    public void setVatDeliveries(List<Receiver> vatDeliveries) {
        this.vatDeliveries = vatDeliveries;
    }

    public List<Receiver> getContractDeliveries() {
        return contractDeliveries;
    }

    public void setContractDeliveries(List<Receiver> contractDeliveries) {
        this.contractDeliveries = contractDeliveries;
    }

    public int getSubmitOrderWay() {
        return submitOrderWay;
    }

    public void setSubmitOrderWay(int submitOrderWay) {
        this.submitOrderWay = submitOrderWay;
    }

    public String getCustomerOrderCodeSon() {
        return customerOrderCodeSon;
    }

    public void setCustomerOrderCodeSon(String customerOrderCodeSon) {
        this.customerOrderCodeSon = customerOrderCodeSon;
    }

    public String getCustomerOrderCode() {
        return customerOrderCode;
    }

    public void setCustomerOrderCode(String customerOrderCode) {
        this.customerOrderCode = customerOrderCode;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getRaiseId() {
        return raiseId;
    }

    public void setRaiseId(String raiseId) {
        this.raiseId = raiseId;
    }

    public String getRaiseModeId() {
        return raiseModeId;
    }

    public void setRaiseModeId(String raiseModeId) {
        this.raiseModeId = raiseModeId;
    }

    public List<Accessory> getCvItems() {
        return cvItems;
    }

    public void setCvItems(List<Accessory> cvItems) {
        this.cvItems = cvItems;
    }

    public String getWi() {
        return wi;
    }

    public void setWi(String wi) {
        this.wi = wi;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getOrdercomefrom() {
        return ordercomefrom;
    }

    public void setOrdercomefrom(String ordercomefrom) {
        this.ordercomefrom = ordercomefrom;
    }

    public String getC1lenovoid() {
        return C1lenovoid;
    }

    public void setC1lenovoid(String c1lenovoid) {
        C1lenovoid = c1lenovoid;
    }

    public String getOrderAddType() {
        return orderAddType;
    }

    public void setOrderAddType(String orderAddType) {
        this.orderAddType = orderAddType;
    }

    public Money getVoucherTotalAmount() {
        return voucherTotalAmount;
    }

    public void setVoucherTotalAmount(Money voucherTotalAmount) {
        this.voucherTotalAmount = voucherTotalAmount;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    //二期新增
    //是否被mq作业取消  orderstatus为1 为取消 可能为作业取消或者被用户撤单
    private String iscancel;
    //更新时间 作业取消的时候更新此时间
    private String updatetime;
    //订单内商品销售类型 0普通商品 1闪购 2预售 3先试后买
    private String salesOrderType;

    public String getHasComment() {
        return hasComment;
    }

    public void setHasComment(String hasComment) {
        this.hasComment = hasComment;
    }

    // 产品表
    private List<Product> products;

    //各种优惠
    private PreferredPayment preferredPayment;



    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public List<Product> addProduct(Product product) {
        if (products == null) {
            products = new ArrayList<Product>();
        }
        products.add(product);
        return products;
    }

    public List<Product> removeProduct(Product product) {
        if (products == null) {
            products = new ArrayList<Product>();
        } else {
            products.remove(product);
        }
        return products;
    }

    //支付表
    private List<PayCount> pay = new ArrayList<PayCount>();

    /**
     * 取代原来的get方法
     *
     * @return
     */
    public PayCount takePay() {
        if (pay.size() == 0) {
            return null;
        } else {
            return pay.get(0);
        }
    }

    /**
     * 取代原来的 set 方法
     *
     * @param payCount
     */
    public void placePay(PayCount payCount) {
        if (pay.size() == 0) {
            pay.add(payCount);
        } else {
            pay.set(0, payCount);
        }
    }

    @Deprecated
    public List<PayCount> getPay() {
        return pay;
    }

    @Deprecated
    public void setPay(List<PayCount> pay) {
        this.pay = pay;
    }

    // 子表(Receiver)
    private List<Receiver> deliveries = new ArrayList<Receiver>();

    /**
     * 取代原来的get方法
     *
     * @return
     */
    public Receiver takeReceiver() {
        if (deliveries.size() == 0) {
            return null;
        } else {
            return deliveries.get(0);
        }
    }

    /**
     * 取代原来的 set 方法
     *
     * @param receiver
     */
    public void placeReceiver(Receiver receiver) {
        if (deliveries.size() == 0) {
            deliveries.add(receiver);
        } else {
            deliveries.set(0, receiver);
        }
    }

    /**
     * 使用takeReceiver代替get方法
     */
    @Deprecated
    public List<Receiver> getDeliveries() {
        return deliveries;
    }

    /**
     * 使用placeReceiver代替get方法
     */
    @Deprecated
    public void setDeliveries(List<Receiver> deliveries) {
        this.deliveries = deliveries;
    }

    public String getPayOrderNo() {
        return payOrderNo;
    }

    public void setPayOrderNo(String payOrderNo) {
        this.payOrderNo = payOrderNo;
    }

    public String getOrderMainCode() {
        return orderMainCode;
    }

    public void setOrderMainCode(String orderMainCode) {
        this.orderMainCode = orderMainCode;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getVkorg() {
        return vkorg;
    }

    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }

    public String getSalesChannel() {
        return salesChannel;
    }

    public void setSalesChannel(String salesChannel) {
        this.salesChannel = salesChannel;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }



    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getAugru() {
        return augru;
    }

    public void setAugru(String augru) {
        this.augru = augru;
    }

    public String getPayDatetime() {
        return payDatetime;
    }

    public void setPayDatetime(String payDatetime) {
        this.payDatetime = payDatetime;
    }

    public String getIsTax() {
        return isTax;
    }

    public void setIsTax(String isTax) {
        this.isTax = isTax;
    }

    public String getTaxContent() {
        return taxContent;
    }

    public void setTaxContent(String taxContent) {
        this.taxContent = taxContent;
    }

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType;
    }

    public String getTaxCompanyType() {
        return taxCompanyType;
    }

    public void setTaxCompanyType(String taxCompanyType) {
        this.taxCompanyType = taxCompanyType;
    }

    public String getTaxCompany() {
        return taxCompany;
    }

    public void setTaxCompany(String taxCompany) {
        this.taxCompany = taxCompany;
    }

    public String getIsRevoked() {
        return isRevoked;
    }

    public void setIsRevoked(String isRevoked) {
        this.isRevoked = isRevoked;
    }

    public String getMarkText() {
        return markText;
    }

    public void setMarkText(String markText) {
        this.markText = markText;
    }

    public String getMemberDesc() {
        return memberDesc;
    }

    public void setMemberDesc(String memberDesc) {
        this.memberDesc = memberDesc;
    }

    public String getAddonstr() {
        return addonstr;
    }

    public void setAddonstr(String addonstr) {
        this.addonstr = addonstr;
    }

    public String getOrderRefer() {
        return orderRefer;
    }

    public void setOrderRefer(String orderRefer) {
        this.orderRefer = orderRefer;
    }


    public String getFaType() {
        return faType;
    }

    public void setFaType(String faType) {
        this.faType = faType;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    public String getFaname() {
        return faname;
    }

    public void setFaname(String faname) {
        this.faname = faname;
    }

    public String getCustomerManagerCode() {
        return customerManagerCode;
    }

    public void setCustomerManagerCode(String customerManagerCode) {
        this.customerManagerCode = customerManagerCode;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }


    public String getIscancel() {
        return iscancel;
    }

    public void setIscancel(String iscancel) {
        this.iscancel = iscancel;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }

    public String getIsAbnormal() {
        return isAbnormal;
    }

    public void setIsAbnormal(String isAbnormal) {
        this.isAbnormal = isAbnormal;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getProductPhoto() {
        return productPhoto;
    }

    public void setProductPhoto(String productPhoto) {
        this.productPhoto = productPhoto;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    /**
     * <br> json后的格式
     * {
     * "payOrderNo": null,
     * "orderMainCode": null,
     * "orderCode": null,
     * "vkorg": null,
     * "salesChannel": null,
     * "memberID": null,
     * "costItem": null,
     * "amountMoney": null,
     * "giveawayCost": null,
     * "giveawayTotal": null,
     * "creditTotal": null,
     * "paymentType": null,
     * "payStatus": null,
     * "payDatetime": null,
     * "taxContent": null,
     * "taxType": null,
     * "taxCompany": null,
     * "isRevoked": null,
     * "markText": null,
     * "memberDesc": null,
     * "addonstr": null,
     * "orderRefer": null,
     * "isFAOrder": null,
     * "customerManagerCode": null,
     * "products": [
     * {
     * "productCode": null,
     * "productID": null,
     * "productName": null,
     * "productNumber": null,
     * "realityPay": null,
     * "productPay": null,
     * "favourablePay": null,
     * "paySubtotal": null,
     * "discountRate": null,
     * "productCredit": null
     * }
     * ],
     * "paycount": {
     * "gatheringBank": null,
     * "gatheringCode": null,
     * "gatheringNum": null,
     * "gatheringName": null,
     * "paymentLX": null,
     * "payment": null,
     * "paymentUser": null,
     * "gatheringDesc": null
     * },
     * "receiver": {
     * "shipCode": null,
     * "shipName": null,
     * "shipAddr": null,
     * "shipZip": null,
     * "shipEmail": null,
     * "shipCity": null,
     * "deliverCounty": null,
     * "shipArea": null,
     * "deliverArea": null,
     * "deliverAreaName": null,
     * "shipMobile": null,
     * "shipTel": null,
     * "descriptionQuestion": null
     * },
     * "faid": null,
     * "faname": null
     * }
     *
     * @param args
     */
    public static void main(String[] args) {
//		MongoOrder order = new MongoOrder();
//
//		Receiver receiver = order.new Receiver();
//		order.setReceiver(receiver);
//
////		Product product = order.new Product();
////		order.addProduct(product);
//
//		PayCount payCount = order.new PayCount();
//		order.setPaycount(payCount);
//
//		String res = JacksonUtil.toJson(order);
//		System.out.println(res);
    }

    public MongoOrder clone() throws CloneNotSupportedException {
        MongoOrder cloned = (MongoOrder) super.clone();
        return cloned;
    }

    public String getSalesOrderType() {
        return salesOrderType;
    }

    public void setSalesOrderType(String salesOrderType) {
        this.salesOrderType = salesOrderType;
    }

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Money getCostItem() {
        return costItem;
    }

    public void setCostItem(Money costItem) {
        this.costItem = costItem;
    }

    public Money getAmountMoney() {
        return amountMoney;
    }

    public void setAmountMoney(Money amountMoney) {
        this.amountMoney = amountMoney;
    }

    public Money getGiveawayCost() {
        return giveawayCost;
    }

    public void setGiveawayCost(Money giveawayCost) {
        this.giveawayCost = giveawayCost;
    }

    public Money getGiveawayTotal() {
        return giveawayTotal;
    }

    public void setGiveawayTotal(Money giveawayTotal) {
        this.giveawayTotal = giveawayTotal;
    }

    public Money getCreditTotal() {
        return creditTotal;
    }

    public void setCreditTotal(Money creditTotal) {
        this.creditTotal = creditTotal;
    }

    public Money getUsedLeDouNum() {
        return usedLeDouNum;
    }

    public void setUsedLeDouNum(Money usedLeDouNum) {
        this.usedLeDouNum = usedLeDouNum;
    }

    public Money getScore() {
        return score;
    }

    public void setScore(Money score) {
        this.score = score;
    }

    public String getWaitReceiptDate() {
        return waitReceiptDate;
    }

    public void setWaitReceiptDate(String waitReceiptDate) {
        this.waitReceiptDate = waitReceiptDate;
    }

    public PreferredPayment getPreferredPayment() {
        if (preferredPayment==null){
            preferredPayment=new PreferredPayment();
        }
        return preferredPayment;
    }

    public void setPreferredPayment(PreferredPayment preferredPayment) {
        this.preferredPayment = preferredPayment;
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getBuyerCode() {
        return buyerCode;
    }

    public void setBuyerCode(String buyerCode) {
        this.buyerCode = buyerCode;
    }
}
