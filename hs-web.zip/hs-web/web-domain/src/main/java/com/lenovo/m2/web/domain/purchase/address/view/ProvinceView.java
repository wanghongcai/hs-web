package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * <br>返回界面的省份列表
 * @author shenjc
 *
 */
public class ProvinceView extends BaseInfo {
	private String provinces;
	
	public ProvinceView(int rc, String msg, String provinces) {
		super(rc, msg);
		this.provinces = provinces;
	}
	
	public ProvinceView() {
		super(0, "");
	}
	
	public String getProvinces() {
		return provinces;
	}

	public void setProvinces(String provinces) {
		this.provinces = provinces;
	}	
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("provinces:" + this.provinces+";");
		return buffer.toString();
	}
}
