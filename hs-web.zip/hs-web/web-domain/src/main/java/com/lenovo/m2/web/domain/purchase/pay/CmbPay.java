package com.lenovo.m2.web.domain.purchase.pay;

/**
 * <br> 招行账号Bean
 * @author jinchen
 *
 */
public class CmbPay {
	private String cmb_key;
	private String cmb_branchid;
	private String cmb_user;
	private String cmb_password;
	private String cmb_cono;
	
	public String getCmb_key() {
		return cmb_key;
	}
	public void setCmb_key(String cmb_key) {
		this.cmb_key = cmb_key;
	}
	public String getCmb_branchid() {
		return cmb_branchid;
	}
	public void setCmb_branchid(String cmb_branchid) {
		this.cmb_branchid = cmb_branchid;
	}
	public String getCmb_user() {
		return cmb_user;
	}
	public void setCmb_user(String cmb_user) {
		this.cmb_user = cmb_user;
	}
	public String getCmb_password() {
		return cmb_password;
	}
	public void setCmb_password(String cmb_password) {
		this.cmb_password = cmb_password;
	}
	public String getCmb_cono() {
		return cmb_cono;
	}
	public void setCmb_cono(String cmb_cono) {
		this.cmb_cono = cmb_cono;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("cmb_key:" + this.cmb_key + ",")
		.append("cmb_branchid:" + this.cmb_branchid + ",")
		.append("cmb_user:" + this.cmb_user + ",")
		.append("cmb_password:" + this.cmb_password + ",")
		.append("cmb_cono:" + this.cmb_cono)
		;
		return buffer.toString();
	}
}
