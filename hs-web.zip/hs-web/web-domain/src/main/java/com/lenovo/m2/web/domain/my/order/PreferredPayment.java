package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by mayan3 on 2015/12/2.
 */
public class PreferredPayment implements Serializable {

    private Money blackBeans; //黑豆
    private Money coupons;  //优惠券使用金额
    private Money couponCode; //优惠码使用金额
    private Money fullReduce;
    private Money happyBeans;//乐豆（金额）
    private Money voucherTotalAmount;//代金券

    public Money getBlackBeans() {
        return blackBeans;
    }

    public void setBlackBeans(Money blackBeans) {
        this.blackBeans = blackBeans;
    }

    public Money getCoupons() {
        return coupons;
    }

    public void setCoupons(Money coupons) {
        this.coupons = coupons;
    }

    public Money getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(Money couponCode) {
        this.couponCode = couponCode;
    }

    public Money getFullReduce() {
        return fullReduce;
    }

    public void setFullReduce(Money fullReduce) {
        this.fullReduce = fullReduce;
    }

    public Money getHappyBeans() {
        return happyBeans;
    }

    public void setHappyBeans(Money happyBeans) {
        this.happyBeans = happyBeans;
    }

    public Money getVoucherTotalAmount() {
        return voucherTotalAmount;
    }

    public void setVoucherTotalAmount(Money voucherTotalAmount) {
        this.voucherTotalAmount = voucherTotalAmount;
    }
}
