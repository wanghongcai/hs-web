package com.lenovo.m2.web.domain.my.enums;

import java.util.HashMap;
import java.util.Map;

public enum ShopIdEnum {
    LENOVO(1, "lenovo"),
    THINK(2, "think"),
    EPP(3, "epp"),
    ROMING(4, "roming"),
    MOTO(5, "moto"),
    DONGDE(6, "dongde"),
    THINKCENTER(7, "thinkcenter"),
    SMB(8, "17 商城"),
    SMB_SCORE(9, "17积分商城"),
    PCSD(11, "PCSD商城"),
    HUISHANG(14, "慧商商城"),
    HUISHANG_SCORE(15, "慧商积分商城"),
    INDIAM_MOTO(16, "印度摩托");

    private final int type;
    private final String descr;
    private static Map<Integer, ShopIdEnum> lookupmap;

    private ShopIdEnum(int type, String descr) {
        this.type = type;
        this.descr = descr;
    }

    public int getType() {
        return this.type;
    }

    public String getDescr() {
        return this.descr;
    }


    public static ShopIdEnum getValueByType(int type) {
        return (ShopIdEnum)lookupmap.get(Integer.valueOf(type));
    }

    public static boolean isThink(Integer shopid) {
        return null == shopid?false:THINK.getType() == shopid.intValue();
    }

    public static boolean isEpp(Integer shopid) {
        return EPP.getType() == shopid.intValue();
    }

    public static boolean isB2C(Integer shopId) {
        return null == shopId?false:LENOVO.getType() == shopId.intValue();
    }

    public static boolean isMoto(Integer shopId) {
        return null == shopId?false:MOTO.getType() == shopId.intValue();
    }

    public static boolean isSmb(Integer shopId) {
        return null == shopId?false:SMB.getType() == shopId.intValue();
    }

    public static boolean isSmb_Score(Integer shopId) {
        return null == shopId?false:SMB_SCORE.getType() == shopId.intValue();
    }

    public static boolean isPCSD(Integer shopId) {
        return null == shopId?false:PCSD.getType() == shopId.intValue();
    }

    public static boolean isHuiShang(Integer shopId) {
        return null == shopId?false:HUISHANG.getType() == shopId.intValue();
    }

    public static boolean isIndiam_Moto(Integer shopId) {
        return null == shopId?false:INDIAM_MOTO.getType() == shopId.intValue();
    }

    public static boolean isHuiShang_score(Integer shopId) {
        return null == shopId?false:HUISHANG_SCORE.getType() == shopId.intValue();
    }

    public static boolean isRoming(Integer shopId) {
        return false;
    }

    static {
        lookupmap = new HashMap();
        ShopIdEnum[] var0 = values();
        int var1 = var0.length;

        for(int var2 = 0; var2 < var1; ++var2) {
            ShopIdEnum type = var0[var2];
            lookupmap.put(Integer.valueOf(type.type), type);
        }

    }
}
