package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * <br>返回收货信息添加后的结果到前台
 * @author shenjc
 *
 */
public class MemberAddressAddView extends BaseInfo {
	private String deliverid;
	public MemberAddressAddView(int rc, String msg, String deliverid) {
		super(rc, msg);
		this.deliverid = deliverid;
	}
	
	public MemberAddressAddView() {
		super(1, "添加收货信息失败");
	}
	
	public String getDeliverid() {
		return deliverid;
	}

	public void setDeliverid(String deliverid) {
		this.deliverid = deliverid;
	}
	
	
	/*public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("deliverid:" + this.deliverid+";");
		return buffer.toString();
	}*/
	
}
