package com.lenovo.m2.web.domain.my.order.newdb;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Created by zhangzhen on 16/7/8.
 */
public class Reverse implements Serializable {
    public static Logger LOGGER =  LogManager.getLogger(Reverse.class);

    private static Map<String, String> rApplyKPrefixMap = new HashMap<String, String>();

    static {
        rApplyKPrefixMap.put("0", "K");
        rApplyKPrefixMap.put("5", "T");
        rApplyKPrefixMap.put("6", "E");
        rApplyKPrefixMap.put("7", "G");
        rApplyKPrefixMap.put("8", "AP");
        rApplyKPrefixMap.put("9", "AG");
        rApplyKPrefixMap.put("10", "WS");
        rApplyKPrefixMap.put("11", "WG");
        rApplyKPrefixMap.put("12", "WA");
        rApplyKPrefixMap.put("13", "WP");
        rApplyKPrefixMap.put("16", "MBG");
        rApplyKPrefixMap.put("17", "T");
        rApplyKPrefixMap.put("18", "T");
        rApplyKPrefixMap.put("19", "T");
    }

    public final static int REVERSE_TYPE_REVOKE = 1;
    public final static int REVERSE_TYPE_RETURN = 2;
    public final static int REVERSE_TYPE_EXCHANGE = 3;
    public final static int AUDIT_STATUS_UNAUDITED = 0;
    public final static int AUDIT_STATUS_ACCEPTED = 1;
    public final static int AUDIT_STATUS_REJECTED = 2;

    private long id;  //订单号

    private long orderId;

    private String reason;

    private String category;

    private String description;

    private boolean complete;

    private int type;

    private int auditStatus;

    private String goodsCodes;

    private String goodsNames;

    private String sns;

    private String refuseReason;

    private String rApplyK;

    private String serviceMode;

    private boolean throwing;

    private String outId;

    private String remark;  //退货原因

    private int version;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp createTime;

    private String createBy;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp updateTime;

    private String updateBy;

    private String returnAddress;

    private boolean needReturnStock;


    private Main main;

    private ReverseDeliveryAddress deliveryAddress;

    private List<ReverseItem> items;//退换货item列表

    private Refund refund;

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isComplete() {
        return complete;
    }

    public void setComplete(boolean complete) {
        this.complete = complete;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(int auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getGoodsCodes() {
        return goodsCodes;
    }

    public void setGoodsCodes(String goodsCodes) {
        this.goodsCodes = goodsCodes;
    }

    public String getGoodsNames() {
        return goodsNames;
    }

    public void setGoodsNames(String goodsNames) {
        this.goodsNames = goodsNames;
    }

    public String getSns() {
        return sns;
    }

    public void setSns(String sns) {
        this.sns = sns;
    }

    public String getRefuseReason() {
        return refuseReason;
    }

    public void setRefuseReason(String refuseReason) {
        this.refuseReason = refuseReason;
    }

    public String getrApplyK() {
        return rApplyK;
    }

    public void setrApplyK(String rApplyK) {
        this.rApplyK = rApplyK;
    }

    public String getServiceMode() {
        return serviceMode;
    }

    public void setServiceMode(String serviceMode) {
        this.serviceMode = serviceMode;
    }

    public boolean isThrowing() {
        return throwing;
    }

    public void setThrowing(boolean throwing) {
        this.throwing = throwing;
    }

    public String getOutId() {
        return outId;
    }

    public void setOutId(String outId) {
        this.outId = outId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Main getMain() {
        if (main == null) {
            main = new Main();
        }
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public ReverseDeliveryAddress getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(ReverseDeliveryAddress deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public List<ReverseItem> getItems() {
        return items;
    }

    public void setItems(List<ReverseItem> items) {
        this.items = items;
    }

    public Reverse(Main main) {
        this.main = main;
    }

    public Refund getRefund() {
        if (refund == null) {
            refund = new Refund();
        }
        return refund;
    }

    public void setRefund(Refund refund) {
        this.refund = refund;
    }

    public String getReturnAddress() {
        return returnAddress;
    }

    public void setReturnAddress(String returnAddress) {
        this.returnAddress = returnAddress;
    }

    public Reverse() {
    }

    public boolean isNeedReturnStock() {
        return needReturnStock;
    }

    public void setNeedReturnStock(boolean needReturnStock) {
        this.needReturnStock = needReturnStock;
    }

    public void genRApplyK() {
        if(rApplyKPrefixMap.get(main.getSource())!=null){
            this.rApplyK = rApplyKPrefixMap.get(main.getSource()) + main.getId() + new DateTime().toString("MMdd") + new Random(System.currentTimeMillis()).nextInt(9999);
        }else{
            LOGGER.info("没有获取到订单来源："+main.getSource());
            rApplyK="9999";
        }
    }

    /**
     * 判断该订单是否可以撤单
     */
    public RemoteResult isApplyRevoke(RemoteResult remoteResult) {
        if (Main.ADD_TYPE_OTO == type) {
            remoteResult.setResultMsg("订单类型为OTO , 不允许做撤单");
            remoteResult.setSuccess(false);
            return remoteResult;
        } else if (Main.FA_TYPE_RESELLERS == main.getFaType()) {
            return remoteResult;
        } else if ((Main.FA_TYPE_DIRECT == main.getFaType() || Main.FA_TYPE_DONGDE == main.getFaType() || Main.FA_TYPE_THINK_DIRECT == main.getFaType() || Main.FA_TYPE_MBG == main.getFaType() || Main.FA_TYPE_THINK_RESELLERS == main.getFaType()) && Main.STATUS_UN_SHIPPED == main.getStatus()) {
            return remoteResult;
        } else {//fa=1；fa(0,2,3,4)且未发货。这两种情况允许撤单
            remoteResult.setResultMsg("FATYPE为1或者为(0,2,3,4)且未发货。这两种情况允许撤单");
            remoteResult.setSuccess(false);
            return remoteResult;
        }
    }

    /**
     * 撤单申请--是否需要同步btcp
     */
    public boolean needSynchronizeBTCP() {
        if (Main.FA_TYPE_MBG == main.getFaType() || Main.FA_TYPE_THINK_RESELLERS == main.getFaType()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 撤单申请--是否是懂得订单
     */
    public boolean isDongDeApplyRevoke() {
        if (Main.FA_TYPE_DONGDE == main.getFaType()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 撤单申请--是否需要同步或者锁定(预处理)
     */
    public boolean isSynchOrLockOperate() {
        if (Main.FA_TYPE_RESELLERS == main.getFaType()) {
            return false;
        } else if (111111 == main.getStatus() && Main.FA_TYPE_MBG != main.getFaType() && Main.FA_TYPE_THINK_RESELLERS != main.getFaType() && Main.FA_TYPE_DONGDE != main.getFaType()) {//TODO:抛单状态 是否抛单
            return false;
        } else {
            return true;
        }
    }

    /**
     * 撤单申请--通知manager 工厂 需要具体的  manager
     */
    public String getOperateType() {
        if (Main.FA_TYPE_RESELLERS == main.getFaType()) {
            return "simple";
        } else if (StringUtils.isNotEmpty(main.getOutId())) {//已抛送成功
            if (Main.FA_TYPE_MBG == main.getFaType() || Main.FA_TYPE_THINK_RESELLERS == main.getFaType()) {
                return "btcp";
            } else if (Main.FA_TYPE_DONGDE == main.getFaType()) {
                return "dongde";
            } else {
                return "simple";
            }
        } else {
            return "dispatch";
        }
    }

    /**
     * 校验退货申请入参
     *
     * @return
     */
    public RemoteResult validateApplyReturn() {
        RemoteResult remoteResult = new RemoteResult();
        if (StringUtils.isEmpty(this.reason)) {
            remoteResult.setResultCode("1001");
            remoteResult.setResultMsg("退货原因不能为空");
        } else {
            remoteResult.setSuccess(true);
        }
        return remoteResult;
    }

    @Override
    public String toString() {
        return "Reverse{" +
                "id=" + id +
                ", orderId=" + orderId +
                ", reason='" + reason + '\'' +
                ", category='" + category + '\'' +
                ", description='" + description + '\'' +
                ", complete=" + complete +
                ", type=" + type +
                ", auditStatus=" + auditStatus +
                ", goodsCodes='" + goodsCodes + '\'' +
                ", goodsNames='" + goodsNames + '\'' +
                ", sns='" + sns + '\'' +
                ", refuseReason='" + refuseReason + '\'' +
                ", rApplyK='" + rApplyK + '\'' +
                ", serviceMode='" + serviceMode + '\'' +
                ", throwing=" + throwing +
                ", outId='" + outId + '\'' +
                ", remark='" + remark + '\'' +
                ", version=" + version +
                ", createTime=" + createTime +
                ", createBy='" + createBy + '\'' +
                ", updateTime=" + updateTime +
                ", updateBy='" + updateBy + '\'' +
                ", returnAddress='" + returnAddress + '\'' +
                ", main=" + main +
                ", deliveryAddress=" + deliveryAddress +
                ", items=" + items +
                ", refund=" + refund +
                '}';
    }
}
