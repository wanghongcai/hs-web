package com.lenovo.m2.web.domain.my.order;


import java.io.Serializable;

/**提供给cerp客服系统的订单bean
 * Created by yezhenyue on 2016/1/19.
 */
public class OrderInfoVo extends OrderDetailListJSONOrderList implements Serializable {
    private String shipName;// 收货人姓名
    private String shipMobile;// 收货人手机
    private String shipAddress;//收货人详细地址

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public String getShipMobile() {
        return shipMobile;
    }

    public void setShipMobile(String shipMobile) {
        this.shipMobile = shipMobile;
    }

    public String getShipAddress() {
        return shipAddress;
    }

    public void setShipAddress(String shipAddress) {
        this.shipAddress = shipAddress;
    }
}
