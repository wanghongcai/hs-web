package com.lenovo.m2.web.domain.purchase.pay;

import com.lenovo.m2.web.common.purchase.util.B2CMainConfig;
import com.lenovo.m2.web.common.purchase.util.MD5;

import java.io.UnsupportedEncodingException;

/**
 * <br>支付宝支付所需Bean
 * @author shenjc
 *
 */
public class AliPcPayBean {
	final private String url = B2CMainConfig.getPayAli_pcALIPAY_GATEWAY_NEW();//"https://www.alipay.com/cooperate/gateway.do";
	//	卖家email或者seller_id
	private String seller_email;
	// 通知url
	final private String notify_url = B2CMainConfig.getPayAli_pcNotify_url();
	//	支付类型：1
	final private String payment_type="1";
	// 接口名称：直接支付
	final private String service="trade_create_by_buyer";
	// 	合作伙伴id
	private String partner;
	// 编码方式
	final private String _input_charset="utf-8";
	// 单价
	private String total_fee;
	// 外部交易号
	private String out_trade_no;
	// 商品名称
	private String subject;
	// 返回url
	final private String return_url = B2CMainConfig.getPayAli_pcCall_back_url();
	// 签名
	private String sign;
	// 签名方式
	final private String sign_type="MD5";
	
	//=================MD5加密秘钥=====================
	private String key;
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String toHtml() throws UnsupportedEncodingException {
		if (seller_email == null) {
			return null;
		}
		this.sign = this.toGetSign();
		StringBuffer sb = new StringBuffer();
		sb.append("<form  id=\"alipaysubmit\" name=\"alipaysubmit\" action=\""+new String(this.url.getBytes(), "utf-8")+"\" method=\"get\">")
		.append("<input type=\"hidden\" name=\"seller_email\" value=\""+new String(this.seller_email.getBytes(), "utf-8")+"\" />")
//		.append("<input type=\"hidden\" name=\"notify_url\" value=\""+new String(this.notify_url.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"payment_type\" value=\""+new String(this.payment_type.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"service\" value=\""+new String(this.service.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"partner\" value=\""+new String(this.partner.getBytes(), "utf-8")+"\" />")
//		.append("<input type=\"hidden\" name=\"_input_charset\" value=\""+new String(this._input_charset.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"total_fee\" value=\""+new String(this.total_fee.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"out_trade_no\" value=\""+new String(this.out_trade_no.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"subject\" value=\""+new String(this.subject.getBytes(), "utf-8")+"\" />")
//		.append("<input type=\"hidden\" name=\"return_url\" value=\""+new String(this.return_url.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"sign\" value=\""+new String(this.sign.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"hidden\" name=\"sign_type\" value=\""+new String(this.sign_type.getBytes(), "utf-8")+"\" />")
		.append("<input type=\"submit\" value=\"确认\" style=\"display:none;\"></form>")
		.append("<script>document.forms['alipaysubmit'].submit();</script>")
		;
		return sb.toString();
	}
	
	public String toHtml1() throws UnsupportedEncodingException {
		if (seller_email == null) {
			return null;
		}
		this.sign = this.toGetSign();
		StringBuffer sb = new StringBuffer();
		sb
		.append("<form  id=\"alipaysubmit\" name=\"alipaysubmit\" action=\""+this.url+"?_input_charset="+this._input_charset+"\" method=\"get\">")
		.append("<input type=\"hidden\" name=\"out_trade_no\" value=\""+this.out_trade_no+"\" />")
		.append("<input type=\"hidden\" name=\"partner\" value=\""+this.partner+"\" />")
		.append("<input type=\"hidden\" name=\"payment_type\" value=\""+this.payment_type+"\" />")
		.append("<input type=\"hidden\" name=\"seller_email\" value=\""+this.seller_email+"\" />")
//		.append("<input type=\"hidden\" name=\"notify_url\" value=\""+this.notify_url+"\" />")
		.append("<input type=\"hidden\" name=\"service\" value=\""+this.service+"\" />")
		.append("<input type=\"hidden\" name=\"sign\" value=\""+this.sign+"\" />")
		.append("<input type=\"hidden\" name=\"sign_type\" value=\""+this.sign_type+"\" />")
		.append("<input type=\"hidden\" name=\"subject\" value=\""+this.subject+"\" />")
//		.append("<input type=\"hidden\" name=\"_input_charset\" value=\""+this._input_charset+"\" />")
		.append("<input type=\"hidden\" name=\"total_fee\" value=\""+this.total_fee+"\" />")
//		.append("<input type=\"hidden\" name=\"return_url\" value=\""+URLEncoder.encode(this.return_url, "utf-8")+"\" />")
		
		
		.append("<input type=\"submit\" value=\"确认\" style=\"display:none;\"></form>")
		.append("<script>document.forms['alipaysubmit'].submit();</script>");
		/*.append("<form  id=\"alipaysubmit\" name=\"alipaysubmit\" action=\""
		+new String(this.url.getBytes(), "utf-8"))
		.append("seller_email="+URLEncoder.encode(this.seller_email, "utf-8")+"&")
		.append("notify_url="+URLEncoder.encode(this.notify_url, "utf-8")+"&")
		.append("payment_type="+URLEncoder.encode(this.payment_type, "utf-8")+"&")
		.append("service="+URLEncoder.encode(this.service, "utf-8")+"&")
		.append("partner="+URLEncoder.encode(this.partner, "utf-8")+"&")
		.append("_input_charset="+URLEncoder.encode(this._input_charset, "utf-8")+"&")
		.append("total_fee="+URLEncoder.encode(this.total_fee, "utf-8")+"&")
		.append("out_trade_no="+URLEncoder.encode(this.out_trade_no, "utf-8")+"&")
		.append("subject="+URLEncoder.encode(this.subject, "utf-8")+"&")
		.append("return_url="+URLEncoder.encode(this.return_url, "utf-8")+"&")
		.append("sign="+URLEncoder.encode(this.sign, "utf-8")+"&")
		.append("sign_type="+URLEncoder.encode(this.sign_type, "utf-8"))
		.append("\" method=\"get\">")
		.append("<input type=\"submit\" value=\"确认\" style=\"display:none;\"></form>")
		.append("<script>document.forms['alipaysubmit'].submit();</script>");*/
		return sb.toString();
	}
	
	/**
	 * <br> 获取签名
	 * @return
	 */
	public String toGetSign() {
		String text =/* "sign_type="+this.sign_type+"&"+
				"sign="+this.sign+"&"+*/
//				"return_url="+this.return_url+"&"+
				"_input_charset="+this._input_charset+"&"+
				"out_trade_no="+this.out_trade_no+"&"+
				"partner="+this.partner+"&"+
				"payment_type="+this.payment_type+"&"+
				"seller_email="+this.seller_email+"&"+
				"service="+this.service+"&"+
				"subject="+this.subject+"&"+
				"total_fee="+this.total_fee
//				"notify_url="+this.notify_url+"&"+
				;
		return MD5.sign(text, this.key, this._input_charset);
	}
	
	public String getSeller_email() {
		return seller_email;
	}
	public void setSeller_email(String seller_email) {
		this.seller_email = seller_email;
	}
	public String getNotify_url() {
		return notify_url;
	}
	public String getPayment_type() {
		return payment_type;
	}
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getTotal_fee() {
		return total_fee;
	}
	public void setTotal_fee(String total_fee) {
		this.total_fee = total_fee;
	}
	public String getOut_trade_no() {
		return out_trade_no;
	}
	public void setOut_trade_no(String out_trade_no) {
		this.out_trade_no = out_trade_no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getReturn_url() {
		return return_url;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getSign_type() {
		return sign_type;
	}
	public String getUrl() {
		return url;
	}
	public String get_input_charset() {
		return _input_charset;
	}
}
