package com.lenovo.m2.web.domain.my.order;
/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2014年12月11日
 */
public class CheckRetrun {
	
	Integer isreturn;  //1: 已换货  2:退货中  3:换货中 4:撤单中  5:已撤单 6:已退货  0:无

	Integer reviewStatus;  //1:已通过  2:未通过   3:未审批  4:审批失败  5:关闭申请
	
	Integer throwingStatus;    //0:未抛单   1：挂起  2：已抛送

	
	public Integer getThrowingStatus() {
		return throwingStatus;
	}

	public void setThrowingStatus(Integer throwingStatus) {
		this.throwingStatus = throwingStatus;
	}

	public Integer getIsreturn() {
		return isreturn;
	}

	public void setIsreturn(Integer isreturn) {
		this.isreturn = isreturn;
	}

	public Integer getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(Integer reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	
	
	
	

}
