package com.lenovo.m2.web.domain.my.order.ctc;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.web.domain.my.order.Product;

import java.io.Serializable;
import java.util.List;

/**
 * Created by jack on 2016/10/25.
 */
public class CtcOrderMessage implements Serializable{

    private String orderCode;   //订单号
    private String createTime;  //订单创建时间
    private String orderStatus; //订单状态
    private List<Product> productList;
    private Money productPrice;//订单支付金额

    private String promotionName;//推广名称

    private String promotionType;//推广类型

    private String promotionChannels; //推广渠道

    private String memberId; //c1用户

    private String lenovoId; //c2用户lenovoid

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Money getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Money productPrice) {
        this.productPrice = productPrice;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getPromotionChannels() {
        return promotionChannels;
    }

    public void setPromotionChannels(String promotionChannels) {
        this.promotionChannels = promotionChannels;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
}
