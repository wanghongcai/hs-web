package com.lenovo.m2.web.domain.purchase.address.view;

import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import com.lenovo.m2.web.domain.purchase.address.MemberAddress;

import java.util.List;


/**
 * <br> 返回查询收货信息列表
 * @author shenjc
 *
 */
public class MemberAddressListView extends BaseInfo {
	private List<MemberAddress> deliverlist;

	public MemberAddressListView(int rc, String msg, List<MemberAddress> deliverlist) {
		super(rc, msg);
		this.deliverlist = deliverlist;
	}
	
	public MemberAddressListView() {
		super(1, "查找收货信息列表失败");
	}
	
	public List<MemberAddress> getDeliverlist() {
		return deliverlist;
	}

	public void setDeliverlist(List<MemberAddress> deliverlist) {
		this.deliverlist = deliverlist;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("deliverlist:" + this.deliverlist.size()+";");
		return buffer.toString();
	}
}
