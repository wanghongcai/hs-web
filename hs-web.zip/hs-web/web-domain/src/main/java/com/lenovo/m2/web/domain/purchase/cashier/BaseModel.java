package com.lenovo.m2.web.domain.purchase.cashier;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * @descript 封装支付公共请求数据
 * @author 2015年5月19日11:23:54
 *
 */
public class BaseModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BaseModel() {
		super();
	}

	public BaseModel(HttpServletRequest request) {
		super();
		this.payType = request.getParameter("paymentTypeCode");
		this.orderId = request.getParameter("orderid");
		this.merchantCode = request.getParameter("merchantCode");
        this.lenovoId = request.getParameter("lenovoId");
        this.plat = request.getParameter("plat");
        this.orderMainCode = request.getParameter("orderMainCode");
        this.shopId = request.getParameter("shopId");
        this.terminal = request.getParameter("terminal");
	}
	//支付类型
	private String payType;
	//订单号 ，支付宝合并支付传递多个orderId，英文","分隔
	private String orderId;
	//商户号
	private String merchantCode;
    //联想id
    private String lenovoId;
    //商城平台编码 1 WAP ,2 微信,3 APP,4 PC
    private String plat;
    //商户号和订单ID 样例：GM12323|23423,GM234324|12212
    private String orderAndMerchantId;
    //订单主单号
    private String orderMainCode;
    //SHOP_ID
    private String shopId;
    //TERMINAL
    private String terminal;

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getPlat() {
        return plat;
    }

    public void setPlat(String plat) {
        this.plat = plat;
    }

    public String getOrderAndMerchantId() {
        return orderAndMerchantId;
    }

    public void setOrderAndMerchantId(String orderAndMerchantId) {
        this.orderAndMerchantId = orderAndMerchantId;
    }

    public String getOrderMainCode() {
        return orderMainCode;
    }

    public void setOrderMainCode(String orderMainCode) {
        this.orderMainCode = orderMainCode;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BaseModel baseModel = (BaseModel) o;

        if (lenovoId != null ? !lenovoId.equals(baseModel.lenovoId) : baseModel.lenovoId != null)
            return false;
        if (merchantCode != null ? !merchantCode.equals(baseModel.merchantCode) : baseModel.merchantCode != null)
            return false;
        if (orderAndMerchantId != null ? !orderAndMerchantId.equals(baseModel.orderAndMerchantId) : baseModel.orderAndMerchantId != null)
            return false;
        if (orderId != null ? !orderId.equals(baseModel.orderId) : baseModel.orderId != null)
            return false;
        if (orderMainCode != null ? !orderMainCode.equals(baseModel.orderMainCode) : baseModel.orderMainCode != null)
            return false;
        if (payType != null ? !payType.equals(baseModel.payType) : baseModel.payType != null)
            return false;
        if (plat != null ? !plat.equals(baseModel.plat) : baseModel.plat != null)
            return false;
        if (shopId != null ? !shopId.equals(baseModel.shopId) : baseModel.shopId != null)
            return false;
        if (terminal != null ? !terminal.equals(baseModel.terminal) : baseModel.terminal != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = payType != null ? payType.hashCode() : 0;
        result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
        result = 31 * result + (merchantCode != null ? merchantCode.hashCode() : 0);
        result = 31 * result + (lenovoId != null ? lenovoId.hashCode() : 0);
        result = 31 * result + (plat != null ? plat.hashCode() : 0);
        result = 31 * result + (orderAndMerchantId != null ? orderAndMerchantId.hashCode() : 0);
        result = 31 * result + (orderMainCode != null ? orderMainCode.hashCode() : 0);
        result = 31 * result + (shopId != null ? shopId.hashCode() : 0);
        result = 31 * result + (terminal != null ? terminal.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BaseModel{" +
                "payType='" + payType + '\'' +
                ", orderId='" + orderId + '\'' +
                ", merchantCode='" + merchantCode + '\'' +
                ", lenovoId='" + lenovoId + '\'' +
                ", plat='" + plat + '\'' +
                ", orderAndMerchantId='" + orderAndMerchantId + '\'' +
                ", orderMainCode='" + orderMainCode + '\'' +
                ", shopId='" + shopId + '\'' +
                ", terminal='" + terminal + '\'' +
                '}';
    }
}
