package com.lenovo.m2.web.domain.purchase.address.view;


import com.lenovo.m2.web.common.purchase.util.BaseInfo;

/**
 * 返回界面的乡镇列表
 *
 * @author licy13
 * @date 2016/7/21
 */
public class VillageView extends BaseInfo {

    private String district;

    public VillageView(int rc, String msg, String district) {
        super(rc, msg);
        this.district = district;
    }

    public VillageView() {
        super(0, "");
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("rc:" + this.getRc() + ";")
                .append("msg:" + this.getMsg() + ";")
                .append("district:" + this.district + ";");
        return buffer.toString();
    }
}
