package com.lenovo.m2.web.domain.purchase.pay;

public class WxPay {
	private String wx_partner;//收款人
	private String wx_paykey;//支付秘钥
	private String wx_branchid;//商户号
	private String wx_gatheringCode;//收款账号
	
	public String getWx_branchid() {
		return wx_branchid;
	}
	public void setWx_branchid(String wx_branchid) {
		this.wx_branchid = wx_branchid;
	}
	public String getWx_partner() {
		return wx_partner;
	}
	public void setWx_partner(String wx_partner) {
		this.wx_partner = wx_partner;
	}
	public String getWx_paykey() {
		return wx_paykey;
	}
	public void setWx_paykey(String wx_paykey) {
		this.wx_paykey = wx_paykey;
	}
	public String getWx_gatheringCode() {
		return wx_gatheringCode;
	}
	public void setWx_gatheringCode(String wx_gatheringCode) {
		this.wx_gatheringCode = wx_gatheringCode;
	}
	
	
}
