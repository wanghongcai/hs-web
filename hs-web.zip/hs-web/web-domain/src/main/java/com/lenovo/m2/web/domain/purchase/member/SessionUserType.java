package com.lenovo.m2.web.domain.purchase.member;

/**
 *
 * @author kangjie
 *
 */
public enum SessionUserType {
	/**
	 * C1用户
	 */
	C1User(1)
	//,XXX类型(2)
	//,XXX类型(4)
	//,XXX类型(8)
	//,XXX类型(16)
	;
	
	private int val;
	
	private SessionUserType(int val){
		this.val = val;
	}
	
	public int val(){
		return this.val;
	}
	
	@Override
	public String toString() {
		return "" + this.val;
	}
}
