package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by yezhenyue on 2015/12/24.
 */
public class OldForNewVo implements Serializable {
    private String orderMainId;//订单编号
    private String contactName;//联系人
    private int orderStatus;//订单状态
    private Money orderPrice;//订单价格
    private String createTime;//订单创建时间
    private String partnerId;//合作伙伴编号
    private String productName;//商品名称

    public String getOrderMainId() {
        return orderMainId;
    }

    public void setOrderMainId(String orderMainId) {
        this.orderMainId = orderMainId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Money getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(Money orderPrice) {
        this.orderPrice = orderPrice;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
