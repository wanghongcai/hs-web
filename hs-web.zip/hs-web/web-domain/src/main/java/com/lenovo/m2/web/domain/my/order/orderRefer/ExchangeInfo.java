package com.lenovo.m2.web.domain.my.order.orderRefer;

import java.io.Serializable;

/**
 * Created by yezhenyue on 2015/8/26.
 * EPP申请售后前端页面传给后端的javabean
 */
public class ExchangeInfo implements Serializable {
    Integer plat;   //平台号
    String raddressid; // 退货中心地址ID
    String rcontent;   // 换货理由
    String reasoncode; //退货原因编码(1:七天无理由退货，2：质量问题)
    String rgcode;    //商品编号
    Integer rnumber;   //换货数量
    String rorderno;  //订单编号
    String rtele;  //联系电话
    String deliberAreaName; //省名
    String deliverCounty; //区县
    Integer isPackagingComplete; //包装箱配件是否齐全

    String shipAddr;   //街道地址

    String shipCity;   //城市
    String shipMobile; // 手机号
    String shipName;  //收货人
    String shipZip;   //邮编
    String merchantId;// 1-商城 2-epp 3-神奇 4-roming 5-think
    String faType;//0,3直营  1,2,4 fa

    public ExchangeInfo() {
    }

    public String getFaType() {
        return faType;
    }

    public void setFaType(String faType) {
        this.faType = faType;
    }

    public String getDeliberAreaName() {
        return deliberAreaName;
    }

    public String getDeliverCounty() {
        return deliverCounty;
    }

    public Integer getIsPackagingComplete() {
        return isPackagingComplete;
    }

    public Integer getPlat() {
        return plat;
    }

    public String getRaddressid() {
        return raddressid;
    }


    public String getRcontent() {
        return rcontent;
    }

    public String getReasoncode() {
        return reasoncode;
    }

    public String getRgcode() {
        return rgcode;
    }


    public Integer getRnumber() {
        return rnumber;
    }


    public String getRorderno() {
        return rorderno;
    }


    public String getRtele() {
        return rtele;
    }

    public String getShipAddr() {
        return shipAddr;
    }

    public String getShipCity() {
        return shipCity;
    }

    public String getShipMobile() {
        return shipMobile;
    }

    public String getShipName() {
        return shipName;
    }

    public String getShipZip() {
        return shipZip;
    }

    public void setDeliberAreaName(String deliberAreaName) {
        this.deliberAreaName = deliberAreaName;
    }

    public void setDeliverCounty(String deliverCounty) {
        this.deliverCounty = deliverCounty;
    }

    public void setIsPackagingComplete(Integer isPackagingComplete) {
        this.isPackagingComplete = isPackagingComplete;
    }

    public void setPlat(Integer plat) {
        this.plat = plat;
    }

    public void setRaddressid(String raddressid) {
        this.raddressid = raddressid;
    }

    public void setRcontent(String rcontent) {
        this.rcontent = rcontent;
    }


    public void setReasoncode(String reasoncode) {
        this.reasoncode = reasoncode;
    }

    public void setRgcode(String rgcode) {
        this.rgcode = rgcode;
    }

    public void setRnumber(Integer rnumber) {
        this.rnumber = rnumber;
    }

    public void setRorderno(String rorderno) {
        this.rorderno = rorderno;
    }

    public void setRtele(String rtele) {
        this.rtele = rtele;
    }

    public void setShipAddr(String shipAddr) {
        this.shipAddr = shipAddr;
    }

    public void setShipCity(String shipCity) {
        this.shipCity = shipCity;
    }

    public void setShipMobile(String shipMobile) {
        this.shipMobile = shipMobile;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public void setShipZip(String shipZip) {
        this.shipZip = shipZip;
    }


    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }
}
