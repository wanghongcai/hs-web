package com.lenovo.m2.web.domain.purchase.seckill;

import java.util.Date;

/**
 * 预约信息  我的预约页面对象
 * @author lihc5
 *
 */
public class ReservationInfo implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private Integer id;
	private String code; 
	private String name;
	private Date reservationtime;
	private Date seckillstarttime;
	private Date seckillendtime;
	private String status;
	private String pic;
	private String faId;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Date getSeckillstarttime() {
		return seckillstarttime;
	}
	public void setSeckillstarttime(Date seckillstarttime) {
		this.seckillstarttime = seckillstarttime;
	}
	public Date getSeckillendtime() {
		return seckillendtime;
	}
	public void setSeckillendtime(Date seckillendtime) {
		this.seckillendtime = seckillendtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Date getReservationtime() {
		return reservationtime;
	}
	public void setReservationtime(Date reservationtime) {
		this.reservationtime = reservationtime;
	}
	public String getFaId() {
		return faId;
	}
	public void setFaId(String faId) {
		this.faId = faId;
	}
	
	
}
