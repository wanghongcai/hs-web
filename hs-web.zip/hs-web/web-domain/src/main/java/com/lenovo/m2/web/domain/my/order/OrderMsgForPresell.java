package com.lenovo.m2.web.domain.my.order;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jack on 2016/11/17.
 */
public class OrderMsgForPresell implements Serializable {

    private String phoneNumber;
    private List<Product> productList = new ArrayList<>();
    private Presell presell;

    public Presell getPresell() {
        return presell;
    }

    public void setPresell(Presell presell) {
        this.presell = presell;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
}
