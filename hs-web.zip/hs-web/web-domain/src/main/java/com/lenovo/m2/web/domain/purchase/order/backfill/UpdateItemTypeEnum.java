package com.lenovo.m2.web.domain.purchase.order.backfill;


import com.lenovo.m2.web.common.promotion.exception.BusinessException;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @ClassName: UpdateItemTypeEnum
 * @Description: 结算缓存更新内容项枚举
 * @author zhanghs
 * @date 2016年2月17日 下午5:48:14
 *
 */
public enum UpdateItemTypeEnum {
    ALL(-1,"全部属性更新"),
    DELIVER(1,"更新地址"),
    INVOICE(2,"发票"),
    PAYTYPE(3,"支付方式"),
    CMANNAGER_CODE(4,"客服经理编码"),
    ORDER_REMARK(5,"订单备注"),
    COUPONIDS(6,"优惠券"),
    COUPONCODE(7,"优惠码"),
    INNERBUYMONEY(8,"内购"),
    GIFTCARES(9,"礼品卡"),
    HAPPYBEAN(10,"乐豆"),
    SN(11,"SN码"),
    IDENTITY_ID(12,"证件信息ID"),
    CHECKOUTTYPE(13,"结算类型"),//这个类型不从前台更新。用于标示懂得通信
    DATARECOVERY(14,"数据恢复险"),
    INVOICEADDRESS(15,"收票地址"),
    INVOICEISCONSIGNEE(16,"收票地址是否同收货地址"),
    CONTRACTADDRESS(17,"合同地址"),
    CONTRACTISCONSIGNEE(18,"合同地址是否同收货地址"),
    ISSENDCONTRACT(19,"是否寄送合同"),
    PRESELLTEL(20,"预售电话"),
    CREDITINFO(21,"信用额度");
    private final int type;
    private final String descr;

    private UpdateItemTypeEnum(int type, String descr) {
        this.type = type;
        this.descr = descr;
    }



    final static Map<Integer, String> lookup = new TreeMap<Integer, String>(){

        private static final long serialVersionUID = -3457012985709276906L;

        {
            for(UpdateItemTypeEnum m : EnumSet.allOf(UpdateItemTypeEnum.class)){
                put(m.type, m.descr);
            }
        }
    };


    final static  Map<Integer, UpdateItemTypeEnum> merchantMap = new HashMap<Integer, UpdateItemTypeEnum>(){
        {
            for(UpdateItemTypeEnum m : EnumSet.allOf(UpdateItemTypeEnum.class)){
                put(m.type, m);
            }
        }
    };

    /**
     * 获取枚举类型的所有<值,名称>对
     *
     * @return
     */
    public static Map<Integer, String> toMap() {
        return lookup;
    }


    public static UpdateItemTypeEnum getValue(int type){
        if(merchantMap.containsKey(type)){
            return merchantMap.get(type);
        }else{
            throw new BusinessException("1", "非法更新项类型=" + type );
        }
    }










    public int getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

}
