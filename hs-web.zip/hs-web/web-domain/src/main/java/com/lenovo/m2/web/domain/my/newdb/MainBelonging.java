package com.lenovo.m2.web.domain.my.newdb;

import java.io.Serializable;
import java.util.Date;

public class MainBelonging implements Serializable {
    private Long orderId;

    private String clientIP;

    private String clientSystemName;

    private String clientBrowserName;

    private String c1LenovoId;

    private String enterprise;

    private String enterpriseCode;

    private String enrolledGroup;

    private String contractNo;

    private String activityID;

    private String activityName;

    private Integer activityMode;

    private String customerRemark;

    private String remark1;

    private String remark2;

    private String remark3;

    private String remark4;

    private Date createTime;

    private Date updateTime;

    private Integer version;

    private Main main;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP == null ? null : clientIP.trim();
    }

    public String getClientSystemName() {
        return clientSystemName;
    }

    public void setClientSystemName(String clientSystemName) {
        this.clientSystemName = clientSystemName == null ? null : clientSystemName.trim();
    }

    public String getClientBrowserName() {
        return clientBrowserName;
    }

    public void setClientBrowserName(String clientBrowserName) {
        this.clientBrowserName = clientBrowserName == null ? null : clientBrowserName.trim();
    }

    public String getC1LenovoId() {
        return c1LenovoId;
    }

    public void setC1LenovoId(String c1LenovoId) {
        this.c1LenovoId = c1LenovoId == null ? null : c1LenovoId.trim();
    }

    public String getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(String enterprise) {
        this.enterprise = enterprise == null ? null : enterprise.trim();
    }

    public String getEnterpriseCode() {
        return enterpriseCode;
    }

    public void setEnterpriseCode(String enterpriseCode) {
        this.enterpriseCode = enterpriseCode == null ? null : enterpriseCode.trim();
    }

    public String getEnrolledGroup() {
        return enrolledGroup;
    }

    public void setEnrolledGroup(String enrolledGroup) {
        this.enrolledGroup = enrolledGroup == null ? null : enrolledGroup.trim();
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo == null ? null : contractNo.trim();
    }

    public String getActivityID() {
        return activityID;
    }

    public void setActivityID(String activityID) {
        this.activityID = activityID == null ? null : activityID.trim();
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName == null ? null : activityName.trim();
    }

    public Integer getActivityMode() {
        return activityMode;
    }

    public void setActivityMode(Integer activityMode) {
        this.activityMode = activityMode;
    }

    public String getCustomerRemark() {
        return customerRemark;
    }

    public void setCustomerRemark(String customerRemark) {
        this.customerRemark = customerRemark == null ? null : customerRemark.trim();
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1 == null ? null : remark1.trim();
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2 == null ? null : remark2.trim();
    }

    public String getRemark3() {
        return remark3;
    }

    public void setRemark3(String remark3) {
        this.remark3 = remark3 == null ? null : remark3.trim();
    }

    public String getRemark4() {
        return remark4;
    }

    public void setRemark4(String remark4) {
        this.remark4 = remark4 == null ? null : remark4.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    @Override
    public String toString() {
        return "MainBelonging{" +
                "orderId=" + orderId +
                ", clientIP='" + clientIP + '\'' +
                ", clientSystemName='" + clientSystemName + '\'' +
                ", clientBrowserName='" + clientBrowserName + '\'' +
                ", c1LenovoId='" + c1LenovoId + '\'' +
                ", enterprise='" + enterprise + '\'' +
                ", enterpriseCode='" + enterpriseCode + '\'' +
                ", enrolledGroup='" + enrolledGroup + '\'' +
                ", contractNo='" + contractNo + '\'' +
                ", activityID='" + activityID + '\'' +
                ", activityName='" + activityName + '\'' +
                ", activityMode=" + activityMode +
                ", customerRemark='" + customerRemark + '\'' +
                ", remark1='" + remark1 + '\'' +
                ", remark2='" + remark2 + '\'' +
                ", remark3='" + remark3 + '\'' +
                ", remark4='" + remark4 + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", version=" + version +
                '}';
    }
}