package com.lenovo.m2.web.domain.my.order.mysqobject;

/**
 * Created by jack on 2016/9/8.
 */
public class MysqlMoveToMongo {

    /*****  我的订单要和mysql解耦，  *******
     *
     *
     * 第一步：迁移历史mysql数据到mongo、（反向调用接口，不需要迁移反向数据）
     *
     * 第二步：修改项目中所有查询mysql的地方，全部查询mongo
     *
     * 第三步：项目切换前提（所有操作已经开始操作mongodb，才能切掉数据源）
     *
     *
     *
     *
     *
     *
     *
     *
     *
     * ************/


}
