package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by jiangzh5 on 2015/7/28.
 */
public class OrderDetailListJSONOrderListGlist implements Serializable {
    private String gcode;    //商品编码
    private String gMaterial; //物料
    private String gname;    //商品名称
    private String gexchange;    //换货状态名称（如果为空表示不是在换货）
    private String evalstatus;    //评价状态（如果为空表示没有评价）
    private String gdesc;    //商品描述
    private String gphoto;    //商品图片url
    private Money gprice;    //商品单价
    private Money grealprice;    //成交价格
    private String gspec;    //商品规格列表，如颜色，内存大小等（按数据库标记的顺序进行排序）。	（单个规则为数组方式，索引0处为规格名，索引1处为规格值）,[[“颜色”,”红色”],[“内存”,”16G”]]
    private String gcount;    //商品数量
    private String groupingID;
    private String deatLike;
    private String isPhysical;
    private String isServiceProd;
    private String phoneServiceNumber;
    private String feeInfo;
    private String numberDetail;
    private String araeCodeName;
    private String salesType;
    private String url;
    private String faid;
    private String thinkname;
    private String thinkpricture;

    // 购买服务时，绑定的SN号。
    private String machineSN;
    private String serviceCode;
    private String skuType;

    @Override
    public String toString() {
        return "OrderDetailListJSONOrderListGlist{" +
                "gcode='" + gcode + '\'' +
                ", gMaterial='" + gMaterial + '\'' +
                ", gname='" + gname + '\'' +
                ", gexchange='" + gexchange + '\'' +
                ", evalstatus='" + evalstatus + '\'' +
                ", gdesc='" + gdesc + '\'' +
                ", gphoto='" + gphoto + '\'' +
                ", gprice=" + gprice +
                ", grealprice=" + grealprice +
                ", gspec='" + gspec + '\'' +
                ", gcount='" + gcount + '\'' +
                ", groupingID='" + groupingID + '\'' +
                ", deatLike='" + deatLike + '\'' +
                ", isPhysical='" + isPhysical + '\'' +
                ", isServiceProd='" + isServiceProd + '\'' +
                ", phoneServiceNumber='" + phoneServiceNumber + '\'' +
                ", feeInfo='" + feeInfo + '\'' +
                ", numberDetail='" + numberDetail + '\'' +
                ", araeCodeName='" + araeCodeName + '\'' +
                ", salesType='" + salesType + '\'' +
                ", url='" + url + '\'' +
                ", faid='" + faid + '\'' +
                ", thinkname='" + thinkname + '\'' +
                ", thinkpricture='" + thinkpricture + '\'' +
                ", machineSN='" + machineSN + '\'' +
                ", serviceCode='" + serviceCode + '\'' +
                ", skuType='" + skuType + '\'' +
                '}';
    }

    public String getSkuType() {
        return skuType;
    }

    public void setSkuType(String skuType) {
        this.skuType = skuType;
    }

    public String getgMaterial() {
        return gMaterial;
    }

    public void setgMaterial(String gMaterial) {
        this.gMaterial = gMaterial;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getMachineSN() {
        return machineSN;
    }

    public void setMachineSN(String machineSN) {
        this.machineSN = machineSN;
    }

    public String getThinkname() {
        return thinkname;
    }

    public void setThinkname(String thinkname) {
        this.thinkname = thinkname;
    }

    public String getThinkpricture() {
        return thinkpricture;
    }

    public void setThinkpricture(String thinkpricture) {
        this.thinkpricture = thinkpricture;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSalesType() {
        return salesType;
    }

    public void setSalesType(String salesType) {
        this.salesType = salesType;
    }

    public String getAraeCodeName() {
        return araeCodeName;
    }

    public void setAraeCodeName(String araeCodeName) {
        this.araeCodeName = araeCodeName;
    }

    public String getFeeInfo() {
        return feeInfo;
    }

    public void setFeeInfo(String feeInfo) {
        this.feeInfo = feeInfo;
    }

    public String getNumberDetail() {
        return numberDetail;
    }

    public void setNumberDetail(String numberDetail) {
        this.numberDetail = numberDetail;
    }

    public String getPhoneServiceNumber() {
        return phoneServiceNumber;
    }

    public void setPhoneServiceNumber(String phoneServiceNumber) {
        this.phoneServiceNumber = phoneServiceNumber;
    }

    public String getIsPhysical() {
        return isPhysical;
    }

    public void setIsPhysical(String isPhysical) {
        this.isPhysical = isPhysical;
    }

    public String getIsServiceProd() {
        return isServiceProd;
    }

    public void setIsServiceProd(String isServiceProd) {
        this.isServiceProd = isServiceProd;
    }

    public String getDeatLike() {
        return deatLike;
    }

    public void setDeatLike(String deatLike) {
        this.deatLike = deatLike;
    }

    public String getGroupingID() {
        return groupingID;
    }

    public void setGroupingID(String groupingID) {
        this.groupingID = groupingID;
    }

    public String getGcode() {
        return gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGexchange() {
        return gexchange;
    }

    public void setGexchange(String gexchange) {
        this.gexchange = gexchange;
    }

    public String getEvalstatus() {
        return evalstatus;
    }

    public void setEvalstatus(String evalstatus) {
        this.evalstatus = evalstatus;
    }

    public String getGdesc() {
        return gdesc;
    }

    public void setGdesc(String gdesc) {
        this.gdesc = gdesc;
    }

    public String getGphoto() {
        return gphoto;
    }

    public void setGphoto(String gphoto) {
        this.gphoto = gphoto;
    }

    public Money getGprice() {
        return gprice;
    }

    public void setGprice(Money gprice) {
        this.gprice = gprice;
    }

    public Money getGrealprice() {
        return grealprice;
    }

    public void setGrealprice(Money grealprice) {
        this.grealprice = grealprice;
    }

    public String getGspec() {
        return gspec;
    }

    public void setGspec(String gspec) {
        this.gspec = gspec;
    }

    public String getGcount() {
        return gcount;
    }

    public void setGcount(String gcount) {
        this.gcount = gcount;
    }


}
