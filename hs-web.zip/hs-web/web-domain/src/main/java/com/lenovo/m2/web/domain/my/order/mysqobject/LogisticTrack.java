package com.lenovo.m2.web.domain.my.order.mysqobject;

import java.io.Serializable;

/**
 * Created by lzg on 2016/8/7.
 */
public class LogisticTrack implements Serializable {

    private String trackTime;

    private String trackDescription;

    public String getTrackTime() {
        return trackTime;
    }

    public void setTrackTime(String trackTime) {
        this.trackTime = trackTime;
    }

    public String getTrackDescription() {
        return trackDescription;
    }

    public void setTrackDescription(String trackDescription) {
        this.trackDescription = trackDescription;
    }
}
