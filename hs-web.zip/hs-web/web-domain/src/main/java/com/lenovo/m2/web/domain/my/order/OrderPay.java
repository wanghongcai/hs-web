package com.lenovo.m2.web.domain.my.order;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;

/**
 * Created by jiangzh5 on 2015/8/7.
 */
public class OrderPay implements Serializable {
    private String ptime;// 支付时间
    private String pno;// 支付单号
    private String pfrom;// 支付来源
    private Money pmoney;// 支付金额

//add by yezhenyue 2015/12/21
    private String paymentLX;// 付款类型  1线上支付 2线下支付
    private String payment;// 支付方式  0 招商银行, 1支付宝, 4支付宝直连支付,2或7银联支付,10或17农行分期，16微信支付

    public String getPaymentLX() {
        return paymentLX;
    }

    public void setPaymentLX(String paymentLX) {
        this.paymentLX = paymentLX;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPfrom() {
        return pfrom;
    }

    public void setPfrom(String pfrom) {
        this.pfrom = pfrom;
    }

    public Money getPmoney() {
        return pmoney;
    }

    public void setPmoney(Money pmoney) {
        this.pmoney = pmoney;
    }

    public String getPtime() {
        return ptime;
    }

    public void setPtime(String ptime) {
        this.ptime = ptime;
    }

    public String getPno() {
        return pno;
    }

    public void setPno(String pno) {
        this.pno = pno;
    }

}
