package com.lenovo.m2.web.domain.my.newdb;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yyduff on 2015/6/26.
 */
public class MBGorderCode {

    public static final int len = 10;

    public static String gainOrderNo(Main orderMain) {
        String orderCode = String.valueOf(orderMain.getId());
        String orderDate = new SimpleDateFormat("yyMMdd").format(orderMain.getCreateTime());
        return orderDate + assembleOrderNo(orderCode);
    }

    public static String gainOrderNo(String orderCode, Timestamp orderTime) {
        String orderDate = new SimpleDateFormat("yyMMdd").format(orderTime);
        return orderDate + assembleOrderNo(orderCode);
    }

    public static String getOrderSourceLettterCodeByPlat(String sourceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "GM");
        map.put("1", "VM");
        map.put("2", "ECS");
        map.put("3", "EJD");
        map.put("4", "ESN");
        map.put("5", "TH");
        map.put("6", "EPP");
        map.put("7", "GS");
        map.put("8", "APP");
        map.put("9", "ASG");
        map.put("10", "EVS");
        map.put("11", "VSG");
        map.put("12", "WAP");
        map.put("13", "WSG");
        map.put("14", "VMV");
        map.put("15", "EPK");
        map.put("16", "MBG");
        map.put("17", "TH");
        map.put("18", "TH");
        map.put("19", "TH");
        map.put("20", "TB");
        map.put("21", "NBD");
        map.put("22", "");
        map.put("23", "EGM");
        String key = sourceId;
        String value = map.get(key);
        if (value == null) value = "";
        return value;
    }

    public static String getOrderSourceLettterCodeByPlat(String plat, String saleType) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("80", "TH");
        map.put("81", "TH");
        map.put("84", "TH");
        map.put("82", "TH");
        map.put("34", "APP");
        map.put("41", "GS");
        map.put("24", "EVS");
        map.put("14", "WAP");
        map.put("44", "GM");
        map.put("50", "TH");
        map.put("51", "TH");
        map.put("54", "TH");
        map.put("52", "TH");
        map.put("30", "APP");
        map.put("31", "ASG");
        map.put("20", "EVS");
        map.put("21", "VSG");
        map.put("10", "WAP");
        map.put("11", "WSG");
        map.put("40", "GM");
        map.put("12", "WAP");
        map.put("22", "EVS");
        map.put("32", "APP");
        map.put("42", "GM");
        map.put("15", "WAP");
        map.put("25", "EVS");
        map.put("35", "APP");
        map.put("45", "GM");
        map.put("220", "EPP");
        map.put("200", "EPP");
        map.put("496", "GM");
        String key = plat + saleType;
        String value = map.get(key);
        if (value == null) value = "";
        return value;
    }

    private static String assembleOrderNo(String orderCode) {
        StringBuffer orderCodeBuffer = new StringBuffer();
        if (orderCode.length() < len) {
            for (int i = 0; i < (len - orderCode.length()); i++) {
                orderCodeBuffer.append("0");
            }
        }
        return orderCodeBuffer.append(orderCode).toString();
    }


}
