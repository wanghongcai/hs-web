package com.lenovo.m2.web.domain.my.order;

/**
 * Created by mayan3 on 2015/11/27.
 */
public class ProcessTimeInfo {
    private String orderDate;//下单时间
    private String payDate;//支付时间
    private String waitReceiptDate;//等待收货
    private String receiveDate;//签收

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getPayDate() {
        return payDate;
    }

    public void setPayDate(String payDate) {
        this.payDate = payDate;
    }

    public String getWaitReceiptDate() {
        return waitReceiptDate;
    }

    public void setWaitReceiptDate(String waitReceiptDate) {
        this.waitReceiptDate = waitReceiptDate;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }
}
