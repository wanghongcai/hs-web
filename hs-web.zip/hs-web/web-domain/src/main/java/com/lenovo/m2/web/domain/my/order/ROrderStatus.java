package com.lenovo.m2.web.domain.my.order;

import java.util.Date;

/**
 * @description 
 * @author 史彦磊
 * @version 1.0
 *  2015年1月28日
 */
public class ROrderStatus {
	Integer rstatus;  //退换货申请审批状态 orderdelivery 表中的reviewStatus字段
	Date ordtime;     //退换货申请审批状态时间 orderdelivery updatetime字段
	String ordertype; // 订单类型  RE 退货   ZSD 换货
	Integer isreturn;  //退换货结果状态  ordermain 表中的isreturn字段
	Date isretime;    // ordermain 表中的updatetime字段
	public Integer getRstatus() {
		return rstatus;
	}
	public void setRstatus(Integer rstatus) {
		this.rstatus = rstatus;
	}
	public Date getOrdtime() {
		return ordtime;
	}
	public void setOrdtime(Date ordtime) {
		this.ordtime = ordtime;
	}
	public String getOrdertype() {
		return ordertype;
	}
	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}
	public Integer getIsreturn() {
		return isreturn;
	}
	public void setIsreturn(Integer isreturn) {
		this.isreturn = isreturn;
	}
	public Date getIsretime() {
		return isretime;
	}
	public void setIsretime(Date isretime) {
		this.isretime = isretime;
	}
	
	
	
	
	
	

}
