package com.lenovo.m2.web.domain.purchase.pay;

import com.lenovo.m2.web.common.purchase.util.BaseInfo;


public class PayInfo extends BaseInfo {
	private String content;
	
	public PayInfo(int rc, String msg, String content) {
		super(rc, msg);
		this.content = content;
	}
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rc:"+this.getRc()+";")
		.append("msg:"+this.getMsg()+";")
		.append("bodyHtml:" + this.getContent()+";");
		return buffer.toString();
	}
}
