package com.lenovo.m2.web.domain.purchase.cashier;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by caoxd2 on 2015/5/29.
 */
public class AliCallbackBaseModel {
    private String gmtPayment;
    private String notifyId;
    private String signType;
    private String sign;
    private String orderNo;
    private String tradeNo;
    private String tradeStatus;
    private String extraCommonData;

    public AliCallbackBaseModel(HttpServletRequest request){
        this.extraCommonData = request.getParameter("extra_common_param");
        this.gmtPayment = request.getParameter("gmt_payment").replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        this.notifyId = request.getParameter("notify_id");
        this.orderNo = request.getParameter("out_trade_no");
        this.signType = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.tradeNo = request.getParameter("trade_no");
        this.tradeStatus = request.getParameter("trade_status");
    }

    public String getGmtPayment() {
        return gmtPayment;
    }

    public void setGmtPayment(String gmtPayment) {
        this.gmtPayment = gmtPayment;
    }

    public String getNotifyId() {
        return notifyId;
    }

    public void setNotifyId(String notifyId) {
        this.notifyId = notifyId;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(String tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    public String getExtraCommonData() {
        return extraCommonData;
    }

    public void setExtraCommonData(String extraCommonData) {
        this.extraCommonData = extraCommonData;
    }
}
