package com.lenovo.m2.web.domain.my.order;


import java.io.Serializable;

/**
 * Created by jiangzh5 on 2015/8/20.
 */
public class UserProduct extends OrderDetailListJSONOrderListGlist implements Serializable {
    String orderTime;

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }
}
