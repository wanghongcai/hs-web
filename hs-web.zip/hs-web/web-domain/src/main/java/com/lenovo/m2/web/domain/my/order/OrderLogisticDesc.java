package com.lenovo.m2.web.domain.my.order;


import com.lenovo.m2.web.common.my.utils.DateUtil;

import java.io.Serializable;

/**
 * Created by jiangzh5 on 2015/8/7.
 */
public class OrderLogisticDesc implements Serializable,Comparable<OrderLogisticDesc> {

    private String lgtime;
    private String lgdesc;
    private String operator;//操作人
    private String orderCode;
    private String merchantId;
    private String lenovoId;
    private String memberId;
    private boolean isWap;

    public boolean isWap() {
        return isWap;
    }

    public void setWap(boolean wap) {
        isWap = wap;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getLgtime() {
        return lgtime;
    }
    public void setLgtime(String lgtime) {
        this.lgtime = lgtime;
    }
    public String getLgdesc() {
        return lgdesc;
    }
    public void setLgdesc(String lgdesc) {
        this.lgdesc = lgdesc;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Override
    public int compareTo(OrderLogisticDesc o) {
//        if(isWap){
            if(DateUtil.StrParseDate(this.lgtime).getTime()< DateUtil.StrParseDate(o.getLgtime()).getTime()){
                return 1;
            }else if(DateUtil.StrParseDate(this.lgtime).getTime()> DateUtil.StrParseDate(o.getLgtime()).getTime()){
                return -1;
            }else{
                return 0;
            }
//        }else{
//            if(DateUtil.StrParseDate(this.lgtime).getTime()<DateUtil.StrParseDate(o.getLgtime()).getTime()){
//                return -1;
//            }else if(DateUtil.StrParseDate(this.lgtime).getTime()>DateUtil.StrParseDate(o.getLgtime()).getTime()){
//                return 1;
//            }else{
//                return 0;
//            }
//        }

    }

}
