package com.lenovo.m2.web.domain.purchase.member;

public class MemberWithBLOBs extends Member {
    private String addon;

    private String interest;

    private String favtags;

    private String custom;

    private String remark;

    private String chatremark;

    public String getAddon() {
        return addon;
    }

    public void setAddon(String addon) {
        this.addon = addon == null ? null : addon.trim();
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest == null ? null : interest.trim();
    }

    public String getFavtags() {
        return favtags;
    }

    public void setFavtags(String favtags) {
        this.favtags = favtags == null ? null : favtags.trim();
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom == null ? null : custom.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getChatremark() {
        return chatremark;
    }

    public void setChatremark(String chatremark) {
        this.chatremark = chatremark == null ? null : chatremark.trim();
    }
}