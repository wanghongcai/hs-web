package com.lenovo.m2.web.domain.my.encrypt;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.web.common.my.lang.StringUtil;
import com.lenovo.m2.web.common.my.utils.DateUtil;
import com.lenovo.m2.web.domain.my.order.smb.SmbGoodList;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by jack on 2016/7/27.
 */
public class StringEncrypt {

    public int returnSencd(String str){
        int i = 0;
        try {
            SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date d = s.parse(str);
            Calendar c = Calendar.getInstance();
            c.setTime(d);
            i = (int)((c.getTimeInMillis() - new Date().getTime()) / 1000);
            if (i < 0){
                return 0;
            }
            return i;
        } catch (ParseException e) {
            e.printStackTrace();
            return i;
        }
    }



    public int checkDate(String str){
        SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            Date d = s.parse(str);
            Calendar c = Calendar.getInstance();
            c.setTime(d);
            //当前时间毫秒数大于设定时间  已结束
            // 当前时间毫秒数小于设定时间  未开始
            if (new Date().getTime() > c.getTimeInMillis()){
                return 0;
            }else{
                return 1;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return 1;
        }
    }

    //加密手机号中间四位
    public String encrypt(String str){
        if(StringUtil.isEmpty(str) || str.length() != 11){
            return str;
        }
        String phoneNumber = str.substring(0,3) + "****" + str.substring(str.length() - 4,str.length());
        return phoneNumber;
    }

    //解析充值类型
    public String includeString(String str){
        if(StringUtil.isEmpty(str)){
            return str;
        }
        return (str.indexOf("话费") > -1 ? "0" : "1");
    }

    //截取订单后四位显示
    public String subString(String orderno){
        if(StringUtil.isEmpty(orderno)){
            return orderno;
        }
        return orderno.substring(orderno.length()-4, orderno.length());
    }

    public String MakeAddress(String deliverAreaName, String shipCity, String deliverCounty, String shipAddr){
        StringBuffer stringBuffer = new StringBuffer();
        if (!StringUtils.isEmpty(deliverAreaName)){
            stringBuffer.append(deliverAreaName);
        }
        if (!StringUtils.isEmpty(shipCity)){
            stringBuffer.append(shipCity);
        }
        if (!StringUtils.isEmpty(deliverCounty)){
            stringBuffer.append(deliverCounty);
        }
        if (!StringUtils.isEmpty(shipAddr)){
            stringBuffer.append(shipAddr);
        }
        return stringBuffer.toString();
    }

    public String MakeOrderCodesForPingJia(List<SmbGoodList> glist){
        String orderCodes = "";
        if (glist != null && glist.size() > 0){
            for (SmbGoodList smbGoodList : glist){
                orderCodes += smbGoodList.getOrderno() + ",";
            }
            if(orderCodes != null && orderCodes.length() > 2){
                orderCodes = orderCodes.substring(0,orderCodes.length()-1);
            }
        }
        return orderCodes;
    }

    public String MakeDubboForInteger(String str){
        String s = "";
        if (!StringUtils.isEmpty(str)){
            Double d = Double.parseDouble(str);
            s = d.intValue() + "";
        }
        return s;
    }


    public static void main(String[] args){

    }

    public String makeDateFormat(Date str){
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(str);

    }

}
