package com.lenovo.m2.web.domain.purchase.pay;

/**
 * <br> 支付类型Bean
 * @author shenjc
 *
 */
public class PayType {
	private String paymentTypeName;
	private String paymentTypeCode;
	
	public String getPaymentTypeName() {
		return paymentTypeName;
	}
	public void setPaymentTypeName(String paymentTypeName) {
		this.paymentTypeName = paymentTypeName;
	}
	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}
	public void setPaymentTypeCode(String paymentTypeCode) {
		this.paymentTypeCode = paymentTypeCode;
	}
}
