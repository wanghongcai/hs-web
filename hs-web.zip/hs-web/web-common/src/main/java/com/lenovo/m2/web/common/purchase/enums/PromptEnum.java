package com.lenovo.m2.web.common.purchase.enums;

/**
 * Created by wanghao on 2017/5/19.
 */
public enum PromptEnum {

    CHECKOUT("checkout"),
    COUPON("coupon"),
    CREDIT("credit"),

    INVOICESERVICE("invoiceService"),
    IDENTITYSERVICE("identityService"),
    ADDRESSNAMESERVICE("addressNameService"),
    CONSIGNEESERVICE("consigneeService"),

    ADDRESS("address"),

    ONEKEYTORECEIVESERVICE("oneKeyToReceiveService"),
    RPCMEMBERCOUNPONRELSSERVICE("rpcMemberCounponrelsService"),

    STOCKPORTAPISERVICE_GETGLOBALSTOCKINFO("stockPortApiService.getGlobalStockInfo"),
    STOCKPORTAPISERVICE_GETGLOBALO2OSTOCKINFO("stockPortApiService.getGlobalO2OStockInfo"),
    STOCKPORTAPISERVICE_UPDATESTOCKSTATUS("stockPortApiService.updateStockStatus"),

    SUBSCRIBESERVICE_SUBSCRIBE("subscribeService.subscribe"),
    SUBSCRIBESERVICE_GETSMSTEMPLATE("subscribeService.getSmsTemplate"),
    SUBSCRIBESERVICE_SENDSMS("subscribeService.sendSMS"),

    PROMOTION("promotion"),

    CONTRACTAPISERVICE_AUTOSIGNBYMIXED("contractApiService.autoSignBymixed"),

    ORDERMIDDLEWARESERVICE_CANCELORDER("orderMiddlewareService.cancelOrder"),
    ORDERMIDDLEWAREFORPAYAPI_PAIDCALLBACK("orderMiddlewareForPayApi.paidCallback"),

    EXCHANGEGOODSSERVICE_APPLY("exchangeGoodsService.apply"),

    RETURNGOODSSERVICE_APPLY("returnGoodsService.apply"),
    RETURNGOODSSERVICE_SAVELOGISTICINFO("returnGoodsService.saveLogisticInfo"),

    REVOKEGOODSSERVICE_APPLY("revokeGoodsService.apply"),
    REVOKEGOODSSERVICE_APPLYCANCELLEDTOREVOKE("revokeGoodsService.applyCancelledToRevoke"),

    REVERSEQUERYSERVICE_QUERYREVERSEPAGE("reverseQueryService.queryReversePage"),
    REVERSEQUERYSERVICE_QUERYREVERSEBYMAP("reverseQueryService.queryReverseByMap"),

    ORDERMONGOSERVICE_GETMONGOORDERDETAIL("orderMongoService.getMongoOrderDetail"),

    PAYBILLSIGNFETTLESERVICE_INSERTSIGNFETTLESELECTIVE("payBillSignFettleService.insertSignFettleSelective"),

    ;

    private String key;

    PromptEnum(String key){
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return key;
    }

    public static void main(String[] args) {
        System.err.println(PromptEnum.CHECKOUT);
    }
}
