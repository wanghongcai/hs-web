package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.arch.framework.domain.Money;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.JsonToken;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import java.io.IOException;
import java.util.Currency;

/**
 * Created by D_xiao on 1/3/17.
 */
public class MoneyDeserializer extends JsonDeserializer<Money> {
    private static String AMOUNT = "amount";
    private static String CURRENCY_CODE = "currencyCode";
    public MoneyDeserializer() {
    }

    public Money deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        JsonToken jt = jp.getCurrentToken();
        String amount;
        if(jt == JsonToken.VALUE_STRING) {
            amount = jp.getText();
            return new Money(amount, "CNY");
        } else if(jt == JsonToken.VALUE_NUMBER_INT) {
            Integer amount2 = Integer.valueOf(jp.getIntValue());
            return new Money(String.valueOf(amount2), "CNY");
        } else if(jt == JsonToken.VALUE_NUMBER_FLOAT) {
            Float amount1 = Float.valueOf(jp.getFloatValue());
            return new Money(String.valueOf(amount1), "CNY");
        } else if(jt != JsonToken.START_OBJECT) {
            return null;
        } else {
            amount = null;
            String currency = null;

            while(jt != JsonToken.END_OBJECT) {
                if(jt == JsonToken.START_OBJECT) {
                    jt = jp.nextToken();
                } else if(jt == JsonToken.FIELD_NAME) {
                    String name = jp.getText();
                    jt = jp.nextToken();
                    String value = jp.getText();
                    if(AMOUNT.equals(name)) {
                        amount = value;
                    } else if(CURRENCY_CODE.equals(name)) {
                        currency = value;
                    }

                    jt = jp.nextToken();
                }
            }

            if(amount != null && currency != null) {
                return new Money(amount, Currency.getInstance(currency));
            } else {
                return null;
            }
        }
    }
}
