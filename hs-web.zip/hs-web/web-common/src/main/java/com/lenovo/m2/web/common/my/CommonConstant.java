package com.lenovo.m2.web.common.my;

/**
 * Created by mayan3 on 2015/11/6.
 */
public class CommonConstant {
    public static final String DEFAULT_SERVER_SECRET = "ljKYO4TdK6cU7pznq7VGT9Cf168Sez7fXWSEC-5J3pvLkT7Xpc7Ea62n3DISCXKif5JI-3x3I9QzVR4gz0K-CA";
    public static final String SEPARATOR_1 = "|";
    public static final String ORDERDETAIL_TYPE = "0";
    public static final String INVOICE_TYPE = "1";
    public static final String PRINT_TYPE = "2";
    public static final String TRACKINFO_TYPE = "3";
    public static final String INVOICE_TRACKINFO_TYPE = "3";
    public static final String OPERATION_TRACKINFO_TYPE_LIST = "4";
    public static final String OPERATION_TRACKINFO_TYPE_INFO = "5";

    public static final String DEFAULT_CONTENT_CHARSET = "UTF-8";
    public static final String STOPWATCH = "stopWatch";



}
