package com.lenovo.m2.web.common.my.parameter;

/**
 * 订单状态表 0待付款|1待发货|2待收货|3待评价|4退换货|5已完成|6已取消
 * Created by mayan3 on 2015/8/26.
 */
public enum OrderStatusEnum {

    PAYMENT("0","待发货");
//    SHIPPED("1"),
//    INBOUND("2"),
//    EVALUATION("3"),
//    RETURNS("4"),
//    COMPLETED("5"),
//    CANCEL("6");

    public String value;
    public String display;

    public String getDisplay() {
        return display;
    }

    OrderStatusEnum(String value,String display) {
        this.value = value;
        this.display = display;
    }
    public String getValue() {
        return value;
    }

    public static void main(String[] args){
        OrderStatusEnum.PAYMENT.getDisplay();

        System.out.print(OrderStatusEnum.PAYMENT.getDisplay());
    }
}
