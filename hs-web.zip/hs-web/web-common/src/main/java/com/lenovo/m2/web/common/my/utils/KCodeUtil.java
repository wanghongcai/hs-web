package com.lenovo.m2.web.common.my.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yyduff on 2015/12/4.
 */
public class KCodeUtil {
    private static Map<String, String> map = new HashMap<String, String>();
    static {
        map.put("0", "K");
        map.put("5", "T");
        map.put("6", "E");
        map.put("7", "G");
        map.put("8", "AP");
        map.put("9", "AG");

        map.put("10", "WS");
        map.put("11", "WG");
        map.put("12", "WA");

        map.put("13", "WP");

        map.put("16", "MBG");

        map.put("17", "T");
        map.put("18", "T");
        map.put("19", "T");

    }
    public static String getKCodeLetterCodeByOrderRefer(String orderRefer) {
        String value = map.get(orderRefer);
        return value == null?"":value;
    }

    public static String getOrderSourceLettterCodeByPlat(String sourceId) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("0", "GM");
        map.put("1", "VM");
        map.put("2", "ECS");
        map.put("3", "EJD");
        map.put("4", "ESN");
        map.put("5", "TH");
        map.put("6", "EPP");
        map.put("7", "GS");
        map.put("8", "APP");
        map.put("9", "ASG");
        map.put("10", "EVS");
        map.put("11", "VSG");
        map.put("12", "WAP");
        map.put("13", "WSG");
        map.put("14", "VMV");
        map.put("15", "EPK");
        map.put("17", "MBG");
        map.put("17", "TH");
        map.put("18", "TH");
        map.put("19", "TH");
        map.put("20", "TB");
        map.put("21", "NBD");
        map.put("22", "");
        map.put("23", "EGM");
        String key = sourceId;
        String value = map.get(key);
        if (value == null) value = "";
        return value;
    }
}
