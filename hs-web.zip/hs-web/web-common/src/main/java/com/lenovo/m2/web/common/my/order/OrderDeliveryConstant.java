package com.lenovo.m2.web.common.my.order;

/**
 * Created by yyduff on 2016/2/23.
 */
public class OrderDeliveryConstant {

    /**
     * 送货时间-工作日
     */
    public static final int DELIVERY_DATE_WORKING_DAY = 1;
    /**
     * 送货时间-双休日
     */
    public static final int DELIVERY_DATE_WEEKLY_REST_DAY = 2;
    /**
     * 送货时间-节假日
     */
    public static final int DELIVERY_DATE_HOLIDAYS = 3;
    /**
     * 送货时间-任意日期
     */
    public static final int DELIVERY_DATE_ANY = 4;

    /**
     * 抛送状态-未抛送
     */
    public static final int THROWING_STATUS_NOT_THROWING = 0;
    /**
     * 抛送状态-挂起-已作废
     */
    public static final int THROWING_STATUS_HANG_UP = 1;
    /**
     * 抛送状态-已抛送
     */
    public static final int THROWING_STATUS_HAVE_BEAN = 2;
    /**
     * 抛送状态-写入队列-已作废
     */
    public static final int THROWING_STATUS_SAVE_MQ = 3;

    /**
     * 发货状态-未发货
     */
    public static final int ORDER_DELIVER_NOT_SHIPPED = 0;
    /**
     * 发货状态-已发货
     */
    public static final int ORDER_DELIVER_SHIPPED = 1;
    /**
     * 发货状态-已签收
     */
    public static final int ORDER_DELIVER_SIGNED = 2;
    /**
     * 发货状态-已退货
     */
    public static final int ORDER_DELIVER_RETURNED = 3;

    /**
     * 订单审核状态-待审核
     */
    public static final int REVIEW_STATUS_WAIT_STATUS = 0;

    /**
     * 订单审核状态-已通过 审批通过 //todo 修改名字 ALLOWED
     */
    public static final int REVIEW_STATUS_HAVE_THROUGH = 1;
    /**
     * 订单审核状态-未通过 //todo 修改名字 REJECTED
     */
    public static final int REVIEW_STATUS_NTO_THROUGH = 2;
    /**
     * 订单审核状态-未审批
     */
    public static final int REVIEW_STATUS_NOT_REVIEW = 3;
    /**
     * 订单审核状态-审批失败 无用
     */
    public static final int REVIEW_STATUS_FAILURE = 4;
    /**
     * 订单审核状态-关闭申请
     */
    public static final int REVIEW_STATUS_CLOSED = 5;

    /**
     * 类型--换新单类型
     */
    public static final String ORDER_TYPE_CHANGE_NEW_ORDER = "ZRE";
    /**
     * 类型--换旧单类型
     */
    public static final String ORDER_TYPE_CHANGE_OLD_ORDER = "ZSD";
    /**
     * 类型--正向订单
     */
    public static final String ORDER_TYPE_NORMAL = "ZOR";
    /**
     * 类型--反向订单
     */
    public static final String ORDER_TYPE_RETURNED = "RE";

    /**
     * 订单审核状态-已通过 审批通过
     */
    public static final int REVIEW_STATUS_PASSED = 1;
    /**
     * 订单审核状态-驳回
     */
    public static final int REVIEW_STATUS_REJECTED = 2;


}
