package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chenww3 on 2015/6/14.
 */
public class BaseInfo {

    private static final Map<Integer, BaseInfo> map = new HashMap<Integer, BaseInfo>();
    static {
        map.put(400, new BaseInfo(400, ErrorMessageEnum.ERROR_PARAM.getCommon()));
        map.put(401, new BaseInfo(401, ErrorMessageEnum.ERROR_NOT_LOGIN.getCommon()));

    }
    public static BaseInfo errInfo(Integer key){
        return map.get(key);
    }

    public BaseInfo() {
    }

    public BaseInfo(Integer rc, String msg) {
        this.rc = rc;
        this.msg = msg;
    }
    
    public BaseInfo(ErrorMessageEnum error) {
      this.rc = error.getCode();
      this.msg = error.getCommon();
    }
    public BaseInfo(String msg) {
        this.msg = msg;
    }
    public BaseInfo(Integer rc) {
        this.rc = rc;
    }

    private int rc;
    private String msg = "";


    public int getRc() {
        return rc;
    }
    public void setRc(int rc) {
        this.rc = rc;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    public static BaseInfo success(){
    	return new BaseInfo(0);
    }
    
    public static BaseInfo fail(){
    	return fail;
    }
    private static BaseInfo fail = new BaseInfo(ErrorMessageEnum.ERROR_SYSTEM_EXCEPTION);
    
}
