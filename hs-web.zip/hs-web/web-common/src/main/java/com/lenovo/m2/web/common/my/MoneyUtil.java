package com.lenovo.m2.web.common.my;

import com.lenovo.m2.arch.framework.domain.Money;

import java.math.BigDecimal;

/**
 * money的部分公用创建方法
 * Created by wanghao on 2016/12/29.
 */
public class MoneyUtil {

    /**
     * 获取初始值为0，租户为当前租户的money对象
     * @return
     */
    public static Money newMoney(){
        Money money = new Money(0,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        return money;
    }

    public  static Money creatMoney(String amount){
        Money money = new Money(amount,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        return money;
    }
    public  static Money creatMoney(Double amount){
        Money money = new Money(amount,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        return money;
    }
    public  static Money creatMoney(BigDecimal amount){
        Money money = new Money(amount,ThreadLocalSessionTenant.getTenant().getCurrencyCode());
        return money;
    }

}
