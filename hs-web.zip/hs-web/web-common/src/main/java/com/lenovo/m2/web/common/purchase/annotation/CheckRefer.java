/**
 * Project Name:purchase-common
 * File Name:CheckRefer.java
 * Package Name:com.lenovo.m2.buy.purchase.common.annotation
 * Date:2016年8月17日下午1:57:36
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.web.common.purchase.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * ClassName:CheckRefer <br/>
 * Function: refer校验. <br/>
 * Date:     2016年8月17日 下午1:57:36 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CheckRefer {

}

