package com.lenovo.m2.web.common.purchase.util;

import java.io.Serializable;

public class Pair<K, V> implements Serializable {

	private static final long serialVersionUID = 844964975270441103L;

	protected K key;
	protected V value;

	public Pair() {

	}

	public Pair(K key, V value) {
		this.key = key;
		this.value = value;
	}

	public V getValue() {
		return value;
	}

	public void setValue(V value) {
		this.value = value;
	}

	public K getKey() {
		return key;
	}

	public void setKey(K key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return "Pair [key=" + key + ", value=" + value + "]";
	}

}