package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.purchase.enums.PlatType;

import java.util.HashMap;
import java.util.Map;

public class ShoppingCartKey {
	
	private static Map<Integer,String> keyMapping = new HashMap<>();
	
	static{
		keyMapping.put(1, "B2C");
		keyMapping.put(2, "B2C");
		keyMapping.put(3, "B2C");
		keyMapping.put(4, "B2C");
		
		keyMapping.put(5, "THINK");
		keyMapping.put(6, "THINK");
		keyMapping.put(7, "THINK");
		keyMapping.put(8, "THINK");
		
		keyMapping.put(20, "EPP");
		keyMapping.put(22, "EPP");
		
		keyMapping.put(30, "ROMING");
	}
	
	public static String getShoppingCartKey(Integer plat, String userid){
		PlatType.checkPlat(plat);
		return String.format("%s|%s", keyMapping.get(plat), userid);
	}

//    public static String getCartKeyForCheckOut(Integer plat){
//        PlatType.checkPlat(plat);
//        return String.format("%s", keyMapping.get(plat));
//    }


}
