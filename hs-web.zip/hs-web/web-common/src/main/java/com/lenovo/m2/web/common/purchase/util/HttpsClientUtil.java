package com.lenovo.m2.web.common.purchase.util;

import com.google.gson.Gson;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.InputStream;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * Created by wanghao on 2017/2/9.
 */
public class HttpsClientUtil {
    private static Logger LOGGER = LogManager.getLogger(HttpsClientUtil.class.getName());

    public static String doPost(String url, Map<String,String> map, String charset){
        DefaultHttpClient httpClient = null;
        HttpPost httpPost = null;
        String result = null;
        CloseableHttpResponse response = null;
        try{
            httpClient = new SSLClient();
            httpPost = new HttpPost(url);
            //设置参数
            List<NameValuePair> list = new ArrayList<NameValuePair>();
            Iterator iterator = map.entrySet().iterator();
            while(iterator.hasNext()){
                Map.Entry<String,String> elem = (Map.Entry<String, String>) iterator.next();
                list.add(new BasicNameValuePair(elem.getKey(),elem.getValue()));
            }
            if(list.size() > 0){
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list,charset);
                httpPost.setEntity(entity);
            }
            response = httpClient.execute(httpPost);
            if(response != null){
                HttpEntity resEntity = response.getEntity();
                if(resEntity != null){
                    result = EntityUtils.toString(resEntity,charset);
                }
            }
        }catch(Exception ex){
            ex.printStackTrace();
            LOGGER.error("请求失败,e["+ex+"]");
        }finally {
            if (response != null){
                try {
                    response.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
        return result;
    }


    //用于进行Https请求的HttpClient
    public static class SSLClient extends DefaultHttpClient{
        public SSLClient() throws Exception{
            super();
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
                @Override
                public void checkServerTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };
            ctx.init(null, new TrustManager[]{tm}, null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx,SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            ClientConnectionManager ccm = this.getConnectionManager();
            SchemeRegistry sr = ccm.getSchemeRegistry();
            sr.register(new Scheme("https", 443, ssf));
        }


    }

    public static InputStream getHttpsURLInputStram(String url){
        InputStream inputStream = null;
        try {
            TrustManager myX509TrustManager = new X509TrustManager() {

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }
            };

            //设置SSLContext
            SSLContext sslcontext = SSLContext.getInstance("TLS");
            sslcontext.init(null, new TrustManager[]{myX509TrustManager}, null);

            //打开连接
            //要发送的POST请求url?Key=Value&amp;Key2=Value2&amp;Key3=Value3的形式
            URL requestUrl = new URL(url);
            HttpsURLConnection httpsConn = (HttpsURLConnection)requestUrl.openConnection();

            //设置套接工厂
            httpsConn.setSSLSocketFactory(sslcontext.getSocketFactory());

            //加入数据
            httpsConn.setRequestMethod("POST");
            httpsConn.setDoOutput(true);
            inputStream = httpsConn.getInputStream();
        }catch (Exception e){
            e.printStackTrace();
            LOGGER.error("获取httpsUrl文件失败,e["+e+"]");
        }



        return inputStream;
    }


    public static void main(String[] args) {
        try {

            Map<String,String> requestMap = new HashMap<>();
            requestMap.put("service","lenovo_direct_banks");
            requestMap.put("fa_id","hs201611041101");
            requestMap.put("shop_id","1000");

            requestMap.put("bill_amount","1500");
            requestMap.put("trans_type","1");

            String signKey = "nlzdsb0x50byzdw8975lm6nqadcuxu90";
            String sign = PaySignUtils.buildSignKey(requestMap,"MD5",signKey);
            requestMap.put("sign",sign);
            requestMap.put("sign_type","MD5");

            String requestStr = new Gson().toJson(requestMap);
            System.out.println(requestStr);
            String url = "https://cashier.lenovouat.cn/banks/getSupportBanks.jhtm";// +
            //"?service=lenovo_direct_banks&fa_id=hs201611041101&shop_id=1000" +
            //"&bill_amount=1500&trans_type=1&sign_type=MD5&sign="+sign;
            //String result = HttpUtil.postStr(url,requestMap);

            String result = HttpsClientUtil.doPost(url,requestMap,"utf-8");
            System.err.println("返回结果" + result);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
