package com.lenovo.m2.web.common.purchase.util;

import java.util.regex.Pattern;

public class CheckParameterUtil {
    /**
     *
     * 校验纳税人识别码是否合法
     */
    public static boolean checkTaxpayerIdentity(String taxpayerIdentity){
        String regEx="^[A-Z0-9]{15}$|^[A-Z0-9]{18}$|^[A-Z0-9]{20}$";
        return taxpayerIdentity.matches(regEx);
    }

    /**
     * 手机号验证
     * @autor
     * @param  str
     * @return 验证通过返回true
     */
    public static boolean isMobile(String str) {
        String p = "^[1][\\d]{10}$";
        return Pattern.compile(p).matcher(str).matches();
    }

    /**
     * 判断邮编
     * @param zipString 邮政编码
     * @return boolean
     */
    public static boolean isZipNO(String zipString){
        String str = "^[0-9][0-9]{5}$";
        return Pattern.compile(str).matcher(zipString).matches();
    }

    /**
     * 判断银行卡格式是否正确
     * @param BackNo
     * @return
     */
    public static  boolean isBackNo(String BackNo){
        String str = "^[\\d]*";
        return Pattern.compile(str).matcher(BackNo).matches();
    }

    /**
     * 判断注册电话是否正确
     * @param phoneNo
     * @return
     */
    public static  boolean isPhone(String phoneNo){
        String str = "^(^[1][\\d]{10}$)|^([0\\+]\\d{2,3}-?)?(\\d{7,8})(-?(\\d{1,4}))?$";
        return Pattern.compile(str).matcher(phoneNo).matches();
    }

    /**
     * 固定电话校验
     * @param phoneNo
     * @return
     */
    public static  boolean isTel(String phoneNo){
        String str = "^([0\\+]\\d{2,3}-?)?(\\d{7,8})(-?(\\d{1,4}))?$";
        return Pattern.compile(str).matcher(phoneNo).matches();
    }

    public static void main(String[] args) {
        System.out.println(isTel("0535-7810755"));
    }
}
