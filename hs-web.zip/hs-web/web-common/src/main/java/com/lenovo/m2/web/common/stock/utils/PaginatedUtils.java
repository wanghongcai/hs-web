package com.lenovo.m2.web.common.stock.utils;

import com.lenovo.m2.arch.framework.domain.PageModel2;

import java.util.List;

/**
 * Created by mayan3 on 2015/10/12.
 */
public class PaginatedUtils<T> {
    /**
     * 每页大小
     */
    private int pageSize;
    /**
     * 当前页。第一页是1
     */
    private int index;
    /**
     * 总页数
     */
    private int totalPage;

    /**
     * 总记录数
     */
    private long totalItem;

    /**
     * 当前页的结果集
     */
    private List<T> datas;

    public PaginatedUtils(){}

    public PaginatedUtils(PageModel2 pageModel){
        pageSize = pageModel.getPageSize();
        index = pageModel.getPageNum();
        totalPage = pageModel.getTotalPageNum();
        totalItem = pageModel.getTotalCount();
        datas = pageModel.getDatas();
    }

    public void setPageModel(PageModel2<T> pageModel) {
        pageSize = pageModel.getPageSize();
        index = pageModel.getPageNum();
        totalPage = pageModel.getTotalPageNum();
        totalItem = pageModel.getTotalCount();
        datas = pageModel.getDatas();
    }

    /**
     * 每页大小
     * @return
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * 是否为第一页
     *
     * @return true 是; false 不是
     */
    public boolean isFirstPage() {
        return index <= 1;
    }

    /**
     * 是否为中间页（不是第一页，也不是最后一页）
     * @return
     */
    public boolean isMiddlePage() {
        return !(isFirstPage() || isLastPage());
    }

    /**
     * 是否为最后一页（当前页>=总页数）
     * @return
     */
    public boolean isLastPage() {
        return index >= totalPage;
    }

    /**
     * 是否有下一页
     * @return
     */
    public boolean isNextPageAvailable() {
        return !isLastPage();
    }

    /**
     * 是否有前一页
     * @return
     */
    public boolean isPreviousPageAvailable() {
        return !isFirstPage();
    }

    /**
     * 取得下一页页码
     *
     * @return
     */
    public int getNextPage() {
        if (isLastPage()) {
            return totalPage;
        } else {
            return index + 1;
        }
    }

    /**
     *  取得前一页页码
     * @return
     */
    public int getPreviousPage() {
        if (isFirstPage()) {
            return 1;
        } else {
            return index - 1;
        }
    }

    /**
     * 获取当前页码
     * @return
     */
    public int getIndex() {
        return index;
    }

    /**
     * 总记录数
     * @return
     */
    public long getTotalItem() {
        return totalItem;
    }

    /**
     * 总页数
     * @return
     */
    public int getTotalPage() {
        return totalPage;
    }

    public List<T> getDatas() {
        return datas;
    }
}
