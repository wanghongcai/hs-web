package com.lenovo.m2.web.common.purchase.annotation;

import com.lenovo.m2.web.common.purchase.enums.TokenEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
* @ClassName: Token 
* @Description: 模拟token 用于防止表单重复提交 
* @author yuzj7@lenovo.com 
* @date 2015年9月4日 下午9:21:39 
*
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Token {
	TokenEnum action();
}
