package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.my.utils.*;

/**
 * Created by wanghao on 2017/4/17.
 */
public class CommonVersion {
    static String versionTime = String.valueOf(System.currentTimeMillis());

    public static String getVersion(){
        return versionTime;
    }

    public String newVersion(){
        return String.valueOf(System.currentTimeMillis());
    }

    @Override
    public String toString(){
        return getVersion();
    }
}
