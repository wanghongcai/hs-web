package com.lenovo.m2.web.common.purchase.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DesCrypt {
    private static final byte[] KEY_IV = new byte[]{(byte)18, (byte)52, (byte)86, (byte)120, (byte)-112, (byte)-85, (byte)-51, (byte)-17};
    private static Log log = LogFactory.getLog(HttpUtil.class);
    public DesCrypt() {
    }

    public static byte[] decrypt(byte[] data, String key) throws Exception {
        byte[] byteKey = (new BASE64Decoder()).decodeBuffer(key);
        SecretKey deskey = null;
        DESedeKeySpec spec = new DESedeKeySpec(byteKey);
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
        deskey = keyfactory.generateSecret(spec);
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        IvParameterSpec ips = new IvParameterSpec(KEY_IV);
        cipher.init(2, deskey, ips);
        byte[] bOut = cipher.doFinal(decryptBASE64(new String(data)));
        return bOut;
    }

    public static byte[] encrypt(byte[] data, String key) throws Exception {
        byte[] byteKey = (new BASE64Decoder()).decodeBuffer(key);
        SecretKey deskey = null;
        DESedeKeySpec spec = new DESedeKeySpec(byteKey);
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
        deskey = keyfactory.generateSecret(spec);
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        IvParameterSpec ips = new IvParameterSpec(KEY_IV);
        cipher.init(1, deskey, ips);
        byte[] bOut = cipher.doFinal(data);
        return encryptBASE64(bOut).getBytes();
    }

    public static String calcDigest(String source, String key) {
        String s = source + key;
        MessageDigest md5 = null;

        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException var8) {
        	log.error(var8);
        }

        BASE64Encoder baseEncoder = new BASE64Encoder();
        String value = null;

        try {
            value = baseEncoder.encode(md5.digest(s.getBytes("utf-8")));
        } catch (UnsupportedEncodingException var7) {
        	log.error(var7);
        }

        return value;
    }

    private static String encryptBASE64(byte[] key) {
        return (new BASE64Encoder()).encodeBuffer(key);
    }

    private static byte[] decryptBASE64(String key) throws Exception {
        return (new BASE64Decoder()).decodeBuffer(key);
    }
}
