package com.lenovo.m2.web.common.purchase.enums;

import com.lenovo.m2.web.common.purchase.exception.BusinessException;
import com.lenovo.m2.web.common.purchase.util.Pair;

import java.util.HashMap;
import java.util.Map;

public enum PlatType {

	WAP(1, "WAP"),
	WECHAT(2, "微信"),
	APP(3, "APP"),
	PC(4, "PC"),

	THINK_WAP(5,"THINK WAP"),
	THINK_WECHAT(6,"THINK 微信"),
	THINK_APP(7,"THINK APP"),
	THINK_PC(8,"THINK PC"),

	EPP_WAP(20,"EPP WAP"),
	EPP_PC(22,"EPP PC"),
	ROMING(30,"ROMING");


//	private final static Integer[] B2C_PLAT = new Integer[]{1,2,3,4};
//	private final static Integer[] THINK_PLAT = new Integer[]{5,6,7,8};
//	private final static Integer[] EPP_PLAT = new Integer[]{20,22};

	private final int type;
	private final String descr;

	private PlatType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private static Map<Integer,PlatType>lookupmap =new HashMap<>();

	static{
		for(PlatType type: PlatType.values()){
			lookupmap.put(type.type, type);
		}

	}

	public static void checkPlat(Integer plat){
		if(!lookupmap.containsKey(plat)){
			throw new BusinessException(400, "非法平台号："+plat);
		}
	}

//	/**
//	 * @Title: 判断是否是Think商城
//	 * @Description: TODO(这里用一句话描述这个方法的作用)
//	 * @author 2015年9月16日 上午11:06:03 BY zhanghs
//	 * @param plat
//	 * @return boolean
//	 * @throws
//	 */
//	public static boolean isThink(Integer plat){
//		if(null == plat){
//			return false;
//		}
//		if(THINK_WAP.getType()==plat || THINK_WECHAT.getType()==plat
//				|| THINK_APP.getType()==plat || THINK_PC.getType()==plat){
//			return true;
//		}
//		return false;
//	}
//
//	/**
//	 * @Title: isEpp
//	 * @Description: 判断是否是Epp商城
//	 * @author 2015年9月16日 上午11:12:53 BY zhanghs
//	 * @param plat
//	 * @return
//	 * @return boolean
//	 * @throws
//	 */
//	public static boolean isEpp(Integer plat){
//		if(null == plat){
//			return false;
//		}
//		if(EPP_WAP.getType()==plat || EPP_PC.getType()==plat ){
//			return true;
//		}
//		return false;
//	}
//
//	/**
//	 * @Title: isB2C
//	 * @Description: 判断是否是B2C商城
//	 * @author 2015年9月16日 上午11:14:51 BY zhanghs
//	 * @param plat
//	 * @return
//	 * @return boolean
//	 * @throws
//	 */
//	public static boolean isB2C(Integer plat){
//		if(null == plat){
//			return false;
//		}
//		if(WAP.getType()==plat || WECHAT.getType()==plat
//				|| APP.getType()==plat || PC.getType()==plat){
//			return true;
//		}
//		return false;
//	}
//
//	/**
//	 * @Title: isRoming
//	 * @Description: 判断是否为ROMING商城
//	 * @author 2015年9月16日 上午11:16:34 BY zhanghs
//	 * @param plat
//	 * @return
//	 * @return boolean
//	 * @throws
//	 */
//	public static boolean isRoming(Integer plat){
//		if(plat == null){
//			return false;
//		}
//		if(ROMING.getType()==plat ){
//			return true;
//		}
//		return false;
//	}

	/**
	 * @Title: getMerchantEnumByPlat
	 * @Description: 根据平台号获取对应得商城
	 * @author 2015年9月16日 上午11:27:40 BY zhanghs
	 * @param plat
	 * @return
	 * @return MerchantEnum
	 * @throws
	 */
//	public static MerchantEnum getMerchantEnumByPlat(Integer plat){
//		checkPlat(plat);
//		if(isB2C(plat)){
//			return MerchantEnum.B2C_MALL;
//		}else if(isThink(plat)){
//			return MerchantEnum.THINK_MALL;
//		}else if(isEpp(plat)){
//			return MerchantEnum.EPP_MALL;
//		}else if(isRoming(plat)) {
//			return MerchantEnum.ROMING_MALL;
//		}else{
//			return null;
//		}
//	}
//
//	public static String getGroupByPlat(Integer plat, String group){
//		if(isThink(plat)){
//			return THINK;
//		}else if(isB2C(plat)){
//			return B2C;
//		}else if(isRoming(plat)){
//			return ROMING.descr;
//		}
//		else{
//			return group;
//		}
//	}


	private static final String THINK = "think";
	private static final String B2C   = "b2c";

	public static boolean isPC(Integer plat) {
		if( PC.getType() == plat ||
				THINK_PC.getType() == plat||
				EPP_PC.getType() == plat){
			return true;
		}else{
			return false;

		}
	}


	public static int getPlatByShopAndTerminal(int shopid, int terminal){
		//TODO
		return 4;
	}

	public static Pair<Integer, Integer> toShopIdAndTerminal(int plat) {
		// TODO Auto-generated method stub
		return new Pair<Integer, Integer>(1, 1);
	}

	public static int getShopIdByPlat(int plat){
/*		if(PlatType.isB2C(plat)){
		/*if(PlatType.isB2C(plat)){
			return ENUM.MallType.Lenovo.getCode();
		}else if(PlatType.isThink(plat)){
			return ENUM.MallType.Think.getCode();
		}else if(PlatType.isEpp(plat)){
			return ENUM.MallType.EPP.getCode();
		}else{
			return ENUM.MallType.Lenovo.getCode();
		}*/
		return 0;
	}
}
