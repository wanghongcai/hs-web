package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

/**
 * 各dubbo接口返回resultCode对应词条翻译文件读取
 * Created by wanghao on 2017/5/19.
 */
public class PromptInit {
    public static Logger log =  LogManager.getLogger(PromptInit.class.getName());
    public static Properties prompts = new Properties();
    public static final String SPLIT = "@";//分隔符
    public static final String SPLIT_CODE_0 = "#";//结算中心，code为0时，msg中的分隔符

    static {
        String file = "";
        file = "/prompt.properties";
        try {
            InputStream stream = ResourceHolder.class.getResourceAsStream(file);
            BufferedReader bf = new BufferedReader(new InputStreamReader(stream));
            prompts.load(bf);

        } catch (IOException e) {
            log.error("--资源文件prompt.properties取值失败--", e);
        }
    }

    /**
     * 根据key获取词条翻译文件中的词条
     * @param key   key值
     * @return
     */
    public static String get(String key){
        String value = "";

        if (StringUtil.isNotEmpty(key)){
            value = prompts.getProperty(key,"");
        }

        return value;
    }

    /**
     * 根据key获取词条翻译文件中的词条,然后再将参数msg分割后，替换词条内容
     * @param key
     * @param msg
     * @return
     */
    public static String get(String key, String msg){
        String value = "";

        if (StringUtil.isNotEmpty(key)){
            value = prompts.getProperty(key,"");
        }

        if ((PromptEnum.CHECKOUT + "." + "0").equals(key) && StringUtil.isNotEmpty(msg) && msg.indexOf(SPLIT_CODE_0)>0){
            //结算中心特殊情况处理，code为0，且需要替换返回的词条信息，如code=0，msg=40041#20@30
            String newCode = PromptEnum.CHECKOUT + "." + msg.substring(0,msg.indexOf(SPLIT_CODE_0));
            String newMsg = msg.substring(msg.indexOf(SPLIT_CODE_0)+1);
            value = get(newCode,newMsg);
            return value;
        }

        if (StringUtil.isNotEmpty(value) && value.indexOf("{0}")>-1){
            //用分隔符分割参数，然后替换词条内容
            log.info("key--" + key + "--msg--" + msg);
            if (StringUtil.isNotEmpty(msg)){
                String[] msgs = msg.split(SPLIT);
                for (int i = 0; i < msgs.length; i++) {
                    value = value.replaceAll("\\{"+i+"\\}",msgs[i]);
                }
            }
        }
        return value;
    }

    public static void main(String[] args) {
        prompts.put("checkout.0","成功");
        prompts.put("checkout.40041","代金券使用额度不能超过该商品的最大优惠额度{0}元");
        String result = get("checkout.0","40041#20@30");
        System.err.println("---"+result);
    }

}
