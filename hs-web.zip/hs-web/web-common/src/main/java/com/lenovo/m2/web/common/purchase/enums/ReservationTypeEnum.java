package com.lenovo.m2.web.common.purchase.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * 预约类型枚举
 * @ClassName: PromotionEnum
 * @Description: (这里用一句话描述这个类的作用)
 * @author zhanghs
 * @date 2015年7月27日 下午10:17:59
 *
 */
public enum ReservationTypeEnum{

    NOT_APPINTMENT(0,"非预约"),
    APPOINTMENT(1,"预约"),
    APPOINTMENT_PERBUY(2,"预约提前购买");

    private final int type;
    private final String descr;
    final  static Map<Integer, ReservationTypeEnum> enumMap = new HashMap<Integer, ReservationTypeEnum>();

    public int getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

    ReservationTypeEnum(int type, String descr) {
        this.type = type;
        this.descr = descr;
    }

    /**根据促销类型得到对应的枚举项
     *
     * @param type
     * @return
     */
    public static ReservationTypeEnum getReservationEnumByType(int type ){
        if(enumMap.size() > 0){
            return enumMap.get(type);
        }

        ReservationTypeEnum[] reservationTypeEnums =  ReservationTypeEnum.values();
        for (ReservationTypeEnum reservationTypeEnum:reservationTypeEnums){
            enumMap.put(reservationTypeEnum.getType(),reservationTypeEnum);
        }
        return enumMap.get(type);
    }
}