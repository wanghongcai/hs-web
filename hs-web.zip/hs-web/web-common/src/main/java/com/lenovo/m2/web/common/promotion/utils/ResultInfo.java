package com.lenovo.m2.web.common.promotion.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luqian on 2015-11-19.
 */
public class ResultInfo {

    private int rc;
    private String msg = "";
    public ResultInfo() {
    }

    public ResultInfo(Integer rc, String msg) {
        this.rc = rc;
        this.msg = msg;
    }
    public int getRc() {
        return rc;
    }
    public void setRc(int rc) {
        this.rc = rc;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    private static final Map<Integer, ResultInfo> map = new HashMap<Integer, ResultInfo>();
    static {
        map.put(0, new ResultInfo(0, "操作成功"));
        map.put(1, new ResultInfo(1, "操作失败"));
        map.put(2,new ResultInfo(2, "参数错误"));
        map.put(3,new ResultInfo(3, "促销规则已存在"));
        
    }
    public static ResultInfo getInfo(Integer key){
        return map.get(key);
    }
}
