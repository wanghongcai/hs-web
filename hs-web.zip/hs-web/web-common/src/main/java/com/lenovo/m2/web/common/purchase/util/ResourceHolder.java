package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.Properties;

/**
 * Created by D_xiao on 1/3/17.
 */
public class ResourceHolder {
    public static Logger log =  LogManager.getLogger(ResourceHolder.class.getName());
    public static Properties words = new Properties();
    private static final String currency = "common.currency";//货币符号

    static {
        String file = "";
        file = "/word.properties";
        try {
            InputStream stream = ResourceHolder.class.getResourceAsStream(file);
            BufferedReader bf = new BufferedReader(new InputStreamReader(stream));
            words.load(bf);

        } catch (IOException e) {
            log.error("--资源文件取值失败--", e);
        }
    }

    /**
     * 通过key从字条翻译文件总取出对应的词条
     * key[0]为词条的key，key[1],key[2]...为需要替换词条中的参数变量，对应配置文件词条中的{1},{2}...
     * @param keys
     * @return
     */
    public static String getText(String... keys) {
        String value = "";
        try {
            if (keys.length>0 && keys[0]!=null && !"".equals(keys[0].trim())){
                value = words.getProperty(keys[0]);
            }
            if (StringUtil.isNotEmpty(value) && keys.length>1){
                for (int i=1; i<keys.length; i++){
                    if (keys[i]!=null && !"".equals(keys[i].trim())){
                        value = value.replaceAll("\\{"+ i +"\\}", keys[i]);
                    }
                }
            }

            if (value == null){
                value = "";
            }
        } catch (Exception e) {
            log.error("vm转换字条报错,value="+ value +",e==",e);
        }

        return value ;
    }


    /**
     * 通过多个key值批量获取词条文件中的词条，然后合并为一个词条
     * @param keys
     * @return
     */
    public static String getTexts(String... keys) {
        StringBuffer value = new StringBuffer();

        try {
            if (keys != null && keys.length>0){
                for (int i=0; i<keys.length; i++){
                    if (keys[i]!=null && !"".equals(keys[i].trim())){
                        value = value.append(words.getProperty(keys[i].trim()));
                    }
                }
            }
        } catch (Exception e) {
            log.error("vm转换字条报错e==",e);
        }

        return value.toString();
    }

    /**
     * 获取货币符号
     * @return
     */
    public static String getCurrency() {
        String value = "";
        try {
            value = words.getProperty(currency);
            log.info("currenCyShopIds=" + value);
            if (StringUtil.isNotEmpty(value)){
                //获取第一个shopId,新建tenant，并获取货币符号
                String currenCyShopId = value.split(",")[0];
                Tenant tenant = Tenant.getTenant(Integer.parseInt(currenCyShopId));
                value = tenant.getCurrencySign();
            }

            if (value == null){
                value = "";
            }
            log.info("value=" + value);
        } catch (Exception e) {
            log.error("vm转换字条报错,value="+ value +",e==",e);
        }

        return value ;
    }


    public static ShowIdentity getOrderText(String key) {
        String resourceName = "/messages/messages_zh.properties";
        String str = toJSONString(resourceName);
        ShowIdentity d = JsonUtil.fromJson(str,ShowIdentity.class);
        return d;
    }

    public static String toJSONString(String file) {
        String value = "";
        InputStream stream = ResourceHolder.class.getResourceAsStream(file);
        Properties properties = new Properties();
        BufferedReader bf = null;
        try {
            bf = new BufferedReader(new InputStreamReader(stream,"UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try {
            properties.load(bf);
        } catch (IOException e) {
            e.printStackTrace();
        }
        value = properties.getProperty("order.showidentity");
        return value;
    }
}
