package com.lenovo.m2.web.common.my.parameter;

import org.apache.commons.lang.StringUtils;

/**
 * service服务
 * Created by mayan3 on 2015/8/25.
 */
public enum ServiceStatusEnum {

    REFUND(1), // 退货
    EXCHANGES(2), // 换货
    REPAIR(3); // 返修

    public int value;

    ServiceStatusEnum(int value) {
        this.value = value;
    }

    public static ServiceStatusEnum getServiceStatus(String status) {
        if (StringUtils.isNotEmpty(status)) {

            switch (Integer.parseInt(status)) {
                case 1:
                    return ServiceStatusEnum.REFUND;
                case 2:
                    return ServiceStatusEnum.EXCHANGES;
                case 3:
                    return ServiceStatusEnum.REPAIR;
            }
        }
        return null;
    }

    public int getValue() {
        return value;
    }
}
