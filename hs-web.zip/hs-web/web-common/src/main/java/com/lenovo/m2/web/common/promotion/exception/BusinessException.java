package com.lenovo.m2.web.common.promotion.exception;

import com.lenovo.m2.web.common.promotion.enums.GloablErrorMessageEnum;

/**
 * 
 * @description	业务异常
 * 
 * @author wangrq1
 * 
 */
public class BusinessException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1255854435024536217L;


	private String errno;

	public BusinessException(String errno, String errmsg){
		super(errmsg);
		this.errno = errno;
	}
	
	
	public BusinessException(GloablErrorMessageEnum error){
		super(error.getCommon());
		this.errno = error.getCode();
	}

	public String getErrno(){
		return errno;
	}

}
