package com.lenovo.m2.web.common.purchase.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Created by luqian on 2015-05-31.
 */
public class PropertiesHelper {
    public static Map<String,Map<String,Object>> properties = new HashMap<String,Map<String,Object>>();

    public static Map<String,Object> loadToMap(String propertyFilePath){
        Map<String,Object> map = properties.get(propertyFilePath);
        if (map == null){
            map = getConfigMap(propertyFilePath);
            properties.put(propertyFilePath,map);
        }
        return map;
    }



    private static Map<String,Object> getConfigMap(String propertyFilePath){
        //1.加载资源文件
        InputStream in;
        Properties pro = new Properties();
        try {
            pro.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(propertyFilePath));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        //获取配置文件的所有键值
        Set<String> keys = pro.stringPropertyNames();

        //文件的内容为空
        if(keys.size() == 0){
            throw new RuntimeException("资源文件的内容为空");
        }

        //把键值对放入map中
        Map<String,Object> map = new HashMap<String,Object>();
        for(String key : keys){
            map.put(key, pro.getProperty(key));
        }
        return map;
    }
}
