package com.lenovo.m2.web.common.purchase.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
* @ClassName: NeedLogin 
* @Description: 需要登录标注， 未登录跳转 
* @author wangrq1@lenovo.com 
* @date 2016年5月12日 
*
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface NeedLogin {
	
}
