package com.lenovo.m2.web.common.my.utils;

import java.util.Map;

/**
 * Created by yezhenyue on 2015/11/5.
 */
public class PlatUtils {
    private static Map<String,String> map;

    public PlatUtils(Map<String,String> map) {
        this.map=map;
    }

    public static String getPlat(String merchantId){
        return map.get(merchantId);
    }

}
