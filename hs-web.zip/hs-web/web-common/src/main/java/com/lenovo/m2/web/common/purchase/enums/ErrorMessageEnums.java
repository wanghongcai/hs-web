package com.lenovo.m2.web.common.purchase.enums;

/**
 * Created by D_xiao on 17/2/13.
 */
public interface ErrorMessageEnums {
    public String getCommon();
    public int getCode();
}
