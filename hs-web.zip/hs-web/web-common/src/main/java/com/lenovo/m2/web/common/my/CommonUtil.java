package com.lenovo.m2.web.common.my;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonUtil {
    private static final Pattern mobilePattern = Pattern.compile("^[1][3,4,5,7,8][0-9]{9}$"); // 验证手机号
	// 邮箱账号验证
	public static final Pattern emailp = Pattern
			.compile("^\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]+$");

	/**
	 * @功能说明:邮箱验证
	 * @开发者:z.k.f
	 * @开发日期:2016年6月24日 下午5:13:49
	 * @param str
	 * @return
	 */
	public static boolean isEmail(String str) {
		Matcher m = emailp.matcher(str);
		boolean b = m.matches();
		return b;
	}

	/**
	 * 
	 * @author: liuhy12
	 * @method: isMobile
	 * @date: 2016年6月21日 下午3:45:48
	 * @ModifiedBy:
	 * @description:手机号验证
	 * @param str
	 * @return
	 */
	public static boolean isMobile(String str) {
		Matcher m = mobilePattern.matcher(str);
		boolean b = m.matches();
		return b;
	}
}