package com.lenovo.m2.web.common.stock.utils;



/**
 * 
* @ClassName: Contants
* @Description: 常量类
* @author yuzj7@lenovo.com
* @date 2015年5月18日 下午12:22:32
*
 */
public class Contants {
	//接口签名校验key
	public static final String 	MD5_KEY = ")(*&^%$#@!MNBVCX76543";
	

	public static final int RECOMMENDPRODUCTCOUNT = 6;
	
	public static final String WAPPLAT = "1";
	
	//乐豆接口校验key 
	public static final String MD5_HAPPYBEAN = "@#$23@89_lenovo_ledou#00";
	
	//md5 订单退货取消md5校验
	public static final String MD5_ORDER = "!@#$%^&*()";
}
