package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.my.utils.JacksonUtil;
import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import net.sf.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;


/** 单点登录工具类
 * Created by zhanglijun on 2015/8/21.
 */
public class SSOUtil {

    public static Logger logger =  LogManager.getLogger(SSOUtil.class);

    /**
     *  单点登录开关
     *
     */
    public static  boolean isSsoSwitch(){
        String isSsoSwitch = PropertiesHelper.loadToMap("pay_switch.properties").get("ssoSwitch").toString();
        if(isSsoSwitch.equals("0")){
            logger.info("单点登录已开启");
            return true;
        }
        logger.info("单点登录已关闭");
        return false;
    }

    /**
     *  判断是否已经登录
     *
     */
    public static  boolean  islogin(HttpServletRequest request){
        String lenovoId= SSOUserInfoUtil.getLenovoId(request);
        logger.info("lenovoId==单点登录获取======"+lenovoId);
        String lenovoid = request.getParameter("lenovoId");
        logger.info("lenovoid==前台页面获取======"+lenovoid);
        if(StringUtil.isNotEmpty(lenovoId)&&StringUtil.isNotEmpty(lenovoid)&&lenovoid.equals(lenovoId)){
            logger.info("单点登录校验正确。。。");
            return  true;
        }else{
            logger.info("单点登录校验失败。。。");
            return false;
        }
    }





    //单点登录的url拼接
    public static  String  ssoLoginUrl(String orderid,String payType,String callback,String bankNo
            ,String cardType,String transType,String shopId,String terminal){
        String loginUrl="";
        try {
            logger.info("用户未登录，跳转到登录页面....");
            String url = PropertiesHelper.loadToMap("properties/cashier_pay.properties").get("pcGoToBank").toString();
            String alipayUrl = url+"?ordercode=" + orderid + "&platCode=" + payType;
            logger.info("用户登录成功后跳转的url==="+alipayUrl);
            String ssourl= PropertiesHelper.loadToMap("properties/cashier_pay.properties").get("ssoRegtUrl").toString();
            if(StringUtil.isNotEmpty(bankNo)){
                alipayUrl+="&bankNo=" + bankNo ;
            }
            if(StringUtil.isNotEmpty(cardType)){
                alipayUrl+="&cardType=" + cardType ;
            }
            if(StringUtil.isNotEmpty(transType)){
                alipayUrl+="&transType=" + transType ;
            }
            if(StringUtil.isNotEmpty(shopId)){
                alipayUrl+="&shopId=" + shopId ;
            }
            if(StringUtil.isNotEmpty(terminal)){
                alipayUrl+="&terminal=" + terminal ;
            }
            loginUrl = ssourl+"?ru=" + java.net.URLEncoder.encode(alipayUrl,"UTF-8");
            logger.info("用户登录的url==="+loginUrl);
        } catch (Exception e) {
            logger.error("单点登录失败跳转异常", e);
        }
        return callback+"("+ JacksonUtil.toJson(new BaseInfo(10,loginUrl ))+")";
    }


    /**
     * 通过调用公共平台方法判断当前登录账号是否是经销商的主账号
     * @param loginName 登录账号
     * @return
     */
    public static boolean isMainAccount(String loginName){
        boolean flag = false;
        try {
            String appKey = CustomizedPropertyConfigurer.getContextProperty("appKey");
            String appSecret = CustomizedPropertyConfigurer.getContextProperty("appSecret");
            String method = CustomizedPropertyConfigurer.getContextProperty("method");
            String openmgrUrl = CustomizedPropertyConfigurer.getContextProperty("openmgrUrl");
            //应用参数 一般情况下参数为应用参数
            Map<String, Object> lenovo_param_json = new HashMap<String, Object>();
//            lenovo_param_json.put("loginName", "18101024154");
            lenovo_param_json.put("loginName", loginName);
            //系统参数，当多个接口中都有某个参数时候，可以把这个参数定义为系统参数
//            Map<String, Object> lenovo_sys_param_json = new HashMap<String, Object>();
//            lenovo_sys_param_json.put("terminal", "0");
//            lenovo_sys_param_json.put("source", "0");
//            lenovo_sys_param_json.put("unique", "0");
//            lenovo_sys_param_json = null;

            Response response = JavaSDKClient.proxy(openmgrUrl,appKey, appSecret, method, lenovo_param_json, null);
            logger.info("查询主账号查询结果--"+response.toJSON().toString());
            if (response != null && response.getStatus() == 200){
                JSONObject object = JSONObject.fromObject(response.getBody().toString());
                if (object.getJSONObject("result") != null && object.getJSONObject("result").getJSONObject("lenovo_cerp_ismasteraccount_hs_response") != null){
                    String msg = object.getJSONObject("result").getJSONObject("lenovo_cerp_ismasteraccount_hs_response").getString("msg");
                    if ("0".equals(msg)){
                        flag = true;
                    }
                }
            }
//            String  str = "{\"result\":{\"status\":200,\"lenovo_cerp_ismasteraccount_response\":{\"ret\":true,\"msg\":\"1\"}},\"resultCode\":\"0\",\"code\":0,\"msg\":\"操作成功\",\"success\":true}";
        } catch (Exception e) {
            logger.error("查询是否是主账号失败：",e);
        }
        return flag;
    }


}
