package com.lenovo.m2.web.common.purchase.exception;

import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;

/**
 * 
 * @description	业务异常
 * 
 * @author wangrq1
 * 
 */
public class BusinessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1255854435024536217L;


	private int errno;
	
	public BusinessException(int errno, String errmsg){
		super(errmsg);
		this.errno = errno;
	}
	
	
	public BusinessException(ErrorMessageEnum error){
		super(error.getCommon());
		this.errno = error.getCode();
	}
	

	public int getErrno(){
		return errno;
	}
	
}
