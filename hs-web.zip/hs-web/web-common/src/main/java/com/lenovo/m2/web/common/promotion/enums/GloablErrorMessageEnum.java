package com.lenovo.m2.web.common.promotion.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luqian on 2015-11-19.
 */
public enum  GloablErrorMessageEnum {
	SUCCESS("0", "操作成功"),
	ERROR_OPERATIONDATA("10000","数据操作失败"),	
	ERROR_PARAM_ILLEGAL("10001","参数不合法"),
	ERROR_PRODUCT_NOTFOUND("10002","未找到商品"),
	ERROR_USER_NOTLOGIN("10003","请重新登录"),
	ERROR_GET_PRODUCT_DETAIL("10004","查询商品基本信息失败"),
	ERROR_GET_PRODUCT_PRICE("10005","查询商品价格失败"),
	ERROR_PLAT_PRICE("10005","平台价格有误"),
	ERROR_SYSTEM_ERROR("99999","系统错误");

    private String code;
    private String common;
    GloablErrorMessageEnum(String code, String common){
        this.code = code;
        this.common = common;
    }

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getCommon() {
        return common;
    }
    public void setCommon(String common) {
        this.common = common;
    }

    final  static Map<String,GloablErrorMessageEnum> enumMap = new HashMap<String,GloablErrorMessageEnum>();
    public static GloablErrorMessageEnum getDisabledByType(String code){
        if(enumMap.size() > 0){
            return enumMap.get(code);
        }
        GloablErrorMessageEnum[]gloablErrorMessageEnums =  GloablErrorMessageEnum.values();
        for (GloablErrorMessageEnum gloablErrorMessageEnum:gloablErrorMessageEnums){
            enumMap.put(gloablErrorMessageEnum.getCode(),gloablErrorMessageEnum);
        }
        return enumMap.get(code);
    }
}
