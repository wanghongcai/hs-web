package com.lenovo.m2.web.common.stock.utils;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class StringUtil {
	
	public static boolean isEmpty(String key){
		if(key!=null && !"".equals(key.trim())){
			return false;
		}
		return true;
	}
	
	public static boolean isEmpty(String...keys){
		for (String key :keys) {
			if (StringUtil.isEmpty(key)) {
				return true;
			}
		}
		return false;
	}
	
	public static String decimalFormatPrice(String param){
		if(param==null||"".equals(param)){
			param = "0.00";
		}
        double tmp = Double.parseDouble(param);
        DecimalFormat df=new DecimalFormat("0.00");
        return df.format(tmp);
	}
	
	
	public static String cleanXss(String str){
		if (str == null || "".equals(str.trim())) {
			return "";
		}
		str = str.replaceAll(" ","");
		return str;
	}
	
	/**
	 * @description 以*(分号)分隔的字符串，去除首尾的*(分号)。
	 * @author qinhc
	 * @createTime 2015上午11:05:00
	 * @param str
	 * @param trim
	 * @return
	 */
	public static String StrRemoveTrim(String str,String trim){
		// str=;2;; 
		String resultStr="";
		String[] strList=str.split(trim);
		for(String s:strList){
			if(!"".equals(s)&&null!=s){
				resultStr=resultStr+s+trim;
			}
		}
		if(resultStr.length()>0){
			resultStr=resultStr.substring(0,resultStr.length()-1);
		}
		return resultStr;
	}
	
	/**
	 * 是否手机号 简单校验11位数字
	 * @param str
	 * @return
	 * @author wangrq1
	 */
	public static boolean isPhone(String str){
		Matcher m =  NUM_11.matcher(str);
		return m.matches();
	}
	
	static Pattern NUM_11 = Pattern.compile("\\d{11}");

	
	public static void main(String[] args) {
		
		System.out.println(isPhone("18001141691"));
		System.out.println(isPhone(""));
		
	}

	/**
	 * 检查字符串是否为数字
	 */
	public static boolean checkIsDigit(String str) {
		return str.matches("[0-9]*");
	}
}
