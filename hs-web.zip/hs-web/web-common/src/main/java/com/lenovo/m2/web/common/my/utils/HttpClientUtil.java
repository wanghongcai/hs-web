package com.lenovo.m2.web.common.my.utils;

import com.lenovo.m2.web.common.purchase.util.PaySignUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @description HttpClient 的工具类
 * @author qinhc123
 * @2015下午6:03:09
 */
public class HttpClientUtil {

	public static Logger logger =  LogManager.getLogger(HttpClientUtil.class);

	/**
	 * @description 发送httpClient post 请求，json 格式返回
	 * @author qinhc
	 * @2015下午6:03:09
	 * @param url
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPost(String url, String body)
			throws Exception {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType("application/json");
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT, 20000);
		// 读取超时
		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				20000);
		try {
			HttpResponse result = httpClient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			logger.info("订单消息返回的数据：" + resData);
		} catch (Exception e) {
			logger.error("订单消息发送请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return resData;
	}
	
	/**
	 * @description
	 * @author qinhc
	 * @2015下午6:00:41
	 * @param url
	 * @param body
	 * @param type 请求的类型
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPostType(String url, String body,String type)
			throws Exception {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType(type);
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT, 20000);
		// 读取超时
		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				20000);
		try {
			HttpResponse result = httpClient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			logger.info("订单消息返回的数据：" + resData);
		} catch (Exception e) {
			logger.error("订单消息发送请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return resData;
	}
	
	/**
	 * 
	* @Description: post 提交
	* @author yuzj7@lenovo.com  
	* @date 2015年5月15日 上午10:41:49
	* @param url
	* @param params
	* @return
	 */
	public static String postStr(String url, Map<String, String> params) throws UnsupportedEncodingException{
		HttpClient httpclient =new DefaultHttpClient();
		HttpPost httpPost = new HttpPost(url);
		httpPost.setHeader("Content-Type", "application/xml; charset=utf-8");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));
		String line = null;   
		String str="";
		 try { 
			HttpResponse response=httpclient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			InputStreamReader inputstream = new InputStreamReader(entity.getContent(), "UTF-8");
			BufferedReader reader = new BufferedReader(inputstream);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str+=line;   
			} 
			reader.close();
			inputstream.close();
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 if(httpclient != null){
				 httpclient.getConnectionManager().shutdown();
			 }
		 }
		return str;
	}
	
	
	/**
	 * post 方法
	 * @param url
	 * @return
	 * @author mamj
	 * @throws UnsupportedEncodingException
	 * @date 2013-11-19 下午03:46:58
	 */
	public static String PostStr(String url, Map<String, String> params,String referer,String cookie,boolean isproxy,String charset) throws UnsupportedEncodingException{
		HttpClient httpclient =new DefaultHttpClient();
		// 请求超时
		httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 60000);
        // 读取超时
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 60000    );
		HttpPost httpPost = new HttpPost(url);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		if(!StringUtils.isEmpty(cookie)){
			httpPost.setHeader("Cookie", cookie);
		}
		if(!StringUtils.isEmpty(referer)){
			httpPost.addHeader("Referer", referer);
		}
         
         if(StringUtils.isEmpty(charset)){
        	 charset = "utf-8";
         }
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, charset));
		String line = null;   
		 StringBuffer str = new StringBuffer("");  
		 InputStreamReader inreader = null;
		 BufferedReader reader = null;
		 try { 
			HttpResponse response=httpclient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			inreader = new InputStreamReader(entity.getContent(), charset);
			reader  = new BufferedReader(inreader);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str.append(line);
			} 
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 if (reader != null) {
	        	  try {
	        		  reader.close();// 最后要关闭BufferedReader  
				} catch (IOException e) {
					e.printStackTrace();
				}
	          }
	    	  if(inreader != null){
	    		  try {
	    			  inreader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	  }
			 if(httpclient != null){
				 httpclient.getConnectionManager().shutdown();
			 }
		 }
		return str.toString();
	}
	
	
	/**
	 * 
	* @Description: http get 请求
	* @author yuzj7@lenovo.com  
	* @date 2015年6月11日 下午5:53:28
	* @param url
	* @return
	 */
	public static String getStr(String url) {
		
		  BufferedReader in = null;  
	      // 定义HttpClient  
	      HttpClient client = new DefaultHttpClient();
	      // 实例化HTTP方法  
	      HttpGet request = new HttpGet();
	      String line = "";  
	      String tmp="";
	      try {  
		      request.setURI(new URI(url));  
		      HttpResponse response = client.execute(request);
	          in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));   
	          while ((tmp=in.readLine()) != null) {   
	            line+=tmp;   
	          }
	      }catch (Exception e) {
			  logger.error("httpclient error:",e);
			  e.printStackTrace();
	      }finally{
	    	  if (in != null) {
	        	  try {
					in.close();// 最后要关闭BufferedReader  
				} catch (IOException e) {
					e.printStackTrace();
				}
	          }
	    	  client.getConnectionManager().shutdown();
	      }  
	      return line;  
	            
	}

	/**
	 *
	 * @Description: https get 请求 绕过证书验证
	 * @author yuzj7@lenovo.com
	 * @date 2018年7月6日
	 * @param url
	 * @return
	 */
	public static String getStrs(String url){

		BufferedReader in = null;
		// 定义HttpClient
		HttpClient client = new DefaultHttpClient();
		String line = "";
		String tmp="";
		try {
			//采用绕过验证的方式处理https请求
			SSLContext sslcontext = createIgnoreVerifySSL();

			//设置协议http和https对应的处理socket链接工厂的对象
			Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register("http", PlainConnectionSocketFactory.INSTANCE)
					.register("https", new SSLConnectionSocketFactory(sslcontext))
					.build();
			PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
			HttpClients.custom().setConnectionManager(connManager);

			// 定义HttpClient
			client = HttpClients.custom().setConnectionManager(connManager).build();
			// 实例化HTTP方法
			HttpGet request = new HttpGet();
			request.setURI(new URI(url));
			HttpResponse response = client.execute(request);
			in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			while ((tmp=in.readLine()) != null) {
				line+=tmp;
			}
		}catch (Exception e) {
			logger.error("httpclient error:",e);
			e.printStackTrace();
		}finally{
			if (in != null) {
				try {
					in.close();// 最后要关闭BufferedReader
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			client.getConnectionManager().shutdown();
		}
		return line;

	}

	/**
	 * 绕过https证书验证
	 *
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static SSLContext createIgnoreVerifySSL() throws NoSuchAlgorithmException, KeyManagementException {
		SSLContext sc = SSLContext.getInstance("SSLv3");

		// 实现一个X509TrustManager接口，用于绕过验证，不用修改里面的方法
		X509TrustManager trustManager = new X509TrustManager() {
			@Override
			public void checkClientTrusted(
					java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
					String paramString) throws CertificateException {
			}

			@Override
			public void checkServerTrusted(
					java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
					String paramString) throws CertificateException {
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		};

		sc.init(null, new TrustManager[] { trustManager }, null);
		return sc;
	}

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url
     *            发送请求的 URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            out.print(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            logger.info("发送POST请求出现异常！" + e);
            e.printStackTrace();
        }
        //使用finally块来关闭输出流、输入流
        finally {
            if (out != null) {
                out.close();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Map<String,String> requestMap = new HashMap<>();
        requestMap.put("service","lenovo_direct_banks");
        //requestMap.put("fa_id","7ef1d628-5bd3-4651-9530-793678cc02af");
        requestMap.put("fa_id","hs201611041101");
        requestMap.put("shop_id","1000");
        requestMap.put("bill_amount","1600.00");
        requestMap.put("trans_type","1");
        //1=nlzdsb0x50byzdw8975lm6nqadcuxu90
        //1000=nlzdsb0x50byzdw8975lm6nqadcuxu90
        String sign = PaySignUtils.buildSignKey(requestMap,"MD5","nlzdsb0x50byzdw8975lm6nqadcuxu90");
        requestMap.put("sign",sign);
        requestMap.put("sign_type","MD5");
        //String url = (String)commonParam.get("URL_LENOVO_DIRECT_BANKS");
        //String url = "https://cashier.lenovouat.cn/banks/getSupportBanks.jhtm";
        String url = "http://10.116.34.107/banks/getSupportBanks.jhtm";
        try {
            String re = HttpClientUtil.sendHttpPost(url,requestMap);
            System.err.println(re);
            /*SendFile send = new SendFile();
            for (Entry<String,String> entry:
                 requestMap.entrySet()) {
                send.setStringParams(entry.getKey(),entry.getValue());

            }
            send.setUrl(url);
            Thread thread = new Thread(send);
            thread.start();*/
            //String result = HttpClientUtil.postStr(url,requestMap);
            //System.err.println(result);
        }catch (Exception e){

        }
    }

    /**
     * 发送HTTP POST请求,支持带多个String参数
     *
     * @param url 链接
     * @param paramMap 参数
     */
    public static String sendHttpPost(String url, Map<String, String> paramMap) throws Exception {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        return sendHttpPost(url, paramMap, httpclient);
    }
    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(String url, Map<String, String> paramMap, CloseableHttpClient httpclient) throws Exception {
        try {
            HttpPost httpPost = new HttpPost(url);
            // 处理发送中文问题
            httpPost.getParams().setParameter("http.protocol.content-charset", HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CONTENT_ENCODING, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CHARSET_PARAM, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.DEFAULT_PROTOCOL_CHARSET, HTTP.UTF_8);

            List<NameValuePair> nvps = new ArrayList<NameValuePair>();

            for (String key : paramMap.keySet()) {
                nvps.add(new BasicNameValuePair(key, paramMap.get(key)));
            }

//	        httpPost.setEntity(new UrlEncodedFormEntity(nvps));
            httpPost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
            return sendHttpPost(httpPost, httpclient);
        } finally {
            httpclient.close();
        }
    }

    private static RequestConfig requestConfig = RequestConfig.custom()
            .setSocketTimeout(15000)
            .setConnectTimeout(15000)
            .setConnectionRequestTimeout(15000)
            .build();

    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(HttpPost httpPost, CloseableHttpClient httpclient) throws Exception {
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = httpclient.execute(httpPost);

        try {
            HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity, Charset.forName("UTF-8"));
        } finally {
            response.close();
        }
    }

    }
class SendFile implements Runnable {
    private String url;
    // private File file;

    private String deleteFilePath;//待发送结束后将要删除的文件路径
    //private String fileParamName;//文件参数名
    private MultipartEntityBuilder builder=MultipartEntityBuilder.create();

    public void run() {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        //httpclient.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 15000);
        HttpPost httpPost = new HttpPost(url);
        //RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(2000).setConnectTimeout(2000).build();//设置请求和传输超时时间
        //httpPost.setConfig(requestConfig);
        //MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        //for(File file:files){
        //FileBody bin = new FileBody(file);
        //builder.addPart(fileParamName, bin);
        //}
        HttpEntity reqEntity = builder.build();
        httpPost.setEntity(reqEntity);
        CloseableHttpResponse resp = null;
        HttpEntity entity = null;
        String result = null;
        try {

            resp = httpclient.execute(httpPost);
            entity = resp.getEntity();
            result = EntityUtils.toString(entity, Charset.forName("UTF-8"));
            System.err.println("发送结果："+result);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("");
        }finally{
            httpPost.releaseConnection();
            //删除发送的文件
            if (deleteFilePath!=null&&new File(deleteFilePath).exists()) {
                new File(deleteFilePath).delete();
            }
        }
    }


    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
	/*public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}*/




	/*public String getFileParamName() {
		return fileParamName;
	}


	public void setFileParamName(String fileParamName) {
		this.fileParamName = fileParamName;
	}*/


    public String getDeleteFilePath() {
        return deleteFilePath;
    }


    public void setDeleteFilePath(String deleteFilePath) {
        this.deleteFilePath = deleteFilePath;
    }


    public MultipartEntityBuilder getBuilder() {
        return builder;
    }


    public void setBuilder(MultipartEntityBuilder builder) {
        this.builder = builder;
    }

    public void setStringParams(String paramName,String text){
        this.getBuilder().addTextBody(paramName, text);
    }
    public void setFileParams(String paramName,File file){
        FileBody bin = new FileBody(file);
        this.getBuilder().addPart(paramName, bin);
    }

}
