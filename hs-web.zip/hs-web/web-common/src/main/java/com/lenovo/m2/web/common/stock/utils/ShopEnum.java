package com.lenovo.m2.web.common.stock.utils;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

public enum ShopEnum {
    GUANWANG(1),
    Think(2),
    EPP(3),
    Roaming(4),
    MOTO(5),
    DONGDE(6),
    THINKCENTER(7),
    SMB(8),
    SMBJF(9),
    SMBASK(10);

    private static BiMap<String, Integer> MAPPING_DICT = HashBiMap.create();
    private int value;

    public static String getShopStr(int type) {
        return (String)MAPPING_DICT.inverse().get(Integer.valueOf(type));
    }

    private ShopEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public String toString() {
        return this.name().toLowerCase();
    }

    static {
        MAPPING_DICT.put("联想官网", Integer.valueOf(GUANWANG.getValue()));
        MAPPING_DICT.put("Think官网", Integer.valueOf(Think.getValue()));
        MAPPING_DICT.put("EPP", Integer.valueOf(EPP.getValue()));
        MAPPING_DICT.put("Roaming", Integer.valueOf(Roaming.getValue()));
        MAPPING_DICT.put("MOTO", Integer.valueOf(MOTO.getValue()));
        MAPPING_DICT.put("DONGDE", Integer.valueOf(DONGDE.getValue()));
        MAPPING_DICT.put("Think产品中心", Integer.valueOf(THINKCENTER.getValue()));
        MAPPING_DICT.put("17商城", Integer.valueOf(SMB.getValue()));
        MAPPING_DICT.put("17积分商城", Integer.valueOf(SMBJF.getValue()));
        MAPPING_DICT.put("17社区", Integer.valueOf(SMBASK.getValue()));
    }
}
