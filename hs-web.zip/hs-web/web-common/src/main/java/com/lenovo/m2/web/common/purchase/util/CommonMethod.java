package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.IntUtil;
import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by caoxd2 on 2015/5/24.
 */
public class CommonMethod {
    public static Logger logger =  LogManager.getLogger(CommonMethod.class);

    public static String digitalConversion(Double d) {
        BigDecimal db = BigDecimal.valueOf(d * 100.00);
        int value = db.intValue();
        return String.valueOf(value);
    }


    public static <T> void getRemoteResult(RemoteResult<T> remoteResult, T t, boolean status, String resultCode, String resultMsg) {
        remoteResult.setT(t);
        remoteResult.setResultCode(resultCode);
        remoteResult.setResultMsg(resultMsg);
        remoteResult.setSuccess(status);
    }

    public static String getProductName(String subject) {
        Pattern p = Pattern.compile("^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$");
        Matcher m = p.matcher(subject);
        if (!m.matches() || subject.length() > 50 || StringUtils.isEmpty(subject)) {
            subject = "联想商品";
        }
        return subject;
    }

    /*public static boolean validateAliCallback(AliCallbackBaseModel callbackBaseModel) {
        if (StringUtils.isBlank(callbackBaseModel.getOrderNo()) || StringUtils.isBlank(callbackBaseModel.getNotifyId()) || StringUtils.isBlank(callbackBaseModel.getSignType()) || StringUtils.isBlank(callbackBaseModel.getSign()) || StringUtils.isBlank(callbackBaseModel.getTradeNo()) || StringUtils.isBlank(callbackBaseModel.getTradeStatus())) {
            return false;
        }
        return true;
    }*/

    /*public static boolean isUpdateOrderStateSuccess(PayOrder payOrder, CashierApi cashierApi, MerchantPayPlatView merchantPayPlatView, String orderNo, String tradeNo, String paymentTime, String paymentType, String lenovoId, String signature, String key_id) {
        String url = merchantPayPlatView.getInNotifyUrl() + "&orderCode=" + orderNo + "&payOrderCode=" + tradeNo + "&payDatetime=" + paymentTime + "&payment=" + paymentType + "&lenovoId=" + lenovoId + "&signature=" + signature + "&orderPrimaryId=" + key_id;
        logger.warn("更新订单状态的url:" + url);
        RemoteResult<String> remoteResult = cashierApi.payCallback(payOrder.getOs(), signature, payOrder.getOut_trade_no(), tradeNo, paymentTime, paymentType, lenovoId, payOrder.getId().toString());
        logger.info("更新订单状态返回信息：" + JSON.toJSONString(remoteResult));
        String result = remoteResult.getT();
        if (result.equals("success")) {
            return true;
        }
        logger.error("更新订单支付状态出错：" + result);
        return false;
    }*/

    public static String getBodyHtml(String formHtml) {
        return "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head><body>"
                + formHtml + "</body></html>";
    }

//    public static String getSyncRedirectUrl(int plat, String filePath) {
//        String url;
//        //商城平台编码 1 WAP ,2 微信,3 APP,4 PC
//        // 商城平台编码 5 THINK WAP ,6 THINK 微信,7 THINK APP,8 THINK PC add by dongcy5 15-7-20
//        switch (plat) {
//            case 1:
//                url = PropertiesHelper.loadToMap(filePath).get("wapSyncRedirectUrl").toString();
//                break;
//            case 2:
//                url = PropertiesHelper.loadToMap(filePath).get("wxSyncRedirectUrl").toString();
//                break;
//            case 3:
//                url = PropertiesHelper.loadToMap(filePath).get("appSyncRedirectUrl").toString();
//                break;
//            case 4:
//                url = PropertiesHelper.loadToMap(filePath).get("pcSyncRedirectUrl").toString();
//                break;
//            case 5:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkWapSyncRedirectUrl").toString();
//                break;
//            case 6:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkWxSyncRedirectUrl").toString();
//                break;
//            case 7:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkAppSyncRedirectUrl").toString();
//                break;
//            case 8:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkPcSyncRedirectUrl").toString();
//                break;
//            default:
//                url = PropertiesHelper.loadToMap(filePath).get("pcSyncRedirectUrl").toString();
//                break;
//        }
//        return url;
//    }

//    public static String getSyncCallbackUrl(int plat, String filePath) {
//        String url;
//        //商城平台编码 1 WAP ,2 微信,3 APP,4 PC
//        // 商城平台编码 5 THINK WAP ,6 THINK 微信,7 THINK APP,8 THINK PC add by dongcy5 15-7-20
//        switch (plat) {
//            case 1:
//                url = PropertiesHelper.loadToMap(filePath).get("wapSyncCallbackUrl").toString();
//                break;
//            case 2:
//                url = PropertiesHelper.loadToMap(filePath).get("wxSyncCallbackUrl").toString();
//                break;
//            case 3:
//                url = PropertiesHelper.loadToMap(filePath).get("appSyncCallbackUrl").toString();
//                break;
//            case 4:
//                url = PropertiesHelper.loadToMap(filePath).get("b2cPcSyncCallbackUrl").toString();
//                break;
//            case 5:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkWapSyncCallbackUrl").toString();
//                break;
//            case 6:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkWxSyncCallbackUrl").toString();
//                break;
//            case 7:
//                url = PropertiesHelper.loadToMap(filePath).get("thinkAppSyncCallbackUrl").toString();
//                break;
//            case 8:
//                url = PropertiesHelper.loadToMap(filePath).get("tkPcSyncCallbackUrl").toString();
//                break;
//            default:
//                url = PropertiesHelper.loadToMap(filePath).get("b2cPcSyncCallbackUrl").toString();
//                break;
//        }
//        return url;
//    }

    /**
     * 获取10进制数据
     *
     * @param keyId
     * @return
     */
    public static String get32To10(String keyId) {
        String str = "";
        str = keyId.substring(3, keyId.length());
        Long id = IntUtil.c32to10(str);
        return id.toString();
    }



    public static String getPlatFromShopIdTerminal(String shopId, String terminal) {
        String plat = "";
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal)) {
                plat = PeakConstant.PLAT_WX;
            }
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_WX;
            }
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_EPP_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_EPP_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                logger.info("商城及平台错误");
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal)) {
                logger.info("商城及平台错误");
            }
        } else if (PeakConstant.SHOPID_ROAMING.equals(shopId)) {
            plat = PeakConstant.PLAT_ROAMING;
        } else if (PeakConstant.SHOPID_MOTO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_WX;
            }
        } else if (PeakConstant.SHOPID_DONGDE.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_WX;
            }
        } else if (PeakConstant.SHOPID_ALLINPAY.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_ALLINPAY_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_ALLINPAY_WAP;
            }
        } else {
            plat = shopId;
        }
        return plat;
    }

    public static String getShopIdFromPlat(String plat) {
        String shopId = "";
        if (PeakConstant.PLAT_PC.equals(plat) || PeakConstant.PLAT_WAP.equals(plat) || PeakConstant.PLAT_APP.equals(plat) || PeakConstant.PLAT_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_LENOVO;
        } else if (PeakConstant.PLAT_THINK_PC.equals(plat) || PeakConstant.PLAT_THINK_WAP.equals(plat) || PeakConstant.PLAT_THINK_APP.equals(plat) || PeakConstant.PLAT_THINK_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_THINK;
        } else if (PeakConstant.PLAT_EPP_PC.equals(plat) || PeakConstant.PLAT_EPP_WAP.equals(plat)) {
            shopId = PeakConstant.SHOPID_EPP;
        } else if (PeakConstant.PLAT_ROAMING.equals(plat)) {
            shopId = PeakConstant.SHOPID_ROAMING;
        } else if (PeakConstant.PLAT_MOTO_PC.equals(plat) || PeakConstant.PLAT_MOTO_WAP.equals(plat) || PeakConstant.PLAT_MOTO_APP.equals(plat) || PeakConstant.PLAT_MOTO_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_MOTO;
        } else {
            shopId = plat;
        }
        return shopId;
    }

    public static String getTerminalFromPlat(String plat) {
        String terminal = "";
        if (PeakConstant.PLAT_PC.equals(plat) || PeakConstant.PLAT_THINK_PC.equals(plat) || PeakConstant.PLAT_EPP_PC.equals(plat) || PeakConstant.PLAT_MOTO_PC.equals(plat)) {
            terminal = PeakConstant.TERMINAL_PC;
        } else if (PeakConstant.PLAT_WAP.equals(plat) || PeakConstant.PLAT_THINK_WAP.equals(plat) || PeakConstant.PLAT_EPP_WAP.equals(plat) || PeakConstant.PLAT_MOTO_WAP.equals(plat)) {
            terminal = PeakConstant.TERMINAL_WAP;
        } else if (PeakConstant.PLAT_APP.equals(plat) || PeakConstant.PLAT_THINK_APP.equals(plat) || PeakConstant.PLAT_MOTO_APP.equals(plat) || PeakConstant.PLAT_ROAMING.equals(plat)) {
            terminal = PeakConstant.TERMINAL_APP;
        } else if (PeakConstant.PLAT_WX.equals(plat) || PeakConstant.PLAT_THINK_WX.equals(plat) || PeakConstant.PLAT_MOTO_WX.equals(plat)) {
            terminal = PeakConstant.TERMINAL_WECHAT;
        }
        return terminal;
    }

    public static String bigDecimalToString(BigDecimal d) {
        return String.valueOf(d);
    }

    /*public static String getHlwzqUrl(String outNotifyUrl) {
        Map<String, Object> resouceMap = PayConfig.loadToMap();
        String payEnvironment = (String) resouceMap.get("PAY_ENVIRONMENT");
        logger.info("运行环境==>" + payEnvironment);
        if ("domain".equals(payEnvironment)) {
            outNotifyUrl = outNotifyUrl.replace("https://cashier.lenovo.com.cn", "https://cashier.lenovo.com.cn/hlwzq");
            logger.info("修改话联网专区通知地址==>" + outNotifyUrl);
        }
        return outNotifyUrl;
    }*/


    /*public static void saveReceiveAddress(ChannelOrder channelOrder, OrderFewInfo orderFewInfo) {
        try {
            channelOrder.setTaxCompany(orderFewInfo.getTaxCompany());
            Deliveries deliveries = orderFewInfo.getDeliveries().get(0);
            String delivery = getDeliveryInfo(deliveries);
            channelOrder.setDelivery(delivery);
            logger.info("Get Delivery Info[" + delivery + "]");
            if(PeakConstant.SHOPID_SMB.equals(channelOrder.getShopId())){
                Deliveries vateDeliveries = orderFewInfo.getVatDeliveries().get(0);
                String vatDelivery = getDeliveryInfo(vateDeliveries);
                channelOrder.setVatDelivery(vatDelivery);
                logger.info("Get VatDelivery Info[" + vatDelivery + "]");
            }
        } catch (Exception e) {
            logger.error("构建收货地址异常", e);
        }
    }*/
    /*private static String getDeliveryInfo(Deliveries deliveries){
        String shipMobile = deliveries.getShipMobile();
        if(StringUtils.isNotEmpty(shipMobile)){
            shipMobile = shipMobile.substring(0, 3) + "****" + shipMobile.substring(7);
        }
        StringBuffer stringBuffer = new StringBuffer();
        if(StringUtils.isNotEmpty(deliveries.getShipName())){
            stringBuffer.append(deliveries.getShipName() + " ");
        }
        if(StringUtils.isNotEmpty(shipMobile)){
            stringBuffer.append(shipMobile + " ");
        }
        if(StringUtils.isNotEmpty(deliveries.getDeliverAreaName())){
            stringBuffer.append(deliveries.getDeliverAreaName() + " ");
        }
        if(StringUtils.isNotEmpty(deliveries.getShipCity())){
            stringBuffer.append(deliveries.getShipCity() + " ");
        }
        if(StringUtils.isNotEmpty(deliveries.getDeliverCounty())){
            stringBuffer.append(deliveries.getDeliverCounty() + " ");
        }
        if(StringUtils.isNotEmpty(deliveries.getShipAddr())){
            stringBuffer.append(deliveries.getShipAddr() + " ");
        }
        return stringBuffer.toString();
    }*/

    public static boolean checkHuabeiActivity() {
        Date checkDate = new Date();
        Date huaBeiDateStart = null;
        Date huaBeiDateEnd = null;
        try {
            Map<String, Object> paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            String huabeiActivityStart = (String) paySwitchMap.get("HUABEI_ACTIVITY_START");
            String huabeiActivityEnd = (String) paySwitchMap.get("HUABEI_ACTIVITY_END");
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            huaBeiDateStart = format.parse(huabeiActivityStart);
            huaBeiDateEnd = format.parse(huabeiActivityEnd);
            if (checkDate.after(huaBeiDateStart) && checkDate.before(huaBeiDateEnd)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception formatException) {
            logger.error("格式化花呗分期活动时间异常", formatException);
            return false;
        }
    }

    public static boolean checkDaChuActivity() {
        Date checkDate = new Date();
        Date daChuDateStart = null;
        Date daChuDateEnd = null;
        try {
            Map<String, Object> paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            String daChuActivityStart = (String) paySwitchMap.get("DACHU_ACTIVITY_START");
            String daChuActivityEnd = (String) paySwitchMap.get("DACHU_ACTIVITY_END");
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            daChuDateStart = format.parse(daChuActivityStart);
            daChuDateEnd = format.parse(daChuActivityEnd);
            if (checkDate.after(daChuDateStart) && checkDate.before(daChuDateEnd)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception formatException) {
            logger.error("格式化打出活动时间异常", formatException);
            return false;
        }
    }

    public static String getSuccessSyncReturnURLByShopIdTerminal(String shopId, String terminal) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/b2c_pc_succ";
            }else {
                returnURL = "syncback/b2c_wap_success";
            }
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("cashier_pay.properties");
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = (String) urlMap.get("THINK_PC_SUCC");
            }else {
                returnURL = (String) urlMap.get("THINK_WAP_SUCC");
            }
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/epp_pc_succ";
            }else {
                returnURL=  "syncback/epp_wap_success";
            }
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/smb_pc_succ";
            }else {
                returnURL = "syncback/b2c_wap_success";
            }
        }
        return returnURL;
    }

    public static String getFailSyncReturnURLByShopIdTerminal(String shopId, String terminal) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/b2c_pc_fail";
            }else {
                returnURL = "syncback/b2c_wap_error";
            }
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("cashier_pay.properties");
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = (String) urlMap.get("THINK_PC_ERROR");
            }else {
                returnURL = (String) urlMap.get("THINK_WAP_ERROR");
            }
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/epp_pc_fail";
            }else {
                returnURL=  "syncback/epp_wap_error";
            }
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/smb_pc_fail";
            }else {
                returnURL = "syncback/b2c_wap_error";
            }
        }
        return returnURL;
    }

    public static String getPCFailSyncReturnURLByShopId(String shopId) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            returnURL = "syncback/b2c_pc_fail";
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("cashier_pay.properties");
            returnURL = (String) urlMap.get("THINK_PC_ERROR");
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            returnURL = "syncback/epp_pc_fail";
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            returnURL = "syncback/smb_pc_fail";
        }else{
            returnURL = "outpay/outpay_pc_fail";
        }
        logger.info("getPCFailSyncReturnURLByShopId, URL[" + returnURL + "]");
        return returnURL;
    }
    public static String getPCSuccSyncReturnURLByShopId(String shopId) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            returnURL = "syncback/b2c_pc_succ";
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("cashier_pay.properties");
            returnURL = (String) urlMap.get("THINK_PC_SUCC");
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            returnURL = "syncback/epp_pc_succ";
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            returnURL = "syncback/smb_pc_succ";
        }else{
            returnURL = "outpay/outpay_pc_succ";
        }
        logger.info("getPCSuccSyncReturnURLByShopId, URL[" + returnURL + "]");
        return returnURL;
    }




    public static boolean checkInShopId(String shopId) {
        return (PeakConstant.SHOPID_LENOVO.equals(shopId) || PeakConstant.SHOPID_THINK.equals(shopId) || PeakConstant.SHOPID_EPP.equals(shopId) || PeakConstant.SHOPID_ROAMING.equals(shopId)
        || PeakConstant.SHOPID_MOTO.equals(shopId) || PeakConstant.SHOPID_DONGDE.equals(shopId) || PeakConstant.SHOPID_THINKCENTER.equals(shopId) || PeakConstant.SHOPID_SMB.equals(shopId)
        || PeakConstant.SHOPID_PCSD.equals(shopId));
    }

    public static boolean checkMoneyPattern(String refundFee) {
        Pattern pattern = Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){1,2})?$");
        Matcher matcher = pattern.matcher(refundFee);
        return matcher.matches();
    }

    public static RemoteResult<String> checkRequestParam(Map<String, String> requestParam) {
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        remoteResult.setSuccess(true);
        try{
            String itBPay = requestParam.get("it_b_pay");
            if(StringUtils.isNotEmpty(itBPay) && !"null".equals(itBPay)){
                logger.info("Invoke checkRequestParam Check:itBPay[" + itBPay + "]");
                if(itBPay.endsWith("m")||itBPay.endsWith("h")||itBPay.endsWith("d")){
                    try {
                        String itBPayStr = itBPay.substring(0, itBPay.length() - 1);
                        Integer itBPayInt = Integer.parseInt(itBPayStr);
                    }catch(NumberFormatException numberException){
                        logger.info("Illegal RequestParam, it_b_pay[" + itBPay + "]");
                        remoteResult.setSuccess(false);
                        remoteResult.setResultCode("it_b_pay");
                        return remoteResult;
                    }
                }else{
                    logger.info("Illegal RequestParam, it_b_pay[" + itBPay + "]");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("it_b_pay");
                    return remoteResult;
                }
            }
            String subject = requestParam.get("subject");
            if(StringUtils.isEmpty(subject)){
                logger.info("Illegal RequestParam, subject[" + subject + "]");
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("subject");
                return remoteResult;
            }
//            String payment = requestParam.get("payment");
//            if(StringUtils.isEmpty(payment)){
//                logger.info("Illegal RequestParam, payment[" + payment + "]");
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode("payment");
//            }
            return remoteResult;
        }catch(Exception e){
            logger.info("Invoke checkRequestParam Exception", e);
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("trade_info");
            return remoteResult;
        }
    }

    /**
     * Build Tenant
     * @param shopId Tenant Id
     * @param currencyCode 货币编码
     * @param language 语言编码
     * @param timeZone 租户时区
     * @param nationalCode 国家编码
     * @param nationalName 国家名称
     * @param currencySign 币种符号
     * @return
     */
    public static Tenant buildTenant(String shopId, String currencyCode, String language, String timeZone, String nationalCode, String nationalName, String currencySign){
        Tenant tenant = new Tenant();
        tenant.setShopId(Integer.parseInt(shopId));
        tenant.setCurrencyCode(currencyCode);
        tenant.setLanguage(language);
        tenant.setTimeZone(timeZone);
        tenant.setNationalCode(nationalCode);
        tenant.setNationalName(nationalName);
        tenant.setCurrencySign(currencySign);
        return tenant;
    }
}
