package com.lenovo.m2.web.common.my.utils;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.lenovo.m2.hsbuy.common.pruchase.enums.MoneyTypeEnum;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.lenovo.m2.arch.framework.domain.Money;

public class MoneySerializer extends JsonSerializer<Money> {



    public MoneySerializer(){

    }

    private MoneyTypeEnum type;



    public void setType(MoneyTypeEnum type) {
        this.type = type;
    }



    public MoneySerializer(MoneyTypeEnum type){
        this.setType(type);
    }



    @Override
    public void serialize(Money value, JsonGenerator jgen, SerializerProvider provider)
            throws IOException, JsonProcessingException {
        jgen.writeStartObject();
        jgen.writeStringField("amount", value.getAmount().toString());
        jgen.writeStringField("currencyCode", value.getCurrencyCode());
        jgen.writeEndObject();
    }


}
