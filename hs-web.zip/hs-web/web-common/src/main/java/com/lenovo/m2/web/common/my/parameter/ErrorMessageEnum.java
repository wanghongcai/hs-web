package com.lenovo.m2.web.common.my.parameter;

/**
 * Created by yyduff on 2016/5/12.
 */
public enum ErrorMessageEnum {

    ERROR_IDENTITY_MAX_SIZE_5M("9000","请上传小于5M的照片！"),
    ERROR_IDENTITY_IS_NULL("9001","证件图片不能为空！"),
    ERROR_SYSTEM("9002","系统异常！"),
    ERROR_IDENTITY_UPLOAD("9003","网络异常！");
    public String code;
    public String message;

     ErrorMessageEnum(String code, String message){
        this.code = code;
         this.message = message;
    }
 public static void main(String[] arags){

//     System.out.print(ErroMessageEnum.ERROR_IDENTITY_MAX_SIZE_5M.code);
 }

}
