package com.lenovo.m2.web.common.purchase.enums;

import com.lenovo.m2.web.common.purchase.exception.BusinessException;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 商城类别
* @ClassName: MerchantEnum
* @Description: (这里用一句话描述这个类的作用)
* @author yuzj7@lenovo.com
* @date 2015年7月21日 下午10:17:59
*
 */
public enum MerchantEnum {

	
	B2C_MALL("1", "B2C商城"),
	EPP_MALL("2", "EPP商城"),
	SHENQI_MALL("3", "神奇商城"),
	ROMING_MALL("4", "Roming商户"),
	THINK_MALL("5", "THINK商城");
	
	
	private String code;// 代号
	private String common;// 说明

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}

	MerchantEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	
	final static  Map<String, String> lookup = new TreeMap<String, String>(){
		
		private static final long serialVersionUID = -3457012985709276906L;

		{
			for(MerchantEnum m : EnumSet.allOf(MerchantEnum.class)){
				put(m.code, m.common);
			}
		}
	};
	
	
	final static  Map<String, MerchantEnum> merchantMap = new HashMap<String, MerchantEnum>(){
		{
			for(MerchantEnum m : EnumSet.allOf(MerchantEnum.class)){
				put(m.code, m);
			}
		}
	};
	
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<String, String> toMap() {
		return lookup;
	}


	public static MerchantEnum getValue(String code){
		if(merchantMap.containsKey(code)){
			return merchantMap.get(code);
		}else{
			throw new BusinessException(1, "非法merchantid=" + code );
		}
	}
	
	public static boolean checkMerchantCode(String code){
		return lookup.containsKey(code);
	}
	
	/**
	 * 
	* @Description: 通过平台获取商户
	* @author yuzj7@lenovo.com  
	* @date 2015年8月19日 下午8:02:40
	* @param plat
	* @return
	 */
	public static MerchantEnum getMerchantByPlat(Integer plat){
		PlatType.checkPlat(plat);
		switch(plat){
			case 1:
			case 2:
			case 3:
			case 4:
				return MerchantEnum.B2C_MALL;
			case 5:
			case 6:
			case 7:
			case 8:
				return  MerchantEnum.THINK_MALL;
			case 20:
			case 22:
				return MerchantEnum.EPP_MALL;
			case 30:
				return MerchantEnum.ROMING_MALL;
		}
		return null;
	}

}


