package com.lenovo.m2.web.common.purchase.enums;

import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * @ClassName: ErrorMessage
 * @Description: 接口平台错误信息汇总
 * @author yuzhijia mail-to yuzhijia88@126.com
 * @date 2014-6-18 上午9:49:48
 *
 */
public enum StockEnum {
	STOCK_SUCCESS("1000", "成功!"),
	STOCK_NOT_EXIST("1001", "库存不存在"), 
	STOCK_MORE_THANONE("1002", "找到多条库存!"), 
	STOCK_NOT_ENOUGH("1004", "库存不足!"), 
	STOCK_CONDITION_NO("1005", "条件不满足！"),
	STOCK_OREERA_FAIL("1007", "操作失败!"), 
	STOCK_FAIL("9999","占用库存失败！"), 
			;
	private String code;// 代号
	private String common;// 说明

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}

	StockEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<String, String> toMap() {
		if(map.size() > 0){
			return map;
		}
		for (int i = 0; i < StockEnum.values().length; i++) {
			map.put(StockEnum.values()[i].getCode(), StockEnum.values()[i].getCommon());
		}
		return map;
	}

}
