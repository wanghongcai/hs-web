package com.lenovo.m2.web.common.purchase.enums;

import java.util.Map;
import java.util.TreeMap;

/**
 * 
* @ClassName: PayTypeEnum 
* @Description: 支付类型枚举
* @author yuzj7@lenovo.com 
* @date 2015年10月15日 下午9:02:36 
*
 */
public enum PayTypeEnum {
	
	PAY_ONLINE("0","在线支付"),
	PAY_ONEHANDMONEY("1","货到付款"),
	;
	private String code;// 代号
	private String common;// 说明
	
	PayTypeEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}


	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<String, String> toMap() {
		if(map.size() > 0){
			return map;
		}
		for (int i = 0; i < PayTypeEnum.values().length; i++) {
			map.put(PayTypeEnum.values()[i].getCode(), PayTypeEnum.values()[i].getCommon());
		}
		return map;
	}
}
