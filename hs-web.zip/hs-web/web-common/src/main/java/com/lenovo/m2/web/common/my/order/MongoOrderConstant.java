package com.lenovo.m2.web.common.my.order;

/**
 * Created by yyduff on 2016/2/23.
 */
public class MongoOrderConstant {

    /**
     *已签收
     */
    public static final String ORDER_DELIVER_SIGNED = "7";
    /**
     * 订单活动状态
     */
    public static final String Order_STATUS_IS_ACTIVE = "1";
}
