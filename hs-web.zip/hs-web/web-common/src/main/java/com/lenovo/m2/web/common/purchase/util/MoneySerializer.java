package com.lenovo.m2.web.common.purchase.util;

/**
 * Created by D_xiao on 1/3/17.
 */

import com.lenovo.m2.arch.framework.domain.Money;
import java.io.IOException;

import com.lenovo.m2.hsbuy.common.pruchase.enums.MoneyTypeEnum;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

public class MoneySerializer extends JsonSerializer<Money> {
    private MoneyTypeEnum type;

    public MoneyTypeEnum getType() {
        return this.type;
    }

    public void setType(MoneyTypeEnum type) {
        this.type = type;
    }

    public MoneySerializer() {
    }

    public MoneySerializer(MoneyTypeEnum type) {
        this.setType(type);
    }

    public void serialize(Money value, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
        if(value != null) {
            switch(this.getType().ordinal()) {
                case 1:
                    jgen.writeString(String.valueOf(value.getAmount().intValue()));
                    break;
                case 2:
                    jgen.writeString(String.valueOf(value.getAmount().intValue()));
                    break;
                default:
                    jgen.writeString(value.getAmount().toString());
            }

        }
    }
}
