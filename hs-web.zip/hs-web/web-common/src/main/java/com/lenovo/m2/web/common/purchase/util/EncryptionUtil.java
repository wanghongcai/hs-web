package com.lenovo.m2.web.common.purchase.util;


/**
 * @Description: 加密解密工具类
 * @author:shenjc
 * @version:v1.0.0
 * @Created:2014年5月22日上午10:27:48
 * @Modified:
 */
public class EncryptionUtil {

	/**
	 * 
	  * @Description: 加密
	  * @param source 加密前的原串
	  * @return String 加密后的加密串
	  * @Created:lining 2014年5月22日上午10:29:01
	  * @Modified:
	 */
	public static String encryption(String source) {
		byte[] a = source.getBytes();
		for (int i = 0; i < a.length; i++) {
			a[i] = (byte) (a[i] ^ 't');
		}
		return Base64.encode(a);
	}
	
	/**
	 * 
	  * @Description: 解密
	  * @param target 需解密的加密串
	  * @return String 解密后的原串
	  * @Created:lining 2014年5月22日上午10:31:34
	  * @Modified:
	 */
	public static String deEncryption(String target) {
		byte[] a = Base64.decode(target);
		for (int i = 0; i < a.length; i++) {
			a[i] = (byte) (a[i] ^ 't');
		}
		String k = new String(a);
		
		return k;
	}
	
	// 测试主函数
	public static void main(String args[]) {
		String s = new String("y2yfcmbpprb0kwum7sljgu9917mdvmc0");
		System.out.println("原始：" + s);
		System.out.println("加密后：" + encryption(s));
		System.out.println("解密后：" + deEncryption(encryption(s)));
		
		String strKey = EncryptionUtil.deEncryption("JAENACYxPCAyRE0dAUJBQA==");
		String strBranchID = EncryptionUtil.deEncryption("RERFRA==");
		String strCono = EncryptionUtil.deEncryption("RERDTUBD");
		System.out.println("strKey>>" + strKey);
		System.out.println("strBranchID>>" + strBranchID);
		System.out.println("strCono>>" + strCono);
	}
}
