package com.lenovo.m2.web.common.purchase.enums;

import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * @ClassName: ErrorMessage
 * @Description: 接口平台错误信息汇总
 * @author yuzhijia mail-to yuzhijia88@126.com
 * @date 2014-6-18 上午9:49:48
 *
 */
public enum StockStatus {
	STOCK_EMPTY(0, "暂无库存"),
	STOCK_LITTLE(1, "少量库存"), 
	STOCK_NORMAL(2, "有库存"), 
	STOCK_PRESALE(3, "预售");
	
	private Integer code;// 代号
	private String common;// 说明

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}

	StockStatus(Integer code, String common) {
		this.code = code;
		this.common = common;
	}

	static  Map<Integer, StockStatus> map = new TreeMap<Integer, StockStatus>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<Integer, StockStatus> toMap() {
		if(map.size() > 0){
			return map;
		}
		for(StockStatus s: StockStatus.values()){
			map.put(s.getCode(), s);
			
		}
		return map;
	}

	public StockStatus valueOf(Integer code){
		return map.get(code);
	}
}
