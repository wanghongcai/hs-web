package com.lenovo.m2.web.common.purchase.enums;

import com.lenovo.enums.ENUM;

public enum Terminal {
	
	
	PC(1, "PC"),
	WAP(2, "WAP"),
	APP(3, "APP"),
	WECHAT(4, "微信");
	
	private final int type;
	private final String descr;
	
	private Terminal(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	} 

	
	public static boolean isWAP(int terminal){
		return WAP.getType() == terminal;
	}
	
	public static boolean isPC(int terminal){
		return PC.getType() == terminal;
	}
	
	public static boolean isAPP(int terminal){
		return APP.getType() == terminal;
	}
	public static boolean isWECHAT(int terminal){
		return WECHAT.getType() == terminal;
	}
	
	public static boolean right(int terminal){
		if(!Terminal.isAPP(terminal) || !Terminal.isPC(terminal) || !Terminal.isWAP(terminal) || !Terminal.isWECHAT(terminal)){
			return false;
		}
		return true;
	}
	
	public static void main(String[] args) {
		
		System.out.println(ENUM.BigPlatform.APP.getCode());
		System.out.println(ENUM.BigPlatform.PC.getCode());
		System.out.println(ENUM.BigPlatform.WAP.getCode());
		
	}
	
	
}
