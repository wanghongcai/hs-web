package com.lenovo.m2.web.common.stock.utils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;

public class HttpClient4Moto {

    private static Logger log = LogManager.getLogger(HttpClient4Moto.class.getName());

    /**
     * 执行GET请求
     *
     * @param url
     * @return
     */
    public static String executeGet(String url,String api,String context) {
        BufferedReader in = null;

        String content = null;
        try {
            // 定义HttpClient
            HttpClient client = new DefaultHttpClient();
            // 实例化HTTP方法
            HttpGet request = new HttpGet();
            request.setHeader("Api-Key",api);
            request.setHeader("Context-Id",context);
            request.setURI(new URI(url));
            HttpResponse response = client.execute(request);
            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
            StringBuffer sb = new StringBuffer("");
            String line;
            String NL = System.getProperty("line.separator");
            while ((line = in.readLine()) != null) {
                sb.append(line + NL);
            }
            in.close();
            content = sb.toString();
        }catch (Exception e){
            log.error("e--",e);
        }finally {
            if (in != null) {
                try {
                    in.close();// 最后要关闭BufferedReader
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return content;
    }

    /**
     * HttpClient POST请求
     */
    public static String executePost(String url, String json,String api,String context) {
        BufferedReader in = null;
        String content = null;
        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        /*        httpPost.setHeader("Accept-Encoding", "gzip, deflate");
        httpPost.setHeader("Accept-Language", "EN");*/
        httpPost.setHeader("Api-Key", api);
        httpPost.setHeader("Context-Id", context);
        httpPost.setHeader("Content-type", "application/json");
        try {
            StringEntity se = new StringEntity(json.toString());
            se.setContentType("application/json");
            se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            httpPost.setEntity(se);
            HttpResponse response = httpClient.execute(httpPost);
            if (response != null) {
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200 || statusCode == 403) {
                    in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
                    StringBuffer sb = new StringBuffer("");
                    String line;
                    String NL = System.getProperty("line.separator");
                    while ((line = in.readLine()) != null) {
                        sb.append(line + NL);
                    }
                    in.close();
                    content = sb.toString();
                }
            }
        }catch (Exception e){
            log.error("e--",e);
        } finally {
            {
                if (in != null) {
                    try {
                        in.close();// 最后要关闭BufferedReader
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return content;
    }

    /**
     * HttpClient PUT请求
     */
    public static String executePut(String url, String json,String api,String context) {
        BufferedReader in = null;
        String content = null;
        HttpClient htpClient = new DefaultHttpClient();
        HttpPut request = new HttpPut(url);
        //request.setHeader("Accept", "application/json, application/xml, text/html, text/*, image/*, */*");
        request.setHeader("Api-Key", api);
        request.setHeader("Context-Id", context);
        request.setHeader("Content-type", "application/json");
        try {
            System.out.println(json.toString());
            StringEntity se = new StringEntity(json);
            se.setContentType("application/json");
            se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            request.setEntity(se);
            HttpResponse response = htpClient.execute(request);
            if (response != null) {
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200 || statusCode == 403) {
                    in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
                    StringBuffer sb = new StringBuffer("");
                    String line;
                    String NL = System.getProperty("line.separator");
                    while ((line = in.readLine()) != null) {
                        sb.append(line + NL);
                    }
                    in.close();
                    content = sb.toString();
                }
            }
        }catch (Exception e){
            log.error("e--",e);
        } finally {
            {
                if (in != null) {
                    try {
                        in.close();// 最后要关闭BufferedReader
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return content;
    }

}
