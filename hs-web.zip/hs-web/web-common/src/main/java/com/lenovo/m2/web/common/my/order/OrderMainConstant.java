package com.lenovo.m2.web.common.my.order;

/**
 * Created by yyduff on 2016/2/23.
 */
public class OrderMainConstant {

    /**
     * 销售订单类型-普通
     */
    public static final int ADD_TYPE_NORMAL = 0;
    /**
     * 销售订单类型-闪购
     */
    public static final int ADD_TYPE_SEC_KILL = 1;
    /**
     * 销售订单类型-预售
     */
    public static final int ADD_TYPE_PRE_SELL = 2;
    /**
     * 销售订单类型-先试后买
     */
    public static final int ADD_TYPE_SALES_TRIAL = 3;
    /**
     * 销售订单类型-K码商品
     */
    public static final int ADD_TYPE_K_CODE = 4;
    /**
     * 销售订单类型-定制
     */
    public static final int ADD_TYPE_DESIGN = 5;
    /**
     * 销售订单类型-以旧换新
     */
    public static final int ADD_TYPE_OLD_CHANGE_NEW = 6;
    /**
     * 销售订单类型-c2c
     */
    public static final int ADD_TYPE_C2C = 7;
    /**
     * 销售订单类型-大侠码
     */
    public static final int ADD_TYPE_XCODE = 8;
    /**
     * 销售订单类型-CTO
     */
    public static final int ADD_TYPE_CTO = 9;
    /**
     * 销售订单类型-OTO
     */
    public static final int ADD_TYPE_OTO = 10;
    /**
     * 销售订单类型-众筹
     */
    public static final String ADD_TYPE_RAISE = "11";
    /**
     * 销售订单类型-团购
     */
    public static final String ADD_TYPE_GROUPPURCHASE = "12";

    /**
     * 销售类型-普通
     */
    public static final int SALES_TYPE_NORMAL = 0;
    /**
     * 销售类型-闪购
     */
    public static final int SALES_TYPE_SEC_KILL = 1;
    /**
     * 销售类型-预售
     */
    public static final int SALES_TYPE_PRE_SELL = 2;
    /**
     * 销售类型-先试后买
     */
    public static final int SALES_TYPE_SALES_TRIAL = 3;
    /**
     * 销售类型-K码商品
     */
    public static final int SALES_TYPE_K_CODE = 4;
    /**
     * 销售类型-定制
     */
    public static final int SALES_TYPE_DESIGN = 5;
    /**
     * 销售类型-CTO
     */
    public static final int SALES_TYPE_CTO = 96;
    /**
     * 销售类型-众筹
     */
    public static final int SALES_TYPE_RAISE = 97;
    /**
     * 销售类型-O2O
     */
    public static final int SALES_TYPE_O2O = 98;

    /**
     * 订单状态-活动订单
     */
    public static final int ORDER_STATUS_SAVE = 0;
    /**
     * 订单状态-作废订单
     */
    public static final int ORDER_STATUS_TO_VOID = 1;
    /**
     * 订单状态-已完成
     */
    public static final int ORDER_STATUS_COMPLETE = 2;

    /**
     * 退换货状态-无
     */
    public static final int IS_RETURN_STATUS_NOT_FOUND = 0;
    /**
     * 退换货状态-已换货
     */
    public static final int IS_RETURN_STATUS_REPLACED = 1;
    /**
     * 退换货状态-退货中
     */
    public static final int IS_RETURN_STATUS_REFUNDING = 2;
    /**
     * 退换货状态-换货中  已申请  未审批
     */
    public static final int IS_RETURN_STATUS_CHANGING = 3;
    /**
     * 退换货状态-撤单中
     */
    public static final int IS_RETURN_STATUS_CANCELLING = 4;
    /**
     * 退换货状态-已撤单
     */
    public static final int IS_RETURN_STATUS_CANCELLED = 5;
    /**
     * 退换货状态-已退货
     */
    public static final int IS_RETURN_STATUS_RETURNED = 6;

    /**
     * FA类型-直营
     */
    public static final int FA_TYPE_DIRECT = 0;
    /**
     * FA类型-代理
     */
    public static final int FA_TYPE_RESELLERS = 1;
    /**
     * FA类型-MBG
     */
    public static final int FA_TYPE_MBG = 2;
    /**
     * FA类型-Think直营
     */
    public static final int FA_TYPE_THINK_DIRECT = 3;
    /**
     * FA类型-ThinkFA
     */
    public static final int FA_TYPE_THINK_RESELLERS = 4;
    /**
     * dongde FA
     */
    public static  final int FA_TYPE_DONGDE = 5;
    /**
     * 商户号-商城
     */
    public static final String  MERCHANT_ID_LENOVO = "1";
    /**
     * 商户号-EPP
     */
    public static final String MERCHANT_ID_EPP = "3";
    /**
     * 商户号-roaming
     */
    public static final String MERCHANT_ID_ROAMING = "4";
    /**
     * 商户号-Think
     */
    public static final String  MERCHANT_ID_THINK = "2";
    /**
     * 商户号-Smb smb商城
     */
    public static final String  MERCHANT_ID_SMB = "8";
    /**
     * 商户号-Smb smbjf商城
     */
    public static final String  MERCHANT_ID_SMBJF = "9";
    /**
     * 商户号-惠商商城
     */
    public static final String  MERCHANT_ID_HUIMALL = "14";
    /**
     * 商户号-惠商积分商城
     */
    public static final String  MERCHANT_ID_HUIMALLJF = "15";
    /**
     * 乐豆换算比率
     */
    public static final  double MONEY_CONVERT_RATE = 0.01;

    /**
     * 两次拆单后是否活动订单标识
     */
    public static final String  IS_ACTIVE_STATUS = "1";
    /**
     * 懂得identity审核状态
     */
    public static  final int    DONGDE_IDENTITY_STATUS_ACCEPT = 1;
    public static  final int    DONGDE_IDENTITY_STATUS_REFUSE = -1;

    public static final String  NOT_ACTIVE_STATUS = "0";

    public static final int IS_PAY_STATUS = 1;
    public static final int NOT_PAY_STATUS = 0;

    public static final int  TERMINAL_PC = 1;
    public static final int  TERMINAL_WAP = 2;
    public static final int  TERMINAL_APP = 3;
    public static final int TERMINAL_WX = 4;
}
