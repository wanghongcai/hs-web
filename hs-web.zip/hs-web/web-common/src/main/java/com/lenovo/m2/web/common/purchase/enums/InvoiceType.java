package com.lenovo.m2.web.common.purchase.enums;

/**
 * 发票类型
 */
public enum InvoiceType {
	
	E_INVOICE(0, "电子发票"), COMMON_INVOICE(1, "普通发票"), VALUE_ADDED_INVOICE(2, "增值发票");

	private final int type;
	private final String descr;
	
	private InvoiceType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}
	
	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	public static enum TitleType{
		
		INDIVIDUAL(0, "个人"), CORPORATION(1, "公司");
		
		private final int type;
		private final String descr;
		
		private TitleType(int type, String descr){
			this.type = type;
			this.descr = descr;
		}

		public int getType() {
			return type;
		}

		public String getDescr() {
			return descr;
		}
		
	}
	
}
