package com.lenovo.m2.web.common.purchase.enums;

/**
 * 
* @ClassName: ErrorMessageEnum
* @Description:公共错误信息汇总
* @author lihc5@lenovo.com
* @date 2015年11月25日
*
 */
public enum ErrorMessageEnum implements ErrorMessageEnums {

	SUCCESS(0,"success"),
	ERROR_NOT_LOGIN(401,"请登陆后操作！"),

	ERROR_SAVE_INVOICE(00001,"公司发票不能开电子票!"),

	ERROR_PARAM(10000,"参数错误！"),
	ERROR_ILLEGAL(10001,"参数非法！"),
	ERROR_ORDER_FAIL(10002,"订单生成失败！"),
	ERROR_QUERY(10003,"查询失败! "),
	ERROR_STOCK_NOT_ENOUGH(10004,"库存不足！"),
	ERROR_STOCK_INTERFACE(10005,"调用库存接口失败！"),
	ERROR_ZC_ILLEGAL(10006,"众筹参数错误！"),
	ERROR_MOBILE(10007,"手机号不正确! "),
	ERROR_UPDATE_MOBILE(10008,"更新手机号失败! "),
	ERROR_ORDER_COMMIT(10009,"订单提交失败! "),
	ERROR_GET_CART(10010,"获取购物车失败! "),
	ERROR_BANKCARD_NUMBER(10011,"请输入正确的银行卡号! "),
	ERROR_ZIPCODE(10012,"请输入正确的邮编! "),
	ERROR_TIMEOUT(10013,"网络异常，请稍后再试!"),
	ERROR_USER_ILLEGAL(10014,"用户信息错误!"),
	ERROR_BUYCODE(10015,"经销商信息获取失败!"),
	ERROR_BUYER_AUTH(10016,"经销商认证信息获取失败!"),
	ERROR_BUYER_AUTH_NO(10017,"经销商尚未实名认证!"),
	ERROR_CAPTCHA(10018, "请输入正确的手机验证码!"),
	ERROR_RETURN_CLOSE(10038, "惠商订单入口已经停用，请前往新的系统下单!"),

	ERROR_CART_UNKNOWN_ITEMTYPE(20000,"添加到购物车，未知的itemtype! "),
	ERROR_SECKILL_CHECK(20001,"闪购资格校验失败! "),
	ERROR_OVER_PURCHASE_NUMBER(20002,"超过购买次数! "),
	ERROR_PURCHASE_UNKNOWN_ITEMTYPE(20003,"立即购买失败，未知的itemtype! "),
	ERROR_PACKAGE_INFO(20004,"套餐信息有误! "),
	ERROR_FIND_NOT_PACKAGE_INFO(20005,"查询不到套餐信息! "),
	ERROR_FIND_NOT_PURCHASE_ROW(20006,"找不到购物行信息! "),
	ERROR_NOT_SELECT_SERVICE_DELETE(20007,"没有选中该服务，不能删除! "),
	ERROR_NOT_APPOINTMENTS_BEGIN_OR_PASS(20008,"预约尚未开始或预约时间已过! "),
	ERROR_NOT_REPRERT_APPOINTMENTS(20009,"您已预约，不能重复预约! "),
	ERROR_GOODS_NOT_FOUND(20010,"查询商品失败!"),
	ERROR_VERIFY_SIGN_FAILD(20012,"验签失败!"),

	

	ERROR_COUPONCODE_INVALID(20023, "无效的优惠码或优惠码已失效（次数用尽）！"),

	/**
	 * 内购额度相关错误信息 add by zhanghs 2015-11-30
	 */
	ERROR_INNERLIMIT_NOT_DECIMALS(20030, "内购额度不能为小数！"),
	ERROR_INNERLIMIT_NOT_VALID(20031, "对不起，您的内购额度还没有生效!"),
	ERROR_INNERLIMIT_MORETHEN_USER_VALID(20032, "使用内购额度大于用户可用内购额度！"),
	ERROR_INNERLIMIT_EXPIRED(20033, "对不起，您的内购额度已经过期!"),
	ERROR_INNERLIMIT_ILLEGITMACY(20034, "使用内购额度非法!"),
	ERROR_INNERLIMIT_MORETHEN_PRODUCT_VALID(20035, "使用的内购额度不能大于商品可用内购额度!"),
	ERROR_INNERLIMIT_CONSUME_FAIL(20036, "消费内购额度失败！"),

	/**
	 * 订单回填去参数化业务
	 */
	ERROR_BACKFILL_UPDATE_FALL(20100,"更新结算缓存失败，请稍后再试!"),
	ERROR_BACKFILL_GET_FALL(20101,"获取结算缓存失败，请稍后再试!"),

	INVOICE_ERROR(30000,"发票信息有误!"),
	ERROR_ORDER_NOT_MONEY(30001,"下单失败，订单金额不能小于或等于0元!"),
	ERROR_GET_SALETYPE(30002,"销售类型获取错误!"),
	ERROR_ORDER_CANCEL(30003,"订单取消失败!"),
	CHOOSE_CONSOLIDATED_INVOICES(30004,"请选择是否合并开票!"),
	ERROR_INVOICE_NOTEMPTY(30005,"发票抬头不能为空!"),
	ERROR_INVOICE_NOT_MORETHAN_100(30006,"发票抬头不能大于100个字符!"),
	ERROR_REGISTERED_ADDRESS_NOT_EMPTY(30007,"注册地址不能为空!"),
	ERROR_REGISTERED_ADDRESS_NOT_MORETHAN_100(30008,"注册地址不能大于100个字符!"),
	ERROR_BANK_ACCOUNT_NOT_EMPTY(30009,"开户银行不能为空!"),
	ERROR_BANK_ACCOUNT_NOT_MORETHAN_100(30010,"开户银行不能大于100个字符!"),
	ERROR_UPLOAD_TWO_PHOTOS(30011,"请上传两张资质图片!"),
	ERROR_INVOICE_ADDRESSEE_NOT_EMPTY(30012,"发票收件人姓名不能为空!"),
	ERROR_INVOICE_ADDRESSEE_NOT_MORETHAN_50(30013,"发票收件人姓名不能大于50个字符!"),
	ERROR_INVOICE_ADDRESSEE_PROVINCE_NOT_EMPTY(30014,"发票收件人所在省份或城市或区县不能为空!"),
	ERROR_INVOICE_ADDRESSEE_INFO_NOT_EMPTY(30015,"发票收件人地址明细不能为空!"),
	ERROR_INVOICE_ADDRESSEE_INFO_NOT_MORETHAN_100(30016,"发票收件人地址明细不能大于100个字符!"),
	ILLEGAL_TAXPAYER_IDENTIFICATION_CODE(30017,"纳税人识别码不合法，不能包含除数字和字母以外的数据!"),
	ERROR_SAME_PHOTOS(30018,"请不要上传两张一模一样的图片资质，否则审核无法通过，无法开具增值税发票! "),
	ERROR_INVOICE_FAIL(30019,"保存增值税发票失败"),
	ERROR_INVOICE_PHONENO_NOT_EMPTY(30020,"注册电话不能为空"),
	ERROR_INVOICE_PHONENO_NOT_FORMAT(30021,"请输入正确的固话或者手机号"),

	ERROR_SYSTEM_BUSY(99990,"系统繁忙,请稍后再试！"),
	ERROR_SYSTEM_EXCEPTION(99999,"系统错误"),

    /******↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  以下是收银台支付的提示信息枚举，开始。↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓**************************************/

    ERROR_USER_NOT_LOGIN(50000,"用户未登录！"),
    ERROR_ORDER_QUERY_FAIL(50001,"Failed to query the order!"),
    ERROR_ILLEGAL_REQUEST(50002,"Illegal request"),
    ERROR_ORDER_STATUS_EXCEPTION(50003,"订单状态异常，请重新发起支付！"),
    ERROR_ORDER_STATUS_INVALID(50004,"订单已失效，请到订单列表查看详情！"),
    ERROR_ORDER_STATUS_PAID(50005,"订单已支付，请到订单列表查看详情！"),
    ERROR_ORDER_CONTRACT_EXCEPTION(50006,"Abnormal order contract!"),
    ERROR_PAYMENTWAY_QUERY_FAIL(50007,"Query payment method failed"),
    ERROR_PAY_EXCEPTION(50008,"支付异常！"),
//    ERROR_(5000,""),
//    ERROR_(5000,""),
//    ERROR_(5000,""),
//    ERROR_(5000,""),
//    ERROR_(5000,""),

    /******↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑  以上是收银台支付的提示信息枚举，结束。↑↑↑↑↑↑↑↑↑↑↑↑↑↑****************************************/


    ;
	private int code;// 代号
	private String common;// 说明
	
	ErrorMessageEnum(Integer code, String common) {
		this.code = code;
		this.common = common;
	}

	public int getCode() { return code; }
	public void setCode(int code) { this.code = code; }
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}


//	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
//	public static Map<String, String> toMap() {
//		if(map.size() > 0){
//			return map;
//		}
//		for (int i = 0; i < ErrorMessageEnum.values().length; i++) {
//			map.put(ErrorMessageEnum.values()[i].getCode(), ErrorMessageEnum.values()[i].getCommon());
//		}
//		return map;
//	}
    @Override
    public String toString() {
        return common;
    }

}
