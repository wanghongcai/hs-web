package com.lenovo.m2.web.common.my.utils;


import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.hsbuy.common.pruchase.enums.MoneyTypeEnum;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.JavaType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.lenovo.m2.web.common.my.utils.MoneySerializer;
import com.lenovo.m2.web.common.my.utils.MoneyDeserializer;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

//import org.codehaus.jackson.JsonFactory;
//import org.codehaus.jackson.JsonGenerator;
//import org.codehaus.jackson.JsonParseException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;


/**
 * Created by chenww3 on 2015/6/14.
 */
public class JsonUtil {



    private static Logger logger = LogManager.getLogger(JsonUtil.class);
    public static final ObjectMapper OM = new ObjectMapper();
    static{
        OM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        OM.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

         /*---money module---*/
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneySerializer());
        module.addDeserializer(Money.class, new MoneyDeserializer());

        OM.registerModule(module);
    }
    public static JavaType assignList(Class<? extends Collection> collection, Class<? extends Object> object) {
        return JsonUtil.OM.getTypeFactory().constructParametricType(collection, object);
    }


    public static <T> ArrayList<T> readValuesAsArrayList(String key, Class<T> object) {
        ArrayList<T> list = null;
        try {
            list = OM.readValue(key, assignList(ArrayList.class, object));
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        } catch (JsonMappingException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        return list;
    }


    public static String toJson(Object obj){
        try {
            return OM.writeValueAsString(obj);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }


    public static <T> T fromJson(String json, Class<T> clazz){
        try {
            return OM.readValue(json, clazz);
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        } catch (JsonMappingException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(),e);
        }
        return null;
    }

    public static class MoneyScore extends JsonUtil{
        public static final ObjectMapper OMM = new ObjectMapper();
        static{
            // 设置输入时忽略在JSON字符串中存在但Java对象实际没有的属性
            OMM.disable(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES);
            OMM.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
            OMM.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            /*---money---*/
            SimpleModule module = new SimpleModule("money", Version.unknownVersion());
            module.addSerializer(Money.class, new MoneySerializer(MoneyTypeEnum.SCORE));
            OMM.registerModule(module);

            OMM.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
        }
    }
}
