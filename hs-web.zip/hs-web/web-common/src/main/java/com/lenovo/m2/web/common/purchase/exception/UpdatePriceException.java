package com.lenovo.m2.web.common.purchase.exception;

/**
 * 
 * @description	更新价格失败异常
 * 
 * @classname     UpdatePriceException 
 * @author        zhanghs
 * @date         2015年7月22日 上午11:09:14 
 * @version     1.0
 */
public class UpdatePriceException extends Exception {

//	private String code;
//	private String msg;
	
	public UpdatePriceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UpdatePriceException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UpdatePriceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UpdatePriceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UpdatePriceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	

	
}
