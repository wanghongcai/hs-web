package com.lenovo.m2.web.common.promotion.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luqian on 2015-11-16.
 */
public enum PromotionCrowd {
    CROWD_ALL(0,"全部"),
    CROWD_PART(1,"部分");


    private final int type;
    private final String descr;
    PromotionCrowd(int type, String descr){
        this.type = type;
        this.descr = descr;
    }

    public String getDescr() {
        return descr;
    }

    public int getType() {
        return type;
    }

    final  static Map<Integer, String> map = new HashMap<Integer, String>();
    final  static  Map<Integer,PromotionCrowd> enumMap = new HashMap<Integer, PromotionCrowd>();
    public static PromotionCrowd getCrowdByType(int type ){
        if(enumMap.size() > 0){
            return enumMap.get(type);
        }
        PromotionCrowd[]crowdEnums =  PromotionCrowd.values();
        for (PromotionCrowd crowdEnum:crowdEnums){
            enumMap.put(crowdEnum.getType(),crowdEnum);
        }
        return enumMap.get(type);
    }

}
