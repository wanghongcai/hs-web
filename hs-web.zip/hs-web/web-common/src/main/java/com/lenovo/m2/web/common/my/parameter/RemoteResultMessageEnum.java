package com.lenovo.m2.web.common.my.parameter;

/**
 * Created by yyduff on 2016/5/12.
 */
public enum RemoteResultMessageEnum {

        DONGDE_SUCCESS("000000","操作成功!");

        public String code;
        public String message;
    RemoteResultMessageEnum(String code,String message){
        this.code = code;
        this.message = message;
    }


}
