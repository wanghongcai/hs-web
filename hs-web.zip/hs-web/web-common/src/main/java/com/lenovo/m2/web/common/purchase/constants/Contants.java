package com.lenovo.m2.web.common.purchase.constants;
/**
 * 
* @ClassName: Contants
* @Description: 常量类
* @author yuzj7@lenovo.com
* @date 2015年5月18日 下午12:22:32
*
 */
public class Contants {
	//接口签名校验key
	public static final String 	MD5_KEY = ")(*&^%$#@!MNBVCX76543";
	//乐豆接口校验key 
	public static final String MD5_HAPPYBEAN = "@#$23@89_lenovo_ledou#00";
	//md5 订单退货取消md5校验
	public static final String MD5_ORDER = "!@#$%^&*()";
	//个人中心收货地址每页显示
	public static final int pageSize = 2;
	
	
}
