package com.lenovo.m2.web.common.my.utils;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 错误码
 * Created by mayan3 on 2015/10/12.
 */
public class ErrorUtil {

    public static Map<String, String> ERR_CODE_MSG_MAP = Maps.newHashMap();

    // 成功
    public static final String SUCCESS = "0";

    /**
     * ************************通用的错误代码start********************************
     */
    // 系统异常错误
    public static final String SYSTEM_UNKNOWN_EXCEPTION = "10001";
    // 必填的参数错误
    public static final String ERR_CODE_COM_REQURIE = "10002";
    //获取订单列表失败
    public static final String ERR_GET_ORDERLIST = "20001";
    //获取订单详情失败
    public static final String ERR_GET_ORDERDETAIL = "20002";
       //获取ORDERDERDELIVERIES失败
    public static final String ERR_GET_ORDERDERDELIVERIES = "20003";

    public ErrorUtil() {
        super();
    }

    static {
        // 通用错误
        ERR_CODE_MSG_MAP.put(SUCCESS, "操作成功");
        ERR_CODE_MSG_MAP.put(SYSTEM_UNKNOWN_EXCEPTION, "未知错误");
        ERR_CODE_MSG_MAP.put(ERR_CODE_COM_REQURIE, "参数错误,请输入必填的参数");

    }

    public static Map<String, String> getERR_CODE_MSG_MAP() {
        return ERR_CODE_MSG_MAP;
    }

    public static String getERR_CODE_MSG(String code) {
        return ERR_CODE_MSG_MAP.get(code);
    }

}
