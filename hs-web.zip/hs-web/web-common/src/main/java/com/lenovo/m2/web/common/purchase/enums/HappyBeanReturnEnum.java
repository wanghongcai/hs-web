package com.lenovo.m2.web.common.purchase.enums;

import java.util.Map;
import java.util.TreeMap;

/**
 * 
* @ClassName: HappyBeanReturnEnum
* @Description: 乐豆接口返回数据枚举
* @author yuzj7@lenovo.com
* @date 2015年7月23日 下午9:41:20
*
 */
public enum HappyBeanReturnEnum {

	HAPPYBEAN_SUCCESS("001", "操作成功"),
	CODE_NOT_RIGHT("002", "code的编码不对"), 
	USERID_NOT_EXIST("003", "userId 缺失"), 
	OPERATION_NOT_RIGHT("004", "opt(对乐豆的操作)不对"), 
	TIME_NOT_RIGHT("005", "时间戳不正确"),
	IILAGE_REQUEST("006", "非法请求"), 
	HAYYP_BEAN_NOT_EN("007","用户乐豆数量不足，无法进行后续操作"),

			;
	private String code;// 代号
	private String common;// 说明

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}

	HappyBeanReturnEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<String, String> toMap() {
		if(map.size() > 0){
			return map;
		}
		for (int i = 0; i < StockEnum.values().length; i++) {
			map.put(HappyBeanReturnEnum.values()[i].getCode(), HappyBeanReturnEnum.values()[i].getCommon());
		}
		return map;
	}


}
