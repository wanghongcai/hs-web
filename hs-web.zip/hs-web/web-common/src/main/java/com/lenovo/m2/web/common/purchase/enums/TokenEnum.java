package com.lenovo.m2.web.common.purchase.enums;
/**
 * 
* @ClassName: TokenEnum 
* @Description: 令牌的使用方式 1，提交，2 生成
* @author yuzj7@lenovo.com 
* @date 2015年9月5日 下午5:17:03 
*
 */
public enum TokenEnum {
	SUBMIT,GENERATE;
}
