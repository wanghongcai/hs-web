package com.lenovo.m2.web.common.purchase.constants;

/**
 * 支付平台数据
 * Created by MengQiang on 2015/5/27.
 */
public class PeakConstant {
    //支付类型
    public static final String PAY_TYPE_CMB = "0";//招商银行支付
    public static final String PAY_TYPE_ALJS = "1";//支付宝即时支付
    public static final String PAY_TYPE_ALSJ = "2";//支付宝手机支付
    public static final String PAY_TYPE_ALCWG = "3";//支付宝纯网关支付
    public static final String PAY_TYPE_ALHB = "4";//支付宝合并支付
    public static final String PAY_TYPE_ALFQ = "5";//支付宝分期支付
    public static final String PAY_TYPE_YDKJ = "6";//支付宝移动快捷支付
    public static final String PAY_TYPE_UNION = "7";//银联支付
    public static final Integer PAY_TYPE_WX = 9;//微信支付
    public static final String PAY_TYPE_WECHAT = "9";//微信支付
    public static final String PAY_TYPE_ABCFQ = "10";//农行分期支付
    public static final Integer CALL_B2C_WX = 16;
    public static final String PAY_TYPE_ALHUABEIFQ = "11";//支付宝花呗分期
    public static final String PAY_TYPE_ALLINPAY = "12";//通联支付
    public static final String PAY_TYPE_PINGAN = "13";//平安支付
    public static final String PAY_TYPE_ALLINPAY_WAP = "14";//通联手机支付
    public static final String PAY_TYPE_PINGAN_WAP = "15";//平安手机支付
    public static final String PAY_TYPE_UMPAY = "16"; //联动优势支付
    public static final String PAY_TYPE_UMPAY_WAP = "17"; //联动优势手机支付
    public static final String PAY_TYPE_SMB_OFFLINE = "20"; //SMB线下支付
    public static final String PAY_TYPE_CMBFQ = "21"; //CMB网关分期支付
    //Plat
    public static final String PLAT_WAP = "1";//WAP
    public static final String PLAT_WX = "2";//微信
    public static final String PLAT_APP = "3";//APP
    public static final String PLAT_PC = "4";//PC
    public static final String PLAT_THINK_WAP = "5";//THINKWAP
    public static final String PLAT_THINK_WX = "6";//THINK微信
    public static final String PLAT_THINK_APP = "7";//THINKAPP
    public static final String PLAT_THINK_PC = "8";//THINKPC
    public static final String PLAT_EPP_WAP = "20";//EPP add by lijie 15-9-01
    public static final String PLAT_EPP_PC = "22";
    public static final String PLAT_ROAMING = "0";
    public static final String PLAT_MOTO_WAP = "51";//MOTO WAP
    public static final String PLAT_MOTO_WX = "52";//MOTO 微信
    public static final String PLAT_MOTO_APP = "53";//MOTO APP
    public static final String PLAT_MOTO_PC = "54";//MOTO PC
    public static final String PLAT_DONGDE_WAP = "61";//DONGDE WAP
    public static final String PLAT_DONGDE_WX = "62";//DONGDE 微信
    public static final String PLAT_DONGDE_APP = "63";//DONGDE APP
    public static final String PLAT_DONGDE_PC = "64";//DONGDE PC

    public static final String PLAT_ALLINPAY_PC = "65";//通联PC
    public static final String PLAT_ALLINPAY_WAP = "66";//通联WAP

    //订单类型
    public static final String ORDER_TYPE_NORMAL_SALES = "0";//普通订单
    public static final String ORDER_TYPE_FLASH_SALES = "1";//闪购
    public static final String ORDER_TYPE_PRESELLS = "2";//预售
    public static final String ORDER_TYPE_ZC = "11";//众筹
    public static final String ORDER_TYPE_TUAN = "12";//团购
    public static final String ORDER_TYPE_DONGDE_CZ = "13";//懂得充值

    //字符集
    public static final String CHARSET = "UTF-8";
    //招商银行请求地址
    public static final String CMB_PC = "https://netpay.cmbchina.com/netpayment/basehttp.dll?PrePayc2";//PC端
    public static final String CMB_TEST = "https://netpay.cmbchina.com/netpayment/basehttp.dll?TestPrePayC2";//Test
    public static final String CMB_PHONE = "https://netpay.cmbchina.com/netpayment/basehttp.dll?Prepaywap";//手机端
    //招商银行回调
    public static final String CMB_WAP_CALLBACK = "https://cashier.lenovo.com.cn/wapcmbpaynotice.jhtm";//手机端回调
    public static final String CMB_WX_CALLBACK = "https://cashier.lenovo.com.cn/wxcmbpaynotice.jhtm";//微信端回调
    public static final String CMB_APP_CALLBACK = "https://cashier.lenovo.com.cn/appcmbpaynotice.jhtm";//APP端回调
    public static final String CMB_PC_CALLBACK = "https://cashier.lenovo.com.cn/pccmbpaynotice.jhtm";//PC端回调

    //更新订单Pay信息 payment 0 招商银行, 1支付宝, 4支付宝直连支付,7银联支付
    public static final String PAYMENT_CMB = "0";
    public static final String PAYMENT_ALI = "1";
    public static final String PAYMENT_UNION = "7";
    //    public static final String PAYMENT_ALICWG = "4";
    public static final String PAYMENT_ABCFQ = "10";//农行分期支付
    public static final String PAYMENT_CMBFQ = "21";//招行分期支付
    public static final String PAYMENT_PINGAN = "13";//平安银行支付

    //merchantpayplat表和wx_pay_order表merchantId字段对应关系
    public static final String PAY_PLAT_SHENQI = "shenqi";
    public static final String PAY_PLAT_B2C = "b2c";
    public static final String PAY_PLAT_EPP = "epp";
    public static final String PAY_PLAT_MOTO = "moto";
    //MERCHANT_FLAG,商户通知标识|1：已成功通知，2：未通知，3：需再次通知商户
    public static final int MFLAG_SUCC = 1;
    public static final int MFLAG_NOT = 2;
    public static final int MFLAG_REPEAT = 3;

    //VERSION
    public static final int VERSION_ONE = 1;

    //TRADE_STATE|1：成功,其他表示失败
    public static final int TRADE_SUCCESS = 1;

    //
    public static final int GETORDERCODE_TRUE = 1;
    public static final int GETORDERCODE_FASE = 0;

    public static final String TRUE_FLAG_STR = "1";
    public static final String FALSE_FLAG_STR = "0";
    public static final int TRUE_FLAG_INT = 1;
    public static final int FLASE_FLAG_INT = 0;
    //扫码类型
    public static final String QRPAYMODE_ZERO = "0";
    public static final String QRPAYMODE_ONE = "1";
    public static final String QRPAYMODE_THREE = "3";
    public static final String QRPAYMODE_FOUR = "4";
    public static final String QRPAYMODE_FIVE = "5";
    public static final String QRPAYMODE_SIX = "6";
    public static final String QRPAYMODE_SEVEN = "7";
    public static final String QRPAYMODE_EIGHT = "8";
    //平台信息改造SHOPID
    public static final String SHOPID_LENOVO = "1";
    public static final String SHOPID_THINK = "2";
    public static final String SHOPID_EPP = "3";
    public static final String SHOPID_ROAMING = "4";
    public static final String SHOPID_MOTO = "5";
    public static final String SHOPID_DONGDE = "6";
    public static final String SHOPID_THINKCENTER = "7";
    public static final String SHOPID_SMB = "8";
    public static final String SHOPID_PCSD = "11";
    public static final String SHOPID_ALLINPAY = "14";//惠商
    public static final String SHOPID_IN = "16";//印度moto项目


    //平台信息改造TERMINAL
    public static final String TERMINAL_PC = "1";
    public static final String TERMINAL_WAP = "2";
    public static final String TERMINAL_APP = "3";
    public static final String TERMINAL_WECHAT = "4";
    //更新ChannelOrder时间格式
    public static final String CHANNEL_ORDER_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    //更新中间件时间格式
    public static final String CALL_MIDDLEWARE_PAY_TYPE = "yyyyMMddHHmmss";
    //退货状态
    public static final Integer REFUND_STATE_SUCCESS = 1;
    public static final Integer REFUND_STATE_UNKNOW = 2;
    public static final Integer REFUND_STATE_FAIL = 3;
    //退货通知状态
    public static final Integer NOTIFY_FLAG_SUCCESS = 1;
    public static final Integer NOTIFY_FLAG_FAIL = 0;
    //代收代付FA
    public static final String LEDGERFAID = "7ef1d628-5bd3-4651-9530-793678cc02af";
    public static final String LEDGERFANAME = "联想(上海)电子科技有限公司";
    //渠道订单标识
    public static final Integer MAIN_ORDER_FLAG = 1;
    public static final Integer SUB_ORDER_FLAG = 0;
    //支付状态
    public static final String PAY_STATUS_ALREADY_PAID = "1";
    public static final String PAY_STATUS_NOT_PAID = "0";
    //订单状态
    public static final String ORDER_STATUS_AVAILABLE = "0";
    public static final String ORDER_STATUS_INVALID = "1";
    //惠商订单审核状态
    //public static final String ORDER_AUDIT_STATUS_AUTOPASS = "0";//自动过审
    public static final String ORDER_AUDIT_STATUS_PASS = "1";//审核通过
    public static final String ORDER_AUDIT_STATUS_WAITAUDIT = "2";//待审核
    public static final String ORDER_AUDIT_STATUS_FAIL = "3";//审核未通过
    public static final String ORDER_AUDIT_SIGNING_CONTRACT = "4";//生成合同中
    public static final String ORDER_AUDIT_SIGNED_CONTRACT = "5";//已签订合同
    //惠商信用账单支付状态
    public static final String CREDIT_ORDER_STATUS_ALREADY_PAID = "1";//已付款
    public static final String CREDIT_ORDER_STATUS_NOT_PAID = "0";//未付款
    //慧商订单使用信用额度状态
    public static final int ORDER_CREDIT_USE_NO = 0;//未使用信用额度
    public static final int ORDER_CREDIT_USE_PART = 1;//部分使用信用额度
    public static final int ORDER_CREDIT_USE_ALL = 2;//全款用信用额度
    //支付方式
    public static final String ORDER_PAYMENTTYPE_OFFLINE = "2";//线下打款
    public static final String ORDER_PAYMENTTYPE_OFFLINE_ZH = "线下银行转账";//线下打款，中文
    //慧商线下支付订单，上传支付资料状态
    public static final String ORDER_OFFLINE_UPLOADSTATUS_NULL = null;//未经过收银台确认，还不能上传资料
    public static final String ORDER_OFFLINE_UPLOADSTATUS_START = "1";//订单列表可以开始上传资料
    public static final String ORDER_OFFLINE_UPLOADSTATUS_END = "2";//订单列表已经上传资料，需要在支付资料中查看资料审核情况

    //币种
    public static final String CURRENCY_CODE_CNY = "CNY";
}
