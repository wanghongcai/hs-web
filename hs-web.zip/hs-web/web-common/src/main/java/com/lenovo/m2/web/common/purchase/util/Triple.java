package com.lenovo.m2.web.common.purchase.util;

public class Triple<K, V, T> extends Pair<K, V> {
	
	private static final long serialVersionUID = -8319703476537070503L;
	
	private T attachment;
	
	public Triple(){

	}
	
	public Triple(Pair<K, V> pair){
		super(pair.getKey(), pair.getValue());
	}
	
	public Triple(K key, V value, T attachment){
		super(key, value);
		this.attachment = attachment;
	}

	public T getAttachment() {
		return attachment;
	}

	public void setAttachment(T attachment) {
		this.attachment = attachment;
	}

	@Override
	public String toString() {
		return "Triple [attachment=" + attachment + ", key=" + key + ", value=" + value + "]";
	}

}
