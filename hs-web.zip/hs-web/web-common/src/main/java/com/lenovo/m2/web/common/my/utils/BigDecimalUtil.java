package com.lenovo.m2.web.common.my.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**字符类型的运算工具类
 *
 */
public class BigDecimalUtil {

	private static Logger logger = LogManager.getLogger(BigDecimalUtil.class);

    /**将两个字符串相加，参加如果为空默认设置为0
     *
     * @param augend
     * @param addend
     * @return 相加后的转换成String返回
     */
	public static String add(String augend,String addend){
		return new BigDecimal(augend!=null&&!augend.equals("")?augend:"0")
				.add(new BigDecimal(addend!=null&&!addend.equals("")?addend:"0")).toString();
	}
	
	public static String add(BigDecimal augend,String addend){
		return augend
				.add(new BigDecimal(addend!=null&&!addend.equals("")?addend:"0")).toString();
	}

    /**将两个数字字符串相减，参加如果为空默认设置为0
     *
     * @param minuend
     * @param subtrahend
     * @return 相减后的转换成String返回
     */
	public static String subtract(String minuend,String subtrahend){
		if(StringUtil.isEmpty(minuend)){
			minuend = "0";
		}
		if(StringUtil.isEmpty(subtrahend)){
			subtrahend = "0";
		}
		return new BigDecimal(minuend!=null&&!minuend.equals("")?minuend:"0")
				.subtract(new BigDecimal(subtrahend!=null&&!subtrahend.trim().equals("")?subtrahend.trim():"0")).toString();
	}

    /**将两个数字字符串相乘，参加如果为空默认设置为0
     *
     * @param multiplicand
     * @param multiplier
     * @return 相乘后的转换成String返回
     */
	public static String mul(String  multiplicand,String multiplier){
		return new BigDecimal(multiplicand!=null&&!multiplicand.equals("")?multiplicand:"0")
				.multiply(new BigDecimal(multiplier!=null&&!multiplier.equals("")?multiplier:"0")).toString();
	}
	
	public static String mul(BigDecimal multiplicand,String multiplier){
		return multiplicand
				.multiply(new BigDecimal(multiplier!=null&&!multiplier.equals("")?multiplier:"0")).toString();
	}

    /**跟零比较大小
     *
     * @param str

     * @return 返回正数：代表大于零，返回零：代表相等，返回负数：代表小于零
     */
	public static int compareToZero(String str){
		return new BigDecimal(str!=null&&!str.trim().equals("")?str.trim():"0").compareTo((new BigDecimal("0")));
	}
	
	/**
	 * @function 将字符串数字转换指定格式
	 * @param number
	 * @param format（例如：0.00,0.000）
	 * @return
	 */
	public static String numberStrformat(String number,String format){
		try {
			BigDecimal big = new BigDecimal((number != null && !"".equals(number))?number:"0");
			DecimalFormat d = new DecimalFormat("0.00");
			return d.format(big);
		} catch (Exception e) {
			logger.error("将字符串数字转换指定格式异常！", e);
			return "0.00";
		}
	}
}
