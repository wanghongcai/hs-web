package com.lenovo.m2.web.common.purchase.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.POIXMLDocument;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.*;
import java.util.*;

/**
 * Created by wanghao on 2017/5/9.
 */
public class ParseExcel {
    private final static String NOTVALUE = "N" ;
    private final static String NOLL = "NOLL" ;

    private static final Logger logger = LogManager.getLogger(ParseExcel.class);

    public static void main(String[] args) {






//        String[] keys = new String[]{"test","200","wanghao"};
//        String value = "你好，你{1}岁，你的名字{2}真好，你活了{1}";
//
//        if (keys.length>1){
//            for (int i=1; i<keys.length; i++){
//                value = value.replaceAll("\\{"+ i +"\\}", keys[i]);
//            }
//        }
//        System.err.println("---"+value);


//        String excelPath = "C:\\Users\\wanghao\\Desktop\\国际化\\词条翻译.xlsx";
//        String propertiesPath = "C:\\Users\\wanghao\\Desktop\\国际化\\word.properties";
//
//        OutputStream out = null;
//        try {
//
//            Map<Integer,Map<Integer,String>> result = ParseExcel.parse(excelPath,null);
//            System.err.println("result---" + result);
//            StringBuffer content = new StringBuffer();
//            for(int rowNum = 1;rowNum<result.size();rowNum++){
//                Map<Integer,String> row = result.get(rowNum);
//                if (row !=null && StringUtil.isNotEmpty(row.get(1)) && !"词条主键".equals(row.get(1))){
//                    content.append(row.get(1)).append("=").append(row.get(2)).append("\n");
//                }
//
//            }
//            File file = new File(propertiesPath);
//            out = new FileOutputStream(file);
//            out.write(content.toString().getBytes("utf-8"));
//            out.flush();
//
//        }catch (Exception e){
//            logger.error("出错了",e);
//        }finally {
//            if (out != null){
//                try {
//                    out.close();
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//        }

        //System.err.println(jisuan("1+2*2/4"));

        String excelPath = "C:\\Users\\wanghao\\Desktop\\国际化\\优惠券异常码表.xlsx";
        String propertiesPath = "C:\\Users\\wanghao\\Desktop\\国际化\\coupon.properties";

        OutputStream out = null;
        try {

            Map<Integer,Map<Integer,String>> result = ParseExcel.parse(excelPath,null);
            System.err.println("result---" + result);
            StringBuffer content = new StringBuffer();
            for(int rowNum = 1;rowNum<result.size();rowNum++){
                Map<Integer,String> row = result.get(rowNum);
                if (row !=null && StringUtil.isNotEmpty(row.get(2)) && !"词条主键".equals(row.get(2))){
                    content.append("checkout.").append(row.get(2)).append("=").append(row.get(3)).append("\n");
                }

            }
            File file = new File(propertiesPath);
            out = new FileOutputStream(file);
            out.write(content.toString().getBytes("utf-8"));
            out.flush();

        }catch (Exception e){
            logger.error("出错了",e);
        }finally {
            if (out != null){
                try {
                    out.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * 将excel表中数据读出，并换成ReferenceLiterature对象信息
     * @param filePath		Excel文件文件路径
     * @param inputStream	Excel文件流
     * @return
     * @throws Exception
     * @author wh
     */
    public static Map<Integer,Map<Integer,String>> parse(String filePath,InputStream inputStream) throws Exception{
        Map<Integer,Map<Integer,String>> parseResult = new HashMap<Integer, Map<Integer,String>>();
        List rows = null;
        ReadExcel readExcel = new ReadExcel();
        if (filePath!=null&&!"".equals(filePath)) {
            if(filePath.indexOf("xls")!=-1){
                //2007+
                try {
                    rows = readExcel.read(filePath, false);
                } catch (Exception e) {
                    throw e;
                }
            }else{
                //2003
                try {
                    rows = readExcel.read(filePath, true);
                } catch (Exception e) {
                    throw e;
                }
            }
        }else if (inputStream!=null){

            //2007+
            try {
                rows = readExcel.read(inputStream,false);
            } catch (Exception e) {
                e.printStackTrace();
                //2003
                try {
                    rows = readExcel.read(inputStream, true);
                } catch (Exception e2) {
                    throw e2;
                }
            }

        }

        try {
            if(rows!=null && rows.size()>0){
                for (int rowNum = 0;rowNum<rows.size();rowNum++) {
                    Row row=(Row) rows.get(rowNum);
                    Map<Integer, String> sortMap = new HashMap<Integer, String>() ;
                    for(int j=0; j<row.getLastCellNum(); j++){
                        Cell cell = row.getCell(j);
                        if(cell != null&&!"".equals(utile(cell))){
                            sortMap.put(j, utile(cell));
                        }else{
                            sortMap.put(j, NOTVALUE);
                        }
                    }
                    parseResult.put(rowNum,sortMap);
                }
                return parseResult;


            }
        } catch (Exception e) {
            logger.error("解析Excel出错",e);
        }
        return parseResult;
    }


    /**
     * 将String中的int取出
     * @param str
     * @return
     */
    private static int StringToInt(String str){
        StringBuffer sb = new StringBuffer() ;
        for(int i = 0; i <=str.length(); i++){
            if(str.charAt(i) >= 0 && str.charAt(i) <= 9){
                sb.append(str.charAt(i));
            }
        }
        return Integer.parseInt(sb.toString());
    }

    public static boolean deleteFile(String filePath){
        File file = new File(filePath);
        if(file.isFile() && file.exists()){
            file.delete();
            return true;
        }else{
            return false;
        }
    }
    private static String utile(Cell cell){
        String numberStr="";
        if(cell!=null){
            if(cell.getCellType()== HSSFCell.CELL_TYPE_NUMERIC){
                double strCell = cell.getNumericCellValue();
                String[] dous = (cell.getNumericCellValue()+"").split("-");
                BigDecimal decimal = null;
                if(dous.length>1){
                    decimal = new BigDecimal(strCell);
                    try {
                        numberStr = decimal.setScale(Integer.parseInt(dous[1]),2)+"";
                    } catch (NumberFormatException e) {
                        // TODO Auto-generated catch block
                        //System.out.println(cell.getStringCellValue());
                        e.printStackTrace();
                    }
                    return numberStr;
                }else{
                    DecimalFormat formatCell = (DecimalFormat) NumberFormat.getPercentInstance();
                    formatCell.applyPattern("0");
                    numberStr = formatCell.format(strCell);
                    if(Double.parseDouble(numberStr)!=strCell){
                        formatCell.applyPattern(Double.toString(strCell));
                        numberStr = formatCell.format(strCell);
                    }
                }
            }
            else
                numberStr=cell.getStringCellValue();
        }
        return numberStr.trim();
    }

    public static Timestamp passStringToTimestamp(Cell cell){
        String utile = utile(cell);
        if(!"".equals(utile)){
            String date = null ;
            //适用于2000-12-12的格式
            String[] dateInfo = utile.split("-");
            if(dateInfo.length > 1){
                date = utile  + " 00:00:00" ;
                return Timestamp.valueOf(date);
            }else{
                //适用于2000/12/12的格式
                date = cell.getDateCellValue() + "";
            }
            if("".equals(date)){
                return null ;
            }
            DateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.US);
            format.setLenient(false);
            //要转换字符串 str_test

            Timestamp ts;
            try {
                ts = new Timestamp(format.parse(date).getTime());
                return ts;
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return null;
    }

}


class ReadExcel {
//	public static List readExcel2007(String path) throws IOException {
//		List list = new ArrayList();
//		XSSFWorkbook xwb = new XSSFWorkbook(path);
//		// 读取第一章表格内容
//		XSSFSheet sheet = xwb.getSheetAt(0);
//		// 定义 row、cell
//		XSSFRow row;
//		String cell;
//		// 循环输出表格中的内容
//		for (int i = sheet.getFirstRowNum(); i < sheet.getPhysicalNumberOfRows(); i++) {
//			row = sheet.getRow(i);
//			String str[] = new String[row.getPhysicalNumberOfCells()];
//			for (int j = row.getFirstCellNum(); j < row.getPhysicalNumberOfCells(); j++) {
//				// 通过 row.getCell(j).toString() 获取单元格内容，
//				cell = row.getCell(j).toString();
//				System.out.print(cell + "\t");
//				str[j]=cell;
//			}
//			System.out.println("");
//			list.add(str);
//		}
//		return list;
//	}
    /**
     * 暂时不能解析带有超链接的表格，该功能待处理
     */
    public List read(String fileName, boolean flag) throws Exception {
        Workbook wb = null;
        if (flag) {// 2003
            File f = new File(fileName);

            FileInputStream is = new FileInputStream(f);
            POIFSFileSystem fs = new POIFSFileSystem(is);
            wb = new HSSFWorkbook(fs);
            is.close();
        } else {// 2007
            wb = new XSSFWorkbook(fileName);
        }
        List list = read(wb);
        return list;
    }

    /**
     * 暂时不能解析带有超链接的表格，该功能待处理
     * @param in
     *            输入流
     * @param flag
     *            是2003还是2007 true：2003，false：2007
     * @throws Exception
     */
    public static List read(InputStream in, boolean flag) throws Exception {
        Workbook wb = null;
		/*if (flag) {// 2003
			wb = new HSSFWorkbook(in);
		} else {// 2007
			wb = new XSSFWorkbook(in);
		}*/
        if (!in.markSupported()) {
            in = new PushbackInputStream(in, 8);
        }
        if (POIFSFileSystem.hasPOIFSHeader(in)) {
            wb = new HSSFWorkbook(in);
        }else
        if (POIXMLDocument.hasOOXMLHeader(in)) {
            wb = new XSSFWorkbook(OPCPackage.open(in));
        }else {

            throw new IllegalArgumentException("你的excel版本目前poi解析不了");
        }
        List list = read(wb);
        return list;
    }

    /**
     * 具体读取Excel
     *
     * @param wb
     * @throws Exception
     */
    public static List read(Workbook wb) throws Exception {
        List list = new ArrayList();
        try {
            int sheetNum = wb.getNumberOfSheets();
            for(int i =0; i<sheetNum ;i++){
                Sheet sheet = (Sheet) wb.getSheetAt(i);
                int rows = sheet.getPhysicalNumberOfRows();
                if (rows==0) {
                    //当rows为0时即Excel表格数据是从sheet的第2页开始的
                    sheet = (Sheet) wb.getSheetAt(1);
                    rows = sheet.getPhysicalNumberOfRows();
                }
                for (int r = 0; r < rows; r++) {
                    Row row = sheet.getRow(r);
                    list.add(row);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    public static List read(String filePath) throws Exception{
        List list = new ArrayList();
        try {
            //File file = new File(filePath);

            OPCPackage opcPackage = OPCPackage.open(filePath);
            XSSFWorkbook xssfWorkbook = new XSSFWorkbook(opcPackage);
            XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0);
            int totaRows = xssfSheet.getPhysicalNumberOfRows();
            System.out.println(totaRows);
            return list;
        } catch (Exception e) {
            throw e;
        }
    }
}