package com.lenovo.m2.web.common.my.mail;

import com.lenovo.m2.web.common.my.mail.domain.MailObject;
import com.lenovo.m2.web.common.my.mail.util.MailUtil;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
/**
 * Created by jack on 2016/7/8.
 */
public class Mail {

    public static Logger log =  LogManager.getLogger(Mail.class.getName());

    public boolean SendMailToEngineer(String exception, String header){

        MailObject mail = new MailObject();
        mail.setHost("smtp.163.com"); // 设置邮件服务器,如果不用163的,自己找找看相关的
        mail.setSender("hellomahao@163.com");
        mail.setReceiver("mahao@litsoft.com.cn"); // 接收人
        mail.setUsername("hellomahao@163.com"); // 登录账号,一般都是和邮箱名一样吧
        mail.setPassword("wjbgsn"); // 发件人邮箱的登录密码
        mail.setSubject(header);
        mail.setMessage(exception);
        boolean send = new MailUtil().send(mail);
        return send;
    }

}
