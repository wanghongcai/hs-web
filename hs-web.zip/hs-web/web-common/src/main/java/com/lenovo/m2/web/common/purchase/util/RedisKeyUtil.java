package com.lenovo.m2.web.common.purchase.util;

/**
 * 存储redis的key 统一管理
 * @author wangrq1
 *
 */
public class RedisKeyUtil {
	
	/**
	 * 预约时间前缀
	 */
	private final static String KEY_RESERVATION_TIME_PREFIX = "RSVT";
	/**
	 * 是否预约
	 */
	private final static String KEY_IS_RESERVATION_PREFIX = "ISRS";

    /**
     * 促销规则
     */
	private final static String KEY_PROMOTION_PREFIX = "PROMOTION";
    /**
     *去除参数，由redis保存
     */
    public static final String PARAMETERS_CARTFORCHECKOUT = "PARAME";
	/**
	 * 存储短信验证码前缀
	 */
	public static String CAPTCHA_PRE ="cap_";

    /**
     * 获取redis中保存参数的key
     *
     */
    public static String getCartKeyForCheckOut(Integer plat , String lenovoid){
        return String.format("%s|%s|%s" ,PARAMETERS_CARTFORCHECKOUT,plat,lenovoid );
    }
	/**
	 * 获取商品预约时间
	 * @param plat
	 * @param gcode
	 * @return
	 * @author wangrq1
	 */
	public static String getReservationTimeKey(Integer plat, String gcode){
		return String.format("%s|%s|%s", KEY_RESERVATION_TIME_PREFIX, plat, gcode);
	}
	
	public static String getIsReservationKey(Integer plat, String good){
		return String.format("%s|%s|%s", KEY_IS_RESERVATION_PREFIX, plat, good);
	}

    public static  String getPromotionKey(String plat, String gcode, String group){
        return  String.format("%s|%s|%s|%s",KEY_PROMOTION_PREFIX, plat, gcode, group);
    }

    /**
     * 用户闪购购买标识， 购买后存 1 
     * @param plat
     * @param lenovoid
     * @param gcode
     * @return
     * @author wangrq1
     */
    /**
     * 促销规则
     */
	private final static String KEY_FLUSH_SALE_FLAG  = "FLUSH_SALE_FLAG";
    public static String getUserFlushSaleFlagKey(Integer plat, String gcode){
    	return String.format("%s|%s|%s", KEY_FLUSH_SALE_FLAG, plat, gcode);
    }
    public static String getUserFlushSaleFlagKey(String gcode){
    	return String.format("%s|%s", KEY_FLUSH_SALE_FLAG, gcode);
    }
    public static void main(String[] args) {
    	System.out.println(String.format("%s|%s", null, null));
	}
}
