package com.lenovo.m2.web.common.my.utils;

import org.codehaus.jackson.map.ObjectMapper;

/**
 * Created by mayan3 on 2015/11/10.
 */
public class JacksonJsonMapperUtil {
    static volatile ObjectMapper objectMapper = null;
    private JacksonJsonMapperUtil() {
    }

    public static ObjectMapper getMapper() {
        if (objectMapper == null) {
            synchronized (ObjectMapper.class) {
                if (objectMapper == null) {
                    objectMapper = new ObjectMapper();
                }
            }
        }
        return objectMapper;
    }
}
