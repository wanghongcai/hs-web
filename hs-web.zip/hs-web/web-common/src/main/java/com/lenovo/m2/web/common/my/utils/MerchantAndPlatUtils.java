package com.lenovo.m2.web.common.my.utils;

import java.util.Map;

/**
 * Created by yezhenyue on 2015/11/5.
 */
public class MerchantAndPlatUtils {
    private static Map<String,Map<String,String>> map;

    private MerchantAndPlatUtils(Map<String, Map<String, String>> map){
        this.map = map;
    }

    public static String getPlat(String merchantId,String plat){
        return map.get(merchantId).get(plat);
    }

    public static Map<String, Map<String, String>> getMap() {
        return map;
    }
}
