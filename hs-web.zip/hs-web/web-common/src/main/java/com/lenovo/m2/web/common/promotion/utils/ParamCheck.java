package com.lenovo.m2.web.common.promotion.utils;

import java.util.Collection;
import java.util.Map;

/**
 * Created by luqian on 2015-11-19.
 */
public class ParamCheck {

    public static Boolean isNullOrEmpty(Object...obj){
        for(Object o:obj){
            if (o == null)
                return true;

            if (o instanceof CharSequence)
                return ((CharSequence) o).length() == 0;

            if (o instanceof Collection)
                return ((Collection) o).isEmpty();

            if (o instanceof Map)
                return ((Map) o).isEmpty();
            if (o instanceof Object[]) {
                Object[] object = (Object[]) obj;
                if (object.length == 0) {
                    return true;
                }
                boolean empty = true;
                for (int i = 0; i < obj.length; i++) {
                    if (!isNullOrEmpty(obj[i])) {
                        empty = false;
                        break;
                    }
                }
                return empty;
            }

        }

        return false;

    }
}
