package com.lenovo.m2.web.common.my.utils.domain;

import java.io.Serializable;

/**
 * Created by fenglg1 on 2017/7/12.
 */
public class PayRecordMessage implements Serializable{
    private String shopId;
    private String faId;
    private String orderId;
    private String buyerId;
    private String buyerCode;
    private String submitTime;

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getFaId() {
        return faId;
    }

    public void setFaId(String faId) {
        this.faId = faId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getBuyerCode() {
        return buyerCode;
    }

    public void setBuyerCode(String buyerCode) {
        this.buyerCode = buyerCode;
    }

    public String getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(String submitTime) {
        this.submitTime = submitTime;
    }

    @Override
    public String toString() {
        return "PayRecordMessage{" +
                "shopId='" + shopId + '\'' +
                ", faId='" + faId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", buyerId='" + buyerId + '\'' +
                ", buyerCode='" + buyerCode + '\'' +
                ", submitTime='" + submitTime + '\'' +
                '}';
    }
}
