package com.lenovo.m2.web.common.my.utils;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.common.my.utils.domain.MoneySerializer;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.module.SimpleModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;

/**
 * <br> json处理类，将json与实体之间相互转化
 * @author shenjc
 *
 */
public class JacksonUtil {
	
	private static Logger logger = LogManager.getLogger(JacksonUtil.class);
	
	public static final ObjectMapper mapper = new ObjectMapper();

    static{
        // 设置输入时忽略在JSON字符串中存在但Java对象实际没有的属性
        mapper.disable(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
        mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        /*---money---*/
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneySerializer());
        mapper.registerModule(module);
        mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
    }

	public static String toJson(Object obj) {
		StringWriter writer = new StringWriter();
		JsonGenerator gen;
		try {
			gen = new JsonFactory().createJsonGenerator(writer);
			mapper.writeValue(gen, obj);
			gen.close();
			String json = writer.toString();
			writer.close();
			return json;
		} catch (IOException e) {
			logger.warn(e.getMessage(),e);
		}
		
		return null;
	}
	
	public static <T> T fromJson(String json, Class<T> classOfT) {
		Object object;
		try {
			object = mapper.readValue(json, classOfT);
			return (T) object;
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        } catch (JsonMappingException e) {
            logger.error(e.getMessage(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(),e);
        }
		return null;
	}

}

