package com.lenovo.m2.web.common.purchase.util;

import java.io.Serializable;

/**
 * Created by jack on 2017/1/9.
 */
public class ShowIdentity implements Serializable{

    private String title;
    private String statusInfo_top;
    private String cardType;
    private String cardNumber;
    private String name;
    private String cardAddress;
    private String cardPhone;
    private String cardUpLoad;
    private String cardNotNull;
    private String cardStyleError;
    private String cardNameNotNull;
    private String cardAddressNotNull;
    private String receiveMessage;
    private String PhoneNumber;
    private String cardRequestOne;
    private String cardRequestTwo;
    private String cardRequestThree;
    private String cardRequestFore;
    private String cardRequestFive;
    private String cardRequestSeven;
    private String cardRequestEight;
    private String cardRequestNine;
    private String cardRequestTen;
    private String cardRequestEleven;
    private String cardRequestTwelve;
    private String cardRequestThirteen;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStatusInfo_top() {
        return statusInfo_top;
    }

    public void setStatusInfo_top(String statusInfo_top) {
        this.statusInfo_top = statusInfo_top;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCardAddress() {
        return cardAddress;
    }

    public void setCardAddress(String cardAddress) {
        this.cardAddress = cardAddress;
    }

    public String getCardPhone() {
        return cardPhone;
    }

    public void setCardPhone(String cardPhone) {
        this.cardPhone = cardPhone;
    }

    public String getCardUpLoad() {
        return cardUpLoad;
    }

    public void setCardUpLoad(String cardUpLoad) {
        this.cardUpLoad = cardUpLoad;
    }

    public String getCardNotNull() {
        return cardNotNull;
    }

    public void setCardNotNull(String cardNotNull) {
        this.cardNotNull = cardNotNull;
    }

    public String getCardStyleError() {
        return cardStyleError;
    }

    public void setCardStyleError(String cardStyleError) {
        this.cardStyleError = cardStyleError;
    }

    public String getCardNameNotNull() {
        return cardNameNotNull;
    }

    public void setCardNameNotNull(String cardNameNotNull) {
        this.cardNameNotNull = cardNameNotNull;
    }

    public String getCardAddressNotNull() {
        return cardAddressNotNull;
    }

    public void setCardAddressNotNull(String cardAddressNotNull) {
        this.cardAddressNotNull = cardAddressNotNull;
    }

    public String getReceiveMessage() {
        return receiveMessage;
    }

    public void setReceiveMessage(String receiveMessage) {
        this.receiveMessage = receiveMessage;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getCardRequestOne() {
        return cardRequestOne;
    }

    public void setCardRequestOne(String cardRequestOne) {
        this.cardRequestOne = cardRequestOne;
    }

    public String getCardRequestTwo() {
        return cardRequestTwo;
    }

    public void setCardRequestTwo(String cardRequestTwo) {
        this.cardRequestTwo = cardRequestTwo;
    }

    public String getCardRequestThree() {
        return cardRequestThree;
    }

    public void setCardRequestThree(String cardRequestThree) {
        this.cardRequestThree = cardRequestThree;
    }

    public String getCardRequestFore() {
        return cardRequestFore;
    }

    public void setCardRequestFore(String cardRequestFore) {
        this.cardRequestFore = cardRequestFore;
    }

    public String getCardRequestFive() {
        return cardRequestFive;
    }

    public void setCardRequestFive(String cardRequestFive) {
        this.cardRequestFive = cardRequestFive;
    }

    public String getCardRequestSeven() {
        return cardRequestSeven;
    }

    public void setCardRequestSeven(String cardRequestSeven) {
        this.cardRequestSeven = cardRequestSeven;
    }

    public String getCardRequestEight() {
        return cardRequestEight;
    }

    public void setCardRequestEight(String cardRequestEight) {
        this.cardRequestEight = cardRequestEight;
    }

    public String getCardRequestNine() {
        return cardRequestNine;
    }

    public void setCardRequestNine(String cardRequestNine) {
        this.cardRequestNine = cardRequestNine;
    }

    public String getCardRequestTen() {
        return cardRequestTen;
    }

    public void setCardRequestTen(String cardRequestTen) {
        this.cardRequestTen = cardRequestTen;
    }

    public String getCardRequestEleven() {
        return cardRequestEleven;
    }

    public void setCardRequestEleven(String cardRequestEleven) {
        this.cardRequestEleven = cardRequestEleven;
    }

    public String getCardRequestTwelve() {
        return cardRequestTwelve;
    }

    public void setCardRequestTwelve(String cardRequestTwelve) {
        this.cardRequestTwelve = cardRequestTwelve;
    }

    public String getCardRequestThirteen() {
        return cardRequestThirteen;
    }

    public void setCardRequestThirteen(String cardRequestThirteen) {
        this.cardRequestThirteen = cardRequestThirteen;
    }
}
