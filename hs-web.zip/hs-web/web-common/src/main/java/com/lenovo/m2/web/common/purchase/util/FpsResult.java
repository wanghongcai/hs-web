package com.lenovo.m2.web.common.purchase.util;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnums;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.Serializable;

/**
 * 页面返回result封装
 * @param <T>
 */
public class FpsResult<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    private static Logger log = LogManager.getLogger(FpsResult.class);
    private int rc = 0;
    private String msg;
    private T data;
    private boolean success;

    public boolean isSuccess() {
        return this.success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getRc() {
        return this.rc;
    }

    public void setRc(int rc) {
        this.rc = rc;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return this.data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setErrorInfo(ErrorMessageEnums info) {
        this.setRc(info.getCode());
        this.setMsg(info.getCommon());
    }

    public void setBaseInfo(BaseInfo b) {
        this.setRc(b.getRc());
        this.setMsg(b.getMsg());
    }

    public FpsResult(ErrorMessageEnums info) {
        this.setRc(info.getCode());
        this.setMsg(info.getCommon());
    }

//    public FpsResult(ErrorMessageEnum info) {
//        this.setRc(info.getCode());
//        this.setMsg(info.getCommon());
//    }

//    public FpsResult(ErrorMessageEnum info, T t) {
//        this.setRc(info.getCode());
//        this.setMsg(info.getCommon());
//        this.setData(t);
//    }
//
//    public FpsResult(BaseInfo info) {
//        this.setRc(info.getRc());
//        this.setMsg(info.getMsg());
//    }

    public <T> FpsResult(int rc, String msg) {
        this.setRc(rc);
        this.setMsg(msg);
    }

    public FpsResult(RemoteResult<T> t, PromptEnum promptEnum){
        if(t!=null){
            this.setRc(t.getResultCode()!=null?Integer.parseInt(t.getResultCode()):0);
            this.setMsg(t.getResultCode()!=null?PromptInit.get(promptEnum+"."+t.getResultCode(),t.getResultMsg()):"");
            this.setData(t.getT());
            this.setSuccess(t.isSuccess());
        }else{
            this.setRc(-1);
            this.setMsg("网络异常，请稍候再试~");
        }
    }

    public FpsResult(RemoteResult<T> t){
        if(t!=null){
            if(t.getResultCode() == null || "null".equals(t.getResultCode()) || "".equals(t.getResultCode())){
                this.setRc(0);
            }else{
                this.setRc(Integer.parseInt(t.getResultCode()));
            }
            this.setMsg(t.getResultMsg());
            this.setData(t.getT());
            this.setSuccess(t.isSuccess());
        }else{
            this.setRc(-1);
            this.setMsg("网络异常，请稍候再试~");
        }
    }

    public FpsResult() {
    }
    public static void main(String[] args){
        RemoteResult<String> r = new RemoteResult<>();
        r.setResultCode("0");
        FpsResult result = new FpsResult(r,PromptEnum.CHECKOUT);
        System.out.print(JsonUtil.toJson(result));
    }

    @Override
    public String toString() {
        return "FpsResult{" +
                "rc=" + rc +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                ", success=" + success +
                '}';
    }
}
