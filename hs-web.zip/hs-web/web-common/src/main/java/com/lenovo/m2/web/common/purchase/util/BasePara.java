package com.lenovo.m2.web.common.purchase.util;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//


import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.util.BaseInfo;
import java.io.Serializable;

public abstract class BasePara implements Serializable {
    private static final long serialVersionUID = 1L;
    private String format;
    private String v;
    private int terminal;
    private String source;
    private int shopId;
    private String ip;
    private User user;
    private Tenant tenant;
    private String beemobile;

    public BasePara() {
    }

    public Tenant getTenant() {
        if(this.tenant == null) {
            Tenant tenantTemp = new Tenant();
            tenantTemp.setShopId(Integer.valueOf(this.getShopId()));
            tenantTemp.setCurrencyCode("CNY");
            return tenantTemp;
        } else {
            return this.tenant;
        }
    }

    public String getBeemobile() {
        return beemobile;
    }

    public void setBeemobile(String beemobile) {
        this.beemobile = beemobile;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public String getIp() {
        return this.ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getShopId() {
        return this.shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getFormat() {
        return this.format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getV() {
        return this.v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public int getTerminal() {
        return this.terminal;
    }

    public void setTerminal(int terminal) {
        this.terminal = terminal;
    }

    public String getSource() {
        return this.source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public BaseInfo validateSystemPara() {
        return this.getTerminal() <= 0?new BaseInfo(ErrorMessageEnum.ERROR_PARAM):new BaseInfo(ErrorMessageEnum.SUCCESS);
    }

    public abstract BaseInfo validateAppPara();

    public boolean equals(Object o) {
        if(this == o) {
            return true;
        } else if(o != null && this.getClass() == o.getClass()) {
            BasePara basePara = (BasePara)o;
            if(this.terminal != basePara.terminal) {
                return false;
            } else {
                label74: {
                    if(this.format != null) {
                        if(this.format.equals(basePara.format)) {
                            break label74;
                        }
                    } else if(basePara.format == null) {
                        break label74;
                    }

                    return false;
                }

                if(this.v != null) {
                    if(!this.v.equals(basePara.v)) {
                        return false;
                    }
                } else if(basePara.v != null) {
                    return false;
                }

                label60: {
                    if(this.source != null) {
                        if(this.source.equals(basePara.source)) {
                            break label60;
                        }
                    } else if(basePara.source == null) {
                        break label60;
                    }

                    return false;
                }

                if(this.ip != null) {
                    if(!this.ip.equals(basePara.ip)) {
                        return false;
                    }
                } else if(basePara.ip != null) {
                    return false;
                }

                boolean var10000;
                label99: {
                    if(this.user != null) {
                        if(this.user.equals(basePara.user)) {
                            break label99;
                        }
                    } else if(basePara.user == null) {
                        break label99;
                    }

                    var10000 = false;
                    return var10000;
                }

                var10000 = true;
                return var10000;
            }
        } else {
            return false;
        }
    }

    public int hashCode() {
        int result = this.format != null?this.format.hashCode():0;
        result = 31 * result + (this.v != null?this.v.hashCode():0);
        result = 31 * result + this.terminal;
        result = 31 * result + (this.source != null?this.source.hashCode():0);
        result = 31 * result + (this.ip != null?this.ip.hashCode():0);
        result = 31 * result + (this.user != null?this.user.hashCode():0);
        return result;
    }

    public String toString() {
        return "BasePara{format=\'" + this.format + '\'' + ", v=\'" + this.v + '\'' + ", terminal=" + this.terminal + ", source=\'" + this.source + '\'' + ", ip=\'" + this.ip + '\'' + ", user=" + this.user + '}';
    }
}
