package com.lenovo.m2.web.common.purchase.enums;

public enum OrderType {
	
	NORMAL_SALES(0, "普通"),
	FLASH_SALES(1, "闪购"),
	PRESELLS(2, "预售"),
	TRY_BEFORE_BUY_SALES(3, "先试后买"),
	K_CODE_SALES(4, "K码商品"),
	CUSTOMIZING_SALES(5, "定制"),
	TRADE_IN_ALLOWANCE(6, "依旧换新"),
	C_2_C(7, "C To C"),
	DA_XIA_MA(8,"大侠码"),
	CTO(9,"cto"),
	O2O(10,"o2o"),
	ZC(11,"众筹");
	
	
	
	private final int type;
	private final String descr;
	
	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private OrderType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public OrderType getOrderType(int type){
		OrderType result = null;
		switch(type){
			case 0:
				result = NORMAL_SALES;
				break;
			case 1:
				result = FLASH_SALES;
				break;
			case 2:
				result = PRESELLS;
				break;
			case 3:
				result = TRY_BEFORE_BUY_SALES;
				break;
			case 4:
				result = K_CODE_SALES;
				break;
			case 5:
				result = CUSTOMIZING_SALES;
				break;
			case 6:
				result = TRADE_IN_ALLOWANCE;
				break;
			case 7:
				result = C_2_C;
				break;
			case 8:
				result = DA_XIA_MA;
				break;
			case 9:
				result = CTO;
				break;
			case 10:
				result = O2O;
				break;
			case 11:
				result = ZC;
				break;
			default:
				throw new IllegalArgumentException("unkown parameter type=" + type + "");
		}
		return result;
	}

}
