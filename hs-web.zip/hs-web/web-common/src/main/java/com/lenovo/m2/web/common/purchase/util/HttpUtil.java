
package com.lenovo.m2.web.common.purchase.util;

import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;


/**
 *
 */
public class HttpUtil {


	private static Log log = LogFactory.getLog(HttpUtil.class);
	private static DefaultHttpClient httpClient;
	private static DefaultHttpClient httpClient_proxy;

	private static String proxyHost = "10.99.60.201";//B2CMainConfig.getProxyHost();// 代理ip地址
	private static int proxyPort = 8080;// B2CMainConfig.getProxyPort();// 代理端口
	
	private static int maxConLifeTimeMs = 300000;
	private static int defaultMaxConPerHost = 50;
	private static int maxTotalConn = 10000;
	private static int conTimeOutMs = 10000;
	private static int soTimeOutMs = 30000;
	
	static {
		try {
			// 创建SSLContext对象，并使用我们指定的信任管理器初始化
//	        TrustManager[] tm = { new MyX509TrustManager() };
			
			Scheme http = new Scheme("http", 80, PlainSocketFactory.getSocketFactory());
			SSLContext sslcontext = SSLContext.getInstance("TLS");
			//sslcontext.init(null, tm, new java.security.SecureRandom());
			sslcontext.init(null, null, null);
			SSLSocketFactory sf = new SSLSocketFactory(sslcontext, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);//STRICT_HOSTNAME_VERIFIER
			Scheme https = new Scheme("https", 443, sf);
			SchemeRegistry sr = new SchemeRegistry();
			sr.register(http);
			sr.register(https);
			PoolingClientConnectionManager cm = new PoolingClientConnectionManager(sr, maxConLifeTimeMs, TimeUnit.MILLISECONDS);
			cm.setMaxTotal(maxTotalConn);
			cm.setDefaultMaxPerRoute(defaultMaxConPerHost);
			//普通http客户端
			httpClient = new DefaultHttpClient(cm);
			httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, conTimeOutMs);
			httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, soTimeOutMs);
			httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.IGNORE_COOKIES);
			httpClient.addResponseInterceptor(new HttpResponseInterceptor() {
				public void process(final HttpResponse response, final HttpContext context) throws HttpException, IOException {
					HttpEntity entity = response.getEntity();
					Header ceheader = entity.getContentEncoding();
					if (ceheader != null && ceheader.getValue().toLowerCase().contains("gzip")) {
						response.setEntity(new GzipDecompressingEntity(response.getEntity()));
					}
				}
			});
			//代理http客户端
			httpClient_proxy = new DefaultHttpClient(cm);
			httpClient_proxy.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, conTimeOutMs);
			httpClient_proxy.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, soTimeOutMs);
			httpClient_proxy.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.IGNORE_COOKIES);
			HttpHost proxy = new HttpHost(proxyHost, proxyPort);
			httpClient_proxy.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
		} catch (Exception e) {
			log.error("HttpExecutor init error", e);
		}
	}

	public static HttpResponse execute(HttpUriRequest request) throws Exception {
		HttpResponse httpResponse;
		try {
			httpResponse = httpClient.execute(request);
		} catch (Exception e) {
			throw e;
		}
		return httpResponse;
	}
	
	public static HttpResponse executeProxy(HttpUriRequest request) throws Exception {
		HttpResponse httpResponse;
		try {
			httpResponse = httpClient/*_proxy*/.execute(request);
		} catch (Exception e) {
			throw e;
		}
		return httpResponse;
	}
	
	public static String executeHttpPost(String url, String body)
			throws Exception {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType("application/json");
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT, 20000);
		// 读取超时
		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				20000);
		try {
			HttpResponse result = httpClient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			log.info("executeHttpPost返回：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPost请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return resData;
	}
	
	public static String executeHttpPostType(String url, String body,String type)
			throws Exception {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType(type);
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT, 20000);
		// 读取超时
		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				20000);
		try {
			HttpResponse result = httpClient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			log.info("executeHttpPostType返回的数据：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPostType请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return resData;
	}
	
	public static String postStr(String url, Map<String, String> params) throws UnsupportedEncodingException{
		HttpClient httpclient =new DefaultHttpClient(); 
		HttpPost httpPost = new HttpPost(url); 
		httpPost.setHeader("Content-Type", "application/xml; charset=utf-8");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>(); 
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));
		String line = null;   
		String str="";
		 try { 
			HttpResponse response=httpclient.execute(httpPost); 
			HttpEntity entity = response.getEntity(); 
			InputStreamReader inputstream = new InputStreamReader(entity.getContent(), "UTF-8");
			BufferedReader reader = new BufferedReader(inputstream);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str+=line;   
			} 
			reader.close();
			inputstream.close();
		 }catch(Exception e){
			 log.error(e);
		 }finally{
			 if(httpclient != null){
				 httpclient.getConnectionManager().shutdown();
			 }
		 }
		return str;
	}
	
	
	public static String PostStr(String url, Map<String, String> params,String referer,String cookie,boolean isproxy,String charset) throws UnsupportedEncodingException{
		HttpClient httpclient =new DefaultHttpClient(); 
		// 请求超时
		httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 60000);
        // 读取超时
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 60000    );
		HttpPost httpPost = new HttpPost(url); 
		List<NameValuePair> nvps = new ArrayList<NameValuePair>(); 
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		if(!StringUtils.isEmpty(cookie)){
			httpPost.setHeader("Cookie", cookie);
		}
		if(!StringUtils.isEmpty(referer)){
			httpPost.addHeader("Referer", referer);
		}
         
         if(StringUtils.isEmpty(charset)){
        	 charset = "utf-8";
         }
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, charset));
		String line = null;   
		 StringBuffer str = new StringBuffer("");  
		 InputStreamReader inreader = null;
		 BufferedReader reader = null;
		 try { 
			HttpResponse response=httpclient.execute(httpPost); 
			HttpEntity entity = response.getEntity();   
			inreader = new InputStreamReader(entity.getContent(), charset);
			reader  = new BufferedReader(inreader);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str.append(line);
			} 
		 }catch(Exception e){
			 log.error(e);
		 }finally{
			 if (reader != null) {
	        	  try {
	        		  reader.close();// 最后要关闭BufferedReader  
				} catch (IOException e) {
					log.error(e);
				}
	          }
	    	  if(inreader != null){
	    		  try {
	    			  inreader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					log.error(e);
				}
	    	  }
			 if(httpclient != null){
				 httpclient.getConnectionManager().shutdown();
			 }
		 }
		return str.toString();
	}
	
	
	public static String getStr(String url) {
		
		  BufferedReader in = null;  
	      // 定义HttpClient  
	      HttpClient client = new DefaultHttpClient();  
	      // 实例化HTTP方法  
	      HttpGet request = new HttpGet();  
	      String line = "";  
	      String tmp="";
	      try {  
		      request.setURI(new URI(url));  
		      request.setHeader("Content-Type", "text/html;charset=UTF-8");
		      HttpResponse response = client.execute(request);  
	          in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));   
	          while ((tmp=in.readLine()) != null) {   
	            line+=tmp;   
	          }
	      }catch (Exception e) {  
	    	  log.error(e);  
	      }finally{
	    	  if (in != null) {
	        	  try {
					in.close();// 最后要关闭BufferedReader  
				} catch (IOException e) {
					log.error(e);
				}
	          }
	    	  client.getConnectionManager().shutdown();
	      }  
	      return line;  
	            
	}



	public static void main(String[] args) throws Exception {
		StringBuffer buffer = new StringBuffer("<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">").append("\r\n");
		buffer.append("<soap12:Body>																					").append("\r\n");
		buffer.append(" 	<SVCProdAdvise xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">						").append("\r\n");
		buffer.append(" 	<machineNo>string</machineNo>															").append("\r\n");
		buffer.append("		<listCart>																				").append("\r\n");
		buffer.append("			<ProductCart>																		").append("\r\n");
		buffer.append("				<productNo>4343</productNo>														").append("\r\n");
		buffer.append("				<number>1</number>																").append("\r\n");
		buffer.append("			</ProductCart>																		").append("\r\n");
		buffer.append("			<ProductCart>																		").append("\r\n");
		buffer.append("				<productNo>565645</productNo>													").append("\r\n");
		buffer.append("				<number>1</number>																").append("\r\n");
		buffer.append("			</ProductCart>																		").append("\r\n");
		buffer.append("		</listCart>																				").append("\r\n");
		buffer.append("		<strAccessUser>ggg</strAccessUser>													").append("\r\n");
		buffer.append(" 	<strAccessPassword>fgsfg</strAccessPassword>											").append("\r\n");
		buffer.append("		</SVCProdAdvise>																		").append("\r\n");
		buffer.append("</soap12:Body>																					").append("\r\n");
		buffer.append("</soap12:Envelope>																				").append("\r\n");
		
//		String aa = HttpUtil.executeHttpPostType("http://10.99.101.76:91/WebService/EPackWSForNewSS.asmx?op=SVCProdAdvise", buffer.toString(), "application/xml");
//		System.out.println("=="+aa);
		PostMethod postMethod = new PostMethod("http://10.99.101.76:91/WebService/EPackWSForNewSS.asmx?wsdl");
				 
				         // 然后把Soap请求数据添加到PostMethod中
				         byte[] b = buffer.toString().getBytes("utf-8");
				         InputStream is = new ByteArrayInputStream(b, 0, b.length);
				         RequestEntity re = new InputStreamRequestEntity(is, b.length,
				                 "application/soap+xml; charset=utf-8");
				         postMethod.setRequestEntity(re);
				 
				         // 最后生成一个HttpClient对象，并发出postMethod请求
				         org.apache.commons.httpclient.HttpClient httpClient = new org.apache.commons.httpclient.HttpClient();
				        int statusCode = httpClient.executeMethod(postMethod);
				         if(statusCode == 200) {
				             System.out.println("调用成功！");
				            String soapResponseData = postMethod.getResponseBodyAsString();
				         System.out.println(soapResponseData);
				        }
				       else {
				             System.out.println("调用失败！错误码：" + statusCode);
				         }
				
	}
}
