package com.lenovo.m2.web.common.purchase.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URLEncoder;
import java.util.*;

/**
 * 支付签名工具类
 * Created by MengQiang on 2016/3/3.
 */
public class PaySignUtils {
    private static final Logger logger = LogManager.getLogger(PaySignUtils.class);



    public static String checkSign(Map<String, String> signMap, String signKey){
        logger.info("Invoke PaySignUtils CheckSign");
        String key = getSign(signMap, signKey);
        logger.info("key[" + key + "]");
        return key;
    }

    /**
     * 生成签名密文
     * @param signMap   待签名参数
     * @param signType  签名类型，目前支持支MD5
     * @param signKey   签名KEY
     * @return  密文串
     */
    public static String buildSignKey(Map<String, String> signMap,String signType, String signKey){
        if("MD5".equals(signType)){
            String key =  getSign(signMap, signKey);
            logger.info("SignKey[" + key + "]");
            return key;
        }else{
            logger.info("目前只支持MD5加密");
            return null;
        }
    }

    /**
     * 验证签名
     * @param sign  密文串
     * @param signMap   待签名参数
     * @param signType  签名类型，目前支持支MD5
     * @param signKey   签名KEY
     * @return 验签结果
     */
    public static boolean checkSignKey(String sign, Map<String, String> signMap,String signType, String signKey){
        if("MD5".equals(signType)){
            String tempSign = getSign(signMap, signKey);
            return sign.equals(tempSign);
        }else{
            logger.info("目前只支持MD5加密");
            return false;
        }
    }
    private static String getSign(Map<String, String> map,String signKey) {
        ArrayList<String> list = new ArrayList<String>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getValue() != null && !"".equals(entry.getValue()) && !"null".equals(entry.getValue())) {
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        logger.info("signList[" + list + "]");
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result += "key=" + signKey;
        logger.info("加入验签的数据：["+result+"]");
        result = MD5Util.MD5Encode(result).toUpperCase();
        return result;
    }
    /**
     * 建立请求，以表单HTML形式构造（默认）
     * @param postMap	请求参数数组
     * @param getWay 	支付网关地址
     * @param method	提交方式：post
     * @return	提交表单HTML文本
     */
    public static String buildRequest(Map<String, String> postMap, String getWay, String method) {
        List<String> keys = new ArrayList<String>(postMap.keySet());
        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<form id=\"outpaysubmit\" name=\"outpaysubmit\" action=\"" + getWay
                + "?_input_charset=UTF-8" + "\" method=\"" + method
                + "\" target=\"_self\">");
        for (int i = 0; i < keys.size(); i++) {
            String name =  keys.get(i);
            String value = postMap.get(name);
            if(value != null && !"".equals(value)){
                sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
            }
        }
        sbHtml.append("<input type=\"submit\" value=\"" + "outpaysubmit" + "\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['outpaysubmit'].submit();</script>");
        return sbHtml.toString();
    }


    /**
     *收银台统一支付请求业务参数拼接
     *@param map
     *@return java.lang.String
     *@author wanghao,@Date 2016/11/24 20:02
     */
    public static String buildCashierPayBusinessParams(Map<String,String> map){
        StringBuffer result = new StringBuffer();
        if (map!=null&&map.size()>0){
            for (Map.Entry<String, String> entry : map.entrySet()) {
                if (StringUtil.isNotEmpty(entry.getValue()))
                    result.append(entry.getKey()).append("=").append(entry.getValue()).append("&+&");
            }
            return result.toString().substring(0,result.length()-3);
        }

        return result.toString();
    }

    /**
     * 建立二维码请求，以HTTP链接形式构造（默认）
     * @param postMap	请求参数数组
     * @param getWay 	支付网关地址
     * @return	生成二维码请求连接
     */
    public static String buildQRCodePayRequest(Map<String, String> postMap, String getWay) {
        ArrayList<String> keys;
        keys = new ArrayList<String>(postMap.keySet());
        String qrCodeUrl = getWay + "?_input_charset=UTF-8";
        for (int i = 0; i < keys.size(); i++) {
            String name = keys.get(i);
            String value =  postMap.get(name);
            if(value != null && !"".equals(value)){
                if("notify_url".equals(name)||"return_url".equals(name)||"exception_url".equals(name)||"trade_info".equals(name)){
                    try {
                        value = URLEncoder.encode(value,"utf-8");
                    } catch (Exception e) {
                        logger.info("buildQRCodePayRequest Param[" + name + "] Exception", e);
                        continue;
                    }
                }
                qrCodeUrl += "&" + name + "=" + value;
            }
        }
        return qrCodeUrl;
    }

    /**
     * 获取所有的请求参数
     * @param requestParams
     * @return
     */
    public static Map<String, String> parseRequestParams(Map<?, ?> requestParams){
        Map<String, String> params = new HashMap<String, String>();
        for (Iterator<?> iter = requestParams.keySet().iterator(); iter
                .hasNext();) {
            String name = (String) iter.next();
            String[] values = (String[]) requestParams.get(name);
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
                valueStr = (i == values.length - 1) ? valueStr + values[i]
                        : valueStr + values[i] + ",";
            }
            // 乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
            // valueStr = new String(valueStr.getBytes("ISO-8859-1")/, "utf-8");
            params.put(name, valueStr);
        }
        return params;
    }
}
