package com.lenovo.m2.web.common.stock.utils;

import java.io.Serializable;

/**
 *
 */
public class ResponseData implements Serializable{

    /**
     * 是否成功
     */
    private boolean success;
    private String code;
    private String msg;
    private String data;

    public ResponseData(){
    }

    public ResponseData(boolean success){
        this.success = success;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
