package com.lenovo.m2.web.common.my.model.useroperationlog;

import java.util.Map;

/**
 * 用于记录用户行为的对象
 * Created by mayan3 on 2015/11/10.
 */
public class UserOperationLog {

    //操作者
    private String lenovoId;

    // 操作IP
    private String ip;

    //返回码
    private String resultCode;

    //用户执行的操作
    private String userOperation;

    //其它信息
    private Map<String,String[]> otherMessageMap;


    /**
     * 用户操作行为记录
     * @param resultCode
     * @param ip
     */
   public UserOperationLog(String lenovoId,String resultCode, String ip){
       this.lenovoId=lenovoId;
       this.ip = ip;
       this.resultCode=resultCode;
   }

    /**
     * 构造用户行为记录的log
     * @param memberId  用户id
     * @param userOperation 用户执行的操作
     */
    public UserOperationLog(String lenovoId,String userOperation,String resultCode, String ip,Map<String,String[]> otherMessageMap){
        this.lenovoId=lenovoId;
        this.userOperation=userOperation;
        this.ip = ip;
        this.resultCode=resultCode;
        this.otherMessageMap=otherMessageMap;
    }

    public Map<String, String[]> getOtherMessageMap() {
        return otherMessageMap;
    }

    public void setOtherMessageMap(Map<String, String[]> otherMessageMap) {
        this.otherMessageMap = otherMessageMap;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getUserOperation() {
        return userOperation;
    }

    public void setUserOperation(String userOperation) {
        this.userOperation = userOperation;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

}
