package com.lenovo.m2.web.common.my;

import com.lenovo.m2.arch.framework.domain.Tenant;

/**
 * @author wangrq1
 * 
 */
public class ThreadLocalSessionTenant {

    private static ThreadLocal<Tenant> localTenant = new ThreadLocal<Tenant>();


    private static ThreadLocal<String> localLenovoId = new ThreadLocal<String>();


    public static String getLocalLenovoId() {
        return localLenovoId.get();
    }

    public static void setLocalLenovoId(String lenovoId) {
        localLenovoId.set(lenovoId);
    }

    public static void removeLenovoId(){
        localLenovoId.remove();
    }

    public static Tenant getTenant() {
        return localTenant.get();
    }
    
    public static void setTenant(Tenant req) {
        localTenant.set(req);
    }
    
    
    public static void removeTenant(){
        localTenant.remove();
    }
    


}
