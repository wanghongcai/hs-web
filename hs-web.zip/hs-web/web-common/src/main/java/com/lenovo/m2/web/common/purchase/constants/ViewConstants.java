package com.lenovo.m2.web.common.purchase.constants;

import com.lenovo.enums.ENUM;
import com.lenovo.m2.hsbuy.common.enums.ShopIdEnum;
import com.lenovo.m2.web.common.purchase.enums.Terminal;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.common.purchase.util.ViewPathUtil;

/**
 * 
* @ClassName: ViewConstants
* @Description: 视图地址配置
* @author yuzj7@lenovo.com
* @date 2015年7月22日 下午5:04:27
*
 */
public class ViewConstants {
	
	public static final String VIEW_PATH_PC_CART = ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "cart/page";
	public static final String VIEW_PATH_WAP_CART = ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "cart/cart/page";


	public final static String getShopingCardPath(int shopid, int terminal){
    	boolean ispc = false;
    	String suffix = "epp";
    	if(terminal == ENUM.BigPlatform.PC.getCode()){
			ispc = true;
		}
    	if(ENUM.MallType.EPP.getCode() == shopid){
    		suffix = "epp";
    	}else if(ENUM.MallType.Lenovo.getCode() == shopid){
    		suffix = "b2c";
    	}else if(ENUM.MallType.Think.getCode() == shopid){
    		suffix = "think";
    	}else if(ShopIdEnum.SMB.getType() == shopid){
    		suffix = "smb";
    	}else if(ShopIdEnum.SMB_SCORE.getType() == shopid || ShopIdEnum.HUI_SANG_SCORE.getType() == shopid){
    		suffix = "smbjf";
    	}else if(ShopIdEnum.HUI_SANG.getType() == shopid ){
			suffix = "hs";
		}
    	String cartpath =  ispc ? VIEW_PATH_PC_CART:VIEW_PATH_WAP_CART;
    	
    	return String.format("%s/cart_%s", cartpath, suffix);
        
	}
	
	
	
	
	public final static String getShopingCardEmptyPath(int shopid, int terminal){
		
		boolean ispc = false;
		if(terminal == ENUM.BigPlatform.PC.getCode()){
			ispc = true;
		}
		
    	String suffix = "epp";
    	if(ENUM.MallType.EPP.getCode() == shopid){

    	}else if(ENUM.MallType.Lenovo.getCode() == shopid){
    		suffix = "b2c";
    	}else if(ENUM.MallType.Think.getCode() == shopid){
    		suffix = "think";
    	}else if(ShopIdEnum.SMB_SCORE.getType() == shopid || ShopIdEnum.SMB_SCORE.getType() == shopid){
            suffix = "smbjf";
        }else if(ShopIdEnum.SMB.getType() == shopid){
        	suffix = "smb";
        }else if(ShopIdEnum.HUI_SANG.getType() == shopid){
			suffix = "hs";
		}
    	
    	String cartpath =  ispc ? VIEW_PATH_PC_CART:VIEW_PATH_WAP_CART;
    	
    	return String.format("%s/cart_empty_%s", cartpath, suffix);
	}
	
	
	/**
	 * 
	* @Description: 返回公共错误页面
	* @author yuzj7@lenovo.com  
	* @date 2015年7月26日 下午4:41:26
	* @param plat
	* @return
	 */
	public final static String getCommonErrorPath(String plat){
		if(StringUtil.isEmpty(plat) || "null".equals(plat)){
			return "cn/common/sys_error";
		}
		return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"/common/error";
	}
	
	public final static String getCommonErrorPath(int terminal){
		return ViewPathUtil.getViewPathByPlat(terminal)+"/common/error";

	}

	/**
	 * 
	* @Description: 提交订单成功
	* @author yuzj7@lenovo.com  
	* @date 2015年7月29日 下午4:46:33
	* @param plat
	* @return
	 */
	public static String getOrderSubmitSuccessPath(String plat) {
		return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"checkout/buy/ordersubmitSuccess";
	}

//    修改地址页面
    public static String getConsignerInfoEdit(String plat) {
        return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"checkout/buy/mycart-address-edit";
    }

	/**得到去支付的页面路径
	 * 
	 * @description
	 * 
	 * @author 2015年8月20日 下午3:10:31 By zhanghs
	 * @title  getToPayPath
	 * @param plat
	 * @return String
	 */
	public static String getToPayPath(String plat) {
		return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"checkout/buy/payment";
	}
	/**
	 * 
	* @Description: 转到提交订单阅读协议页面
	* @author yuzj7@lenovo.com  
	* @date 2015年8月23日 下午4:21:20
	* @param plat
	* @return
	 */
	public static String getHelpTerms(String plat) {
		return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"checkout/buy/terms";
	}

	public static String getInvoiceVATVM(String plat) {
		return ViewPathUtil.getViewPathByPlat(Integer.parseInt(plat))+"checkout/buy/VAT_TMP";
	}

	/**
	 * 
	* @Title: getCheckoutPath 
	* @Description: 到结算页
	* @param terminal
	* @return    设定文件
	 */
	public static String getCheckoutPath(int terminal){
		if(Terminal.PC.getType() == terminal){
			return ViewPathUtil.getViewPathByPlat(terminal) +"checkout/buy/ordersubmit";
		}else{
			return ViewPathUtil.getViewPathByPlat(terminal) +"checkout/order/buy/ordersubmit";
		}
	}
	
	
	private static final String AJAX_CART_MAIN = "/WEB-INF/vm/cn/pc/cart/fragment/cart_main.vm";
	private static final String AJAX_CART_EMPTY = "/WEB-INF/vm/cn/pc/cart/fragment/cart_empty.vm";
    private static final String AJAX_CART_MAIN_WAP = "/WEB-INF/vm/cn/wap/cart/cart/fragment/cart_main.vm";
    private static final String AJAX_CART_EMPTY_WAP = "/WEB-INF/vm/cn/wap/cart/cart/fragment/cart_empty.vm";
    private static final String AJAX_CART_SERVICE_WAP = "/WEB-INF/vm/cn/wap/cart/cart/fragment/part/cart_service.vm";
    private static final String AJAX_CART_MAIN_SMBJF = "/WEB-INF/vm/cn/pc/cart/smbjf/cart_main.vm";
    private static final String AJAX_CART_EMPTY_SMBJF = "/WEB-INF/vm/cn/pc/cart/smbjf/cart_empty.vm";

    /**
	 * 获取购物车异步刷新购物车的模版地址
	 * @param terminal
	 * @param empty
	 * @return
	 * @author wangrq1
	 */
	public static String getAjaxCartTemplate(int terminal, boolean empty, boolean isService, int shopId){
		if(ShopIdEnum.LENOVO.getType() == shopId || ShopIdEnum.THINK.getType() == shopId ||
				ShopIdEnum.SMB.getType() == shopId || ShopIdEnum.isEpp(shopId) || ShopIdEnum.isHuiShang(shopId)){

			if(Terminal.PC.getType() == terminal){
	            return empty ? AJAX_CART_EMPTY : AJAX_CART_MAIN;
	        }else if(Terminal.WAP.getType() == terminal || Terminal.APP.getType() == terminal || Terminal.WECHAT.getType() == terminal){
	            if (!isService){
	                return empty ? AJAX_CART_EMPTY_WAP : AJAX_CART_MAIN_WAP;
	            }else {
	                return empty ? AJAX_CART_SERVICE_WAP : AJAX_CART_SERVICE_WAP;
	        }
	        }
			return "";
		}else if(ShopIdEnum.SMB_SCORE.getType() == shopId || ShopIdEnum.HUI_SANG_SCORE.getType() == shopId){
            return empty ? AJAX_CART_EMPTY_SMBJF : AJAX_CART_MAIN_SMBJF;
        }else{
            return "";
        }
	}
	
	/**
	 * 我的预约模版
	 * @return
	 * @author wangrq1
	 */
	public final static String getMyReservationTemplate(Integer terminal){
    	return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "cart/reservation/myreservation";
        
	}

	/**
	 * 充值页模版
	 * @return
	 * @author wangrq1
	 */
	public final static String getChargeIndex(Integer terminal){
		if(Terminal.PC.getType() == terminal){
			return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "charge/page/index";
		}else{
			return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "cart/charge/page/index";
		}
	}

    /**
     * 帮助
     * @return
     * @author wangrq1
     */
    public final static String getHelpx(Integer terminal){
        if(Terminal.PC.getType() == terminal){
            return ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "charge/page/questionAnswering";
        }else{
            return ViewPathUtil.getViewPathByPlat(Terminal.WAP.getType()) + "cart/charge/page/questionAnswering";
        }
    }

	/**
	 * 充值首页碎片模板
	 * @return
	 * @author wangrq1
	 */
	public final static String getHomePageChargeFragment(){
    	return  ViewPathUtil.getViewPathByPlat(Terminal.PC.getType()) + "charge/page/fragment";
	}
	
}


