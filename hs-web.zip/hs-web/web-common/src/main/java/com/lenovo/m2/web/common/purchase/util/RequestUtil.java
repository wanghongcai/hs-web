package com.lenovo.m2.web.common.purchase.util;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by wanghao on 2017/6/5.
 */
public class RequestUtil {

    /**
     * 获取当前请求的域名
     * @param request
     * @return
     */
    public static String  getDomain(HttpServletRequest request){
        String domain = "";
        StringBuffer url = request.getRequestURL();
        domain = url.delete(url.length() - request.getRequestURI().length(), url.length()).append("/").toString();

        return domain;
    }
}
