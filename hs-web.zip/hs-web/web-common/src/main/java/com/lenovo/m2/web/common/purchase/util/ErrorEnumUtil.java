package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum_IN;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum_us;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnums;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Locale;

/**
 * Created by D_xiao on 2/10/17.
 * 枚举选择工具类,通过tenant选择errormessage枚举以对应不同语言.
 */
    public class ErrorEnumUtil {

        public static Logger log =  LogManager.getLogger(ErrorEnumUtil.class.getName());

        private ErrorEnumUtil() {
        }

        static <T extends Enum<T>> T valueOf(Class<T> enumClass, String name) {
            return Enum.valueOf(enumClass, name.toUpperCase(Locale.ENGLISH));
        }

        public static ErrorMessageEnums getErrorMessage(Tenant tenant , String name){
            try{
                switch(tenant.getShopId()){
                    case 1 : return valueOf(ErrorMessageEnum.class, name);
                    case 10 : return valueOf(ErrorMessageEnum_us.class,name);
                    default : return valueOf(ErrorMessageEnum.class,name);
                }
            }catch(IllegalArgumentException e){
                log.error("ErrorMessage枚举获取异常,无此枚举信息",e);
                return null;
            }
        }

    public static ErrorMessageEnums getErrorMessage(String name){
        try{
            Tenant tenant = ThreadLocalSessionTenant.getTenant();
            switch(tenant.getShopId()){
                case 1 : return valueOf(ErrorMessageEnum.class, name);
                case 10 : return valueOf(ErrorMessageEnum_us.class,name);
                case 16 : return valueOf(ErrorMessageEnum_IN.class,name);//印度摩托
                default : return valueOf(ErrorMessageEnum.class,name);
            }
        }catch(IllegalArgumentException e){
            log.error("ErrorMessage枚举获取异常,无此枚举信息",e);
            return null;
        }
    }

    public static  void main(String[] args) {
        Tenant tenant = new Tenant();
        tenant.setShopId(1);
//        ErrorMessageEnums error = getErrorMessage(tenant,"ERROR_PARAM1");
//        System.out.println(error.getCommon());
    }

}
