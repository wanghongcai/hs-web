package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;

/**
 * 视图返回路径工具类
 * Created by D_xiao on 2017/5/9.
 */
public class ViewPathUtil {
    public static  String getViewPathByPlat(Integer terminal){
        String area = "cn/";
        String path = "pc/";
        Integer shopId  = ThreadLocalSessionTenant.getTenant() == null? 1 : ThreadLocalSessionTenant.getTenant().getShopId();
        switch (shopId){
            case 1: area = "cn/";break;
            case 100:area = "en/";break;
            default : break;
        }
        if(terminal != null ){
            switch (terminal) {
                case 2:
                case 3:
                case 4:
                    path = "wap/";
                    break;
                case 1:
                    path = "pc/";
                    break;
                default:
                    break;
            }
        }
        StringBuffer sb = new StringBuffer().append(area).append(path);
        return sb.toString();
    }
}
