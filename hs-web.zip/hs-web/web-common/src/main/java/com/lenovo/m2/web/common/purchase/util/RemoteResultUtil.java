package com.lenovo.m2.web.common.purchase.util;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;

/**
 * 对dubbo接口的统一返回结果进行操作
 * Created by wanghao on 2017/5/24.
 */
public class RemoteResultUtil {

    /**
     * 修改remoteResult中的resultMsg,根据resultCode，进行国际化翻译
     * @param remoteResult
     * @param promptEnum
     * @return
     */
    public static RemoteResult updateMsg(RemoteResult remoteResult, PromptEnum promptEnum){
        if (remoteResult != null ){
            remoteResult.setResultMsg(remoteResult.getResultCode()!=null?PromptInit.get(promptEnum+"."+remoteResult.getResultCode()):"");
        }
        return remoteResult;
    }

    /**
     * 修改remoteResult中的resultMsg,根据resultCode，进行国际化翻译词条，然后用原resultMsg中的内容替换词条总的部分内容
     * @param remoteResult
     * @param promptEnum
     * @return
     */
    public static RemoteResult updateMsgAndReplace(RemoteResult remoteResult, PromptEnum promptEnum){
        if (remoteResult != null ){
            remoteResult.setResultMsg(remoteResult.getResultCode()!=null?PromptInit.get(promptEnum+"."+remoteResult.getResultCode(),remoteResult.getResultMsg()):"");
        }
        return remoteResult;
    }
}
