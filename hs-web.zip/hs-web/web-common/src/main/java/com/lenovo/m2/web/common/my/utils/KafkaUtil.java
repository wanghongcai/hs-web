package com.lenovo.m2.web.common.my.utils;

import com.lenovo.kafka.api.core.factory.KafkaProduceFactory;
import com.lenovo.kafka.api.core.factory.KafkaProduceOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by jack on 2017/3/1.
 */
public class KafkaUtil {

    static Logger log = LogManager.getLogger(KafkaProduceFactory.class);

    public static void KafkaSendMessage(String properties, String propertiesKey, String topic, String str){
        Properties props = null;
        try {
            log.info("properties={}",properties);
            props = PropertiesLoaderUtils.loadAllProperties(properties);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String env = props.getProperty(propertiesKey);
        KafkaProduceOptions options = new KafkaProduceOptions();
        log.info("env=metadataBrokerList={}",env);
        log.info("topic={}",topic);
        options.setMetadataBrokerList(env);
        options.setTopicName(topic);
        log.info("JsonUtil.toJson(options)={}",JsonUtil.toJson(options));
        KafkaProduceFactory factory = new KafkaProduceFactory(options);
//        log.info("factory={}",JsonUtil.toJson(factory));
        factory.sendMessage(str);
    }

}
