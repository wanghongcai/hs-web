package com.lenovo.m2.web.common.purchase.enums;

/**
 * 购物车项对应的类型信息
 * 1、主品， 2、赠品，3、套餐
 */
public enum ItemType {

	SKU(1, "SKU"), GIFT(2, "theGifts"), PKG(3, "thePacks");

	private final int type;
	private final String descr;

	private ItemType(int type, String descr) {
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	public static ItemType getItemTypeByType(int type) {
		ItemType result = null;
		switch (type) {
			case 1:
				result = SKU;
				break;
			case 2:
				result = GIFT;
                break;
			case 3:
				result = PKG;
                break;
			default:
				throw new IllegalArgumentException("can't find match enum instance where type=" + type);
		}
		return result;
	}
	
	public static ItemType getItemTypeByType(String type) {
		ItemType result = null;
		switch (type) {
			case "x":
				result = SKU; 
				break;
			case "y":
				result = GIFT;
				break;
			case "z":
				result = PKG; 
				break;
			default:
				throw new IllegalArgumentException("can't find match enum instance where type=" + type);
		}
		return result;
	}

}
