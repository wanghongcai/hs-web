package com.lenovo.m2.web.common.purchase.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by D_xiao on 2/10/17.
 */
public class TimeConvertUtil {

    private static final Logger LOGGER = LogManager.getLogger(TimeConvertUtil.class);

    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final String TIME_ZONE_ID = "Asia/Shanghai";

    /**
     * 将给定的时间转换成指定时区的时间
     * @param timeZoneId  eg: America/New_York
     * @param dateTime    eg: 2017-06-14 16:52:05
     * @return
     */
    public static String convertTime(String timeZoneId, String dateTime){
        if(StringUtils.isEmpty(dateTime)){
            return "";
        }
        TimeZone timeZone = null;
        if(StringUtils.isEmpty(timeZoneId)){
            timeZone = TimeZone.getTimeZone(TIME_ZONE_ID);
        }else{
            timeZone = TimeZone.getTimeZone(timeZoneId);
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
        try {
            Date localDateTime = sdf.parse(dateTime);
            sdf.setTimeZone(timeZone);
            return sdf.format(localDateTime);
        } catch (ParseException e) {
            LOGGER.error("Parse date error." + ExceptionUtil.getStackTrace(e));
            return "";
        }
    }

    public static String convertTime(String timeZoneId, Date date){
        if(date == null){
            return "";
        }
        TimeZone timeZone = null;
        if(StringUtils.isEmpty(timeZoneId)){
            timeZone = TimeZone.getTimeZone(TIME_ZONE_ID);
        }else{
            timeZone = TimeZone.getTimeZone(timeZoneId);
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
        sdf.setTimeZone(timeZone);
        return sdf.format(date);
    }

    public static String convertTime(TimeZone timeZone, String dateTime){
        if(StringUtils.isEmpty(dateTime)){
            return "";
        }
        if(timeZone == null){
            return dateTime;
        }
        return convertTime(timeZone.getID(), dateTime);
    }

    public static String covertTime(TimeZone timeZone, Date date){
        if(date == null){
            return "";
        }
        if(timeZone == null){
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
            return sdf.format(date);
        }
        return convertTime(timeZone.getID(), date);
    }

    public static void main(String[] args){
        System.out.println(TimeConvertUtil.convertTime("America/New_York", "2017-06-14 16:56:02"));
        System.out.println(TimeConvertUtil.convertTime("", "2017-06-14 16:56:02"));
        System.out.println(TimeConvertUtil.convertTime("America/New_York", new Date()));
        System.out.println(TimeConvertUtil.convertTime(Calendar.getInstance().getTimeZone(), "2017-06-14 15:02:24"));
    }

}
