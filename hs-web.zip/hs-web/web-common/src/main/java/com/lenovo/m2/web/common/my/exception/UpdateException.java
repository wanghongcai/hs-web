package com.lenovo.m2.web.common.my.exception;

/**
 * Created by yyduff on 2016/1/14.
 */
public class UpdateException extends Exception {
    public UpdateException(String message) {
        super(message);
    }
}
