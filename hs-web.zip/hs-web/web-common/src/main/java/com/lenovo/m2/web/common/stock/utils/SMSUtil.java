package com.lenovo.m2.web.common.stock.utils;


/**
 * Created by mayan3 on 2016/6/15.
 */
public class SMSUtil {
    public static final long SEND_SMS_INTERVAL = 1000 * 60 * 2; // 发送短信验证码的间隔，2分钟只能发1条短信，单位ms

    public static final int SMS_VALID = 2 * 60; // 短信验证码的有效期，2分钟

    public static final int SMS_ONEDAY = 24 * 60 * 60; // 时间 一天 1440分钟 ,单位s

}
