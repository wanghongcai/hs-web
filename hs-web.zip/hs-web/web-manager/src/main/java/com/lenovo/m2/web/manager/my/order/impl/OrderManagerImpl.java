package com.lenovo.m2.web.manager.my.order.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.ordercenter.PayRecordsDetailResult;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.web.common.my.utils.*;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.web.common.purchase.util.RemoteResultUtil;
import com.lenovo.m2.web.domain.my.MyResultCode;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.domain.my.order.smb.SmbDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetail;
import com.lenovo.m2.web.manager.my.order.OrderManager;
import com.lenovo.m2.web.remote.my.order.OrderMongoService;
import com.lenovo.m2.web.remote.my.order.OrderService;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by mayan3 on 2015/10/12.
 */
@Component("orderManager")
public class OrderManagerImpl implements OrderManager {

    private static final Logger logger = LogManager.getLogger(OrderManagerImpl.class);


    @Autowired
    private OrderService orderService;
    @Autowired
    private OpenOrderService openOrderService;
    @Autowired
    private OrderMongoService orderMongoService;
    @Autowired
    private OrderMiddlewareService orderMiddlewareService;

    @Override
    public RemoteResult<PageModel2<OrderDetailListJSONOrderList>> queryOrder(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType) {
        RemoteResult<PageModel2<OrderDetailListJSONOrderList>> remoteResult = new RemoteResult<PageModel2<OrderDetailListJSONOrderList>>(false);
        try {
            PageModel2<OrderDetailListJSONOrderList> page = orderService.queryOrder(merchantId, lenovoId, pageQuery, orddate, searchtext, orderstatus,orderType);
            if (null != page) {
                remoteResult.setT(page);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(ErrorUtil.ERR_GET_ORDERLIST);
            logger.error(e.getMessage(), e);
        }

        return remoteResult;
    }

    @Override
    public RemoteResult<PageModel2<OrderInfoVo>> queryOrderForCustomerService(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType) {
        RemoteResult<PageModel2<OrderInfoVo>> remoteResult = new RemoteResult<PageModel2<OrderInfoVo>>(false);
        try {
            PageModel2<OrderInfoVo> page = orderService.queryOrderForCustomerService(merchantId, lenovoId, pageQuery, orddate, searchtext, orderstatus,orderType);
            if (null != page) {
                remoteResult.setT(page);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(ErrorUtil.ERR_GET_ORDERLIST);
            logger.error(e.getMessage(), e);
        }

        return remoteResult;
    }


    @Override
    public RemoteResult<OrderDetailDesc> getOrderDetailDescByOrdercode(String orderCode, String merchantId) {
        RemoteResult<OrderDetailDesc> remoteResult = new RemoteResult<OrderDetailDesc>(false);

        try {

            logger.info("orderCode={},merchantId={}",orderCode,merchantId);
            OrderDetailDesc res = orderService.getOrderDetailDescByOrdercode(orderCode, merchantId);
            logger.info("OrderDetailDesc={}", JsonUtil.toJson(res));
            if (null != res) {
                remoteResult.setT(res);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(ErrorUtil.ERR_GET_ORDERDETAIL);
            logger.error(e.getMessage(), e);
        }

        return remoteResult;
    }

    @Override
    public String getVoiceUrl(String ordernm) {
        String btcpNm = orderService.getVoiceUrl(ordernm); // "N000001067";
        if (btcpNm != null) {
            String cid = CustomizedPropertyConfigurer.getContextProperty("invoice.cid");
            String data_digest = CustomizedPropertyConfigurer.getContextProperty("invoice.data_digest");
            String url = CustomizedPropertyConfigurer.getContextProperty("invoice.url");
            StringBuffer buffer = new StringBuffer();
            buffer.append("<Order><ShipmentsNo>").append(btcpNm).append("</ShipmentsNo></Order>");
            try {
                HttpPost post = new HttpPost(url);
                List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                String xml = buffer.toString();
                nvps.add(new BasicNameValuePair("xml", xml));
                // ”cid”为分配的客户ID
                nvps.add(new BasicNameValuePair("cid", cid));
                // “data_digest”字段进行签名验证
                MessageDigest md51 = MessageDigest.getInstance("MD5");
                String value = xml + data_digest;
                value = Base64.encode(md51.digest(value.getBytes("utf-8")));
                nvps.add(new BasicNameValuePair("data_digest", value));
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nvps, "utf-8");
                post.setEntity(entity);
                HttpResponse response = HttpUtil.executeProxy(post);

                String result = EntityUtils.toString(response.getEntity());
                // 返回结果解析
                SAXReader saxReader = new SAXReader();
                saxReader.setEncoding("utf-8");
                Document doc;
                doc = saxReader.read(new ByteArrayInputStream(result.trim().getBytes("UTF-8")));
                Element root = doc.getRootElement();
                if (root != null) {
                    String code = root.elementText("Code"); // 400
                    if (code != null) {
                        String message = code + "$" + root.elementText("Message");
                        return message; //
                    } else {
                        return root.elementText("PDF_URL");
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        return null;
    }

    @Override
    public String getInVoiceUrlFromDB(String ordernm) {
        String url = null;
        try {
            url = orderService.getInVoiceUrlFromDB(ordernm);
            return url;
        } catch (Exception e) {
            logger.error("查询发票url失败 orderCode: " + ordernm, e);
        }
        return null;
    }

//    @Override
//    public RemoteResult<Integer> updateOrderConfirm(String ordercode, String memberId, String merchantId) {
//        logger.info("### updateOrderConfirm the ordercode is: " + ordercode + " memberId is: " + memberId + " merchantId is: " + merchantId);
//        RemoteResult<Integer> remoteResult = new RemoteResult<Integer>(false);
//        remoteResult.setResultCode(MyResultCode.ORDER_ERROR);
//        remoteResult.setSuccess(false);
//        remoteResult.setT(-3);
//        remoteResult.setResultMsg("updateOrderConfirm签收接口异常");
//        try {
//            Integer i = orderService.updateOrderConfirm(ordercode, memberId, merchantId);
//            if (i == 1) {
//                remoteResult.setT(0);
//                remoteResult.setSuccess(true);
//                remoteResult.setResultMsg("签收成功");
//                remoteResult.setResultCode("200");
//                return remoteResult;
//            } else if (i == -1) {
//                remoteResult.setT(-1);
//                remoteResult.setSuccess(false);
//                remoteResult.setResultMsg("该用户无此订单");
//                remoteResult.setResultCode("9001");
//                return remoteResult;
//            } else if (i == -2) {
//                remoteResult.setT(-2);
//                remoteResult.setSuccess(false);
//                remoteResult.setResultMsg("重复签收");
//                remoteResult.setResultCode("9002");
//                return remoteResult;
//            }
//        } catch (Exception e) {
//            logger.error("updateOrderConfirm签收接口异常", e);
//            return remoteResult;
//        }
//
//        return remoteResult;
//    }

    @Override
    public RemoteResult<PageModel2<UserProduct>> queryPayedUserProducts(String merchantId, String lenovoId, PageQuery pageQuery, String orddate) {
        RemoteResult<PageModel2<UserProduct>> remoteResult = new RemoteResult<PageModel2<UserProduct>>(false);
        try {
            PageModel2<UserProduct> page = orderService.queryPayedUserProducts(merchantId, lenovoId, pageQuery, orddate);
            if (null != page) {
                remoteResult.setT(page);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(MyResultCode.ORDER_ERROR);
            logger.error(e.getMessage(), e);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<MongoOrderDetail> getOrderByOrdercode(String merchantId, String orderCode) {
        RemoteResult<MongoOrderDetail> remoteResult = new RemoteResult<MongoOrderDetail>(false);
        try {
            MongoOrderDetail res = orderMongoService.getOrderByOrdercode(orderCode, merchantId);
            if (null != res) {
                remoteResult.setT(res);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(MyResultCode.ORDER_ERROR);
            e.printStackTrace();
        }

        return remoteResult;
    }


    @Override
    public RemoteResult<Boolean> deleteOrder(String ordercode, String lenovoId, String merchantId) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<>(false);
        remoteResult.setResultMsg("操作失败");
        try {
            int i = orderMongoService.updateMongoOrder(merchantId, ordercode, "isDelete", "1");
            if (i == 1) {
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("200");
                remoteResult.setResultMsg("删除成功");
                return remoteResult;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            remoteResult.setT(false);
            remoteResult.setResultCode("9999");
            remoteResult.setResultMsg(e.getMessage());
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public List<OrderDetailListJSONOrderList> getOrderDetailByOrderMainCode(String orderno, String shopId) {
        List<OrderDetailListJSONOrderList> orderDetailByOrderMainCode = orderService.getOrderDetailByOrderMainCode(orderno,shopId);
        return orderDetailByOrderMainCode;
    }

    @Override
    public SmbDetail getSmbDetail(String orderno, String shopId, SmbOrderDetail smbOrderDetail) {
        SmbDetail smbDetail = orderService.getSmbDetail(orderno,shopId,smbOrderDetail);
        return smbDetail;
    }

    @Override
    public RemoteResult<List<MongoOrderDetail>> getMongoOrderDetailsByOrdercode(String merchantId, String orderNo) {
        RemoteResult<List<MongoOrderDetail>> remoteResult = new RemoteResult<List<MongoOrderDetail>>();
        try {
            List<MongoOrderDetail> res = orderMongoService.getOrderDetailByOrderMainCode(orderNo, merchantId);
            logger.info("res={}", JsonUtil.toJson(res));
            if (null != res) {
                remoteResult.setT(res);
                remoteResult.setSuccess(true);
            }
        } catch (Exception e) {
            remoteResult.setResultCode(MyResultCode.ORDER_ERROR);
            e.printStackTrace();
        }

        return remoteResult;
    }

    @Override
    public RemoteResult cancelOrder(String orderId, String orderCode) {
        RemoteResult remoteResult = orderMiddlewareService.cancelOrder(Long.parseLong(orderId), Integer.parseInt(orderCode), 0);
        RemoteResultUtil.updateMsg(remoteResult, PromptEnum.ORDERMIDDLEWARESERVICE_CANCELORDER);
        return remoteResult;
    }

    @Override
    public RemoteResult cancelOrder(String orderId, Tenant tenant) {
        RemoteResult remoteResult =orderMiddlewareService.cancelOrder(Long.parseLong(orderId), 0, tenant.getShopId());
        RemoteResultUtil.updateMsg(remoteResult, PromptEnum.ORDERMIDDLEWARESERVICE_CANCELORDER);
        return remoteResult;
    }

    @Override
    public RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayListParam) {
        return openOrderService.queryDownlinePayList(downlinePayListParam);
    }

    @Override
    public RemoteResult<PayRecordsDetailResult> payRecordsDetail(String p, Tenant t) {
        return openOrderService.payRecordsDetail(p,t);
    }

    @Override
    public RemoteResult confirmReceive(String ordno, String lenovoId, Tenant tenant) {
        RemoteResult remoteResult = openOrderService.updateOrderConfirm(ordno,lenovoId,tenant);
        return remoteResult;
    }

    @Override
    public RemoteResult<Map<String, Object>> getOrderTrackInfo(String orderNo, Tenant tenant) {
        RemoteResult<Map<String, Object>> remoteResult = orderService.getOrderTrackInfo(orderNo,tenant);
        return remoteResult;
    }


}
