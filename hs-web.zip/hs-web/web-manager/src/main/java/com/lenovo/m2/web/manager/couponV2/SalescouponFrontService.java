package com.lenovo.m2.web.manager.couponV2;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.OldforNewModel.SendCouponOldforNewOrderVo;
import com.lenovo.m2.couponV2.api.dubboModel.UserApi;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.common.BaseInfo;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;

import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/11.
 */
public interface SalescouponFrontService {

    /**
     * 领取epp优惠券
     * @param couponway 1 注册后送券；2 订单成功后送券
     * @param lenovoid
     * @param memberCode
     * @return
     */
    public RemoteResult<Boolean> addEppCoupon(int couponway, String lenovoid, String memberCode);

    /**
     * 绑券接口
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    RemoteResult<Boolean> bindCoupons(Long couponId, String lenovoId, String memberCode);

    /**
     * 绑券接口
     * @param shopId
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    RemoteResult<Boolean> bindCoupons(String shopId, Long couponId, String lenovoId, String memberCode);

    /**
     * 单个绑券接口，优惠券只能领取一次
     * @param shopId
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    RemoteResult<Boolean> bindCouponsForOnce(String shopId, Long couponId, String lenovoId, String memberCode);

    /**
     * 绑定全员券方法
     * @param lenovoid
     * @param memberCode
     * @param groupcode
     * @param shopid
     * @return
     */
    public int bindAllMemberSalesCoupons(String lenovoid, String memberCode, String groupcode, String shopid);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用  1已使用
     * @param pageQuery
     * @return
     */
    RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery);

    /**
     * 获取用户的可以优惠券数量，查询的同时会绑全员券
     * @param userApi
     * @param shopId
     * @param terminal
     * @return
     */
    public RemoteResult getSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal);

    /**
     *  获取用户的可用优惠券
     * @param userApi
     * @param shopId
     * @param terminal
     * @return
     */
    public RemoteResult getUserSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 1:Lenovo，2:Think，3:EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用 1已使用
     * @param pageQuery
     * @return
     */
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(String lenovoId, String shopid, String terminal, String status, String time, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 1:Lenovo，2:Think，3:EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用 1已使用
     * @param pageQuery
     * @return
     */
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery);



    /**
     * 单个用户批量赠送指定优惠券,对外接口
     * @param couponIds
     * @param lenovoId
     * @param memberCode
     * @return
     */
    public RemoteResult bindBatchCoupons(String couponIds, String lenovoId, String memberCode);

    /**
     * 根据优惠券分类获取优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult getSalescouponsByClassification(PageQuery pageQuery, Map map);

    /**
     * 根据优惠券ID获取优惠券
     * @param pageQuery
     * @param map
     * @return
     */
//    public RemoteResult getSalescouponsBySalesCouponIds(PageQuery pageQuery, Map map);
    public RemoteResult getSalescouponsBySalesCouponIds(Tenant tenant , PageQuery pageQuery, Map map);

    /**
     * 查看用户是否拥有该优惠券
     * @param map
     * @return
     */
    public RemoteResult getUserIshaveTheCoupon(Map map);

    /**
     * 获取优惠券可领取数量
     * @param map
     * @return
     */
    public RemoteResult getSalesCouponsNumbersForId(Map map);

    public RemoteResult getMemberCouponsStatus(Map map);
    public RemoteResult queryCouponByUseScope(Tenant tenant, int useScope, Long salescouponId, String couponName);

}
