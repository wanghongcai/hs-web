package com.lenovo.m2.web.manager.purchase.order.task;


import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.bee.PromotionInfo;
import com.lenovo.m2.web.common.my.utils.JsonUtil;
import com.lenovo.m2.web.domain.purchase.order.C2CCookie;
import com.lenovo.m2.web.remote.purchase.promotion.RemotePromotionService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by D_xiao on 16/11/14.
 */
@Component("cookieTask")
@Scope("prototype")
public class CookieTask extends Thread {
    public static Logger log =  LogManager.getLogger(CookieTask.class.getName());
    @Autowired
    private RemotePromotionService remotePromotionService;

    private String orderNum;
    private String cTwoMember;
    private HttpServletRequest request;
    private String c2cType ;
    private Tenant tenant;
    private String c2cStr;
    public void setOrderNum(String orderNum){
        this.orderNum = orderNum;
    }
    public void setRequest(HttpServletRequest request){
        this.request = request;
    }
    public void setCTwoMember(String cTwoMember){
        this.cTwoMember = cTwoMember;
    }
    public void setC2cType(String c2cType){
        this.c2cType = c2cType;
    }
    public void setTenat(Tenant tenant){
        this.tenant = tenant;
    }
    public  void run(){
        log.info("线程启动 -- >");
        Cookie[] cookies = request.getCookies();
        String name = "";
        Integer type = 0;//0 普通 1 c2c 2 cps 3 小蜜蜂
        Map<String,String> cps = new HashMap<>();
        StringBuffer sb = new StringBuffer();
        try {
            for(Cookie c:cookies){
                name = c.getName();
                sb.append(name+":"+c.getValue()+"|");
                if("wi".equals(name)||"cid".equals(name)){
                    type = 2;
                    cps.put(name,URLDecoder.decode(c.getValue(), "UTF-8"));
                }
            }
            if(type!=2){
                for(Cookie c:cookies){
                    name = c.getName();
                    if("c2clenovo".equals(name) && c2cType !=null &&  "1".equals(c2cType)) {
                        type = 1;
                        c2cStr = URLDecoder.decode(c.getValue(), "UTF-8");
                        c2cStr = c2cStr.replace("“", "\"");
                    }
                }
            }
        } catch (Exception e) {
            log.error("CookieTask cookie转utf8编码异常:",e);
        }
        log.info("订单号为::"+orderNum+",购买人"+cTwoMember+",商品类型"+c2cType+",cookie:"+sb.toString()+",type:"+type);

        PromotionInfo promotionInfo = new PromotionInfo();
        if(c2cType!=null && "3".equals(c2cType)){//小蜜蜂
            promotionInfo.setOrderCode(orderNum);
            promotionInfo.setType(Integer.parseInt(c2cType));
            remotePromotionService.pushPromotionInfo(promotionInfo,tenant);
        } else if(type != 0){
            promotionInfo.setOrderCode(orderNum);
            promotionInfo.setType(type);
            promotionInfo.setcTwoMember(cTwoMember);
            try{
                if(type == 1){
                    log.info("订单号为::"+orderNum+",c2cCookie="+c2cStr);
                    if(c2cStr!=null && !"".equals(c2cStr)){
                        C2CCookie cookie = JsonUtil.fromJson(c2cStr,C2CCookie.class);
                        promotionInfo.setPromotionName(cookie.getPromotionName()!=null?cookie.getPromotionName():"");
                        promotionInfo.setPromotionChannels(cookie.getPromotionChannels()!=null?cookie.getPromotionChannels():"");
                        promotionInfo.setPromotionType(cookie.getPromotionType()!=null?cookie.getPromotionType():"");
                        promotionInfo.setcOneMember(cookie.getMemberId()!=null?cookie.getMemberId():"");
                    }
                }else{
                    promotionInfo.setCampaignId(cps.containsKey("cid")?cps.get("cid"):"");
                    promotionInfo.setFeedback(cps.containsKey("wi")?cps.get("wi"):"");
                }
                log.info("订单号为::"+orderNum+",promotionInfo信息:{},tenant:{}",JsonUtil.toJson(promotionInfo),tenant);
                remotePromotionService.pushPromotionInfo(promotionInfo,tenant);
            }catch(Exception e){
                log.info("订单号为::"+orderNum+" 发送失败!");
                log.error("CookieTask cookie解析json异常:",e);
            }


        }

    }
}
