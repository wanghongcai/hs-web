//package com.lenovo.m2.web.manager.purchase.complain;
//
//import com.lenovo.m2.web.domain.purchase.complain.Complain;
//
//import java.util.List;
//import java.util.Map;
//
///**
// * <br> 投诉进行mongoDB的数据操作
// * @author shenjc
// *
// */
//public interface ComplainMongoService {
//
//	/**
//	 * <br> 保存投诉建议
//	 * @param complain
//	 */
//	public int saveComplain(Complain complain);
//
//	/**
//	 * <br> 查询投诉建议
//	 * @return
//	 */
//	public List<Complain> getComplain(Map<String, String> params);
//}
