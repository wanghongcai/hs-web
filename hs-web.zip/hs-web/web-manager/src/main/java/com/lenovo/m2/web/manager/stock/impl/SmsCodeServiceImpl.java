package com.lenovo.m2.web.manager.stock.impl;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.web.common.stock.utils.ErrorUtils;
import com.lenovo.m2.web.common.stock.utils.SMSUtil;
import com.lenovo.m2.web.common.stock.utils.StringUtil;
import com.lenovo.m2.web.manager.stock.RedisObjectManager;
import com.lenovo.m2.web.manager.stock.SmsCodeService;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by mayan3 on 2016/6/15.
 */
@Component("smsCodeService")
public class SmsCodeServiceImpl implements SmsCodeService {
    @Autowired
    private RedisObjectManager redisObjectManager;
//TODO
//    @Autowired
//    private SubscribeService subscribeService;


    private static final String CACHE_PREFIX_SMSCODE = "MOBILE:SMSCODE_";
    private static final String CACHE_PREFIX_SMSSMSTEXT = "MOBILE:SMSTEXT_";
    private static final Logger LOGGER = LogManager.getLogger(SmsCodeServiceImpl.class);


    @Override
    public RemoteResult sendSmsCode(String mobile,String userAgent,String ip,String leId,String shopId) {
        RemoteResult result = new RemoteResult(false);
        String smsText = null;
        try {
            //写入缓存
            String cacheKey = buildCacheKeyForSmsCode(mobile);
            //初始化缓存映射
            Map<String, String> cacheMap = redisObjectManager.hashGetAll(cacheKey);
            //读取短信内容
            smsText = redisObjectManager.getString(CACHE_PREFIX_SMSSMSTEXT);
            if (Strings.isNullOrEmpty(smsText)) {
                RemoteResult smsResult = null; //TODO subscribeService.getSmsTemplate("2");
                if (smsResult.isSuccess()) {
                    smsText = (String) smsResult.getT();
                    redisObjectManager.setString(CACHE_PREFIX_SMSSMSTEXT, smsText, SMSUtil.SMS_ONEDAY);
                }
            }

            if (MapUtils.isEmpty(cacheMap) || !StringUtil.checkIsDigit(cacheMap.get("sendTime"))) {
                //生成随机数
                String randomCode = RandomStringUtils.randomNumeric(5);
                //TODO
                //subscribeService.sendSMS(String.format(smsText, randomCode), mobile,ip,leId,userAgent,ip,shopId);
                //更新缓存
                updateSmsCacheInfo(cacheKey, randomCode);
                redisObjectManager.expire(cacheKey, SMSUtil.SMS_VALID);

                result.setSuccess(true);
                result.setResultMsg("验证码已发送至" + mobile);
                return result;
            } else {
                //获取缓存数据
                long sendTime = Long.parseLong(cacheMap.get("sendTime"));
                long curtime = System.currentTimeMillis();
                boolean valid = curtime >= (sendTime + SMSUtil.SEND_SMS_INTERVAL); // 2分钟只能发1条短信
                if (!valid) {
                    result.setResultCode(ErrorUtils.ERR_CODE_SMS_MINUTELIMIT);
                    result.setResultMsg("两分钟内只能发一条短信");
                    return result;
                }
                // 使用原来验证码
                String randomCode = cacheMap.get("smsCode");
                //读取短信内容
                if (Strings.isNullOrEmpty(randomCode)) {
                    randomCode = RandomStringUtils.randomNumeric(5);
                }
                //TODO
//                subscribeService.sendSMS(String.format(smsText, randomCode), mobile,ip,leId,userAgent,ip,shopId);
                //更新缓存
                updateSmsCacheInfo(cacheKey, randomCode);
                result.setSuccess(true);
                result.setResultMsg("验证码已发送至" + mobile);
                return result;
            }
        } catch (Exception e) {
            result.setResultCode(ErrorUtils.ERR_CODE_SMS_ERROR);
            result.setResultMsg("发送验证码失败");
            LOGGER.error(e.getMessage(),e);
        }
        return result;
    }

    public boolean updateSmsCacheInfo(String cacheKeySmscode, String smsCode) {
        boolean flag = true;
        try {

            Map<String, String> mapData = Maps.newHashMap();
            mapData.put("smsCode", smsCode);    //初始化验证码
            mapData.put("sendTime", Long.toString(System.currentTimeMillis()));   //发送时间
            redisObjectManager.hashMultipleSet(cacheKeySmscode, mapData);
        } catch (Exception e) {
            flag = false;
            LOGGER.error("[SMS] service method updateSmsCacheInfo error.{}", e);
        }
        return flag;
    }

    private String buildCacheKeyForSmsCode(String mobile) {
        return CACHE_PREFIX_SMSCODE + "_" + mobile;
    }
}
