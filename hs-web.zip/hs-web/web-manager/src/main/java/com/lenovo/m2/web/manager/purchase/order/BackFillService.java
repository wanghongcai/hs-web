package com.lenovo.m2.web.manager.purchase.order;

import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;
import com.lenovo.m2.web.domain.purchase.order.backfill.UpdateItemTypeEnum;

import java.util.List;


public interface BackFillService {

    public final static String PRE_BACKFILL_CACHE_KEY="BK";

    /**初始化结算缓存
     *
     * @param backFillOrderVo 回填对象
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param lid lid（用户结算缓存唯一标识）
     * @param shopId 商户id
     *
     */
    BackFillOrderVo initCheckOutCache(String lenovoId, int terminal, int shopId, String lid, BackFillOrderVo backFillOrderVo);


    /**初始化结算缓存
     *
     * @param tempOrder 临时订单对象
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     *
     */
//    BackFillOrderVo initCheckOutCache(String lenovoId,int terminal,int shopId,TempOrder tempOrder);

    /**更新单个或整体缓存项
     *
     * @param content 更新内容
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     * @param updateItemTypeEnum 更新项
     * @return 更新失败则返回null
     */
    BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId, String lid, String content, UpdateItemTypeEnum updateItemTypeEnum);

    /**更新单个或整体缓存项
     *
     * @param backFillOrderVo 回填对象
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     * @param updateItemTypeEnum 更新项
     * @return 更新失败则返回null
     */
    BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId, String lid, BackFillOrderVo backFillOrderVo, UpdateItemTypeEnum updateItemTypeEnum);

    /**更新部分结算缓存
     *
     * @param backFillOrderVo 回填对象
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     * @param updateItemTypeEnums 更新项集合
     * @return 更新失败则返回null
     */
    BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId, String lid, BackFillOrderVo backFillOrderVo, List<UpdateItemTypeEnum> updateItemTypeEnums);

    /**更新结算缓存
     *
     * @param backFillOrderVo 回填对象
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     * @return 更新失败则返回null
     */
    BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId, String lid, BackFillOrderVo backFillOrderVo);

    /**显示结算缓存
     *
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     *
     */
//    void showCheckOutCache(String lenovoId,int terminal,int shopId);

    /**查询结算缓存,不存在则返回null
     *
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     */
    BackFillOrderVo getCheckOutCache(String lenovoId, int terminal, int shopId, String lid);

    /**清空结算缓存
     *
     * @param terminal 终端id
     * @param lenovoId 用户id
     * @param shopId 商户id
     * @param lid lid（用户结算缓存唯一标识）
     */
    void clearCheckOutCache(String lenovoId, int terminal, int shopId, String lid) throws  Exception;
    
    /**
     * 
    * @Title: isRightLid 
    * @Description:校验用户输入的lid 是否正确，不正确就调回购物车，防止攻击
    * @param lenovoId
    * @param terminal
    * @param shopId
    * @param lid
    * @return    设定文件
     */
    public boolean isRightLid(String lenovoId, int terminal, int shopId, String lid);

}
