package com.lenovo.m2.web.manager.purchase.cashier;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;

import javax.servlet.http.HttpServletRequest;

/**
 * Create For Cashier
 * 收银台业务Manager
 * Created by MengQiang on 2015/8/21.
 */
public interface CashierManager {

    /**
     *收银台统一支付请求拼接
     *@param request
     *@return com.lenovo.m2.arch.framework.domain.RemoteResult
     *@author wanghao,@Date 2016/11/24 17:23
     */
    public RemoteResult toCashierPay(SessionUser user, HttpServletRequest request);

    /**
     * 收银台惠商信用还款支付
     * @param request
     * @return
     */
    public RemoteResult toCashierCreditPay(SessionUser user,HttpServletRequest request);

    /**
     *
     * 支付成功回调修改订单状态为已支付
     * @param tenant
     * @param outTradeNo
     * @param request
     * @param mongoOrderDetail
     * @return
     * @Author wanghao,@Date 2017/2/10 15:04
     */
    RemoteResult<String> callUpdate(Tenant tenant, String outTradeNo, HttpServletRequest request, MongoOrderDetail mongoOrderDetail);

//    RemoteResult<String> callUpdateCredit(Tenant tenant, String outTradeNo, HttpServletRequest request, CreditPartitionBillsApi creditPartitionBillsApi);

    /**
     * 检查mongo订单的状态
     * @param lenovoId
     * @param mongoOrderDetail
     * @return
     */
    public String checkMongoOrder(String lenovoId,MongoOrderDetail mongoOrderDetail);

    /**
     * 检查信用账单的状态
     * @param lenovoId
     * @param mongoOrderDetail
     * @return
     */
    public String checkCreditOrder(String lenovoId,PayTrackingApi mongoOrderDetail);
}
