package com.lenovo.m2.web.manager.purchase.order;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.web.common.purchase.util.FpsResult;

import javax.servlet.http.HttpServletRequest;

/**
 * 
* @ClassName: SubmitOrderService 
* @Description: 提交订单服务
* @author yuzj7@lenovo.com 
* @date 2016年3月10日 上午11:18:56 
*
 */
public interface SubmitOrderService {
	/**
	 * 
	* @Title: submitOrder 
	* @Description: TODO(这里用一句话描述这个方法的作用) 
	* @param terminal
	* @param lid
	* @return    设定文件
	 */
	public String submitOrder(Boolean selectNormal,String preSaleMobile, String creditInfo,Tenant tenant, Integer terminal, String lid, String orderremark, String cmanagercode, HttpServletRequest request, SessionUser user, String captcha);

	/**
	 *
	* @Title: checkOut
	* @Description: 订单结算
	* @param terminal
	* @param lid
	* @return    设定文件
	 */
	public String checkOut(Integer terminal, Tenant tenant, String lid, HttpServletRequest request, SessionUser user);

	/**
	*
	* @Title: UseVirtualCurrency
	* @Description: 使用虚拟货币（优惠券，优惠码，内购，礼品卡，乐豆）
	* @param terminal
	* @param lid
	* @param virTualType	类型:  (6,"优惠券"),(7,"优惠码"),(8,"内购"),(9,"礼品卡"),(10,"乐豆"),(14,"数据恢复险"),
	* @param value	优惠值
	* @return
	 */
	public String UseVirtualCurrency(Integer terminal, Tenant tenant, String lid, Integer virTualType, String value, SessionUser user, HttpServletRequest request);


}
