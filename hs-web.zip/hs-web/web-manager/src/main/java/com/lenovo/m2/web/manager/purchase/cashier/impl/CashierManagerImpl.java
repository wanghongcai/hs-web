package com.lenovo.m2.web.manager.purchase.cashier.impl;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.credit.api.dubboService.CreditService;
import com.lenovo.m2.credit.api.model.CreditPartitionBillsApi;
import com.lenovo.m2.credit.api.model.PayTrackingApi;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.middleware.PayAccount;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import com.lenovo.m2.hsbuy.domain.order.mongo.Receiver;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.web.common.my.ThreadLocalSessionTenant;
import com.lenovo.m2.web.common.purchase.constants.PeakConstant;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.domain.my.encrypt.StringEncrypt;
import com.lenovo.m2.web.domain.purchase.cashier.CashierPayModel;
import com.lenovo.m2.web.domain.purchase.cashier.ModelUtil;
import com.lenovo.m2.web.manager.purchase.cashier.CashierManager;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Create For Cashier
 * 收银台Manager实现类
 * Created by mengqiang1 on 2015/8/21.
 */
@Service
public class CashierManagerImpl implements CashierManager {

    @Autowired
    private OpenOrderService OpenOrderService;
    @Autowired
    private OrderMiddlewareService orderMiddlewareService;
    @Autowired
    private CreditService creditService;


    private static Logger logger = LogManager.getLogger(CashierManagerImpl.class.getName());



    @Override
    public RemoteResult toCashierPay(SessionUser user,HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);
        CashierPayModel model = (CashierPayModel) ModelUtil.getModel(request);
        String orderMainCode = model.getOrderMainCode();
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String shopId = model.getShopId();
        String terminal = model.getTerminal();
        String accountType = model.getAccount_type();
        String bankCode = model.getBank_code();
        String cardType = model.getCard_type();
        String bankType = model.getBank_type();
        Tenant tenant = ThreadLocalSessionTenant.getTenant();
        String qrPayMode = model.getQrPayMode();
        String usedPoints = model.getUsedPoints();

        RemoteResult<MongoOrderDetail> mongoOrderDetailRemoteResult = OpenOrderService.getMongoOrderDetail(tenant,orderMainCode);
        logger.info("获取订单信息：mongoOrderDetailRemoteResult："+ JsonUtil.toJson(mongoOrderDetailRemoteResult));
        if (mongoOrderDetailRemoteResult == null || !mongoOrderDetailRemoteResult.isSuccess() || mongoOrderDetailRemoteResult.getT() == null) {
            logger.info("Direct Pay Get mongoOrderDetail Fail, mongoOrderDetailRemoteResult【"+ mongoOrderDetailRemoteResult +"】 OrderMainCode[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg(ErrorEnumUtil.getErrorMessage("ERROR_ORDER_QUERY_FAIL").toString());
            return returnResult;
        }
        MongoOrderDetail mongoOrderDetail = mongoOrderDetailRemoteResult.getT();
        String fa_id = mongoOrderDetail.getFaid();

        try {
            if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
                logger.info("订单已支付，订单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg(ErrorEnumUtil.getErrorMessage("ERROR_ORDER_STATUS_PAID").toString());
                return returnResult;
            }
            if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(mongoOrderDetail.getOrderStatus()))) {
                logger.info("主订单已失效，订单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg(ErrorEnumUtil.getErrorMessage("ERROR_ORDER_STATUS_INVALID").toString());
                return returnResult;
            }

            if(PeakConstant.ORDER_CREDIT_USE_NO != mongoOrderDetail.getCreditLineWay()){
                //只有信用使用了信用且是慧商订单，才会判断主账号和签署合同
                if (PeakConstant.SHOPID_ALLINPAY.equals(shopId)){
                    //只有惠商，判断当前的用户是否是当前经销商的主账号//// TODO: 2017/5/23
                    if (!SSOUtil.isMainAccount(user.getUsername())){
//            if (false){
                        logger.info("Illegal Request, user is not the main user=="+user.getUsername()+" orderMainCode["+orderMainCode+"]");
                        returnResult.setSuccess(false);
                        returnResult.setResultCode("400");
                        returnResult.setResultMsg("当前登录用户不是主账号");
                        return returnResult;
                    }
                    //验证订单的合同是否已签署
                    if (!PeakConstant.ORDER_AUDIT_SIGNED_CONTRACT.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
                        logger.info("支付异常,当前订单未签订合同,orderMainCode--" + orderMainCode);
                        returnResult.setSuccess(false);
                        returnResult.setResultCode("400");
                        returnResult.setResultMsg("支付异常");
                        return returnResult;
                    }
                }
            }


            if(String.valueOf(tenant.getShopId()).equals(PeakConstant.SHOPID_IN)){
                //印度moto需要将真实的余额数据乘以100为支付平台需要的数据
                if (StringUtil.isNotEmpty(usedPoints)){
                    String str = BigDecimalUtil.mul(usedPoints,"100");
                    usedPoints = new BigDecimal(str).intValue()+"";
                }

            }

        } catch (Exception e) {
            logger.error("支付异常" + e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg(ErrorEnumUtil.getErrorMessage("ERROR_PAY_EXCEPTION").toString());
        }
        //// TODO: 2017/3/13 关闭账号验证功能
        String requestLenovoId= SSOUserInfoUtil.getLenovoId(request);
//        String requestLenovoId= mongoOrderDetail.getLenovoId();
        if (!mongoOrderDetail.getLenovoId().equals(requestLenovoId)){
            logger.info("登陆账号和订单账号不相同，订单号[" + orderMainCode + "]，currentLenovoId["+requestLenovoId+"],orderLenovoId["+mongoOrderDetail.getLenovoId()+"]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("当前登陆账号和订单的用户账号不相同");
            return returnResult;
        }

        //开始构建支付请求参数,,暂时仅用于moto支付
        StringBuffer commonParamBuffer = new StringBuffer();
        if (mongoOrderDetail.getBillingDeliveries() != null && mongoOrderDetail.getBillingDeliveries().size() > 0){
            Receiver receiver = mongoOrderDetail.getBillingDeliveries().get(0);
            commonParamBuffer.append("firstname^" + (StringUtil.isEmpty(receiver.getShipName())?"":receiver.getShipName()) + "|");
            commonParamBuffer.append("phone^" + (StringUtil.isEmpty(receiver.getShipMobile())?"":receiver.getShipMobile()) + "|");
            commonParamBuffer.append("email^" + (StringUtil.isEmpty(receiver.getShipEmail())?"":receiver.getShipEmail()));
        }
        String extra_common_param = commonParamBuffer.toString();

        //
//        try {
//            extra_common_param = URLEncoder.encode(commonParamBuffer.toString(), "UTF-8");
//        } catch (UnsupportedEncodingException e) {
//            logger.info("回传数据Encode异常");
//        }
        logger.info("AliPay Direct Pay Extra_Common_Param[" + extra_common_param + "]");
        //支付金额,单位（元）
        String totalFee = mongoOrderDetail.getAmountMoney().getAmount().toString();

        String receive_buyer = null;
        String receive_phone = null;
        String receive_address = null;
        String tax_type = null;
        String tax_info = null;
        String tax_receive_buyer = null;
        String tax_receive_phone = null;
        String tax_receive_address = null;
        String subject = "";
        String body = "";
        String payment_way = mongoOrderDetail.getPaymentWay();
        String order_type = mongoOrderDetail.getOrderAddType();
        if (mongoOrderDetail.getDeliveries() != null && mongoOrderDetail.getDeliveries().size()>0){
            //收货地址
            Receiver receiver = mongoOrderDetail.getDeliveries().get(0);
            receive_buyer = receiver.getShipName();
            receive_phone = new StringEncrypt().encrypt(receiver.getShipMobile());
            receive_address = receiver.getDeliverAreaName()+"_"+receiver.getShipCity()
                    +"_"+receiver.getDeliverCounty()+"_"+receiver.getShipAddr();
        }
        tax_type = mongoOrderDetail.getTaxType();
        tax_info = mongoOrderDetail.getTaxCompany();
        if (mongoOrderDetail.getVatDeliveries() != null &&mongoOrderDetail.getVatDeliveries().size()>0){
            //发票收货地址
            Receiver receiver = mongoOrderDetail.getDeliveries().get(0);
            tax_receive_buyer = receiver.getShipName();
            tax_receive_phone = new StringEncrypt().encrypt(receiver.getShipMobile());
            tax_receive_address = receiver.getDeliverAreaName()+"_"+receiver.getShipCity()
                    +"_"+receiver.getDeliverCounty()+"_"+receiver.getShipAddr();
        }
        if (mongoOrderDetail.getProducts() != null && mongoOrderDetail.getProducts().size()>0){
            for (Product product:mongoOrderDetail.getProducts())
            {
                if (StringUtils.isNotEmpty(product.getProductName()))
                    subject += "," + product.getProductName();
                if (StringUtils.isNotEmpty(product.getProductDesc()))
                    body += "," + product.getProductDesc();
            }
            if ( subject.length()>0){
                subject = subject.substring(1);
            }
            if (body.length()>0){
                body = body.substring(1);
            }
        }

        String overtime = "1d";

        String bodyHtml = buildToPayHtml(request,false,orderMainCode,fa_id,requestLenovoId,receive_buyer,receive_phone,receive_address
                ,tax_type,tax_info,tax_receive_buyer,tax_receive_phone,tax_receive_address,subject,body,payment_way,order_type,totalFee
                ,overtime,extra_common_param,accountType,bankCode,bankType, cardType,usedPoints,payType,shopId,terminal,tenant);

        logger.info(bodyHtml);
        returnResult.setT(bodyHtml);
        if (StringUtils.isEmpty(bodyHtml)) {
            returnResult.setSuccess(false);
            returnResult.setResultMsg("处理支付失败");
            logger.info("构建支付HTML失败");
        }

        return returnResult;
    }

    @Override
    public RemoteResult toCashierCreditPay(SessionUser user,HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);

        CashierPayModel model = (CashierPayModel) ModelUtil.getModel(request);
        String orderMainCode = model.getOrderMainCode();//信用账单号
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String shopId = model.getShopId();
        String terminal = model.getTerminal();
        String accountType = model.getAccount_type();
        String bankCode = model.getBank_code();
        String bankType = model.getBank_type();
        String cardType = model.getCard_type();
//        String usedPoints = model.getUsedPoints();
        String usedPoints = "0";//信用还款不能使用积分支付
        Tenant tenant = ThreadLocalSessionTenant.getTenant();

        if (PeakConstant.SHOPID_ALLINPAY.equals(shopId)){
            //只有惠商，判断当前的用户是否是当前经销商的主账号//// TODO: 2017/5/23
            if (!SSOUtil.isMainAccount(user.getUsername())){
//            if (false){
                logger.info("Illegal Request, user is not the main user=="+user.getUsername()+" orderMainCode["+orderMainCode+"]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("当前登录用户不是主账号");
                return returnResult;
            }
        }

        RemoteResult<PayTrackingApi> creditRemoteResult = creditService.getPayTracking(orderMainCode);
        if (creditRemoteResult == null || !creditRemoteResult.isSuccess()){
            logger.error("Direct Pay Get creditRemoteResult Fail,creditRemoteResult["+ creditRemoteResult +"], OrderMainCode[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("未查到信用账单信息，请重新发起支付");
            return returnResult;
        }
        PayTrackingApi payTracking = creditRemoteResult.getT();

        if (payTracking == null || payTracking.getOrderId() == null) {
            logger.error("Direct Pay Get payTracking Fail, OrderMainCode[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("未查到信用账单信息，请重新发起支付");
            return returnResult;
        }
        String fa_id = payTracking.getFaId();
        MongoOrderDetail mongoOrderDetail = null;
        try {
            //信用账单对应订单信息
            RemoteResult<MongoOrderDetail> mongoOrderDetailRemoteResult = OpenOrderService.getMongoOrderDetail(tenant,payTracking.getOrderId());
            logger.info("获取订单信息：remoteResult："+ JsonUtil.toJson(mongoOrderDetailRemoteResult));
            if (mongoOrderDetailRemoteResult == null || !mongoOrderDetailRemoteResult.isSuccess() || mongoOrderDetailRemoteResult.getT() == null) {
                logger.error("Direct Pay Get mongoOrderDetail Fail, mongoOrderDetailRemoteResult【"+ mongoOrderDetailRemoteResult +"】 OrderMainCode[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("查询订单信息出错，请重新发起支付");
                return returnResult;
            }
            mongoOrderDetail = mongoOrderDetailRemoteResult.getT();

            //主订单号必须已经支付，才能信用还款
            if (!PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
                logger.info("主订单还未支付，主订单号["+mongoOrderDetail.getOrderCode()+"],信用账单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("主订单还未支付，请到订单列表页确认。");
                return returnResult;
            }

            if (PeakConstant.CREDIT_ORDER_STATUS_ALREADY_PAID.equals(String.valueOf(payTracking.getPayStatus()))) {
                logger.info("账单单已支付，账单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("订单已支付，请到订单列表页确认。");
                return returnResult;
            }
        } catch (Exception e) {
            logger.error("支付异常" + e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("支付异常");
        }
        String requestLenovoId= SSOUserInfoUtil.getLenovoId(request);
        //// TODO: 2017/8/9 调试，，，，，，，，
        if (!payTracking.getBuyerId().toString().equals(requestLenovoId)){
//        if (false){
            logger.info("登陆账号和订单账号不相同，订单号[" + orderMainCode + "]，currentLenovoId["+requestLenovoId+"],orderLenovoId["+payTracking.getBuyerId()+"]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("当前登陆账号和信用账单的用户账号不相同");
            return returnResult;
        }

        StringBuffer commonParamBuffer = new StringBuffer();
        commonParamBuffer.append("faid=" + "" + ",");//
        commonParamBuffer.append("payType=" + payType + ",");
        commonParamBuffer.append("lenovoId=" + lenovoId);
        String extra_common_param = "";
        try {
            extra_common_param = URLEncoder.encode(commonParamBuffer.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.info("回传数据Encode异常");
        }
        logger.info("CreditPay Direct Pay Extra_Common_Param[" + extra_common_param + "]");
        //支付金额,单位（元）

        String totalFee = payTracking.getReturnAmount().toString();

        String receive_buyer = null;
        String receive_phone = null;
        String receive_address = null;
        String tax_type = null;
        String tax_info = null;
        String tax_receive_buyer = null;
        String tax_receive_phone = null;
        String tax_receive_address = null;
        String subject = "";
        String body = "";
        accountType = String.valueOf(payTracking.getAccountType());

        if (mongoOrderDetail.getProducts() != null && mongoOrderDetail.getProducts().size()>0){
            for (Product product:mongoOrderDetail.getProducts())
            {
                if (StringUtils.isNotEmpty(product.getProductName()))
                    subject += "," + product.getProductName();
                if (StringUtils.isNotEmpty(product.getProductDesc()))
                    body += "," + product.getProductDesc();
            }
            if ( subject.length()>0){
                subject = subject.substring(1);
            }
            if (body.length()>0){
                body = body.substring(1);
            }
        }
        String overtime = "1d";
        String order_type = "15";//约定信用账单传15
        String bodyHtml = buildToPayHtml(request,true,orderMainCode,fa_id,requestLenovoId,receive_buyer,receive_phone,receive_address,tax_type,tax_info,tax_receive_buyer,
                tax_receive_phone,tax_receive_address,subject,body,"0",order_type,totalFee,overtime,null,accountType,bankCode,bankType,cardType,usedPoints,
                payType,shopId,terminal,tenant);

        logger.info(bodyHtml);
        returnResult.setT(bodyHtml);
        if (StringUtils.isEmpty(bodyHtml)) {
            returnResult.setSuccess(false);
            returnResult.setResultMsg("处理支付失败");
            logger.info("构建支付HTML失败");
        }

        return returnResult;
    }

    @Override
    public String checkMongoOrder(String lenovoId, MongoOrderDetail mongoOrderDetail){
        String resultReason = null;

        if (StringUtils.isNotEmpty(lenovoId) && !lenovoId.equals(mongoOrderDetail.getLenovoId())) {
            logger.info("Illegal Request LenovoID NOT METCH。lenovoId["+lenovoId+"],orderLenovoId["+mongoOrderDetail.getLenovoId()+"]");
            resultReason = ErrorEnumUtil.getErrorMessage("ERROR_ILLEGAL_REQUEST").toString();
        }
        if (!PeakConstant.ORDER_AUDIT_STATUS_PASS.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))
                && !PeakConstant.ORDER_AUDIT_SIGNED_CONTRACT.equals(String.valueOf(mongoOrderDetail.getAuditStatus()))) {
            logger.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],OrderAuditStatus[" + mongoOrderDetail.getAuditStatus() + "]");
            resultReason = ErrorEnumUtil.getErrorMessage("ERROR_ORDER_STATUS_EXCEPTION").toString();
        }
        if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(mongoOrderDetail.getOrderStatus()))) {
            logger.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],OrderStatus[" + mongoOrderDetail.getOrderStatus() + "]");
            resultReason = ErrorEnumUtil.getErrorMessage("ERROR_ORDER_STATUS_EXCEPTION").toString();
        }
        if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(mongoOrderDetail.getPayStatus()))) {
            logger.info("Illegal Status,mongoOrderDetail[" + mongoOrderDetail + "],PayStatus[" + mongoOrderDetail.getPayStatus() + "]");
            resultReason = ErrorEnumUtil.getErrorMessage("ERROR_ORDER_STATUS_PAID").toString();
        }

        return resultReason;
    }

    @Override
    public String checkCreditOrder(String lenovoId, PayTrackingApi payTracking){
        String resultReason = null;
        if (StringUtils.isNotEmpty(lenovoId) && !lenovoId.equals(payTracking.getBuyerId().toString())) {
            logger.info("Illegal Request LenovoID NOT METCH,lenovoId["+lenovoId+"],buyerId["+payTracking.getBuyerId()+"]");
            resultReason = "非法请求！";
        }
        if (PeakConstant.CREDIT_ORDER_STATUS_ALREADY_PAID.equals(String.valueOf(payTracking.getPayStatus()))) {
            logger.info("Illegal Status,,payTracking[" + payTracking + "],Status[" + payTracking.getPayStatus() + "]");
            resultReason = "账单已支付！";
        }else if (!PeakConstant.CREDIT_ORDER_STATUS_NOT_PAID.equals(String.valueOf(payTracking.getPayStatus()))) {
            logger.info("Illegal Status,creditPartitionBills[" + payTracking + "],Status[" + payTracking.getPayStatus() + "]");
            resultReason = "账单状态异常，请重新发起！";
        }
        return resultReason;
    }


    /**
     *
     * 支付成功回调修改订单状态为已支付
     * @param tenant
     * @param orderCode
     * @param request
     * @param mongoOrderDetail
     * @return
     */
    @Override
    public RemoteResult<String> callUpdate(Tenant tenant, String orderCode, HttpServletRequest request, MongoOrderDetail mongoOrderDetail){
        RemoteResult<String> remonteResult = new RemoteResult<String>();
        if (checkStatus(mongoOrderDetail)){
            logger.info("订单已支付，流水号==>" + orderCode);
            remonteResult.setSuccess(true);
            remonteResult.setResultMsg("SUCCESS");
            return remonteResult;
        }else{
            PayAccount payAccount = buildPayAccount(request,tenant,mongoOrderDetail);
            logger.info("调用支付回调更该订单接口参数payAccount:"+payAccount.toString()+" tenant:"+tenant.toString()+" orderCode:"+orderCode+"" +
                    " lenovoId:"+mongoOrderDetail.getLenovoId()+" orderAddType:"+mongoOrderDetail.getOrderAddType());

            try {
                ///回调修改订单
                remonteResult = orderMiddlewareService.paidCallback(tenant,orderCode
                        ,mongoOrderDetail.getLenovoId(),payAccount,Integer.parseInt(mongoOrderDetail.getOrderAddType()));
                logger.info("调用支付回调更该订单接口成功，流水号==>" + orderCode +",remonteResult["+remonteResult+"]");
            } catch (Exception e) {
                logger.error("调用支付回调更该订单接口失败,e={}",e);
            }

            return remonteResult;
        }

    }

//    @Override
//    public RemoteResult<String> callUpdateCredit(Tenant tenant, String orderCode, HttpServletRequest request, CreditPartitionBillsApi creditPartitionBillsApi){
//        RemoteResult<String> remonteResult = new RemoteResult<String>();
//        if (checkCreditStatus(creditPartitionBillsApi)){
//            logger.info("账单已支付，流水号==>" + orderCode);
//            remonteResult.setSuccess(true);
//            remonteResult.setResultMsg("SUCCESS");
//            return remonteResult;
//        }else{
//            logger.info("信用账单还款成功，调用信用接口。orderCode["+orderCode+"]");
//            //信用账单支付成功
//            RemoteResult<Integer> creditRemoteResult = creditService.repay(orderCode);
//            if (creditRemoteResult != null && creditRemoteResult.isSuccess()){
//                logger.info("订单支付成功，调用信用账单接口成功--"+creditRemoteResult.getT());
//                remonteResult.setSuccess(true);
//            }else {
//                logger.error("订单支付成功，调用信用账单接口失败--creditRemoteResult["+creditRemoteResult+"]");
//            }
//
//            return remonteResult;
//        }
//
//    }

    public PayAccount buildPayAccount(HttpServletRequest request ,Tenant tenant, MongoOrderDetail mongoOrderDetail){
        PayAccount payAccount = new PayAccount();
        payAccount.setBankTraceNo(request.getParameter("transaction_no"));
        payAccount.setPayVoucherNo(request.getParameter("trade_no"));
        //payAccount.setPayTransactionNo(request.getParameter("trade_no"));
        payAccount.setPaidTime(request.getParameter("gmt_payment"));
        payAccount.setPayment(convertPayment(request.getParameter("payment")));
        //也传支付方式
        payAccount.setGatheringBank(getPayType(request.getParameter("payment")));
        payAccount.setPaymentType(mongoOrderDetail.getPaymentType());

        payAccount.setPayStatus("1");
        ////
        //payAccount.setTotalPay(new Money(mongoOrderDetail.getAmountMoney().getAmount(),tenant.getCurrencyCode()));
        payAccount.setTotalPay(new Money(request.getParameter("total_fee"),tenant.getCurrencyCode()));
        return payAccount;
    }

    /**
     * 校验订单状态，防止重复通知
     *
     * @param mongoOrderDetail mongoOrderDetail
     * @return boolean
     */
    private boolean checkStatus(MongoOrderDetail mongoOrderDetail) {
        boolean flag = false;
        if (null !=  mongoOrderDetail && null != mongoOrderDetail.getPayStatus() && !"0".equals(mongoOrderDetail.getPayStatus())) {
            flag = true;
        }
        return flag;
    }

    /**
     * 校验信用账单状态，防止重复通知
     *
     * @param creditPartitionBillsApi creditPartitionBillsApi
     * @return boolean
     */
    private boolean checkCreditStatus(CreditPartitionBillsApi creditPartitionBillsApi) {
        boolean flag = false;
        if (null !=  creditPartitionBillsApi && null != creditPartitionBillsApi.getStatus() && !"0".equals(creditPartitionBillsApi.getStatus().toString())) {
            flag = true;
        }
        return flag;
    }
    /**
     *构建支付请求
     *@param creditPay  是否是信用支付
     *@param orderMainCode
     *@param fa_id
     *@param lenovo_id
     *@param receive_buyer
     *@param receive_phone
     *@param receive_address
     *@param tax_type
     *@param tax_info
     *@param tax_receive_buyer
     *@param tax_receive_phone
     *@param tax_receive_address
     *@param subject
     *@param body
     *@param payment_way
     *@param order_type
     *@param totalFee
     *@param it_b_pay
     *@param extent_param
     *@param accountType
     *@param bankCode
     *@param cardType
     *@param payType
     *@param shopId
     *@param terminal
     *@return java.lang.String
     *@author wanghao,@Date 2017/3/14 17:11
     */
    public String buildToPayHtml(HttpServletRequest request, boolean creditPay,String orderMainCode, String fa_id, String lenovo_id, String receive_buyer, String receive_phone,
                                 String receive_address, String tax_type, String tax_info, String tax_receive_buyer,
                                 String tax_receive_phone, String tax_receive_address,String subject, String body,
                                 String payment_way, String order_type, String totalFee, String it_b_pay, String extent_param,
                                 String accountType, String bankCode, String bankType, String cardType, String usedPoints, String payType, String shopId, String terminal,Tenant tenant){
        String bodyHtml = "";

        try {//请求参数
            Map<String, String> requestParamMap = new HashMap<String, String>();
            //业务参数
            Map<String, String> businessParamMap = new HashMap<String, String>();
            //构建业务参数
            businessParamMap.put("out_trade_no", orderMainCode);
            businessParamMap.put("fa_id", fa_id);
            businessParamMap.put("lenovo_id", lenovo_id);
            businessParamMap.put("receive_buyer", receive_buyer);
            businessParamMap.put("receive_phone", receive_phone);
            businessParamMap.put("receive_address", receive_address);
            businessParamMap.put("tax_type", tax_type);
            businessParamMap.put("tax_info", tax_info);
            businessParamMap.put("tax_receive_buyer", tax_receive_buyer);
            businessParamMap.put("tax_receive_phone", tax_receive_phone);
            businessParamMap.put("tax_receive_address", tax_receive_address);
            //subject不能超过80个字符
            if (StringUtil.isNotEmpty(subject) && subject.length()>80){
                subject = subject.substring(0,75) +"...";
            }
            businessParamMap.put("subject", subject);
            businessParamMap.put("body", body);
            businessParamMap.put("payment_way", payment_way);
            businessParamMap.put("order_type", order_type);
            //返还乐豆
            //businessParamMap.put("reward_ledou",mongoOrderDetail.getRewardLedou());
            businessParamMap.put("reward_ledou", null);
            businessParamMap.put("total_fee", totalFee);
            //超时时间
            businessParamMap.put("it_b_pay", getOrderInvalidTime(shopId,order_type,PropertiesHelper.loadToMap("cashier_pay.properties")));
            businessParamMap.put("extend_param", extent_param);
            businessParamMap.put("account_type", accountType);
            businessParamMap.put("bank_code", bankCode);
            businessParamMap.put("bank_type", bankType);
            businessParamMap.put("card_type", cardType);
            businessParamMap.put("reward_point", usedPoints);//使用积分或（印度moto使用虚拟账户余额）
            String trade_info = PaySignUtils.buildCashierPayBusinessParams(businessParamMap);
            try {
                trade_info = URLEncoder.encode(trade_info, "UTF-8");
            } catch (Exception e) {
                logger.info("URLEncode TradeInfo Exception", e);
            }
            //构建请求参数
            requestParamMap.put("service", "lenovo_direct_pay");
            //异步回调地址
            String notifyUrl = null;
            //同步回调地址
            String returnUrl = "";
            //异常通知地址
            String exceptionUrl = "";
            String domain = RequestUtil.getDomain(request);
            domain = domain.replace("http:","https:");//加https
//            if (PeakConstant.SHOPID_IN.equals(shopId)){
//                //印度摩托回调地址，如：https://motob2r.lenovouat.com/buy/in/
//                domain += "buy/in/";
//            }

            if (creditPay){
//                notifyUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_CREDIT_PAY_NOTIFY_URL");
                returnUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_CREDIT_PAY_RETURN_URL");
                exceptionUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_CREDIT_PAY_EXCEPTION_URL");
            }else {
//                notifyUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_PAY_NOTIFY_URL");
                returnUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_PAY_RETURN_URL");
                exceptionUrl = domain + PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_PAY_EXCEPTION_URL");
            }

//            requestParamMap.put("notify_url", notifyUrl);
            requestParamMap.put("return_url", returnUrl);
            requestParamMap.put("exception_url", exceptionUrl);
            requestParamMap.put("payment", payType);
            requestParamMap.put("qr_pay_mode", "");
            requestParamMap.put("shop_id", shopId);
            requestParamMap.put("currency_code", tenant.getCurrencyCode());
            requestParamMap.put("terminal", terminal);
            requestParamMap.put("input_charset", AlipayConfig.input_charset.toUpperCase());
            requestParamMap.put("trade_info", trade_info);

            String sign = PaySignUtils.buildSignKey(requestParamMap, "MD5", (String) PropertiesHelper.loadToMap("cashier_pay.properties").get(shopId));
            //签名
            requestParamMap.put("sign", sign);
            //签名类型
            requestParamMap.put("sign_type", "MD5");
            String cashierUrl = (String) PropertiesHelper.loadToMap("cashier_pay.properties").get("CASHIER_PAY_TOPAY_"+tenant.getCurrencyCode());


            bodyHtml = PaySignUtils.buildRequest(requestParamMap, cashierUrl, "post");

            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付订单请求</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
        }catch (Exception e){
            logger.error("构建支付请求失败",e);
        }
        return bodyHtml;
    }

    public String getPayType(String payment){
        String payType = "其他";

        if ("12".equals(payment)){
            payType = "通联支付";
        }else if ("13".equals(payment)){
            payType = "平安支付";
        }else if ("16".equals(payment)){
            payType = "联动优势支付";
        }else if ("17".equals(payment)){
            payType = "联动优势快捷支付";
        }else if ("18".equals(payment)){
            payType = "通联H5快捷支付";
        }else if ("42".equals(payment)){
            payType = "信用支付";
        }

        return payType;
    }

    public String convertPayment(String payment){
        String orderPayment = "31";
        if ("12".equals(payment)){
            orderPayment = "31";
        } else if ("13".equals(payment)){
            orderPayment = "32";
        } else if ("16".equals(payment)){
            orderPayment = "33";
        } else if ("17".equals(payment)){
            orderPayment = "34";
        } else if ("18".equals(payment)){
            orderPayment = "35";
        } else if ("42".equals(payment)){
            orderPayment = "42";
        }
        return orderPayment;
    }

    private String getOrderInvalidTime(String shopId, String orderAddType, Map<String, Object> commonParam) {
        String invalidTime = "1d";
        try {
            if (commonParam != null) {
                String queryStr = "ORDER_INVALID_TIME_" + shopId + "_" + orderAddType;
                String invalidTimeStr = (String) commonParam.get(queryStr);
                logger.info("Invoke buildOrderInvalidTime Query[" + queryStr + "],invalidTime[" + invalidTimeStr + "]");
                if (StringUtils.isNotEmpty(invalidTimeStr) && !("null".equals(invalidTimeStr))) {
                    int invalidTimeInt = Integer.parseInt(invalidTimeStr);
                    if (invalidTimeInt > 1440) {
                        invalidTimeInt = invalidTimeInt / 1440;
                        invalidTime = invalidTimeInt + "d";
                    } else if (invalidTimeInt <= 60) {
                        invalidTime = (invalidTimeInt / 60.0) + "h";
                    } else {
                        invalidTimeInt = invalidTimeInt / 60;
                        invalidTime = invalidTimeInt + "h";
                    }
                }
            }
        } catch (Exception e) {
            logger.error("获取超时时间出错，e["+e+"]");
        }
        return invalidTime;
    }

}
