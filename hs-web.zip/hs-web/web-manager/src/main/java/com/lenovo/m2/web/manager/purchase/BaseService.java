package com.lenovo.m2.web.manager.purchase;

import java.util.List;
import java.util.Map;


/**
 *
 * @author kangjie
 *
 */
public class BaseService extends BaseCommonUtil {
	/**
	 * 截取赠品的编码
	 * @param list
	 * @return
	 *  -- 因为 传入的 list 实际上元素类型是 map，所以强转为map 再 进行操作， put 值
	 */
	protected List<Map<String, String>> cutGiftCode(List<Map<String, String>> list){
		if(list != null){
			for (int i = 0; i < list.size(); i++) {
				Map<String, String> map = (Map<String, String>)list.get(i);
				String str = map.get("giftcode");
				if(str!=null && str.indexOf(";") != -1){
					String[] arr = str.split(";");
					if(arr.length >1){
						map.put("giftcode",arr[1]);
					}
				}
			}
		}
		return list;
	}

}
