package com.lenovo.m2.web.manager.purchase.order.task;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Created by D_xiao on 16/11/14.
 */
@Component("taskService")
public class TaskService implements ApplicationContextAware {

    private ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }

    public CookieTask getInstance(){
        CookieTask oneTask = (CookieTask) context.getBean("cookieTask");
        return oneTask;
    }


}
