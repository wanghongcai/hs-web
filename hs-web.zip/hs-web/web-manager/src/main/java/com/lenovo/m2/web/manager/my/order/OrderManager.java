package com.lenovo.m2.web.manager.my.order;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.ordercenter.PayRecordsDetailResult;
import com.lenovo.m2.web.domain.my.order.*;
import com.lenovo.m2.web.domain.my.order.smb.SmbDetail;
import com.lenovo.m2.web.domain.my.order.smb.SmbOrderDetail;

import java.util.List;
import java.util.Map;

/**
 * Created by mayan3 on 2015/10/8.
 */

public interface OrderManager {

    RemoteResult<PageModel2<OrderDetailListJSONOrderList>> queryOrder(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType);

    RemoteResult<PageModel2<OrderInfoVo>> queryOrderForCustomerService(String merchantId, String lenovoId, PageQuery pageQuery, String orddate, String searchtext, String orderstatus, String orderType);

    RemoteResult<OrderDetailDesc> getOrderDetailDescByOrdercode(String orderCode, String merchantId);

    String getVoiceUrl(String ordernm);

    String getInVoiceUrlFromDB(String ordernm);

    RemoteResult<PageModel2<UserProduct>> queryPayedUserProducts(String merchantId, String lenovoId, PageQuery pageQuery, String orddate);

    RemoteResult<MongoOrderDetail> getOrderByOrdercode(String merchantId, String orderCode);

    RemoteResult cancelOrder(String orderId, Tenant tenant);

    RemoteResult cancelOrder(String orderId, String orderCode);


    RemoteResult<Boolean> deleteOrder(String ordercode, String lenovoId, String merchantId);

    List<OrderDetailListJSONOrderList> getOrderDetailByOrderMainCode(String orderno, String shopId);

    SmbDetail getSmbDetail(String orderno, String shopId, SmbOrderDetail smbOrderDetail);

    RemoteResult<List<MongoOrderDetail>> getMongoOrderDetailsByOrdercode(String merchantId, String orderNo);

    RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayListParam);

    RemoteResult<PayRecordsDetailResult> payRecordsDetail(String p, Tenant t);


    /******new********/

    RemoteResult confirmReceive(String ordno, String lenovoId, Tenant tenant);


    RemoteResult<Map<String,Object>> getOrderTrackInfo(String orderNo, Tenant tenant);
}
