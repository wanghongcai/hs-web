//package com.lenovo.m2.web.manager.purchase.complain.impl;
//
//import com.lenovo.m2.buy.purchase.common.util.MongoBeanUtil;
//import com.lenovo.m2.web.dao.my.dao.simple.common.impl.BaseMongoDaoImpl;
//import com.lenovo.m2.web.domain.purchase.complain.Complain;
//import com.lenovo.m2.web.manager.purchase.complain.ComplainMongoService;
//import com.mongodb.*;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
///**
// * <br> 投诉进行mongoDB的数据操作
// * @author shenjc
// *
// */
//@Service
//public class ComplainMongoServiceImp extends BaseMongoDaoImpl<Complain> implements ComplainMongoService {
//
//	/**
//	 * <br> 保存投诉建议
//	 * @param complain
//	 */
//	public int saveComplain(Complain complain) {
//		DBObject obj = BasicDBObjectBuilder.start()
//				.add("plat", complain.getPlat())
//				.add("content", complain.getAcontent())
//				.add("atele", complain.getAtele())
//				.add("atype", complain.getAtype()).get();
//		WriteResult result = super.getMCollection().save(obj);
//		return result.getLastError().ok()?1:0;
//	}
//
//	/**
//	 * <br> 查询投诉建议
//	 * @return
//	 */
//	public List<Complain> getComplain(Map<String, String> params) {
//		if (params == null) {
//			return null;
//		}
//		List<Complain> list = new ArrayList<Complain>();
//		DBObject query = new BasicDBObject(params);
//		DBCursor cursor = super.getMCollection().find(query);
//		while(cursor.hasNext()) {
//			DBObject tmp = cursor.next();
//			Complain comp = MongoBeanUtil.<Complain>dbObject2Bean(tmp, new Complain());
//			list.add(comp);
//		}
//		return list;
//	}
//}
