package com.lenovo.m2.web.manager.purchase.order.impl;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.common.common.Pair;
import com.lenovo.m2.hsbuy.common.enums.ShopIdEnum;
import com.lenovo.m2.hsbuy.common.pay.common.soa.Constant;
import com.lenovo.m2.hsbuy.domain.member.SessionUser;
import com.lenovo.m2.hsbuy.domain.member.User;
import com.lenovo.m2.hsbuy.domain.purchase.coupon.CouponResultVo;
import com.lenovo.m2.hsbuy.domain.purchase.param.CheckOutParam;
import com.lenovo.m2.hsbuy.domain.purchase.param.CpsUse;
import com.lenovo.m2.hsbuy.domain.purchase.param.SubmitOrderParam;
import com.lenovo.m2.hsbuy.domain.purchase.result.CheckOutResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.SubmitOrderResult;
import com.lenovo.m2.web.common.my.utils.HttpClientUtil;
import com.lenovo.m2.web.common.my.utils.StringUtil;
import com.lenovo.m2.web.common.purchase.enums.ErrorMessageEnum;
import com.lenovo.m2.web.common.purchase.enums.PayTypeEnum;
import com.lenovo.m2.web.common.purchase.enums.PromptEnum;
import com.lenovo.m2.web.common.purchase.util.*;
import com.lenovo.m2.web.domain.my.MobileMsg;
import com.lenovo.m2.web.domain.purchase.order.CheckOutOrderVo;
import com.lenovo.m2.web.domain.purchase.order.TempInvoice;
import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;
import com.lenovo.m2.web.domain.purchase.order.backfill.UpdateItemTypeEnum;
import com.lenovo.m2.web.manager.purchase.order.BackFillService;
import com.lenovo.m2.web.manager.purchase.order.SubmitOrderService;
import com.lenovo.m2.web.manager.purchase.order.task.CookieTask;
import com.lenovo.m2.web.manager.purchase.order.task.TaskService;
import com.lenovo.m2.web.redis.MyRedisConn;
import com.lenovo.m2.web.remote.captcha.SmsCerpService;
import com.lenovo.m2.web.remote.purchase.order.RemoteOrderService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 
 * @ClassName: SubmitOrderServiceImpl
 * @Description: 提交订单实现
 * @author yuzj7@lenovo.com
 * @date 2016年3月10日 上午11:23:10
 *
 */
@Service
public class SubmitOrderServiceImpl implements SubmitOrderService {
	private static Logger log =  LogManager.getLogger(SubmitOrderServiceImpl.class.getName());

	@Autowired
	private BackFillService backFillService;
	@Autowired
	private RemoteOrderService remoteOrderService;
	@Autowired
	private TaskService taskService;
	@Autowired
	protected MyRedisConn myRedisConn;
	@Autowired
	private SmsCerpService smsCerpService;

	private static ExecutorService pool = Executors.newCachedThreadPool();

	private String payUrl = CustomizedPropertyConfigurer.getContextProperty("cart.pay.url");
	private String smbPayUrl = CustomizedPropertyConfigurer.getContextProperty("smb.pay.url");
	private String customerUrl = CustomizedPropertyConfigurer.getContextProperty("customer.url");
	private String customerUrl_wap = CustomizedPropertyConfigurer.getContextProperty("customer.url.wap");
	private static String buyerUrl = CustomizedPropertyConfigurer.getContextProperty("buyer.url");

	/**
	 * 惠商查询user信息
	 * @param sessionUser
	 * @param tenant
     * @return
     */
	private static User getUser(SessionUser sessionUser, Tenant tenant){
		log.info("submitorder getUser.....");
		User u = User.SessionUser2User(sessionUser);
		try {
			if(tenant.getShopId() == ShopIdEnum.HUI_SANG.getType()|| tenant.getShopId() == ShopIdEnum.HUI_SANG_SCORE.getType()){
				com.alibaba.fastjson.JSONObject object = getBuyerAndFA(u.getUserId());
				if(object!= null){
					u.setBuyerCode(object.getString("jxsname") == null? "" : object.getString("jxsname"));//经销商名称
				}else{
					u.setBuyerCode("");
				}
				u.setMemberId(u.getGroupCode());
			}
		}catch (Exception e){
			log.error("获取分销商/经销商信息失败!",e);
			u.setMemberId("");
			u.setBuyerCode("");
			u.setUsername("");
		}
		log.info("buyerId:{},user msg:{}",u.getUserId(), JsonUtil.toJson(u));
		return u;
	}

	public static com.alibaba.fastjson.JSONObject getBuyerAndFA(String buyerId){
		String address = buyerUrl + buyerId;//1000000518
		com.alibaba.fastjson.JSONObject jsonObject = new com.alibaba.fastjson.JSONObject();
		try {
			String jsonResult = HttpClientUtil.getStr(address);
			log.info("分销商/经销商信息:"+jsonResult);
			com.alibaba.fastjson.JSONObject object = com.alibaba.fastjson.JSON.parseObject(jsonResult);
			if(object != null && object.getJSONObject("page")!=null && object.getInteger("success") == 1){
				com.alibaba.fastjson.JSONArray jsonArray = object.getJSONObject("page").getJSONArray("data");
				if(jsonArray!=null && jsonArray.size()>0){
					jsonObject =jsonArray.getJSONObject(0);
				}
			}
			return jsonObject;
		}catch (Exception e){
			log.error("获取分销商/经销商信息失败!",e);
			return null;
		}

	}
	/**
	 * 
	* @Title: getPayurlByShopId
	* @Description: 获取支付地址
	* @param shopId
	* @param terminal
	* @return    设定文件
	* @throws
	 */
	private String getPayurlByShopId(int shopId,int terminal){
		if(ShopIdEnum.isSmb(shopId)){
			return smbPayUrl;
		}
		return payUrl;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.lenovo.m2.buy.purchase.manager.order.SubmitOrderService#submitOrder
	 * (com.lenovo.m2.buy.purchase.domain.api.order.SubmitOrderEntity,
	 * javax.servlet.http.HttpServletRequest,
	 * com.lenovo.m2.buy.purchase.domain.member.SessionUser)
	 */
	@Override
	public String submitOrder(Boolean selectNormal,String preSaleMobile,String creditInfo, Tenant tenant, Integer terminal, String lid, String orderremark, String cmanagercode, HttpServletRequest request, SessionUser sessionUseruser, String captcha) {

		SubmitOrderParam entity = new SubmitOrderParam();
		User u = User.SessionUser2User(sessionUseruser);
		//User user = getUser(sessionUseruser,tenant);
		String type = "0";
		String beemobile = "";
		try {
			if(tenant.getShopId() == ShopIdEnum.HUI_SANG.getType()|| tenant.getShopId() == ShopIdEnum.HUI_SANG_SCORE.getType()){
				com.alibaba.fastjson.JSONObject object = getBuyerAndFA(u.getUserId());
				if(object!= null){
					u.setBuyerCode(object.getString("jxsname") == null? "" : object.getString("jxsname"));//经销商名称
					if(object.getString("beemobile")!=null && !"".equals(object.getString("beemobile"))){
						type = "3";
						beemobile = object.getString("beemobile");
					}
				}else{
					u.setBuyerCode("");
				}
				u.setMemberId(u.getGroupCode());
				return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_RETURN_CLOSE")));
			}
		}catch (Exception e){
			log.error("获取分销商/经销商信息失败!",e);
			u.setMemberId("");
			u.setBuyerCode("");
			u.setUsername("");
		}
		if(tenant.getShopId() == ShopIdEnum.HUI_SANG.getType() && "".equals(u.getBuyerCode())){
			return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_BUYCODE")));
		}
		entity.setUser(u);
		entity.setIp(IpUtil.getIp(request));
		entity.setTerminal(terminal);
		entity.setV("1.0");
		entity.setFormat("json");
		entity.setSource("1");
		// 从内存中获取请求参数
		BackFillOrderVo vo = backFillService.getCheckOutCache(sessionUseruser.getLenovoid(), entity.getTerminal(), tenant.getShopId(),lid);
		log.info("缓存 : :::::::::::: ={}", JsonUtil.toJson(vo));
		if(null == vo){
			return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_ILLEGAL")));
		}

		//pc端使用优惠券是校验手机,目前只针对惠商商城
	/*	if(tenant.getShopId() == ShopIdEnum.HUI_SANG.getType()|| tenant.getShopId() == ShopIdEnum.HUI_SANG_SCORE.getType()){
			if (terminal == 1 && !StringUtil.isEmpty(vo.getCouponids())) {
				if (StringUtil.isEmpty(captcha)) {
					return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_CAPTCHA")));
				}
				MobileMsg mobile = new MobileMsg();
				mobile.setMobile(sessionUseruser.getUsername());
				mobile.setCaptcha(captcha);
				mobile.setShopId("14");
				boolean flag = smsCerpService.verifySmsCaptcha(mobile);
				if (!flag) {
					return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_CAPTCHA")));
				}
			}
		}*/
		
		entity.setPaytype(vo.getPaytype());
		entity.setInnerBuyMoney(Integer.parseInt(StringUtil.isEmpty(vo.getInnerBuyMoney()) ?"0":vo.getInnerBuyMoney()));
		entity.setCouponCode(vo.getCouponcode());
		entity.setCouponids(vo.getCouponids());
		entity.setHappyBeanNum(null == vo.getHappyBeanNum()? 0 : vo.getHappyBeanNum());
		//entity.setSharecode(vo.getSharecode());
		entity.setConsigneeId(vo.getConsigneeId());
		entity.setBuyType(null == vo.getBuyType() ? 0 : vo.getBuyType());
		entity.setCheckoutType(vo.getCheckOutType());
		entity.setHoneybeeMobile(beemobile);
		creditInfo = vo.getCreditInfo();
		//entity.setCreditInfo(creditInfo);//facode|100@facode|200
		if(ShopIdEnum.isHuiShang(tenant.getShopId()) && creditInfo != null && creditInfo.length()>0){
			List<Pair<String, Money>> buyerCredits = new ArrayList<>();
			String[] faList = creditInfo.split("@");
			if(faList.length>0){
				for(String faSingle : faList){
					String[] fa = faSingle.split("\\|");
					Pair<String ,Money > pair = new Pair<>(fa[0], new Money(fa[1],tenant.getCurrencyCode()));
					buyerCredits.add(pair);
				}
			}
			entity.setBuyerCredits(buyerCredits);
		}
		//懂得通信没有发票
		if(!"dongde".equals(vo.getCheckOutType()) && !"dongdenonumber".equals(vo.getCheckOutType()) && !ShopIdEnum.isSmb_Score(tenant.getShopId())){
//			if(ShopIdEnum.isHuiShang(tenant.getShopId())){
//				entity.setInvoiceheadType(1);
//				entity.setInvoiceId(vo.getInvoice());
//				entity.setInvoiceType(2);
//				entity.setInvoiceheadcontent("公司");
//			}else{
				if(StringUtil.isEmpty(vo.getInvoice())){
					return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"INVOICE_ERROR")));
				}
				TempInvoice invoice = JsonUtil.fromJson(vo.getInvoice(), TempInvoice.class);
				if((null == invoice ||  null == invoice.getInvoiceTypeId() || null == invoice.getInvoiceHeader()) && !ShopIdEnum.isSmb(tenant.getShopId())){
					return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"INVOICE_ERROR")));
				}
				if(ShopIdEnum.isSmb(tenant.getShopId())){
					//entity.setInvoiceheadType(Integer.parseInt(invoice.getPayerType()));
					entity.setPayNameType(invoice.getPayerType());
					entity.setInvoiceheadType(Integer.parseInt(invoice.getInvoiceHeader()));
					entity.setInvoiceId(invoice.getVatInvoiceId());
					entity.setPayName(invoice.getPayerContent());
					entity.setIsConfirmPersonVat((null == invoice.isPayerSure() || !invoice.isPayerSure() ? 0 : 1));
					//entity.setInvoiceType();
					entity.setInvoiceType(invoice.getInvoiceTypeId());
					if(selectNormal !=null && selectNormal){
						entity.setInvoiceType(1);//增票为普票使用
					}
				}else{
					entity.setInvoiceType(invoice.getInvoiceTypeId());
					entity.setInvoiceheadType(Integer.parseInt(invoice.getInvoiceHeader()));
					entity.setInvoiceheadcontent(invoice.getInvoiceContent());
					entity.setInvoiceId(invoice.getVatInvoiceId());
				}
//			}
		}
		entity.setIsHtsameToSh(StringUtil.isEmpty(vo.getContractIsConsigneeId())?0:Integer.parseInt(vo.getContractIsConsigneeId()));
		entity.setIsSpsameToSh(StringUtil.isEmpty(vo.getInvoiceIsConsigneeId())?0:Integer.parseInt(vo.getInvoiceIsConsigneeId()));
		entity.setIsSendHt(StringUtil.isEmpty(vo.getIsSendContract())?0:Integer.parseInt(vo.getIsSendContract()));
		entity.setCmanagercode(cmanagercode);
		entity.setOrderremark(orderremark);
		entity.setIdDentity(vo.getIdentityId());
		entity.setSpConsigneeId(vo.getInvoiceAddressId());
		entity.setHtConsigneeId(vo.getContractAddressId());
		entity.setPreSaleMobile(preSaleMobile);
		//entity.setPaytype("0");

		String priceListFlag = request.getParameter("priceListFlag");
		log.info("订单来源为报价单submitOrder："+priceListFlag);
		if(null!=priceListFlag && "1".equals(priceListFlag)){
			if(null!=entity.getCouponids() && !"".equals(entity.getCouponids())){
				log.info("订单来源为报价单,则不允许使用优惠券："+priceListFlag);
				return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_ORDER_FAIL")));
			}
		}

		//检查是否有CPS的cookie
		Cookie[] cookies = request.getCookies();
		String aid,channel,cid,wi,target;
		String inform = "";
		for (Cookie cookie : cookies) {
			if("inform".equals(cookie.getName())){
				inform = URLDecoder.decode(cookie.getValue().toString());
				break;
			}
		}
		log.info("submitorder inform:{}",inform);
		//对cookie信息进行解析并存入map
		Map<String,String> stringMap = new HashMap<>();
		if(!"".equals(inform)){
			String[] stringArray = inform.split("&");
			List<String> stringList = Arrays.asList(stringArray);
			for(String str : stringList){
				if(str.contains("wi=")){
					stringMap.put("wi",str.substring(3));
				}else{
					String[] strArray = str.split("=");
					stringMap.put(strArray[0],strArray[strArray.length-1]);
				}
			}
		}
		aid = stringMap.get("aid");
		channel = stringMap.get("channel");
		cid = stringMap.get("cid");
		wi = stringMap.get("wi");
		target = stringMap.get("target");
		//封装CPS信息
		CpsUse cu = new CpsUse();
		cu.setSource(aid);
		cu.setChannel(channel);
		cu.setCid(cid);
		cu.setWi(wi);
		cu.setTarget(target);
		entity.setCpsUse(cu);

		log.info("submitorder entity:{}",JsonUtil.toJson(entity));
		RemoteResult<SubmitOrderResult> json= remoteOrderService.submitOrder(tenant,entity);
		log.info("submitorder result={}", JsonUtil.toJson(json));

		//存在CPS的cookie信息
		if(null != cid && !"".equals(cid) && null != wi && !"".equals(wi)){
			if(null!=json){
				if(json.isSuccess()){
					remoteOrderService.sendOrderInfoToCPS(tenant,json.getT().getOrdernumber());
				}
			}
		}

		// 从新封装结果信息，返回支付地址      
		if (null != json) {
			try {
				if("103".equals(json.getResultCode()) || "102".equals(json.getResultCode()) || "101".equals(json.getResultCode())){
					//发票未认证返回错误信息（新增）
					return JsonUtil.toJson(new FpsResult(json));
				}

				FpsResult<SubmitOrderResult> apiResult = new FpsResult(json, PromptEnum.CHECKOUT);
				if (apiResult.getRc() != ErrorMessageEnum.SUCCESS.getCode()) {
					return JsonUtil.toJson(new FpsResult(json,PromptEnum.CHECKOUT));
				}
				String ordernumber = apiResult.getData() != null ? apiResult.getData().getOrdernumber().toString() : "";
				if (apiResult.getData() != null && !"".equals(ordernumber)) {
					String key = "checkC2COrder" + lid;

					if (myRedisConn.existsKey(key) || !"3".equals(type)) {
						type = myRedisConn.get(key);
					}
					CookieTask cookieTask = taskService.getInstance();
					cookieTask.setOrderNum(ordernumber);
					cookieTask.setRequest(request);
					cookieTask.setCTwoMember(u.getUserId());
					cookieTask.setC2cType(type);
					cookieTask.setTenat(tenant);
					pool.execute(cookieTask);
				}
				//惠商商城调到中间成功页面
				if (ShopIdEnum.isHuiShang(tenant.getShopId())) {
					FpsResult<String> temp = new FpsResult<String>(ErrorMessageEnum.SUCCESS);
					temp.setData("toHsSuccess.jhtm?orderMainCode=" + ordernumber + "&shopId=" + tenant.getShopId() + "&terminal=" + entity.getTerminal());
					return JsonUtil.toJson(temp);
				}
				// 若为o2o商品并且为货到付款 跳转到个人中心
				if (PayTypeEnum.PAY_ONEHANDMONEY.getCode().equals(entity.getPaytype())) {
					//think pc
					log.info("entity.getTerminal():{},eques:{}", entity.getTerminal(), tenant.getShopId() == 1);
					if (entity.getTerminal() == 1) {
						FpsResult<String> temp = new FpsResult<String>(ErrorMessageEnum.SUCCESS);
						temp.setData("toO2Opsuccess.jhtm?orderMainCode=" + ordernumber + "&shopId=" + tenant.getShopId() + "&terminal=" + entity.getTerminal());
						return JsonUtil.toJson(temp);
					} else {
						FpsResult<String> temp = new FpsResult<String>(ErrorMessageEnum.SUCCESS);
						temp.setData("toO2Owsuccess.jhtm?orderMainCode=" + ordernumber + "&shopId=" + tenant.getShopId() + "&terminal=" + entity.getTerminal());
						return JsonUtil.toJson(temp);
					}
				}
				//积分商城调到中间成功页面
				if (ShopIdEnum.isSmb_Score(tenant.getShopId())) {
					FpsResult<String> temp = new FpsResult<String>(ErrorMessageEnum.SUCCESS);
					temp.setData("toScoreSuccess.jhtm?orderMainCode=" + ordernumber + "&shopId=" + tenant.getShopId() + "&terminal=" + entity.getTerminal());
					return JsonUtil.toJson(temp);
				}
				FpsResult<String> temp = new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"SUCCESS"));
				temp.setData(getPayurlByShopId(tenant.getShopId(), terminal) + "?orderMainCode=" + ordernumber + "&shopId=" + tenant.getShopId() + "&terminal=" + entity.getTerminal());
				backFillService.clearCheckOutCache(u.getUserId(), terminal, tenant.getShopId(), lid);
				return JsonUtil.toJson(temp);
			}catch (java.lang.Exception e){
				log.error("submit order error:",e);
				return null;
			}

		}
		try{
			return JsonUtil.toJson(new FpsResult(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_ORDER_FAIL")));
		}catch(java.lang.Exception e){
			log.error("submitorder error",e);
			return null;
		}

	}

	@Override
	public String checkOut(Integer terminal, Tenant tenant, String lid, HttpServletRequest request, SessionUser sessionUser) {
		CheckOutParam entity = new CheckOutParam ();
	    //User user = User.SessionUser2User(sessionUser);
		User user = getUser(sessionUser,tenant);
		entity.setIp(IpUtil.getIp(request));
		entity.setUser(user);
		BackFillOrderVo bkVo =  backFillService.getCheckOutCache(user.getUserId(), terminal, tenant.getShopId(), lid);
		if (bkVo != null) {
			entity.setHappyBeanNum(bkVo.getHappyBeanNum()==null?0:bkVo.getHappyBeanNum());
			entity.setCouponids(bkVo.getCouponids());
			entity.setCouponCode(bkVo.getCouponcode());
			entity.setInnerBuyMoney(bkVo.getInnerBuyMoney() == null ? 0 : Integer.parseInt(StringUtil.isEmpty(bkVo.getInnerBuyMoney())? "0":bkVo.getInnerBuyMoney()));
			entity.setConsigneeId(bkVo.getConsigneeId()); 
			entity.setBuyType(null == bkVo.getBuyType() ? 0 : bkVo.getBuyType());
			entity.setCreditInfo(null == bkVo.getCreditInfo() ? "":bkVo.getCreditInfo());
		}else{
			//根据结算缓存找不到则返回错误
			FpsResult<CheckOutOrderVo> result = new FpsResult<>();
			result.setErrorInfo(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_BACKFILL_GET_FALL"));
			return JsonUtil.toJson(result);
		}
		entity.setTerminal(terminal);
		RemoteResult<CheckOutResult>  json= remoteOrderService.checkout(tenant,entity);
		log.info("checkout return :"+ JsonUtil.toJson(json));
		FpsResult<CheckOutResult> apiResult = new FpsResult(json,PromptEnum.CHECKOUT);
		if(ErrorMessageEnum.SUCCESS.getCode()==apiResult.getRc()){
			//把懂得通信checkoutType 初始化入缓存
			backFillService.updateCheckOutCache(user.getUserId(), terminal, tenant.getShopId(), lid, apiResult.getData().getCheckoutType(), UpdateItemTypeEnum.CHECKOUTTYPE);
			CheckOutOrderVo checkOutOrderVo = new CheckOutOrderVo(apiResult.getData(),bkVo);
			List<CouponResultVo> coupons = checkOutOrderVo.getCheckOutOrder().getCouponList();
			if(null!=coupons && coupons.size()>0){
				String key = "checkC2COrder"+lid;
				for(CouponResultVo coupon : coupons){
					if(null!=coupon.getUsescope() && coupon.getUsescope() == 4 ){
						myRedisConn.set(key,"1");
					}
				}
			}
			FpsResult<CheckOutOrderVo> temp = new FpsResult<CheckOutOrderVo>();
			temp.setData(checkOutOrderVo);
			if(ShopIdEnum.isSmb_Score(tenant.getShopId())){
				try {
					return JsonUtil.MoneyScore.OMM.writeValueAsString(temp);
				} catch (java.io.IOException e) {
					log.error("occur error :",e);
				}
			}
			return JsonUtil.toJson(temp);
		}else {
			return  JsonUtil.toJson(new FpsResult(json,PromptEnum.CHECKOUT));
		}

	}

	@Override
	public String UseVirtualCurrency(Integer terminal, Tenant tenant, String lid, Integer virTualType, String value, SessionUser sessionUser,HttpServletRequest request) {
		CheckOutParam entity = new CheckOutParam();
		//User user = User.SessionUser2User(sessionUser);
		User user = getUser(sessionUser,tenant);
		entity.setUser(user);
		BackFillOrderVo bkVo = backFillService.updateCheckOutCache(user.getUserId(), terminal, tenant.getShopId(), lid, value, UpdateItemTypeEnum.getValue(virTualType));
//		BackFillOrderVo bkVo =  backFillService.getCheckOutCache(user.getUserId(), terminal, shopId, lid);
		if (bkVo != null) {
			entity.setHappyBeanNum(bkVo.getHappyBeanNum()==null?0:bkVo.getHappyBeanNum());
			entity.setCouponids(bkVo.getCouponids());
			entity.setCouponCode(bkVo.getCouponcode());
			entity.setInnerBuyMoney(bkVo.getInnerBuyMoney() == null ? 0 : Integer.parseInt(StringUtil.isEmpty(bkVo.getInnerBuyMoney())?"0":bkVo.getInnerBuyMoney()));
			entity.setConsigneeId(bkVo.getConsigneeId());
			entity.setBuyType(null == bkVo.getBuyType() ? 0 : bkVo.getBuyType());
			entity.setCreditInfo(bkVo.getCreditInfo());
		}else{
			//根据结算缓存找不到则返回错误
			FpsResult<CheckOutOrderVo> result = new FpsResult<>();
			result.setErrorInfo(ErrorEnumUtil.getErrorMessage(tenant,"ERROR_BACKFILL_GET_FALL"));
			return JsonUtil.toJson(result);
		}
		entity.setTerminal(terminal);
		entity.setIp(IpUtil.getIp(request));
		String creditInfo = bkVo.getCreditInfo();
		//entity.setCreditInfo(creditInfo);//facode|100@facode|200
		//提交信用额度，不要注！代码报错请删除本地包，重新拉包
		if(ShopIdEnum.isHuiShang(tenant.getShopId()) && creditInfo != null && creditInfo.length()>0) {
			List<Pair<String, Money>> buyerCredits = new ArrayList<>();
			String[] faList = creditInfo.split("@");
			if (faList.length > 0) {
				for (String faSingle : faList) {
					String[] fa = faSingle.split("\\|");
					Pair<String, Money> pair = new Pair<>(fa[0], new Money(fa[1], tenant.getCurrencyCode()));
					buyerCredits.add(pair);
				}
			}
			entity.setBuyerCredits(buyerCredits);
			//entity.setCreditInfo(JsonUtil.toJson(buyerCredits));
		}
		RemoteResult<CheckOutResult> json  = remoteOrderService.checkout(tenant,entity);
		String resultMsg = json.getResultMsg();
		log.info("coupon msg:{}",resultMsg);
		log.info("checkout return:{}", JsonUtil.toJson(json));
		FpsResult<CheckOutResult> apiResult = new FpsResult(json,PromptEnum.CHECKOUT);
		if(ErrorMessageEnum.SUCCESS.getCode()==apiResult.getRc()){
			CheckOutOrderVo checkOutOrderVo = new CheckOutOrderVo(apiResult.getData(),bkVo);
			RemoteResult<CheckOutOrderVo> result = new RemoteResult<>();
			result.setResultCode(json.getResultCode());
			result.setResultMsg(json.getResultMsg());
			result.setT(checkOutOrderVo);
			result.setSuccess(true);
			log.info("checkoutordervo :{}",JsonUtil.toJson(result));
			FpsResult<CheckOutOrderVo> temp = new FpsResult<>(result,PromptEnum.CHECKOUT);
			return JsonUtil.toJson(temp);
		}else {
			//删除使用失败的虚拟货币
			backFillService.updateCheckOutCache(user.getUserId(),terminal,tenant.getShopId(),lid,"", UpdateItemTypeEnum.getValue(virTualType));
			return JsonUtil.toJson(apiResult);
		}
	}



	/**
	 * 
	 * @Title: getCpsObject
	 * @Description: 获取cps 参数
	 * @param request
	 * @return 设定文件
	 */
	public CpsUse getCpsObject(HttpServletRequest request) {
		CpsUse cu = new CpsUse();
		try {
			Cookie[] cookies = request.getCookies();
			if (cookies.length > 0 && cookies != null) {
				log.info("cookies:" + JsonUtil.toJson(cookies));
				for (Cookie c : cookies) {

					String name = c.getName();
					if ("wi".equals(name)) {
						cu.setWi(c.getValue() + "");
					}
					if ("cid".equals(name)) {
						cu.setCid(c.getValue() + "");
					}
					if ("target".equals(name)) {
						cu.setTarget(c.getValue() + "");
					}
					if ("channel".equals(name)) {
						cu.setChannel(c.getValue() + "");
					}
					if ("source".equals(name)) {
						cu.setSource(c.getValue() + "");
					}
				}
			}
		} catch (java.lang.Exception e) {
			log.error("错误信息" + e);
		}

		return cu;
	}

}
