package com.lenovo.m2.web.manager.purchase.order.impl;

import com.lenovo.m2.web.common.purchase.util.JsonUtil;
import com.lenovo.m2.web.common.purchase.util.StringUtil;
import com.lenovo.m2.web.domain.purchase.order.backfill.BackFillOrderVo;
import com.lenovo.m2.web.domain.purchase.order.backfill.UpdateItemTypeEnum;
import com.lenovo.m2.web.manager.purchase.order.BackFillService;
import com.lenovo.m2.web.redis.MyRedisConn;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

//import com.lenovo.m2.buy.purchase.manager.order.factory.OrderServiceFactory;

/**
 * @author zhanghs
 * @version V1.0
 * @Title: ${file_name}
 * @Description: 订单回填和去参数化业务对象
 * @date 2016年2月17日 下午4:56:20
 */
@Service("backFillService")
public class BackFillServiceImpl implements BackFillService {
	private static Logger logger =  LogManager.getLogger(BackFillServiceImpl.class.getName());

    @Autowired
    protected MyRedisConn redisConn;

//    @Autowired
//    private CouponService couponService;
//    @Autowired
//    private OrderServiceFactory orderServiceFactory;
    @Override
    public BackFillOrderVo initCheckOutCache(String lenovoId, int terminal, int shopId,String lid, BackFillOrderVo backFillOrderVo) {
        String key = this.getKey(lenovoId,terminal,shopId,lid);
        String backFillStr = redisConn.get(key);
        logger.info("key查询计算缓存的KEY："+key+"-------返回结果："+backFillStr);
        if (StringUtil.isEmpty(backFillStr)) {
            backFillStr = JsonUtil.toJson(backFillOrderVo);
            redisConn.setex(key, 60 * 60 * 24, backFillStr);//默认有效时长为1天
            return backFillOrderVo;
        }else {
            logger.info("<======initCheckOutCache,backFillOrderVo:{}============>",JsonUtil.toJson(backFillOrderVo));
            BackFillOrderVo saveBackFillOrder = JsonUtil.fromJson(backFillStr,BackFillOrderVo.class);
//            saveBackFillOrder.setItemids(backFillOrderVo.getItemids());
            saveBackFillOrder.setSharecode(backFillOrderVo.getSharecode());
            backFillStr = JsonUtil.toJson(saveBackFillOrder);
            logger.info("<======initCheckOutCache,sharecode:{},backFillStr:{}============>",backFillOrderVo.getSharecode(),backFillStr);
            redisConn.setex(key, 60 * 60 * 24 , backFillStr);//默认有效时长为30天
            return saveBackFillOrder;
        }
    }

//    @Override
//    public BackFillOrderVo initCheckOutCache(String lenovoId, int terminal, int shopId, TempOrder tempOrder) {
//        try{
//            BackFillOrderVo backFillOrderVo = new BackFillOrderVo();
//            backFillOrderVo.setSharecode(tempOrder.getSharecode());
////            backFillOrderVo.setItemids(tempOrder.getItemids());
//            backFillOrderVo.setInvoice(JsonUtil.toJson(tempOrder.getInvoice()));
//            backFillOrderVo.setPaytype(tempOrder.getPaytype());
//            backFillOrderVo.setDeliverid(tempOrder.getDeliverid());
//
//            String key = this.getKey(lenovoId,terminal,shopId);
//            String backFillStr = redisConn.get(key);
//            logger.info("key查询计算缓存的KEY：" + key + "-------返回结果：" + backFillStr);
//            if (StringUtil.isEmpty(backFillStr)) {//用户没有对应的结算缓存
//                backFillStr = JsonUtil.toJson(backFillOrderVo);
//                redisConn.setex(key,60*60*24*30,backFillStr);//默认有效时长为30天
//                return backFillOrderVo;
//            }else {
//
//                //用户已有对应的结算缓存
//                BackFillOrderVo saveBackFillOrder = JsonUtil.fromJson(backFillStr,BackFillOrderVo.class);
////                saveBackFillOrder.setItemids(backFillOrderVo.getItemids());
//                saveBackFillOrder.setSharecode(backFillOrderVo.getSharecode());
//                saveBackFillOrder.setDeliverid(tempOrder.getDeliverid());//地址在调用本方法之前已做过验证
//
//                //在此验证结算缓存中地址有效性
//               /* String deliverid = tempOrder.getDeliverid();
//                if(StringUtil.isEmpty(deliverid)){
//                        String deliverID = backFillOrderVo.getDeliverid();
//                        // 验证收货地址id
//                        Receiver receiver =  orderServiceFactory.getOrderService(terminal,tempOrder.getSalesType()+"").getReceiverByDeliverid(lenovoId, deliverID, terminal);
//                        if (receiver != null) {
//                            saveBackFillOrder.setDeliverid(deliverID);
//                        }
//                }else {
//                    saveBackFillOrder.setDeliverid(deliverid);
//                }*/
//
//                /*验证支付方式的有效性*/
//                String defaultPayType = tempOrder.getPaytype();
//                String chachePayType = saveBackFillOrder.getPaytype();
//                try{
//                    if(PayTypeEnum.PAY_ONLINE.getCode().equals(defaultPayType)){//只支持线上付款
//                        saveBackFillOrder.setPaytype(defaultPayType);
//                    }else{
//                        saveBackFillOrder.setPaytype(defaultPayType);//先设置支付方式为默认支付方式
//                        if(!StringUtil.isEmpty(chachePayType)) {
//                            if (PayTypeEnum.toMap().keySet().contains(chachePayType)) {
//                                saveBackFillOrder.setPaytype(chachePayType);
//                            }
//                        }
//                    }
//
//                }catch (Exception e ){
//                    logger.error("初始化结算缓存，支付方式出错", e);
//                    saveBackFillOrder.setPaytype(defaultPayType);
//                }
//
//                /*验证优惠券的有效性*/
//                try{
//                    String couponids = saveBackFillOrder.getCouponids();
//                    if(!StringUtil.isEmpty(couponids)){
//                        List<Map<String, Object>> couponlist = tempOrder.getCouponlist();
//                        if(couponlist!=null && couponlist.size()>0){
//                            String[] bfCouponIds = couponids.split(",");
//                            String validCouponIds ="";
//                            for (String bfCouponId: bfCouponIds){
//                                for (Map<String,Object> coupon:couponlist) {
//                                    String couponId = coupon.get("couponid")==null?"":(String)coupon.get("couponid");
//                                    if (couponId.equals(bfCouponId)){
//                                        validCouponIds+=("".equals(validCouponIds) ? "" : ",") +couponId;
//                                        break;
//                                    }
//                                }
//                            }
//                            saveBackFillOrder.setCouponids(validCouponIds);
//
//                        }else{
//                            saveBackFillOrder.setCouponids("");
//                        }
//                    }
//                }catch (Exception e){
//                    logger.error("初始化结算缓存，验证优惠券出错",e);
//                    saveBackFillOrder.setCouponids("");
//                }
//
//
//                /*验证优惠码的有效性*/
//                try{
//                    String couponCode = saveBackFillOrder.getCouponcode();
//                    if(!StringUtil.isEmpty(couponCode)){
//                        List<String> productCodes = tempOrder.getMasterSkus().getValue();
//                        Map couponMapCode =couponService.getCouponWithProducts(productCodes, couponCode, terminal);
//                        if (MapUtils.isEmpty(couponMapCode)) {//优惠码已经无效则删除优惠码
//                            saveBackFillOrder.setCouponcode("");
//                        }
//                    }
//                }catch (Exception e ){
//                    logger.error("初始化结算缓存，验证优惠码出错",e);
//                    saveBackFillOrder.setCouponcode("");
//                }
//
//                /*验证内购额度有效性*/
//                String innerMoney = saveBackFillOrder.getInnerBuyMoney();
//                if(!StringUtil.isEmpty(innerMoney)){
//                    String innerBuySum = tempOrder.getInnerbuySum();//商品总内购额度
//                    String totalInner = tempOrder.getUserCanuseInnerBuy();//用户可以内购额度
//                    try{
//                        if (Double.parseDouble(innerBuySum)-Double.parseDouble(innerMoney)<0 || Double.parseDouble(totalInner)-Double.parseDouble(innerMoney)<0){
//                            saveBackFillOrder.setInnerBuyMoney("");
//                        }
//                    }catch (Exception e ){
//                        logger.error("初始化结算缓存，验证内购额度出错",e);
//                        saveBackFillOrder.setInnerBuyMoney("");
//                    }
//                }
//
//
//                backFillStr = JsonUtil.toJson(saveBackFillOrder);
//                redisConn.setex(key, 60 * 60 * 24 * 30, backFillStr);//默认有效时长为30天
//                return saveBackFillOrder;
//            }
//
//        }catch(Exception e){
//            logger.error("初始化结算缓存失败",e);
//            return null;
//        }
//
//    }

    @Override
    public BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId,String lid, String content, UpdateItemTypeEnum updateItemTypeEnum) {
        String key = this.getKey(lenovoId,terminal,shopId,lid);
        String backFillStr = redisConn.get(key);
        logger.info("key查询计算缓存的KEY："+key+"-------返回结果："+backFillStr);
        if (StringUtil.isEmpty(backFillStr)) {
            //logger.error("根据key值："+key+" 获取不到对应的值结算缓存更新失败");
            //return null;
        	backFillStr = "{}";
        }
        try{
                BackFillOrderVo saveBackFill = JsonUtil.fromJson(backFillStr,BackFillOrderVo.class);
                switch (updateItemTypeEnum){
                    case DELIVER:
                        saveBackFill.setConsigneeId(content);
                        break;
                    case INVOICE:
                        saveBackFill.setInvoice(content);
                        break;
                    case PAYTYPE:
                        saveBackFill.setPaytype(content);
                        break;
//                    case CMANNAGER_CODE:
//                        saveBackFill.setCmanagercode(content);
//                        break;
//                    case ORDER_REMARK:
//                        saveBackFill.setOrderremark(content);
//                        break;
                    case COUPONIDS:
                        saveBackFill.setCouponids(content);
                        break;
                    case COUPONCODE:
                        saveBackFill.setCouponcode(content);
                        break;
                    case GIFTCARES:
                        saveBackFill.setGiftCards(content);
                        break;
                    case INNERBUYMONEY:
                        saveBackFill.setInnerBuyMoney(content);
                        break;
                    case HAPPYBEAN:
                        saveBackFill.setHappyBeanNum(Integer.parseInt(StringUtil.isEmpty(content) ? "0" : content));
                        break;
                    case SN:
                        saveBackFill.setServicesn(content);
                        break;
                    case IDENTITY_ID:
                        saveBackFill.setIdentityId(Long.parseLong(StringUtil.isEmpty(content) ? "-1" : content));
                        break;
                    case CHECKOUTTYPE:
                        saveBackFill.setCheckOutType(content);
                        break;
                    case DATARECOVERY:
                        // 2016/6/6 数据恢复险
                        saveBackFill.setDatarecovery(content);
                        break;
                    case INVOICEADDRESS:
                        // 2016/07/04 收票地址
                        saveBackFill.setInvoiceAddressId(content);
                        break;
                    case INVOICEISCONSIGNEE:
                        // 2016/07/18 收票地址是否同收货地址
                        saveBackFill.setInvoiceIsConsigneeId(content);
                        break;
                    case CONTRACTADDRESS:
                        // 2016/07/18 合同地址
                        saveBackFill.setContractAddressId(content);
                        break;
                    case CONTRACTISCONSIGNEE:
                        // 2016/07/18 合同地址是否同收货地址
                        saveBackFill.setContractIsConsigneeId(content);
                        break;
                    case ISSENDCONTRACT:
                        // 2016/07/20 是否寄送合同地址
                        saveBackFill.setIsSendContract(content);
                        break;
                    case PRESELLTEL:
                        saveBackFill.setPresellTel(content);
                        break;
                    case CREDITINFO:
                        saveBackFill.setCreditInfo(content);
                        break;
                    default:return null;
                }

                backFillStr = JsonUtil.toJson(saveBackFill);
                redisConn.setex(key,60*60*24,backFillStr);//默认有效时长为30天
                return saveBackFill;
            }catch (Exception e){
                logger.error("更新结算缓存"+updateItemTypeEnum.getDescr()+" 出错",e);
                return null;
            }
        }
    @Override
    public BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId,String lid, BackFillOrderVo backFillOrderVo,UpdateItemTypeEnum updateItemTypeEnum) {
        List<UpdateItemTypeEnum> updateItemTypeEnums = new ArrayList<>();
        updateItemTypeEnums.add(updateItemTypeEnum);
        return this.updateCheckOutCache(lenovoId,terminal,shopId,lid,backFillOrderVo,updateItemTypeEnums);
    }

    @Override
    public BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId,String lid, BackFillOrderVo backFillOrderVo, List<UpdateItemTypeEnum> updateItemTypeEnums) {
        String key = this.getKey(lenovoId,terminal,shopId,lid);
        String backFillStr = redisConn.get(key);
        logger.info("key查询计算缓存的KEY："+key+"-------返回结果："+backFillStr);
        if (StringUtil.isEmpty(backFillStr)) {
            logger.error("根据key值：" + key + " 获取不到对应的值结算缓存更新失败");
            return null;
        }else {
            try{
                BackFillOrderVo saveBackFill = JsonUtil.fromJson(backFillStr,BackFillOrderVo.class);
                for (UpdateItemTypeEnum updateItemTypeEnum:updateItemTypeEnums){
                    switch (updateItemTypeEnum){
                        case ALL:
                            saveBackFill=backFillOrderVo;
                            break;
                        case DELIVER:
                            saveBackFill.setConsigneeId(backFillOrderVo.getConsigneeId());
                            break;
                        case INVOICE:
                            saveBackFill.setInvoice(backFillOrderVo.getInvoice());
                            break;
                        case PAYTYPE:
                            saveBackFill.setPaytype(backFillOrderVo.getPaytype());
                            break;
//                        case CMANNAGER_CODE:
//                            saveBackFill.setCmanagercode(backFillOrderVo.getCmanagercode());
//                            break;
//                        case ORDER_REMARK:
//                            saveBackFill.setOrderremark(backFillOrderVo.getOrderremark());
//                            break;
                        case COUPONIDS:
                            saveBackFill.setCouponids(backFillOrderVo.getCouponids());
                            break;
                        case COUPONCODE:
                            saveBackFill.setCouponcode(backFillOrderVo.getCouponcode());
                            break;
                        case GIFTCARES:
                            saveBackFill.setGiftCards(backFillOrderVo.getGiftCards());
                            break;
                        case INNERBUYMONEY:
                            saveBackFill.setInnerBuyMoney(backFillOrderVo.getInnerBuyMoney());
                            break;
                        case HAPPYBEAN:
                            saveBackFill.setHappyBeanNum(backFillOrderVo.getHappyBeanNum());
                            break;
                        case SN:
                            saveBackFill.setServicesn(backFillOrderVo.getServicesn());
                            break;
                        case IDENTITY_ID:
                            saveBackFill.setIdentityId(backFillOrderVo.getIdentityId());
                            break;
                        case CHECKOUTTYPE:
                            saveBackFill.setCheckOutType(backFillOrderVo.getCheckOutType());
                            break;
                        case DATARECOVERY:
                            // 2016/6/6 数据恢复险
                            saveBackFill.setDatarecovery(backFillOrderVo.getDatarecovery());
                            break;
                        case INVOICEADDRESS:
                            // 2016/07/04 收票地址
                            saveBackFill.setInvoiceAddressId(backFillOrderVo.getInvoiceAddressId());
                            break;
                        case INVOICEISCONSIGNEE:
                            // 2016/07/18 收票地址是否同收货地址
                            saveBackFill.setInvoiceIsConsigneeId(backFillOrderVo.getInvoiceIsConsigneeId());
                            break;
                        case CONTRACTADDRESS:
                            // 2016/07/18 合同地址
                            saveBackFill.setContractAddressId(backFillOrderVo.getContractAddressId());
                            break;
                        case CONTRACTISCONSIGNEE:
                            // 2016/07/18 合同地址是否同收货地址
                            saveBackFill.setContractIsConsigneeId(backFillOrderVo.getContractIsConsigneeId());
                            break;
                        case ISSENDCONTRACT:
                            // 2016/07/20 是否寄送合同地址
                            saveBackFill.setIsSendContract(backFillOrderVo.getIsSendContract());
                            break;
                        default:return null;
                    }
                }

                backFillStr = JsonUtil.toJson(saveBackFill);
                redisConn.setex(key,60*60*24,backFillStr);//默认有效时长为30天
                return saveBackFill;
            }catch (Exception e){
                logger.error("更新结算缓存"+updateItemTypeEnums+" 出错",e);
                return null;
            }

        }
    }

    @Override
    public BackFillOrderVo updateCheckOutCache(String lenovoId, int terminal, int shopId,String lid, BackFillOrderVo backFillOrderVo) {
        return this.updateCheckOutCache(lenovoId,terminal,shopId,lid,backFillOrderVo,UpdateItemTypeEnum.ALL);
    }

//    @Override
//    public void showCheckOutCache(String lenovoId, int terminal, int shopId) {
//
//    }

    @Override
    public BackFillOrderVo getCheckOutCache(String lenovoId, int terminal, int shopId,String lid) {
        String key = this.getKey(lenovoId,terminal,shopId,lid);
        String backFillStr = redisConn.get(key);
        logger.info("key查询计算缓存的KEY：" + key + "-------返回结果：" + backFillStr);
        if (StringUtils.isNotEmpty(backFillStr)) {
            return JsonUtil.fromJson(backFillStr,BackFillOrderVo.class);
        }
        return null;
    }

    @Override
    public void clearCheckOutCache(String lenovoId, int terminal, int shopId,String lid) throws  Exception{
        String key = this.getKey(lenovoId,terminal,shopId,lid);
        logger.info("要清除的缓存的KEY：" + key );
        redisConn.del(key);
    }

    /**
     * 根据商户id,终端id，用户id获取结算缓存的key值
     * @param lenovoId
     * @param terminal
     * @param shopId
     * @return
     */
    private String getKey(String lenovoId, int terminal, int shopId,String lid){
        return PRE_BACKFILL_CACHE_KEY+"|"+shopId+"|"+terminal+"|"+lenovoId+"|"+lid;
    }

    public static void main(String[] args) {
        BackFillOrderVo b  = new BackFillOrderVo();
        b.setInnerBuyMoney("100");
        b.setHappyBeanNum(500);
        b.setCouponcode("sdfsfcd");
        b.setConsigneeId("1111111");
        b.setPaytype("0");
        b.setBuyType(0);
        System.out.print(JsonUtil.toJson(b));
    }

    /*
     * (non-Javadoc)
     * @see com.lenovo.m2.buy.purchase.manager.order.BackFillService#isRightLid(java.lang.String, int, int, java.lang.String)
     */
	@Override
	public boolean isRightLid(String lenovoId, int terminal, int shopId, String lid) {
		String key = this.getKey(lenovoId, terminal, shopId, lid);
		return redisConn.existsKey(key);
	}
}


