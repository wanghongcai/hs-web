package com.lenovo.m2.web.manager.couponV2.Impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.dubboModel.UserApi;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;
import com.lenovo.m2.web.manager.couponV2.SalescouponFrontService;
import com.lenovo.m2.web.remote.couponV2.SalescouponFrontRemote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/11.
 */
@Service("salescouponFrontService")
public class SalescouponFrontServiceImpl  implements SalescouponFrontService{
    @Override
    public RemoteResult<Boolean> bindCoupons(String shopId, Long couponId, String lenovoId, String memberCode) {
        return salescouponFrontRemote.bindCoupons(shopId,couponId, lenovoId, memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCouponsForOnce(String shopId, Long couponId, String lenovoId, String memberCode) {
        return salescouponFrontRemote.bindCouponsForOnce(shopId,couponId, lenovoId, memberCode);
    }

    @Autowired
    private SalescouponFrontRemote salescouponFrontRemote;

    @Override
    public RemoteResult<Boolean> addEppCoupon(int couponway, String lenovoid, String memberCode) {
        return salescouponFrontRemote.addEppCoupon(couponway, lenovoid, memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCoupons(Long couponId, String lenovoId, String memberCode) {
        return salescouponFrontRemote.bindCoupons(couponId, lenovoId, memberCode);
    }

    @Override
    public int bindAllMemberSalesCoupons(String lenovoid,  String memberCode, String groupcode, String shopid) {
        return salescouponFrontRemote.bindAllMemberSalesCoupons(lenovoid, memberCode, groupcode, shopid);
    }

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(String lenovoId, String shopid, String terminal,String status, PageQuery pageQuery) {
        return salescouponFrontRemote.getAppSaleCoupons(lenovoId, shopid, terminal, status, pageQuery);
    }

    @Override
    public RemoteResult getSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal) {
        return salescouponFrontRemote.getSalescouponsWithLenovoId(userApi, shopId, terminal);
    }

    @Override
    public RemoteResult getUserSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal) {
        return salescouponFrontRemote.getUserSalescouponsWithLenovoId(userApi,shopId,terminal);
    }

    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(String lenovoId, String shopid, String terminal, String status,String time, PageQuery pageQuery) {
        return salescouponFrontRemote.getMemberCouponrelsPage4UserCenter(lenovoId, shopid, terminal, status, time, pageQuery);
    }

    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery) {
        return salescouponFrontRemote.getMemberCouponrelsPage4WapUserCenter(lenovoId, shopid, terminal, status, pageQuery);
    }


    @Override
    public RemoteResult bindBatchCoupons(String couponIds, String lenovoId, String memberCode) {
        return salescouponFrontRemote.bindBatchCoupons(couponIds, lenovoId, memberCode);
    }

    @Override
    public RemoteResult getSalescouponsByClassification(PageQuery pageQuery,Map map) {
        return salescouponFrontRemote.getSalescouponsByClassification(pageQuery,map);
    }

    @Override
    public RemoteResult getSalescouponsBySalesCouponIds(Tenant tenant ,PageQuery pageQuery, Map map) {
        return salescouponFrontRemote.getSalescouponsBySalesCouponIds(tenant ,pageQuery,map);
    }

    @Override
    public RemoteResult getUserIshaveTheCoupon(Map map) {
        return salescouponFrontRemote.getUserIshaveTheCoupon(map);
    }

    @Override
    public RemoteResult getSalesCouponsNumbersForId(Map map) {
        return salescouponFrontRemote.getSalesCouponsNumbersForId(map);
    }

    @Override
    public RemoteResult getMemberCouponsStatus(Map map) {
        return salescouponFrontRemote.getMemberCouponsStatus(map);
    }

    @Override
    public RemoteResult queryCouponByUseScope(Tenant tenant, int useScope, Long salescouponId, String couponName) {
        return salescouponFrontRemote.getSalescouponsByUseScope(tenant, useScope, salescouponId, couponName);
    }

}
