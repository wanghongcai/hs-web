package com.lenovo.m2.web.manager.stock;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created by mayan3 on 2016/6/15.
 */
public interface SmsCodeService {

    public RemoteResult sendSmsCode(String mobile, String userAgent, String ip, String leId, String shopId);
}
